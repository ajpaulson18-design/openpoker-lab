"""Capture the independently checked division vectors from the frozen executable."""
from hashlib import file_digest
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'dydivision-src1'
STUDY=WORK/'dydivision-cohort1'
OUT=WORK/'dydivision-vectors1'
HEAD='e8a22cfb46d4c188a7468500f261e0c0e7a77d81'

def require(value,message):
    if not value: raise RuntimeError(message)

def digest(path):
    with path.open('rb') as stream: return file_digest(stream,'sha256').hexdigest()

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write('\n')

def main():
    OUT.mkdir(exist_ok=False)
    require(sys.dont_write_bytecode,'no bytecode required')
    frozen=json.loads((STUDY/'source.json').read_bytes())
    expected={name:item['raw_sha256'] for name,item in frozen['files'].items()}
    require(frozen['head']==HEAD and subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD,'source head differs')
    before={name:digest(SOURCE/name) for name in expected}
    require(before==expected,'raw source differs')
    save('source-before.json',before)
    build_path=WORK/'dydivision-controls-build1/dyadic-policy-division-controls/native-exact-build-manifest.json'
    build=json.loads(build_path.read_bytes())
    exe=Path(build['executable'])
    require(build['target']=='dyadic-policy-division-controls' and digest(exe)==build['executable_sha256'],'binary differs')
    for name,identity in build['source_sha256'].items():
        require(before[name]==identity,'native source differs')
        committed=subprocess.check_output(['git','show',HEAD+':'+name],cwd=SOURCE)
        actual=(SOURCE/name).read_bytes()
        require(actual==committed or actual.replace(b'\r\n',b'\n')==committed,'committed source differs')
    sys.path.insert(0,str(SOURCE))
    from tests.virtual_frozen_run_control import run_bounded_child
    observed=run_bounded_child([str(exe)],b'',OUT/'process',stdout_limit=131072)
    require(observed['actual_exit_observed'] and observed['returncode']==0 and not observed['failures'],'native controls failed')
    require((OUT/'process/stderr.bin').read_bytes()==b'','unexpected stderr')
    lines=(OUT/'process/stdout.bin').read_text(encoding='ascii').splitlines()
    require(len(lines)==97 and lines[-1]=='grid division controls passed','vector count differs')
    for line in lines[:-1]:
        tag,*values=line.split('\t')
        weight,total,quotient,remainder=map(int,values)
        require(tag=='vector' and 0<=weight<=total and 0<total and total.bit_length()<=704,'input bounds differ')
        require((quotient,remainder)==divmod(weight<<52,total),'Python divmod differs')
    closure={}
    for module in tuple(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(SOURCE):
                name=path.relative_to(SOURCE).as_posix()
                require(name in before and digest(path)==before[name],'import closure differs')
                closure[name]=before[name]
    after={name:digest(SOURCE/name) for name in expected}
    require(after==before and digest(exe)==build['executable_sha256'],'source or executable drift')
    save('source-after.json',after)
    result={'source_head':HEAD,'python_vectors':96,'cpp_differential_vectors':10000,
        'status':'independent_integer_vectors_pass','raw_source_stable':True,
        'build_manifest_sha256':digest(build_path),'executable_sha256':digest(exe),
        'operator_sha256':digest(Path(__file__)),'imported_source_closure':closure,
        'stdout_sha256':digest(OUT/'process/stdout.bin'),'training_invocations':0}
    save('result.json',result)
    print(json.dumps(result))

if __name__=='__main__':main()
