"""Package committed bounded State component controls; no whole-game training."""
from hashlib import file_digest
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
WORK=Path(__file__).resolve().parent
OUT=WORK/'dyl-source-controls2'
DEST=WORK/'dyadic-training-repo/benchmarks/results/native-dyadic-bounded-lifecycle-v1'
def identity(path):
    with path.open('rb') as f:return {'bytes':path.stat().st_size,'sha256':file_digest(f,'sha256').hexdigest()}
def main():
    result=json.loads((OUT/'completion.json').read_bytes())
    if not (result['raw_source_stable'] and result['tests_per_mode']==26 and result['skips']==0
            and result['whole_game_training_invocations']==0
            and all(x['actual_exit_observed'] and x['returncode']==0 and not x['failures'] for x in result['exits'].values())):
        raise ValueError('component acceptance incomplete')
    files={}
    for name in ('dyl-source-controls2','dyl-source-controls1','dyl-state-controls1'):
        directory=WORK/name
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():raise ValueError('linked component evidence')
            if path.is_file():files[name+'/'+path.relative_to(directory).as_posix()]=path
    for name in ('dyl-source-state-build2','dyl-source-trainer-build2','dyl-state-build1'):
        for basename in ('native-exact-build-manifest.json','build.log','build-failure.json'):
            path=WORK/name/basename
            if path.is_file():files[name+'/'+basename]=path
    for name in ('trusted-dyadic-lifecycle-controls-v1.py','trusted-dyadic-lifecycle-controls-v2.py',
                 'trusted-virtual-dyadic-training-launch-v17.py','dyl-source-controls1.log','dyl-source-controls2.log'):
        path=WORK/name
        if path.is_file():files['operators/'+name]=path
    files['operators/'+Path(__file__).name]=Path(__file__)
    inventory={name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive=DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as z:
        for name,path in files.items():z.write(path,name)
        z.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as z:
        if z.testzip():raise ValueError('component archive CRC differs')
        for name,record in inventory.items():
            with z.open(name) as f:
                if z.getinfo(name).file_size!=record['bytes'] or file_digest(f,'sha256').hexdigest()!=record['sha256']:
                    raise ValueError('component archive member differs')
    manifest={'status':'accepted_bounded_state_component_only','source_head':result['head'],
              'controls':result,'sweep_counts':[1,2,3,4,8],
              'failure_scenarios':['io-cap','flush-cap','missing-row','early-export','max-sweeps','second-export'],
              'scope':'synthetic State recurrence; no longer whole-game training or convergence result',
              'preserved_failures':['strict nodiscard test compilation','tiny fixture catalog admission','source-only cached bytecode pre-import rejection'],
              'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(json.dumps(manifest))
if __name__=='__main__':main()
