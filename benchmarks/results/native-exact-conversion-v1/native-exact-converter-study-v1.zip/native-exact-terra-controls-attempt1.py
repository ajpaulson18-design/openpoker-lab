import hashlib,json,math,random,struct,subprocess,sys
from fractions import Fraction
from pathlib import Path
repo=Path(__file__).with_name('native-exact-four-street-repo');build=Path(__file__).with_name('native-exact-converter-build');manifest=json.loads((build/'native-exact-build-manifest.json').read_text());exe=build/'native-exact-binary64-probe.exe'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('native/exact_binary64.hpp','native/exact_binary64_probe.cpp'):
 if manifest['source_sha256'][name]!=digest(repo/name):raise ValueError('candidate/build source differs '+name)
if manifest['executable_sha256']!=digest(exe):raise ValueError('binary hash differs')
rng=random.Random(328142);cases=[]
def put(n,d):
 if n.bit_length()<=65536 and d.bit_length()<=65536:cases.append((n,d))
# Adjacent float pairs, with exact midpoint and perturbations on each side.
def midpoint(a,b):
 x=(Fraction.from_float(a)+Fraction.from_float(b))/2
 return x
small=float.fromhex('0x1p-1022'); maxf=float.fromhex('0x1.fffffffffffffp+1023')
for x in (midpoint(math.nextafter(small,0),small), Fraction.from_float(maxf)+Fraction(2)**970):
 for offset in (-1,0,1):
  y=x+Fraction(offset,2**1200) if x < 1 else x+offset
  for sign in (-1,1):put(sign*y.numerator,y.denominator)
for i in range(900):
 e=rng.randint(-1022,1023);raw=(rng.getrandbits(52)|(1<<52));base=math.ldexp(raw,e-52)
 nextv=math.nextafter(base,math.inf)
 if not math.isfinite(nextv):continue
 mid=midpoint(base,nextv)
 for k in (-1,0,1):
  perturb=Fraction(1,2**min(5000,max(1200,mid.denominator.bit_length()+25)))
  y=mid+k*perturb
  for sign in (-1,1):put(sign*y.numerator,y.denominator)
for i in range(400):
 bits=rng.choice([1,53,1024,4096,16000,65535,65536]);shift=rng.randint(-1024,1024)
 n=(1<<(bits-1))|rng.getrandbits(min(bits-1,64));d=(1<<(bits-1))|rng.getrandbits(min(bits-1,64))
 if shift>=0:n<<=shift
 else:d<<=-shift
 put(n,d);put(-n,d)
def record(n,d):return ('-' if n<0 else '')+format(abs(n),'x')+' '+format(d,'x')
payload='OPENPOKER_EXACT_BINARY64_V1\n'+'\n'.join(record(n,d) for n,d in cases)+'\n'
r=subprocess.run([str(exe)],input=payload.encode('ascii'),capture_output=True,timeout=120)
if r.returncode!=0:raise RuntimeError((r.returncode,r.stderr[:1000],r.stdout[-1000:]))
lines=r.stdout.decode('ascii').splitlines();assert lines.pop(0)=='READY\tOPENPOKER_EXACT_BINARY64_V1';assert len(lines)==len(cases)
for i,((n,d),line) in enumerate(zip(cases,lines)):
 try:
  f=float(Fraction(n,d));expected='rounded_below_normal' if f==0. or abs(f)<small else None
 except OverflowError:expected='rounded_overflow';f=None
 fields=line.split('\t')
 if expected:
  if fields!=['ERR',expected]:raise AssertionError((i,expected,line,n.bit_length(),d.bit_length()))
 else:
  bits=struct.unpack('>Q',struct.pack('>d',f))[0]
  if fields[0]!='OK' or int(fields[1],16)!=bits:raise AssertionError((i,hex(bits),line,n.bit_length(),d.bit_length()))
  if not(0<int(fields[2])<=65536 and 0<int(fields[3])<=65589):raise AssertionError(('receipt',i,line))
print(json.dumps({'status':'passed','cases':len(cases),'seed':328142,'exe_sha256':digest(exe),'source_sha256':{x:digest(repo/x) for x in ('native/exact_binary64.hpp','native/exact_binary64_probe.cpp')},'scope':'independent Python Fraction rounding oracle; native converter only'}))
