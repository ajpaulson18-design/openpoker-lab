"""Authenticate frozen source and independently replay saved conversion streams."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'native-exact-four-street-repo'
STUDY = WORK / 'native-exact-converter-study-v1'
FROZEN = '015d20f5f37173333a0a4cdbe7954ecbd2588b5b'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n', encoding='utf-8', newline='\n')

def git(*args, input=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=input)

before = json.loads((STUDY / 'source-before.json').read_bytes())
need(before['commit'] == FROZEN and not before['status'], 'unclean frozen source')
need(git('rev-parse', 'HEAD').decode().strip() == FROZEN and not git('status', '--porcelain'), 'current source not clean frozen HEAD')
names = git('ls-files', '-z').decode().split('\0')[:-1]
need(set(names) == set(before['sha256']), 'tracked source closure changed')
raw_sources = {name: (ROOT / name).read_bytes() for name in names}
need({name: sha(raw) for name, raw in raw_sources.items()} == before['sha256'], 'raw source drift')
objects = git('ls-tree', '-rz', '--full-tree', FROZEN).split(b'\0')[:-1]
blobs = {}
for item in objects:
    metadata, name = item.split(b'\t', 1)
    mode, kind, oid = metadata.split()
    need(kind == b'blob', 'non-blob frozen closure')
    blobs[name.decode()] = oid.decode()
need(set(blobs) == set(names), 'committed closure mismatch')
stream = git('cat-file', '--batch', input=('\n'.join(blobs.values()) + '\n').encode())
position = 0
git_hashes = {}
for name, oid in blobs.items():
    end = stream.index(b'\n', position)
    head = stream[position:end].split()
    need(head[0].decode() == oid and head[1] == b'blob', 'invalid git blob response')
    size = int(head[2]); raw = stream[end + 1:end + 1 + size]
    need(len(raw) == size and stream[end + 1 + size:end + 2 + size] == b'\n', 'truncated git blob')
    need(raw.replace(b'\r\n', b'\n') == raw_sources[name].replace(b'\r\n', b'\n'), 'raw/git source mismatch: ' + name)
    git_hashes[name] = sha(raw)
    position = end + size + 2
need(position == len(stream), 'extra git batch bytes')
write(STUDY / 'source-authentication.json', {'commit': FROZEN, 'tracked_files': len(names),
    'raw_sha256': before['sha256'], 'git_blob_sha256': git_hashes,
    'scope': 'All committed tracked source authenticated against captured raw bytes before saved-only arithmetic. CRLF normalization used only for text equality; both raw and committed SHA256 maps retained.'})

independent = STUDY / 'independent'
receipt = json.loads((independent / 'receipt.json').read_bytes())
for name, expected in receipt['saved_sha256'].items():
    need(sha((independent / name).read_bytes()) == expected, 'saved review artifact drift')
build = json.loads((independent / 'build-manifest.json').read_bytes())
for name, expected in build['source_sha256'].items():
    need(before['sha256'][name] == expected, 'build source differs from captured source')
inputs = (independent / 'probe-input.txt').read_text(encoding='ascii').splitlines()
outputs = (independent / 'probe-stdout.txt').read_text(encoding='ascii').splitlines()
need(inputs.pop(0) == 'OPENPOKER_EXACT_BINARY64_V1' and outputs.pop(0) == 'READY\tOPENPOKER_EXACT_BINARY64_V1', 'wrong saved protocol')
need(len(inputs) == len(outputs) == 5966, 'saved case count mismatch')
need(json.loads((independent / 'probe-status.json').read_bytes()) == {'returncode': 0}, 'candidate process failed')
need((independent / 'probe-stderr.txt').read_bytes() == b'', 'unexpected candidate stderr')
accepted = rejected = 0
for index, (line, result) in enumerate(zip(inputs, outputs)):
    tokens = line.split()
    need(len(tokens) == 2 and all(len(token.lstrip('-')) <= 16384 for token in tokens), 'invalid saved integer record')
    numerator, denominator = (int(token, 16) for token in tokens)
    need(denominator > 0 and max(abs(numerator).bit_length(), denominator.bit_length()) <= 65536, 'saved input exceeds cap')
    try:
        value = float(Fraction(numerator, denominator))
        expected_error = 'rounded_below_normal' if numerator and (value == 0 or abs(value) < float.fromhex('0x1p-1022')) else None
    except OverflowError:
        expected_error = 'rounded_overflow'
    fields = result.split('\t')
    if expected_error:
        need(fields == ['ERR', expected_error], 'saved error mismatch at ' + str(index))
        rejected += 1
    else:
        need(math.isfinite(value), 'nonfinite accepted oracle')
        bits = struct.unpack('>Q', struct.pack('>d', value))[0]
        need(len(fields) == 5 and fields[0] == 'OK' and int(fields[1], 16) == bits, 'saved result mismatch at ' + str(index))
        need(0 < int(fields[2]) <= 65536 and 0 < int(fields[3]) <= 65589 and int(fields[4]) > 0, 'invalid saved receipt')
        accepted += 1
write(STUDY / 'saved-only-replay.json', {'source_commit': FROZEN, 'authenticated_files': len(names),
    'cases': len(inputs), 'accepted': accepted, 'rejected_as_required': rejected,
    'all_bits_and_errors_match': True, 'candidate_invocations': 0, 'production_imports': 0,
    'scope': 'Root independently replays saved raw conversion inputs/results with Fraction after complete raw/Git source authentication; no candidate or archived production execution.'})

for name in ('native-exact-terra-controls.py', 'native-exact-terra-controls-attempt1.py',
             'native-exact-terra-controls-attempt2.py', 'native-exact-terra-controls-attempt3.py',
             'native-exact-terra-controls-first.log', 'native-exact-terra-controls-smoke.log',
             'native-exact-terra-controls-smoke-v2.log', 'native-exact-whole-design-review.md'):
    (STUDY / name).write_bytes((WORK / name).read_bytes())
(STUDY / 'development-failure-summary.log').write_bytes((WORK / 'native-exact-converter-build/development-failures.log').read_bytes())
(STUDY / 'package-native-exact-converter.py').write_bytes(Path(__file__).read_bytes())
for path in (WORK / 'native-exact-terra-smoke-v1').iterdir():
    if path.is_file():
        folder = STUDY / 'reviewer-first-failure'; folder.mkdir(exist_ok=True)
        (folder / path.name).write_bytes(path.read_bytes())
for name in build['source_sha256']:
    target = STUDY / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw_sources[name])
after = {'commit': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain').decode().strip(),
    'sha256': {name: sha((ROOT / name).read_bytes()) for name in names}}
need(after == before, 'source drift after saved replay')
write(STUDY / 'source-after.json', after)
files = sorted(path for path in STUDY.rglob('*') if path.is_file() and
    ('build' not in path.relative_to(STUDY).parts or path.suffix in ('.log', '.json')))
write(STUDY / 'manifest.json', {'source_commit': FROZEN, 'sha256': {
    path.relative_to(STUDY).as_posix(): sha(path.read_bytes()) for path in files}})
archive = WORK / 'native-exact-converter-study-v1.zip'
need(not archive.exists(), 'archive already exists')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for path in [*files, STUDY / 'manifest.json']:
        packed.writestr(path.relative_to(STUDY).as_posix(), path.read_bytes())
print(json.dumps({'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()),
    'manifest_sha256': sha((STUDY / 'manifest.json').read_bytes()), 'entries': len(files) + 1,
    'cases': len(inputs), 'accepted': accepted, 'rejected': rejected, 'authenticated_files': len(names)}))
