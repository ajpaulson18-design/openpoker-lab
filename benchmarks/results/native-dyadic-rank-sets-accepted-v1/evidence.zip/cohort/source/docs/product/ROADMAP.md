# Roadmap and commercial direction

Status is separated from implementation in [current state](../engineering/CURRENT_STATE.md).
This is a priority map, not new approval to start features or a dated release promise.

| Workstream | Status and source | Next safe action |
| --- | --- | --- |
| Repository institutional memory | Confirmed owner mission | Keep evidence, onboarding and handoffs synchronized |
| Solver coverage and accuracy | Documented direction in [solver progress](../solver-progress.md), not a ranked current commitment | Continue only with explicit game scope, whole-call/resource evidence and independent policy/value validation before changing defaults |
| Bounded heads-up preflop | Implemented for finite trees and selected physical outcomes; optional training, diagnostics and admission paths are documented separately | Preserve exact conditioned probabilities, visible-information responses and each opt-in resource envelope; report misses rather than widening claims |
| Fixed-flop complete future deck | Implemented as a separate fixed-flop game with forced turn/river checkdown | Treat the known-value and measured fixtures as model-specific; do not infer later-street or full-deck preflop solving |
| Matrix-free river/turn and specialized river paths | Optional bounded library paths are implemented; existing defaults remain | Use their own contracts and source-frozen evidence; do not generalize one fixture's speed or accuracy |
| Beyond current bounded solver models | Full-board preflop supports restricted shove/fold and finite betting with forced later checkdown; full-deck future betting, multiway equilibrium, broader ranges and unrestricted no-limit are not certified | Establish tractable scope, independent validation and tooling/reuse audit before proposing implementation |
| Contextual coach | Confirmed owner direction; existing slices documented in [coach architecture](../ai-coach-architecture.md) | Improve scenario understanding through trusted evidence; identify unsupported difficulty assessments explicitly |
| Visual interface | Recorded approved baseline in [visual interface](../visual-interface.md) | Minor evidence-driven refinements; broader redesign requires owner direction |
| Range inference, history import, model calibration | README development direction; not completed | Define opportunity semantics and held-out evaluation before predictive claims |
| Commercial packaging and monetization | Owner commercial goal; specific choices unknown | Validate target users, willingness to pay and retention before committing pricing or distribution |

## Commercial strategy: established versus unknown

Established: commercial success in the product's niche matters; accessibility,
contextual education and opponent-aware transparent analysis are differentiation
directions. Reliability, honest scope and reproducibility are part of customer
value. The owner's personal-use benchmark guides quality.

Unknown: target paid segment, pricing, subscriptions versus purchase, hosting,
distribution, support costs, traction, retention, revenue forecasts and competitor
ranking. No market research or financial projections were performed in this
knowledge audit. [Research records](../solver-research.md) concern algorithm design
and provenance, not product-market fit. Do not convert them into market evidence.

The application currently binds to loopback. Public commercial hosting would need
a separately approved security and operational design, not simply a bind change.
Current MIT/public status is preserved; commercial intent alone does not approve
a license or visibility change. [License boundaries](../research/LICENSING.md).

## Full-board restricted preflop addition

The separate [preflop shove/fold API](../preflop-push-fold.md) adds full-deck final-board
chance to a bounded heads-up SB fold/shove and BB fold/call game, with at most
four compatible private pairs. Its prepared equity tables can be reused. This
does not expand the existing selected-outcome preflop API to a full-deck game,
or add limps, non-all-in raises, later-street betting or multiway equilibrium.
Read the dedicated specification for work admission and independent evidence.

## Exact preflop validation direction

Finite [full-board preflop betting](../preflop-full-checkdown.md) also supports
limps, finite non-all-in raises and all-ins under forced later checkdown. The
[weighted exact-witness project](../preflop-weighted-sequence.md) establishes a
model-specific equilibrium anchor with independent physical-count and response
checks. It does not expand full-deck future betting or current range caps.
