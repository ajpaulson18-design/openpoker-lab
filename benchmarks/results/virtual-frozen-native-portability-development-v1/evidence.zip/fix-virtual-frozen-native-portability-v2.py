from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET
repo=Path.cwd();out=repo.parent/'virtual-frozen-native-portability-v2';out.mkdir(exist_ok=False)
paths=sorted((repo/'native').glob('virtual_frozen*'))
for p in paths:(out/p.name).write_bytes(p.read_bytes())
p=repo/'native/virtual_frozen_walk.hpp';raw=p.read_bytes();old=b'if(actor==target){std::size_t r=row_begin;const auto p=prefix_index(node.state.street);';new=b'if(actor==target){std::size_t r=row_begin;(void)prefix_index(node.state.street);'
if raw.count(old)!=1 and raw.count(new)!=1:raise RuntimeError('expected validation call missing')
p.write_bytes(raw.replace(old,new))
formatter=r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\Llvm\bin\clang-format.exe'
records=[]
for p in paths:
    raw=p.read_bytes()
    result=subprocess.run([formatter,'-style={BasedOnStyle: LLVM, SortIncludes: Never, FixNamespaceComments: false}','--output-replacements-xml',str(p)],capture_output=True,check=True)
    (out/(p.name+'.replacements.xml')).write_bytes(result.stdout)
    repl=ET.fromstring(result.stdout).findall('replacement')
    for r in repl:
        at=int(r.attrib['offset']);length=int(r.attrib['length']);text=(r.text or '').encode()
        if b''.join(raw[at:at+length].split()) != b''.join(text.split()):raise RuntimeError('non-whitespace formatter edit: '+p.name)
    changed=raw
    for r in reversed(repl):
        at=int(r.attrib['offset']);length=int(r.attrib['length']);changed=changed[:at]+(r.text or '').encode()+changed[at+length:]
    p.write_bytes(changed)
    records.append({'file':p.name,'before_format_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(changed).hexdigest(),'whitespace_replacements':len(repl)})
(out/'receipt.json').write_text(json.dumps({'semantic_edit':'discard unused prefix-index result but retain validation call','formatting':records},indent=2)+'\n');print(json.dumps(records))

