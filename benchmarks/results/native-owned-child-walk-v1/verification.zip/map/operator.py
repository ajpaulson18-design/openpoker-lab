"""Recover map symbols without changing the frozen training executable."""
import hashlib,json,os,struct,subprocess
from pathlib import Path
WORK=Path(__file__).resolve().parent
BUILD=WORK/'dyprofile-standard-build2'
SOURCE=WORK/'dyprofile-src2'
OUT=WORK/'dywalk-symbol-map1'
HEAD='53a4072c3bd055e1fca9b787556da170af3c3c6d'
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def pe(path):
 raw=path.read_bytes()
 require(raw[:2]==b'MZ','DOS header')
 nt=struct.unpack_from('<I',raw,0x3c)[0]
 require(64<=nt<len(raw)-264 and raw[nt:nt+4]==b'PE\0\0','PE header')
 machine,count,timestamp,_,_,size,characteristics=struct.unpack_from('<HHIIIHH',raw,nt+4)
 op=nt+24
 require(machine==0x8664 and 1<=count<=32 and size>=240 and struct.unpack_from('<H',raw,op)[0]==0x20b,'AMD64 PE32+ required')
 imagebase=struct.unpack_from('<Q',raw,op+24)[0]
 dirs=[struct.unpack_from('<II',raw,op+112+8*i) for i in range(16)]
 sections=[]
 for i in range(count):
  p=op+size+40*i
  name=raw[p:p+8].rstrip(b'\0').decode('ascii')
  vs,rva,rs,rp=struct.unpack_from('<IIII',raw,p+8)
  flags=struct.unpack_from('<I',raw,p+36)[0]
  require(rp+rs<=len(raw) and vs<=16<<20,'section bound')
  # Include file padding and zero-filled mapped tail as separate properties.
  content=raw[rp:rp+rs]
  sections.append({'name':name,'rva':rva,'virtual_size':vs,'raw_size':rs,'flags':flags,
    'raw_sha256':hashlib.sha256(content).hexdigest(),'raw':content})
 return {'imagebase':imagebase,'entry_rva':struct.unpack_from('<I',raw,op+16)[0],
   'image_size':struct.unpack_from('<I',raw,op+56)[0],'timestamp':timestamp,
   'file_characteristics':characteristics,'dll_characteristics':struct.unpack_from('<H',raw,op+70)[0],
   'directories':dirs,'sections':sections}
def public(p):return {k:([{kk:vv for kk,vv in sec.items() if kk!='raw'} for sec in v] if k=='sections' else v) for k,v in p.items()}
def main():
 OUT.mkdir(exist_ok=False)
 build=json.loads((BUILD/'native-exact-build-manifest.json').read_bytes())
 exe=Path(build['executable']);obj=BUILD/'native-virtual-dyadic-training-probe.obj'
 require(sha(exe)==build['executable_sha256']=='080a92dd0557cafbda78074e27d193115491a96fdba4f1d29569aff0f7eae0b3','frozen executable differs')
 compiler=Path(build['compiler']);linker=compiler.parent/'link.exe'
 require(sha(compiler)==build['compiler_sha256'],'compiler identity differs')
 before={name:sha(SOURCE/name) for name in build['source_sha256']}
 require(before==build['source_sha256'],'native source closure differs')
 require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD,'frozen source head')
 for name in before:
  actual=(SOURCE/name).read_bytes();committed=subprocess.check_output(['git','show',HEAD+':'+name],cwd=SOURCE)
  require(actual==committed or actual.replace(b'\r\n',b'\n')==committed,'committed input differs')
 identities={'exe':sha(exe),'obj':sha(obj),'compiler':sha(compiler),'linker':sha(linker)}
 save('source-before.json',before);save('inputs-before.json',identities)
 target=OUT/'mapped-standard.exe';mapfile=OUT/'mapped-standard.map'
 command=[str(compiler),'/nologo',str(obj),'/Fe'+str(target),'/link','/MAP:'+str(mapfile),'/INCREMENTAL:NO','/VERBOSE:LIB']
 save('command.json',command)
 result=subprocess.run(command,cwd=OUT,capture_output=True,timeout=180)
 require(len(result.stdout)+len(result.stderr)<=8<<20,'link log bound')
 (OUT/'stdout.log').write_bytes(result.stdout);(OUT/'stderr.log').write_bytes(result.stderr)
 save('process.json',{'returncode':result.returncode,'actual_exit_observed':True})
 require(result.returncode==0 and target.is_file() and mapfile.is_file(),'map relink failed; preserve output')
 original,mapped=pe(exe),pe(target)
 left={p['name']:p for p in original['sections']};right={p['name']:p for p in mapped['sections']}
 differences=[]
 for name in sorted(set(left)|set(right)):
  a,b=left.get(name),right.get(name)
  if a is None or b is None:differences.append({'section':name,'inventory_differs':True});continue
  metadata={k:(a[k],b[k]) for k in ('rva','virtual_size','raw_size','flags') if a[k]!=b[k]}
  rawdiff=[i for i,(x,y) in enumerate(zip(a['raw'],b['raw'])) if x!=y]
  if metadata or rawdiff or len(a['raw'])!=len(b['raw']):
   differences.append({'section':name,'metadata_differences':metadata,'differing_bytes':len(rawdiff),
    'first_offsets':rawdiff[:128],'original_sha256':a['raw_sha256'],'mapped_sha256':b['raw_sha256']})
 header_fields=('imagebase','entry_rva','image_size','file_characteristics','dll_characteristics','directories')
 header_differences={k:(original[k],mapped[k]) for k in header_fields if original[k]!=mapped[k]}
 exact=not differences and not header_differences
 after={name:sha(SOURCE/name) for name in before}
 require(after==before and identities=={'exe':sha(exe),'obj':sha(obj),'compiler':sha(compiler),'linker':sha(linker)},'input drift')
 save('source-after.json',after);save('inputs-after.json',identities)
 report={'source_head':HEAD,'original_executable_sha256':sha(exe),'mapped_executable_sha256':sha(target),
  'map_sha256':sha(mapfile),'map_bytes':mapfile.stat().st_size,'operator_sha256':sha(Path(__file__)),
  'original':public(original),'mapped':public(mapped),'section_differences':differences,'header_differences':header_differences,
  'mapped_sections_and_layout_exact':exact,'symbol_transfer_admitted':exact,'input_stable':True,
  'object_provenance':'OBJ identity recorded at inspection, not attested in original build manifest',
  'limits':'No execution or sampling; public map labels cannot establish inline/source attribution; preserve aliases'}
 save('result.json',report)
 print(json.dumps({k:report[k] for k in ('mapped_sections_and_layout_exact','symbol_transfer_admitted','section_differences','header_differences')}))
if __name__=='__main__':main()
