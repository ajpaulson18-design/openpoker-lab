"""Observe unchanged N10 T2 with a bounded owned-child sampler; preserve all calls."""
from collections import Counter
import ctypes
import hashlib
import json
import ntpath
from pathlib import Path
import runpy
from statistics import median
import shutil
import subprocess
import sys

WORK=Path(__file__).resolve().parent
ROOT=WORK/'dywalk-repo'
ORACLE=WORK/'dyprofile-src2'
REF=WORK/'dyprofile-on-cohort2'
OUT=WORK/'dywalk-study3'
HEAD='6aa659831430120069f6cc0df4b5cfeefe77a4f7'
ORACLE_HEAD='53a4072c3bd055e1fca9b787556da170af3c3c6d'
PAIRS=8
HELPER=WORK/'dywalk-build7/owned-child-stack-sample/native-owned-child-stack-sample.exe'
NATIVE=WORK/'dyprofile-standard-build2/native-virtual-dyadic-training-probe.exe'
MAP=WORK/'dywalk-symbol-map1/mapped-standard.map'
MAPPED=WORK/'dywalk-symbol-map1/mapped-standard.exe'

def need(ok,message):
 if not ok:raise RuntimeError(message)
def read(path):return json.loads(path.read_bytes())
def save(path,value):
 with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def identity(path):return {'bytes':path.stat().st_size,'sha256':sha(path)}
def committed(root,head,closure):
 for name,digest in closure.items():
  raw=(root/name).read_bytes()
  need(hashlib.sha256(raw).hexdigest()==digest,'raw source differs')
  original=subprocess.check_output(['git','show',head+':'+name],cwd=root)
  need(raw==original or raw.replace(b'\r\n',b'\n')==original,'committed source differs')
def norm(value):return ntpath.normcase(ntpath.normpath(str(value)))
def main():
 OUT.mkdir(exist_ok=False)
 observations=[]
 try:
  need(sys.dont_write_bytecode,'source-only bytecode suppression required')
  need(shutil.disk_usage(OUT).free>4<<30,'diagnostic disk reserve')
  helpers=runpy.run_path(str(WORK/'trusted-virtual-dyadic-training-launch-v43.py'))
  snapshot=helpers['snapshot']
  need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD,'source HEAD differs')
  need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ORACLE).decode().strip()==ORACLE_HEAD,'oracle HEAD differs')
  before=snapshot(ROOT);oracle_before=snapshot(ORACLE)
  save(OUT/'source-before.json',before);save(OUT/'oracle-source-before.json',oracle_before)
  sys.path.insert(0,str(ROOT))
  from tests.test_native_exact_reach import authenticate
  from tests.virtual_frozen_run_control import run_bounded_dyadic_probe
  from scripts.verify_owned_child_stack_sample import load_report,verify_report
  from scripts.verify_native_public_map import bind_public_map,locate_public_function
  helper_identity=authenticate(HELPER,ROOT,'owned-child-stack-sample')
  native_identity=authenticate(NATIVE,ORACLE,'virtual-dyadic-training')
  committed(ROOT,HEAD,helper_identity[1]['source_sha256'])
  committed(ORACLE,ORACLE_HEAD,native_identity[1]['source_sha256'])
  correspondence=bind_public_map(NATIVE.read_bytes(),MAPPED.read_bytes(),MAP.read_bytes())
  need(correspondence['correspondence']['normalized_sha256']=='45c2cc1732b0bb5b0fdd80bea62c446fc32fb1570f0e9f3896cd5d14c6fbc782','public map correspondence differs')
  save(OUT/'public-map.json',correspondence)
  operator_hash=sha(Path(__file__))
  fixed={str(p):identity(p) for p in (HELPER,NATIVE,MAP,MAPPED)}
  config={'source_head':HEAD,'oracle_source_head':ORACLE_HEAD,'pairs_per_comparison':PAIRS,
   'comparisons':['instrumentation','wrapper'],'median_ratio_limit':1.01,
   'order':[['baseline','checked'] if k%2==0 else ['checked','baseline'] for k in range(PAIRS)],
   'interval_ms':20,'minimum_enabled_samples':50,'operator_sha256':operator_hash,'input_identities':fixed,
   'scope':'one Windows host, finite ten-card bounded-division T2; wall-time primary-thread stacks',
   'memory_scope':'bounded runner reports observer-process memory for wrapped calls, not owned-child memory',
   'attribution':'public RVA extents only; all partial/unknown samples and folded aliases retained',
   'quality_gate':None}
  save(OUT/'configuration.json',config)
  system_paths={norm(m['path']):Path(m['path']) for m in read(WORK/'dywalk-race-controls-normal-2/enabled-report.json')['modules']
    if norm(m['path'])!=norm(WORK/'dywalk-build7/owned-child-stack-sample-controls/native-owned-child-stack-sample-controls.exe')}
  system_before={key:identity(path) for key,path in system_paths.items()}
  save(OUT/'system-modules-before.json',system_before)
  reference=read(REF/'result.json')
  # Offline decorated-name rendering only. No symbol-server or process attachment.
  import os
  dbg=ctypes.WinDLL(str(Path(os.environ['SystemRoot'])/'System32/dbghelp.dll'))
  render=dbg.UnDecorateSymbolName
  render.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint32,ctypes.c_uint32]
  render.restype=ctypes.c_uint32
  groups={}
  for item in correspondence['proven_function_ranges']:
   aliases=[]
   for alias in item['aliases']:
    output=ctypes.create_string_buffer(65536)
    count=render(alias['name'].encode('ascii'),output,len(output),0x1000)
    aliases.append({'decorated':alias['name'],'name':output.value.decode('ascii') if count else alias['name'],
                    'object':alias['object']})
   groups[str(item['begin_rva'])]={'begin_rva':item['begin_rva'],'end_rva':item['end_rva'],'aliases':aliases}
  save(OUT/'function-groups.json',groups)
  def group_for(address,modules,is_return):
   query=address-1 if is_return and address else address
   matches=[m for m in modules if int(m['base'],16)<=query<int(m['base'],16)+m['size']]
   need(len(matches)<=1,'overlapping module mappings')
   if not matches:return 'unknown_module',None
   module=matches[0]
   if norm(module['path'])!=norm(NATIVE):return 'external_module:'+Path(module['path']).name,None
   rva=query-int(module['base'],16)
   item=locate_public_function(correspondence,rva)
   return ('main_unresolved_extent',None) if item is None else ('main',str(item['begin_rva']))
  def summarize(report):
   seeds=Counter();nearest=Counter();inclusive=Counter()
   for sample in report['samples']:
    addresses=[(int(sample['seed_rip'],16),False)]+[(int(f['pc'],16),True) for f in sample['frames']]
    found=[]
    for address,is_return in addresses:
     kind,key=group_for(address,report['modules'],is_return)
     found.append((kind,key))
    seeds[found[0][1] if found[0][1] is not None else found[0][0]]+=1
    project=[key for _,key in found if key is not None and
             any(a['name'].startswith('openpoker::') for a in groups[key]['aliases'])]
    nearest[project[0] if project else 'unresolved_project_context']+=1
    for key in set(project):inclusive[key]+=1
   return {'samples':len(report['samples']),'seed_groups':dict(seeds),
     'nearest_project_context':dict(nearest),'inclusive_project_context':dict(inclusive),
     'limits':'Counts per observed sample, not CPU percentages or exclusive source-owner costs'}
  def check_artifacts(target):
   for name,key in (('compact-wire.json','compact_encoding_receipt'),('factored-execution.json','factored_execution'),
                    ('equal-quantizer.json','equal_quantizer')):
    need(read(target/name)==reference[key],'execution receipt differs')
   for folder in ('page-images','page-images-rows'):
    expected={p.name for p in (REF/folder).iterdir()}
    need({p.name for p in (target/folder).iterdir()}==expected,'owner artifact inventory differs')
    for name in expected:
     need(identity(target/folder/name)==identity(REF/folder/name),'owner artifact bytes differ')
  results={}
  for comparison in ('instrumentation','wrapper'):
   folder=OUT/comparison;folder.mkdir()
   runs=[]
   for pair in range(PAIRS):
    for mode in (('baseline','checked') if pair%2==0 else ('checked','baseline')):
     target=folder/f'pair-{pair+1}-{mode}';target.mkdir()
     wrapped=comparison=='instrumentation' or mode=='checked'
     enabled=comparison=='instrumentation' and mode=='checked'
     if wrapped:
      symbols=target/'symbols-empty';symbols.mkdir()
      command=[str(HELPER),'--child',str(NATIVE),'--scratch',str(target/'page-images'),
               '--report',str(target/'observation.json'),'--symbols',str(symbols),'--interval-ms','20']
      if not enabled:command.append('--disabled')
     else:command=[str(NATIVE),str(target/'page-images')]
     save(target/'command.json',command)
     need(all(identity(Path(path))==meta for path,meta in fixed.items()),'binary/map drift before call')
     observed=run_bounded_dyadic_probe(command,'TRAIN_TEN_BOUNDED_DIVISION',target/'process')
     save(target/'observed.json',observed)
     need(observed['actual_exit_observed'] and observed['returncode']==0 and not observed['failures'] and observed['automatic_retries']==0,
          'native observation failed; preserve first attempt')
     capture=reference['compact_sweep_capture'];native=observed['streams'][0]
     need(native['sha256']==capture['retained_sha256'] and native['wire_sha256']==capture['wire_sha256'] and
          native['saved_bytes']==capture['contract']['retained_bytes'] and native['observed_bytes']==capture['contract']['wire_bytes'] and
          observed['sweep_capture']==capture,'whole native stream differs')
     need((target/'process/stderr.bin').read_bytes()==b'','native/wrapper stderr differs')
     check_artifacts(target)
     record={'comparison':comparison,'pair':pair+1,'mode':mode,'wrapped':wrapped,'enabled':enabled,
             'seconds':observed['duration_seconds'],'directory':target.relative_to(OUT).as_posix(),
             'retained_sha256':native['sha256'],'wire_sha256':native['wire_sha256']}
     if wrapped:
      report=load_report(target/'observation.json')
      summary=verify_report(report,str(NATIVE),'periodic_stack_observation' if enabled else 'disabled',0)
      save(target/'verified-observation.json',summary)
      record['observation_summary']=summary
      if enabled:
       need(summary['sample_count']>=50,'enabled sample coverage miss')
       need(all(norm(m['path']) in system_before or norm(m['path'])==norm(NATIVE)
                for m in report['modules'] if m['path']), 'observed module was not in pre-run identity census')
       record['public_context']=summarize(report)
       save(target/'public-context.json',record['public_context'])
     need(all(identity(Path(path))==meta for path,meta in fixed.items()),'binary/map drift after call')
     observations.append(record);runs.append(record)
     save(target/'verified.json',record)
     print(json.dumps({k:record[k] for k in ('comparison','pair','mode','seconds')}),flush=True)
   times={mode:[r['seconds'] for r in runs if r['mode']==mode] for mode in ('baseline','checked')}
   ratios=[next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='checked')/
           next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='baseline') for p in range(1,PAIRS+1)]
   results[comparison]={'pairs':PAIRS,'training_invocations':len(runs),'seconds':times,
     'median_seconds':{mode:median(values) for mode,values in times.items()},'paired_ratios':ratios,
     'median_paired_ratio':median(ratios),'overhead_acceptance':median(ratios)<=1.01,'observations':runs}
   print(json.dumps({'comparison':comparison,'median_paired_ratio':median(ratios)}),flush=True)
  enabled=[r for r in observations if r['enabled']]
  nearest=Counter();seeds=Counter();inclusive=Counter()
  for record in enabled:
   nearest.update(record['public_context']['nearest_project_context'])
   seeds.update(record['public_context']['seed_groups'])
   inclusive.update(record['public_context']['inclusive_project_context'])
  need(sha(Path(__file__))==operator_hash,'operator source drift')
  need(authenticate(HELPER,ROOT,'owned-child-stack-sample')==helper_identity and
       authenticate(NATIVE,ORACLE,'virtual-dyadic-training')==native_identity,'build identity drift')
  system_after={key:identity(path) for key,path in system_paths.items()}
  need(system_after==system_before,'system module file drift')
  save(OUT/'system-modules-after.json',system_after)
  imported={}
  for module in tuple(sys.modules.values()):
   filename=getattr(module,'__file__',None)
   if filename:
    path=Path(filename).resolve()
    if path.is_relative_to(ROOT):
     name=path.relative_to(ROOT).as_posix()
     need(before.get(name)==sha(path),'import source differs')
     imported[name]=before[name]
  after=snapshot(ROOT);oracle_after=snapshot(ORACLE)
  need(after==before and oracle_after==oracle_before,'source drift')
  save(OUT/'source-after.json',after);save(OUT/'oracle-source-after.json',oracle_after)
  result={'status':'owned_child_sampling_complete','source_head':HEAD,'oracle_source_head':ORACLE_HEAD,
    'training_invocations':len(observations),'comparisons':results,'source_stable':True,'oracle_source_stable':True,
    'all_streams_and_owner_artifacts_exact':True,'imported_source_closure':imported,
    'enabled_samples':sum(r['public_context']['samples'] for r in enabled),
    'exit_race_events':sum(r.get('observation_summary',{}).get('exit_race_event_count',0) for r in observations),
    'seed_groups':dict(seeds),'nearest_project_context':dict(nearest),'inclusive_project_context':dict(inclusive),
    'sampling_acceptance':all(r['overhead_acceptance'] for r in results.values()),
    'quality_gate':None,'saved_only_replay':'required separately','background_load':'uncontrolled'}
  save(OUT/'result.json',result)
  save(OUT/'terminal.json',{'status':'complete','training_invocations':len(observations)})
  print(json.dumps({k:result[k] for k in ('sampling_acceptance','enabled_samples','nearest_project_context')}),flush=True)
 except BaseException as error:
  save(OUT/'terminal.json',{'status':'failed','completed_calls':len(observations),
                           'first_error':type(error).__name__+': '+str(error)})
  raise
if __name__=='__main__':main()

