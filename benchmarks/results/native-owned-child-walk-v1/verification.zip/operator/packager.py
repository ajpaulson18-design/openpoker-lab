"""Package the stack observation study and preserve both interrupted attempts."""
from collections import Counter
from hashlib import file_digest, sha256
import json
from pathlib import Path
from statistics import median
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / "dywalk-repo"
OUT = ROOT / "benchmarks/results/native-owned-child-walk-v1"
STUDIES = [WORK / ("dywalk-study" + str(i)) for i in range(1,4)]
REPLAY = WORK / "dywalk-study3-replay1"
OBSERVERS = [WORK / ("observe-owned-child-walk" + str(i) + ".py") for i in range(1,4)]
BASELINE = ROOT / "benchmarks/results/native-dyadic-phase-profile-v1"
CONTROLS = [WORK / ("dywalk-race-controls-" + mode + "-2") for mode in ("normal","optimized")]
MAP = WORK / "dywalk-symbol-map1"
BUILD = WORK / "dywalk-build7"

def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

def save(path, record):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write("\n")

def terminal_counts(folder, study):
    counts = {}
    checked_samples = 0
    terminal_events = 0
    for name, comp in study["comparisons"].items():
        observations = comp["observations"]
        need(len(observations) == 16 and comp["pairs"] == 8, "comparison census differs")
        ordered = [(pair, mode) for pair in range(1,9)
                   for mode in (("baseline","checked") if pair%2 else ("checked","baseline"))]
        need([(r["pair"],r["mode"]) for r in observations] == ordered, "pair order differs")
        by_mode = {mode:[] for mode in ("baseline","checked")}
        for observation in observations:
            run = folder / observation["directory"]
            process = read(run / "process/process.json")
            need(process["actual_exit_observed"] and process["returncode"] == 0 and
                 not process["failures"] and process["automatic_retries"] == 0 and
                 process["duration_seconds"] == observation["seconds"], "observed call exit or timing differs")
            need(read(run/"verified.json") == observation and
                 digest(run/"process/stdout.bin") == observation["retained_sha256"], "observed output differs")
            if observation["wrapped"]:
                report = read(run/"observation.json")
                terminal_events += len(report["exit_race_events"])
                need(report["child_exit_code"] == report["cleanup_exit_code"] == 0, "child exits differ")
                if observation["enabled"]:
                    sample_count = len(report["samples"])
                    need(sample_count >= 50 and sample_count == observation["public_context"]["samples"],
                         "sample census differs")
                    need(sum(observation["public_context"]["nearest_project_context"].values()) == sample_count,
                         "attribution denominator differs")
                    checked_samples += sample_count
            by_mode[observation["mode"]].append(observation["seconds"])
        ratios = [a/b for a,b in zip(by_mode["checked"],by_mode["baseline"])]
        ratio = median(ratios)
        need(ratios == comp["paired_ratios"] and ratio == comp["median_paired_ratio"] and
             (ratio <= 1.01) is comp["overhead_acceptance"], "timing aggregate differs")
        counts[name] = {"median_paired_ratio":ratio,"accepted":ratio <= 1.01}
    need(checked_samples == study["enabled_samples"] and terminal_events == study["exit_race_events"],
         "sample or race total differs")
    return counts

def main():
    need(not OUT.exists(), "immutable packet already exists")
    study = read(STUDIES[2]/"result.json")
    need(read(STUDIES[2]/"terminal.json")=={"status":"complete","training_invocations":32}, "study incomplete")
    need(study["source_stable"] and study["oracle_source_stable"] and
         study["all_streams_and_owner_artifacts_exact"] and study["quality_gate"] is None, "scope or parity differs")
    source = read(STUDIES[2]/"source-before.json")
    for pre in ("","oracle-","system-modules-"):
        need(read(STUDIES[2]/(pre+"source-before.json" if pre!="system-modules-" else pre+"before.json")) ==
             read(STUDIES[2]/(pre+"source-after.json" if pre!="system-modules-" else pre+"after.json")),
             "source or system module drift")
    counts = terminal_counts(STUDIES[2],study)
    need(study["sampling_acceptance"] is all(d["accepted"] for d in counts.values()), "acceptance differs")
    replay = read(REPLAY/"result.json")
    need(replay["exit"]["returncode"] == replay["native_training_invocations"] ==
         replay["saved_only_replay"]["native_producer_calls"] == 0 and replay["raw_source_stable"],
         "saved-only replay failed")
    need(read(REPLAY/"source-before.json")==read(REPLAY/"source-after.json"), "replay source differs")
    prior = read(BASELINE/"manifest.json")
    need(digest(BASELINE/"verification.zip")==prior["archive"]["sha256"],"baseline archive differs")
    files = {}
    def add(name,path):
        need(name not in files and path.is_file(), "missing or duplicate member "+name)
        files[name]=path
    def collect(name,folder,include):
        need(folder.is_dir(), "missing artifact folder")
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                relative=path.relative_to(folder)
                if include(relative):
                    add(name+"/"+relative.as_posix(),path)

    first_failures=[]
    for i,(folder,operator) in enumerate(zip(STUDIES,OBSERVERS),1):
        config=read(folder/"configuration.json")
        need(digest(operator)==config["operator_sha256"],"operator identity differs")
        add("study"+str(i)+"/operator.py",operator)
        for identity,record in config["input_identities"].items():
            path=Path(identity)
            need(path.stat().st_size==record["bytes"] and digest(path)==record["sha256"],
                 "study input identity differs")
        terminal=read(folder/"terminal.json")
        if i<3:
            need(terminal["status"]=="failed" and terminal["completed_calls"]==2,"prior failure differs")
            fail=read(folder/"instrumentation/pair-2-checked/observation.json")
            need(fail["error"]=="SuspendThread_failed" and fail["cleanup_exit_code"]==0,
                 "prior failed capture differs")
            first_failures.append({"source_head":config["source_head"],"terminal":terminal,
                                   "capture_error":fail["error"],"cleanup_exit_code":fail["cleanup_exit_code"]})
        collect("study"+str(i),folder, lambda path:
                (path.suffix in (".json",".py",".cpp",".yml") and "failed-source" not in path.parts)
                or path.name in ("request.bin","stderr.bin")
                or i<3 and path.name=="stdout.bin"
                or i==3 and path.as_posix()=="instrumentation/pair-1-checked/process/stdout.bin")
        add("study"+str(i)+"/operator.log",WORK/("dywalk-study-operator"+str(i)+".log"))
    collect("replay",REPLAY,lambda p:p.name!="expanded.bin")
    add("replay/operator.py",WORK/"replay-owned-child-walk3.py")
    collect("map",MAP,lambda p:p.suffix in (".json",".map",".log"))
    add("map/operator.py",WORK/"recover-dywalk-symbol-map.py")
    add("map/original-image.bin",WORK/"dyprofile-standard-build2/native-virtual-dyadic-training-probe.exe")
    add("map/map-relinked-image.bin",MAP/"mapped-standard.exe")
    add("map/original-build.json",WORK/"dyprofile-standard-build2/native-exact-build-manifest.json")
    add("map/strict-relink.log",WORK/"dywalk-symbol-map-operator1.log")
    for mode, folder in zip(("normal","optimized"),CONTROLS):
        log=WORK/("dywalk-race-controls-"+mode+"-2.log")
        need("Ran 16 tests" in log.read_text() and "\nOK\n" in log.read_text(),"control census differs")
        add("controls/"+mode+"/operator.log",log)
        collect("controls/"+mode,folder,lambda p:p.suffix!=".exe")
        collect("controls/"+mode+"-process",Path(str(folder)+"-process"),lambda p:True)
    add("operator/packager.py",Path(__file__))
    native_sources=set()
    for target in ("owned-child-stack-sample","owned-child-stack-sample-controls"):
        manifest=BUILD/target/"native-exact-build-manifest.json"
        compiled=read(manifest)
        need(compiled["target"]==target and digest(Path(compiled["executable"]))==compiled["executable_sha256"],
             "build identity differs")
        need(all(source[name]==value for name,value in compiled["source_sha256"].items()),
             "build closure differs")
        native_sources.update(compiled["source_sha256"])
        add("build/"+target+".json",manifest)
    for name in ("dywalk-sampler-smoke1","dywalk-build3/owned-child-stack-sample-controls"):
        collect("preserved-build-failures/"+name.replace("/","_"),WORK/name,
                lambda p:p.name in ("build.log","build-failure.json"))
    add("preserved-test-failures/report-filename.log",WORK/"dywalk-expanded-controls-operator1.log")
    all_source=native_sources | set(study["imported_source_closure"])
    for name in sorted(all_source):
        path=ROOT/name
        raw=path.read_bytes()
        pinned=subprocess.check_output(["git","show",study["source_head"]+":"+name],cwd=ROOT)
        need(sha256(raw).hexdigest()==source[name] and (raw==pinned or raw.replace(b"\r\n",b"\n")==pinned),
             "introduced source bytes differ "+name)
        add("source/"+name,path)
    inventory={name:{"bytes":path.stat().st_size,"sha256":digest(path)} for name,path in sorted(files.items())}
    OUT.mkdir()
    archive = OUT/"verification.zip"
    with ZipFile(archive,"x",ZIP_DEFLATED) as z:
        for name,path in sorted(files.items()):
            z.write(path,name)
        z.writestr("inventory.json",json.dumps(inventory,indent=2,sort_keys=True))
    with ZipFile(archive) as z:
        need(z.testzip() is None,"invalid archive")
        for name,value in inventory.items():
            with z.open(name) as stream:
                need(z.getinfo(name).file_size==value["bytes"] and
                     file_digest(stream,"sha256").hexdigest()==value["sha256"],"archive member drift")
    result={"version":OUT.name,"source_head":study["source_head"],"training_invocations":32,
            "focused_tests_per_mode":16,"failed_studies":first_failures,"comparisons":counts,
            "sampling_acceptance":study["sampling_acceptance"],"observations":study["enabled_samples"],
            "exit_race_events":study["exit_race_events"],"nearest_project_context":study["nearest_project_context"],
            "seed_groups":study["seed_groups"],"inclusive_project_context":study["inclusive_project_context"],
            "quality_gate":None,"larger_game_admission":False,"saved_only_replay":replay["saved_only_replay"],
            "reference_archive_sha256":prior["archive"]["sha256"],"source_files":len(all_source),
            "limits":"Periodic main-thread wall-time observations. No exclusive owner or inline-function attribution. One Windows host.",
            "archive":{"path":"verification.zip","bytes":archive.stat().st_size,"sha256":digest(archive),
                       "members":len(inventory)+1}}
    save(OUT/"manifest.json",result)
    print(json.dumps(result["archive"]))

if __name__=="__main__":
    main()

