"""Independent rank-free indexed sparse Chance forecast; no native producer."""
import argparse, hashlib, json, subprocess, sys
from collections import Counter
from functools import lru_cache
from itertools import combinations
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('repo',type=Path)
p.add_argument('--expected-head',required=True)
args=p.parse_args()
repo=args.repo.resolve(strict=True)
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
if head!=args.expected_head: raise ValueError('source HEAD differs')
sys.path.insert(0,str(repo))
from tests.full_deck_public_chance_reference import PROOF9,proof_ranges
from tests.virtual_betting_template_reference import build_reference_template
from tests.virtual_frozen_update_reference import _template_case
T=build_reference_template(_template_case()); ranges=proof_ranges()
pairs=[frozenset(a+b) for a,_ in ranges[0] for b,_ in ranges[1] if set(a).isdisjoint(b)]
def words(bits): return max(1,(bits+63)//64)
def logceil(n): return (n-1).bit_length() if n else 0
def add(bits): return 2+3*words(bits)
def copy(bits): return 1+2*words(bits)
def mul(a,b):
    x,y=words(a),words(b)
    return 2+2*(x+y)+x*y
def uniform_exp(m):
    units=[(1<<52)//m+(a<(1<<52)%m) for a in range(m)]
    return 52-min((x&-x).bit_length()-1 for x in units)
@lru_cache(None)
def suffix(id):
    node=T.nodes[id]
    return (uniform_exp(len(node.edges)) if node.phase=='decision' else 0)+max((suffix(e.child) for e in node.edges),default=0)

def forecast(size,indexed):
    deck=tuple(sorted((*PROOF9,0))) if size==10 else tuple(sorted((*PROOF9,0,1)))
    if len(deck)!=size: raise ValueError('fixture deck size')
    live={0:{()}}
    populations={}
    for street in (0,3,4,5):
        if street:
            old=0 if street==3 else street-1
            candidates=(combinations(deck,3) if street==3 else
                        (board+(card,) for board in live[old] for card in deck if card not in board))
            live[street]={b for b in candidates if any(private.isdisjoint(b) for private in pairs)}
        populations[street]=Counter(tuple(sum(set(hand).isdisjoint(board) for hand,_ in side) for side in ranges)
                                    for board in live[street])
    planes={frozenset(board) for board in live[5]}
    n=len(planes)
    ranks=sum(set(hand).isdisjoint(board) for board in planes for side in ranges for hand,_ in side)
    costs=Counter(); queries=Counter(); literals=0
    def charge(showdown,street,target,exp,mult=1,group='terminal'):
        reach=exp+1
        for counts,pop in populations[street].items():
            own,opp=counts[target],counts[1-target]
            bucket=8+reach+logceil(opp); out=4+bucket
            units=pop*mult
            input_cost=12+6+street+2*(4+2*words(reach))+4
            dynamic=(12+opp*mul(4,reach)+own*opp*((16 if showdown else 8)+add(bucket))
                     +own*mul(4,bucket)+2*(copy(out)+2))
            costs['input']+=units*input_cost
            costs['contraction']+=units*dynamic
            queries[group]+=units
            if showdown:
                costs['lookup']+=units*((6+8*n.bit_length()) if indexed else 2*n)
                queries['showdown']+=units
    def visit(id,past,first):
        nonlocal literals
        literals+=1
        node=T.nodes[id];street=node.street
        if node.phase=='decision':
            actor=node.state.player
            past=list(past);first=list(first)
            past[actor]+=1;first[actor]+=uniform_exp(len(node.edges))
        elif node.phase=='reveal':
            for target in (0,1): charge(False,node.state.board_length,target,0,2,'marginal')
        else:
            showdown=node.phase=='showdown'
            for target in (0,1):
                query_street=5 if showdown else street
                charge(showdown,query_street,target,first[1-target],group='terminal_first')
                charge(showdown,query_street,target,52*past[1-target],group='terminal_second')
        for edge in node.edges: visit(edge.child,past,first)
    for target in (0,1): charge(False,0,target,0,2,'marginal')
    visit(T.root,(0,0),(0,0))
    if literals!=1105: raise ValueError('literal geometry differs')
    costs['setup']=65536
    costs['rank']=4096*ranks
    costs['sort']=512*n
    costs['fill_and_lru']=n*(64+4*n)
    if indexed:
        costs['index_setup']=4*n+16
        costs['index_updates']=n*(8*n+16*n.bit_length()+32)
    return {'deck':deck,'value_bits':644 if size==10 else 646,'prefix_populations':{str(k):{str(key):v for key,v in sorted(pop.items())} for k,pop in populations.items()},
            'prefix_counts':{str(k):len(v) for k,v in live.items()},'planes':n,'rank_calls':ranks,
            'queries':dict(queries),'costs':dict(costs),'chance_total':sum(costs.values())}

result={'scope':'Independent rank-free Chance work forecast only; no production builder, hand ranks, training or native calls.',
        'source_head':head,'fixtures':{}}
for size in (10,11):
    result['fixtures'][str(size)]={mode:forecast(size,mode=='indexed') for mode in ('linear','indexed')}
print(json.dumps(result,indent=2,sort_keys=True))
