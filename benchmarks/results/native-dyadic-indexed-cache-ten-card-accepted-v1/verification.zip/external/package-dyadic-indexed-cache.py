"""Preserve the source-frozen indexed-cache study and exact digest replay."""
import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import struct
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-phase-payload-repo'
RESULTS = REPO/'benchmarks/results'
COHORT = WORK/'dyidx-ten-cohort1'
OPERATOR = WORK/'dyidx-ten-launch1'
DEST = RESULTS/'native-dyadic-indexed-cache-ten-card-accepted-v1'
BASE = RESULTS/'native-dyadic-row-batched-ten-card-accepted-v1'
BASE_PUBLICATION = 'bc1819a2f298854ef8fd04e73352c114f2e5a33e'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def reconstructed_wire(numeric, images):
    digest = sha256()
    total = 0

    def consume(stream, size):
        nonlocal total
        remaining = size
        while remaining:
            block = stream.read(min(1<<20, remaining))
            require(block, 'wire reconstruction truncated')
            digest.update(block)
            remaining -= len(block)
        total += size

    with numeric.open('rb') as stream:
        consume(stream, 8+16*8+11*8+1105*96+119196*24)
        for sweep, image in enumerate(images, 1):
            consume(stream, 281066*8+4*12*8)
            header = struct.pack('<8sQQQ', b'OPLCPG01', sweep, sweep%2, image['bytes'])
            digest.update(header)
            total += len(header)
            with (COHORT/'page-images'/image['name']).open('rb') as checkpoint:
                consume(checkpoint, image['bytes'])
                require(not checkpoint.read(1), 'wire checkpoint trailing bytes')
        consume(stream, numeric.stat().st_size-stream.tell())
        require(not stream.read(1), 'wire numerical trailing bytes')
    return {'bytes': total, 'sha256': digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--head',required=True)
    parser.add_argument('--control-log',type=Path,action='append',required=True)
    args = parser.parse_args()
    run = read(COHORT/'result.json')
    outer = read(OPERATOR/'completion.json')
    require(run['head'] == outer['head'] == args.head and run['training_invocations']==1
            and outer['mode']=='train_ten_indexed_cache' and outer['raw_source_stable']
            and outer['actual_exit_observed'] and outer['returncode']==0 and not outer['failures']
            and read(COHORT/'terminal.json')['status']=='complete', 'source-frozen cohort incomplete')
    source = read(COHORT/'source.json')['files']
    hashes = {name: record['raw_sha256'] for name,record in source.items()}
    require(read(OPERATOR/'source-before.json') == read(OPERATOR/'source-after.json') == hashes,
            'source inventories differ')
    for path in (OPERATOR/'bootstrap.json', COHORT/'saved-review-bootstrap.json'):
        boot = read(path)
        require(all(hashes.get(name)==digest for name,digest in boot['compiled'].items())
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    build_path = COHORT/'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(identity(Path(build['executable']))['sha256']==build['executable_sha256']
            and all(hashes[name]==digest for name,digest in build['source_sha256'].items()), 'native build differs')
    build_hash = identity(build_path)['sha256']
    for label in ('admit_ten_indexed_cache','train_ten_indexed_cache','saved-review'):
        receipt = read(COHORT/label/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures']
                and receipt['automatic_retries']==0, 'child exit differs')
        if label!='saved-review':
            binary = read(COHORT/label/'binary-identity.json')
            require(binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                    and binary['build_manifest_sha256']==build_hash, 'observed native executable differs')
    trained = COHORT/'train_ten_indexed_cache'
    process = read(trained/'process.json')
    capture = run['sweep_capture']
    inputs = run['checkpoint_inputs']
    replay = run['saved_only_replay']
    require(identity(trained/'process.json')['sha256']==run['sweep_capture_process_sha256']
            and process['sweep_capture']==capture and identity(trained/'stdout.bin')==inputs['stream']
            and capture['retained_sha256']==inputs['stream']['sha256']==replay['saved_output_sha256']
            and replay['checkpoint_verification']=='independent_compact_digest'
            and replay['native_producer_calls']==0, 'digest replay binding differs')
    for item in (BASE/'manifest.json', BASE/'verification.zip'):
        require(identity(item)['sha256']==hashes[item.relative_to(REPO).as_posix()], 'baseline source differs')
    baseline = read(BASE/'manifest.json')
    prior = baseline['saved_only_replay']
    shared=('sweeps','profile_and_br','checkpoint_images','shape','combined_divisions',
            'changed_current_rows','quality_gate','planned_entries','planned_payload_bits',
            'parent_work_plan','parent_work_actual','state_payload_bits')
    require(baseline['status']=='accepted_ten_card_row_batched_training_and_replay' and
            baseline['source_head']=='7a85266f488ad66849cdc67c98aefd4006f7902b' and
            identity(BASE/'verification.zip')['sha256']==baseline['archive']['sha256'] and
            all(replay[key]==prior[key] for key in shared) and
            all(run[key]==baseline[key] for key in ('paging','policy_spill','row_directory','quantizer')) and
            inputs['sweep_images']==baseline['checkpoint_inputs']['sweep_images'],
            'indexed cache changed numerical output or another owner')
    for group in ('work_plan','work_actual'):
        require(all(replay[group][owner]==value for owner,value in prior[group].items() if owner!='chance'),
                'indexed cache changed work outside Chance')
    changing={'setup_work','cache_lookup_work','peak_live_entries'}
    chance=prior['chance_actual']
    observed=replay['chance_actual']
    require(all(observed[key]==value for key,value in chance.items() if key not in changing) and
            observed['setup_work']==chance['setup_work']+84 and
            chance['peak_live_entries']<=observed['peak_live_entries']<=chance['peak_live_entries']+66 and
            replay['work_actual']['chance']-prior['work_actual']['chance']==
                observed['cache_lookup_work']-chance['cache_lookup_work']+84,
            'indexed cache changed nonindex Chance work or its bounded metadata footprint')
    trace=run['rank_index_trace']
    index=run['rank_index']
    require(index==read(COHORT/'page-images/rank-index.json') and
            trace==read(COHORT/'rank-index-trace.json') and
            all(index[key]==trace[key] for key in index) and
            trace['native_calls']==trace['rank_calls']==0 and
            (trace['queries'],trace['searches'],trace['parent_cache_lookup_work'])==(412080,79560,4331258) and
            observed['cache_lookup_work']==trace['parent_cache_lookup_work'],
            'rank index differs from the independent full structural trace')
    projection_path=WORK/'dyadic-indexed-chance-source-closed-0122ce9.json'
    projection=read(projection_path)
    require(projection['source_head']==args.head and projection['raw_source_stable'] and
            projection['source_files']==len(source) and
            projection['native_producer_calls']==projection['hand_rank_calls']==0 and
            projection['source_inventory_sha256']==identity(COHORT/'source.json')['sha256'] and
            projection['external_script_sha256']==identity(WORK/'project-dyadic-indexed-chance-source-closed.py')['sha256'] and
            all(hashes[name]==digest for name,digest in projection['imported_source_sha256'].items()) and
            projection['fixtures']['10']['indexed']['chance_total']==run['admission']['component_work']['chance']==132742404 and
            projection['fixtures']['10']['linear']['chance_total']==baseline['admission']['component_work']['chance']==127793144 and
            projection['fixtures']['11']['indexed']['chance_total']==448157615 and
            projection['fixtures']['11']['linear']['chance_total']==526856639 and
            projection['fixtures']['11']['indexed']['value_bits']==646,
            'complete rank-free Chance forecast or source closure differs')
    with ZipFile(BASE/'verification.zip') as zipped:
        earlier=zipped.read('cohort/train_ten_row_batched/stdout.bin')
    saved=(trained/'stdout.bin').read_bytes()
    require(len(earlier)==len(saved)==9833076 and
            sha256(earlier).hexdigest()==prior['saved_output_sha256'] and
            earlier[:-520]==saved[:-520] and earlier[-520:-512]==saved[-520:-512]==b'OPLDTP02',
            'indexed cache changed exact bytes outside the receipt footer')
    compared={'baseline_native_observation':baseline['measured_comparison']['row_batched_native_observation'],
              'indexed_cache_native_observation':run['indexed_cache_comparison']['indexed_cache_native_observation'],
              'baseline_chance_work_plan':prior['work_plan']['chance'],
              'indexed_chance_work_plan':replay['work_plan']['chance'],
              'baseline_chance_work_actual':prior['work_actual']['chance'],
              'indexed_chance_work_actual':replay['work_actual']['chance']}
    images = inputs['sweep_images']
    require(reconstructed_wire(trained/'stdout.bin',images)==
            {'bytes': capture['contract']['wire_bytes'], 'sha256': capture['wire_sha256']},
            'independent full wire reconstruction differs')
    for image in images:
        require(identity(COHORT/'page-images'/image['name'])=={key:image[key] for key in ('bytes','sha256')},
                'retained final slot identity differs')
    files = {}
    for label, directory in (('cohort',COHORT),('operator',OPERATOR)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(), 'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label=='cohort' and (rel.parts[0]=='source' or
                    (rel.parts[0]=='build' and path.name!='native-exact-build-manifest.json') or
                    (rel.parts[0]=='page-images' and path.name in ('committed.bin','staged.bin'))):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    # Preserve the exact component-control source closure and indexed selector.
    control_build=WORK/'dyidx-chance-build3/native-exact-build-manifest.json'
    control=read(control_build)
    require(identity(Path(control['executable']))['sha256']==control['executable_sha256'],
            'prepared control executable changed')
    files['controls/prepared/native-exact-build-manifest.json']=control_build
    for name,digest in control['source_sha256'].items():
        path=REPO/name
        require(identity(path)['sha256']==digest,'prepared control source changed after execution')
        committed=subprocess.check_output(['git','show',args.head+':'+name],cwd=REPO)
        raw=path.read_bytes()
        require(raw==committed or path.suffix in ('.cpp','.hpp','.py','.md','.txt','.json') and raw.replace(b'\r\n',b'\n')==committed,
                'prepared control source differs from committed closure')
        files['controls/prepared/source/'+name]=path
    for mode in ('normal1','optimized1'):
        directory=WORK/('dyidx-chance-controls-'+mode)/'indexed-cache'
        receipt=read(directory/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures'],
                'indexed component control process failed')
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(),'linked indexed control artifact')
            if path.is_file():
                files['controls/prepared/'+mode+'/'+path.relative_to(directory).as_posix()]=path
    for path in (Path(__file__),WORK/'trusted-virtual-dyadic-training-launch-v25.py',
                 WORK/'project-dyadic-indexed-chance.py',
                 WORK/'project-dyadic-indexed-chance-source-closed.py',
                 WORK/'dyadic-indexed-chance-forecast-0122ce9.json',
                 WORK/'dyadic-indexed-chance-source-closed-0122ce9.json',
                 WORK/'dyadic-indexed-chance-source-closed-0122ce9.stderr.log',
                 *args.control_log):
        files[f'external/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes']
                        and file_digest(stream,'sha256').hexdigest()==expected['sha256'],'archive member differs')
    manifest = {'status':'accepted_ten_card_indexed_cache_training_and_replay','source_head':args.head,
                'baseline_publication':BASE_PUBLICATION,'operator':outer,
                'exact_numerical_parity_outside_receipt_footer':True,'independent_wire_reconstruction':True,
                'rank_free_chance_forecast':projection,
                'measured_comparison':compared,'packed_replay_images':baseline['packed_replay_images'],
                **{key:run[key] for key in ('admission','sweep_capture','sweep_capture_process_sha256','checkpoint_inputs',
                    'paging','row_directory','policy_spill','indexed_cache_comparison','rank_index','rank_index_trace',
                    'quantizer','saved_only_replay','training_invocations','quality_gate')},
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observation':compared,
                      'wire':capture['wire_sha256']},sort_keys=True))


if __name__=='__main__':
    main()
