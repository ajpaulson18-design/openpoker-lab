"""Rank-free full-image PROOF9 T4 projection. It does not admit or train."""
from hashlib import sha256
import json
from pathlib import Path

work = Path.cwd().parent
root = Path.cwd()
base_file = root/'benchmarks/results/native-dyadic-proof9-three-sweep-accepted-v1/manifest.json'
base_bytes = base_file.read_bytes()
base = json.loads(base_bytes)
old = base['admission']
assert base['status']=='accepted_proof9_three_sweep_checkpoint_digest_replay'
R,S = old['rows'],old['slots']
A,L = old['page_stage_split_words'],old['page_image_words']
G = L-A
T = 4
logical = (5*T+1)*S

def oracle(name, replacements):
    code = (root/f'tests/{name}.py').read_text(encoding='utf-8')
    for before,after in replacements:
        assert code.count(before)==1
        code=code.replace(before,after)
    local={}
    exec(compile(code,name,'exec'),local)
    return local

stage=oracle('virtual_dyadic_stage_schedule', (
    ('sweeps!=3 or ten_card','sweeps not in (3,4) or ten_card'),
    ('    if sweeps==3:\n        expected_calls = (348984, 5931, 1820190)',
     '    if sweeps in (3,4):\n        expected_calls = (116328*sweeps,1977*sweeps,606730*sweeps)'),
    ('        if sweeps==3:\n            expected_reads = (581640,3122992,174492,954766,548,2223164)',
     '        if sweeps in (3,4):\n            expected_reads = (581640,3122992,174492,954766,548,2223164) if sweeps==3 else actual_reads'),
))['stage_schedule'](virtual_zero=True,sweeps=T)
directory=oracle('virtual_dyadic_directory_trace',(
    ('((True, 2), (False, 3))','((True, 2), (False, 3), (False, 4))'),
))['directory_trace'](ten_card=False,sweeps=T)
assert logical==stage['logical_read_calls']+T*stage['per_sweep_stage_calls']
assert stage['written_words']==T*L
page_work=(16*logical+T*(5*A+6*G)+8*T*L+8*2*T*S+2*T*L+
           160*stage['batched_write_calls']+2*(4096+64+1))
dir_work=4*old['row_directory_entries']+16*R+16*directory['logical_reads']+4*directory['misses']*128
spill_work=T*(32*R+16*(S-R)+4*S)+64
p=old['parent_work']
def scale(n):
    quotient,remainder=divmod(n,3)
    assert remainder==0
    return quotient*T
parent=dict(p,visit=(8+12*T)*old['visits'],
    support=64*((T+1)*old['candidates']+T*old['hidden_completion_candidates_per_pass']),
    reach=scale(p['reach']),value_add=scale(p['value_add']),terminal_scale=scale(p['terminal_scale']),
    average=scale(p['average']),output=p['output']+(6*S+32*R),
    route=p['route']+(T-3)*16*R+scale(old['packed_regret_work'])-old['packed_regret_work']
          +page_work-old['paging_work']+dir_work-old['directory_work']+spill_work-old['policy_spill_work'])
assert parent['support']-p['support']==64*(old['candidates']+old['hidden_completion_candidates_per_pass'])
work_plan=dict(old['component_work'],
    chance=old['component_work']['chance']+45_397_807,
    history=old['component_work']['history']+40*old['actions']+72*old['reveals']+48*old['visits']+40*R,
    state=old['component_work']['state']+88*R+132*S+(16*S+8*R)*11,
    quantizer=old['component_work']['quantizer']+old['general_quantizer_work'],
    parent=sum(parent.values()))
assert work_plan['state']+work_plan['quantizer']<=500_000_000
copy_work=old['sweep_stream']['copy_work']//3*T
numerical=old['output_bytes']+8*S+4*12*8
result={'status':'rank_free_projection_only','baseline_manifest_sha256':sha256(base_bytes).hexdigest(),
        'hand_rank_calls':0,'native_producer_calls':0,'requested_sweeps':T,
        'retained_width_bits':old['value_bits'],'regret_bound_bits':(16*T*(580<<625)).bit_length(),
        'average_bound_bits':(T*(580<<625)).bit_length(),'owner_work':work_plan,'parent_work':parent,
        'total_numerical_work':sum(work_plan.values()),'copy_work':copy_work,
        'total_with_copy_work':sum(work_plan.values())+copy_work,
        'logical_pager_requests':logical,'pager':stage,'directory':directory,
        'retained_numerical_bytes':numerical,'raw_wire_bytes':numerical+T*(32+8*L),
        'legacy_pager_limits':{'logical_requests':1000000,'write_words':1820190},
        'caveat':'Exact fixed horizon and full staging projected. New named owner caps and compiled admission pending.'}
target=work/'dyadic-proof9-t4-projection1.json'
with target.open('x',encoding='utf-8') as out:
    json.dump(result,out,indent=2,sort_keys=True)
    out.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('pager','directory','parent_work')},sort_keys=True))
print(json.dumps({'pager_read_words':stage['physical_read_words'],'pager_read_misses':stage['cache_misses'],
    'pager_writes':stage['batched_write_calls'],'directory_misses':directory['misses'],
    'directory_read_bytes':directory['read_bytes']},sort_keys=True))