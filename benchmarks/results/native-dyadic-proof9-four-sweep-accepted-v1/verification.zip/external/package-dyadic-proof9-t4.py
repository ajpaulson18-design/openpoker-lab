"""Bind the PROOF9 T4 saved stream and independently rebuild the transient wire."""
import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-training-repo'
SPLIT = REPO/'benchmarks/results/native-dyadic-split-checkpoint-accepted-v1'
BASE = SPLIT.parent/'native-dyadic-proof9-three-sweep-accepted-v1'
DEST = SPLIT.parent/'native-dyadic-proof9-four-sweep-accepted-v1'
EARLY = ('cohort/page-images/staged.bin', 'cohort/page-images/committed.bin')


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def reconstruct(numerical, frames, split_path, baseline_path, pages):
    digest = sha256()
    with numerical.open('rb') as stream, ZipFile(split_path) as split, ZipFile(baseline_path) as baseline:
        digest.update(stream.read(8+16*8+11*8+1105*96+24420*24))
        for sweep, frame in enumerate(frames, 1):
            digest.update(stream.read(58164*8+4*12*8))
            if sweep<=2:
                body = split.read(EARLY[sweep-1])
            else:
                body = (pages/('staged.bin' if sweep==3 else 'committed.bin')).read_bytes()
                if sweep==3:
                    require(baseline.read(EARLY[0])==body, 'third archived image differs')
            require(frame=={'sweep':sweep,'slot':sweep%2,'bytes':len(body),
                            'sha256':sha256(body).hexdigest()}, 'image epoch differs')
            digest.update(struct.pack('<8sQQQ',b'OPLCPG01',sweep,sweep%2,len(body)))
            digest.update(body)
        digest.update(stream.read())
    return digest.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--head', required=True)
    p.add_argument('--cohort', type=Path, required=True)
    p.add_argument('--operator', type=Path, required=True)
    p.add_argument('--recovery', type=Path, required=True)
    p.add_argument('--control-log', type=Path, action='append', required=True)
    args = p.parse_args()
    cohort, operator, recovery = args.cohort, args.operator, args.recovery
    run, outer = read(recovery/'completion.json'), read(operator/'operator-launch.json')
    require(run['head']==outer['head']==args.head and outer['mode']=='train_proof9_t4'
            and run['raw_source_revalidated'] and run['training_invocations']==1
            and run['native_producer_calls_during_recovery']==0
            and run['original_terminal']==read(cohort/'terminal.json')
            and run['original_terminal']['status']=='failed'
            and run['original_exit']==read(operator/'exit.json')==
                {'actual_exit_observed':True,'returncode':1,'failures':[]}
            and run['replay_exit']==read(recovery/'saved-review/exit.json')==
                {'actual_exit_observed':True,'returncode':0,'failures':[]},
            'source-frozen producer or recovery receipt differs')
    hashes = {name: item['raw_sha256'] for name,item in read(cohort/'source.json')['files'].items()}
    require(read(operator/'source-before.json')==hashes,
            'source inventories differ')
    fixed=read(recovery/'source-before.json')
    require(fixed==read(recovery/'source-after.json') and fixed.keys()==hashes.keys()
            and {name for name in hashes if hashes[name]!=fixed[name]}==
                {'scripts/verify_virtual_dyadic_training.py','tests/test_virtual_dyadic_checkpoint_digests.py'}
            and all(identity(Path(name))==item for name,item in read(recovery/'inputs.json').items()),
            'recovery source or original input identity differs')
    for path,inventory in ((operator/'bootstrap.json',hashes),
            (cohort/'saved-review-bootstrap.json',hashes),(recovery/'saved-review/bootstrap.json',fixed)):
        boot = read(path)
        require(all(inventory.get(name)==digest for name,digest in boot['compiled'].items())
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    build_path = cohort/'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(identity(Path(build['executable']))['sha256']==build['executable_sha256']
            and all(hashes[name]==digest for name,digest in build['source_sha256'].items()), 'native build differs')
    build_hash = identity(build_path)['sha256']
    for label in ('admit_proof9_t4','train_proof9_t4'):
        binary = read(cohort/label/'binary-identity.json')
        require(binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                and binary['build_manifest_sha256']==build_hash, 'observed native binary differs')
    for label in ('admit_proof9_t4','train_proof9_t4'):
        receipt = read(cohort/label/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures']
                and receipt['automatic_retries']==0, 'process exit differs')

    trained = cohort/'train_proof9_t4'
    capture, inputs, replay = (run[key] for key in ('sweep_capture','checkpoint_inputs','saved_only_replay'))
    numerical = trained/'stdout.bin'
    frames = capture['frames']
    require(identity(trained/'process.json')['sha256']==run['sweep_capture_process_sha256']
            and read(trained/'process.json')['sweep_capture']==capture and identity(numerical)==inputs['stream']
            and capture['retained_sha256']==inputs['stream']['sha256']==replay['saved_output_sha256']
            and replay['status']=='saved_four_sweep_exact_replay_pass'
            and replay['checkpoint_verification']=='independent_compact_digest'
            and frames==inputs['sweep_epochs']==replay['checkpoint_epochs'] and len(frames)==4
            and inputs['sweep_images']==replay['checkpoint_images']
            and replay['native_producer_calls']==0
            and replay==read(recovery/'saved-review/stdout.log'), 'digest replay binding differs')
    split_path = SPLIT/'evidence.zip'
    baseline_path = BASE/'verification.zip'
    for item in (BASE/'manifest.json',baseline_path,SPLIT/'manifest.json',split_path):
        require(identity(item)['sha256']==hashes[item.relative_to(REPO).as_posix()], 'baseline source differs')
    baseline = read(BASE/'manifest.json')
    split_manifest = read(SPLIT/'manifest.json')
    require(baseline['status']=='accepted_proof9_three_sweep_checkpoint_digest_replay'
            and identity(baseline_path)['sha256']==baseline['archive']['sha256']
            and frames[:3]==baseline['saved_only_replay']['checkpoint_epochs']
            and split_manifest['status']=='accepted_split_checkpoint_training_and_replay'
            and identity(split_path)['sha256']==split_manifest['archive']['sha256'],
            'earlier archives differ')
    pages = cohort/'page-images'
    require(reconstruct(numerical,frames,split_path,baseline_path,pages)==capture['wire_sha256']
            and numerical.stat().st_size+sum(32+f['bytes'] for f in frames)==capture['contract']['wire_bytes'],
            'complete wire reconstruction differs')
    files = {}
    for label,directory in (('cohort',cohort),('operator',operator),('recovery',recovery)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(),'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label=='cohort' and (rel.parts[0]=='source' or
                    (rel.parts[0]=='build' and path.name!='native-exact-build-manifest.json') or
                    (rel.parts[0]=='page-images' and path.name=='staged.bin')):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__),WORK/'trusted-virtual-dyadic-training-launch-v20.py',
                 WORK/'recover-dyadic-proof9-t4.py',
                 WORK/'project-dyadic-proof9-t4.py',WORK/'dyadic-proof9-t4-projection1.json',*args.control_log):
        files[f'external/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes']
                        and file_digest(stream,'sha256').hexdigest()==expected['sha256'],'archive member differs')
    manifest = {'status':'accepted_recovered_proof9_four_sweep_checkpoint_digest_replay','source_head':args.head,
                'baseline_source_head':baseline['source_head'],
                'original_operator_exit':run['original_exit'],'original_terminal':run['original_terminal'],
                'saved_only_recovery':{key:run[key] for key in ('recovery_head','replay_exit',
                    'native_producer_calls_during_recovery','raw_source_revalidated')},
                'first_three_numerical_sweeps_match':True,'independent_wire_reconstruction':True,
                'earlier_checkpoint_archives':[
                    {'path':split_path.relative_to(REPO).as_posix(),**identity(split_path),
                     'members_by_sweep':dict(zip(('1','2'),EARLY))},
                    {'path':baseline_path.relative_to(REPO).as_posix(),**identity(baseline_path),
                     'members_by_sweep':{'3':EARLY[0]}}],
                **{key:run[key] for key in ('admission','sweep_capture','sweep_capture_process_sha256',
                    'checkpoint_inputs','paging','row_directory','policy_spill','proof9_t4_comparison',
                    'saved_only_replay','training_invocations','quality_gate')},
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observation':run['proof9_t4_comparison']['native_observation'],
                      'wire':capture['wire_sha256']},sort_keys=True))


if __name__=='__main__':
    main()
