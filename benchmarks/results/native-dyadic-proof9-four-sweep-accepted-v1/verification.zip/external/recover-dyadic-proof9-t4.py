"""Recover only the failed PROOF9 T4 report from its authenticated saved stream."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

WORK = Path(__file__).resolve().parent
SOURCE = WORK/'dyt4-proof9-src1'
REPLAY_SOURCE = WORK/'dyt4-proof9-replay-src1'
COHORT = WORK/'dyt4-proof9-cohort1'
OPERATOR = WORK/'dyt4-proof9-launch1'
OUT = WORK/'dyt4-proof9-recovery1'
HEAD = 'de8b762b21b492cd0278ed7a38ffdbe7a9234947'
FIXED = {'scripts/verify_virtual_dyadic_training.py','tests/test_virtual_dyadic_checkpoint_digests.py'}


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_bytes())


def main():
    require(len(sys.argv)==2 and len(sys.argv[1])==40,'one committed recovery head required')
    recovery_head=sys.argv[1]
    operator=WORK/'trusted-virtual-dyadic-training-launch-v20.py'
    ops=runpy.run_path(str(operator))
    git,snapshot,sha,observe,save=(ops[key] for key in ('git','snapshot','sha','observe','save'))
    def identity(path):
        return {'bytes':path.stat().st_size,'sha256':sha(path)}
    def check_boot(path, hashes, module, launch):
        boot=read(path)
        require(boot['entry_module']==module
                and boot['trusted_first_stage']['bootstrap_sha256']==launch['bootstrap_sha256']
                and boot['trusted_first_stage']['command_sha256']==launch['first_stage_sha256']
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files']
                and all(hashes.get(name)==digest for name,digest in boot['compiled'].items()),
                'executed source closure differs')
        return boot

    original_exit=read(OPERATOR/'exit.json')
    failure=read(COHORT/'terminal.json')
    launch=read(OPERATOR/'operator-launch.json')
    require(original_exit=={'actual_exit_observed':True,'returncode':1,'failures':[]}
            and failure['status']=='failed' and failure['receipt']['training_invocations_entered']==1
            and failure['receipt']['first_error']=='ValueError: fixed cohort child failed; saved first attempt retained'
            and launch['head']==HEAD and launch['mode']=='train_proof9_t4'
            and launch['operator_sha256']==sha(operator),'original attempt differs')
    failed_dir=COHORT/'saved-review'
    first_replay=read(failed_dir/'process.json')
    require(first_replay['actual_exit_observed'] and first_replay['returncode']==1
            and not first_replay['automatic_retries'] and not first_replay['failures']
            and first_replay['streams'][1]['sha256']==sha(failed_dir/'stderr.bin')
            and (failed_dir/'stderr.bin').read_bytes().rstrip(b'\r\n').endswith(
                b'ValueError: zip() argument 2 is longer than argument 1')
            and (failed_dir/'stdout.bin').stat().st_size==0,
            'original replay failure differs')

    source=read(COHORT/'source.json')
    hashes={name:item['raw_sha256'] for name,item in source['files'].items()}
    require(source['head']==read(COHORT/'claim.json')['head']==HEAD
            and git(SOURCE,'rev-parse','HEAD').decode().strip()==HEAD
            and snapshot(SOURCE)==hashes==read(OPERATOR/'source-before.json'),
            'original captured source changed')
    require(git(REPLAY_SOURCE,'rev-parse','HEAD').decode().strip()==recovery_head
            and set(git(REPLAY_SOURCE,'diff','--name-only',HEAD,recovery_head).decode().splitlines())==FIXED,
            'recovery commit exceeds approved verifier fix')
    corrected=snapshot(REPLAY_SOURCE)
    require(corrected.keys()==hashes.keys()
            and {name for name in hashes if hashes[name]!=corrected[name]}==FIXED,
            'recovery source bytes differ outside verifier fix')
    boot_name='scripts/run_virtual_frozen_source_only.py'
    bootstrap=REPLAY_SOURCE/boot_name
    first=launch['first_stage']
    require(sha(bootstrap)==hashes[boot_name]==launch['bootstrap_sha256']
            and hashlib.sha256(first.encode()).hexdigest()==launch['first_stage_sha256']
            and bootstrap.read_bytes().replace(b'\r\n',b'\n')==git(REPLAY_SOURCE,'show',recovery_head+':'+boot_name),
            'trusted recovery bootstrap identity differs')
    check_boot(OPERATOR/'bootstrap.json',hashes,'scripts.run_virtual_dyadic_training_cohort',launch)
    check_boot(COHORT/'saved-review-bootstrap.json',hashes,'scripts.verify_virtual_dyadic_training',launch)
    build_path=COHORT/'build/native-exact-build-manifest.json'
    build=read(build_path)
    require(build['target']=='virtual-dyadic-training'
            and sha(Path(build['executable']))==build['executable_sha256']
            and all(hashes[name]==value==sha(COHORT/'source'/name) for name,value in build['source_sha256'].items()),
            'producer build closure differs')
    for mode in ('admit_proof9_t4','train_proof9_t4'):
        directory=COHORT/mode
        process=read(directory/'process.json')
        binary=read(directory/'binary-identity.json')
        require(process['status']=='exited' and process['actual_exit_observed'] and process['returncode']==0
                and not process['failures'] and not process['automatic_retries']
                and binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                and binary['build_manifest_sha256']==sha(build_path)
                and (directory/'request.bin').read_bytes()==('DYADIC_T4_V1 '+mode.upper()+'\n').encode('ascii')
                and sha(directory/'request.bin')==process['request_sha256']
                and (directory/'stderr.bin').stat().st_size==0,'observed producer exit or identity differs')
        for name,record in zip(('stdout.bin','stderr.bin'),process['streams'],strict=True):
            require(identity(directory/name)=={'bytes':record['saved_bytes'],'sha256':record['sha256']},
                    'producer saved stream changed')

    sys.path.insert(0,str(REPLAY_SOURCE))
    from scripts import run_virtual_dyadic_training_cohort as controller
    from tests.virtual_dyadic_stage_schedule import stage_schedule
    admission=read(COHORT/'admission.json')
    require(admission==read(COHORT/'admit_proof9_t4/stdout.bin'),'original admission differs')
    controller.validate_admission(admission,proof9_t4=True)
    inputs=read(COHORT/'checkpoint-inputs.json')
    data=COHORT/'train_proof9_t4/stdout.bin'
    pages=COHORT/'page-images'
    row_path=COHORT/'page-images-rows'
    schedule=stage_schedule(virtual_zero=True,sweeps=4)
    paging=controller.verify_paging(pages,admission,schedule)
    images=[{'name':name,**paging['images'][name]} for name in ('staged.bin','committed.bin')]
    capture=controller.verify_sweep_capture(process,admission,images,inputs['stream']['sha256'])
    require(inputs=={'stream':identity(data),'sweep_images':images,'sweep_epochs':capture['frames']},
            'original checkpoint inputs differ')
    spill=controller.verify_policy_spill(pages,data,admission)
    directory=controller.verify_row_directory(row_path,data,admission)
    comparison=controller.compare_proof9_t4_prefix(data,source,capture['frames'])
    comparison['native_observation']={k:process[k] for k in ('duration_seconds','memory')}
    observed_inputs={str(path):identity(path) for path in
        (data,COHORT/'train_proof9_t4/process.json',*(pages/name for name in ('staged.bin','committed.bin','policy.bin','policy.json','paging.json')),
         row_path/'rows.bin',row_path/'rows.json',COHORT/'checkpoint-inputs.json',failed_dir/'process.json',failed_dir/'stderr.bin')}
    OUT.mkdir()
    save(OUT/'source-before.json',corrected)
    save(OUT/'inputs.json',observed_inputs)
    replay_dir=OUT/'saved-review'
    replay_dir.mkdir()
    receipt=replay_dir/'bootstrap.json'
    command=[sys.executable,'-I','-S','-B','-c',first,str(bootstrap),hashes[boot_name],
             '--module','scripts.verify_virtual_dyadic_training','--receipt',str(receipt),'--',
             '--saved',str(data),'--sha256',inputs['stream']['sha256'],'--paired','--rank-sets','--proof9-t4',
             '--sweep-checkpoint-digest',*(frame['sha256'] for frame in capture['frames'])]
    exit_receipt=observe(command,REPLAY_SOURCE,replay_dir)
    boot=check_boot(receipt,corrected,'scripts.verify_virtual_dyadic_training',launch)
    require('scripts/verify_virtual_dyadic_training.py' in boot['compiled'],'verifier closure omitted entry source')
    replay=read(replay_dir/'stdout.log')
    require(replay['status']=='saved_four_sweep_exact_replay_pass' and replay['native_producer_calls']==0
            and replay['saved_output_sha256']==inputs['stream']['sha256']
            and replay['checkpoint_verification']=='independent_compact_digest'
            and replay['checkpoint_epochs']==capture['frames'] and replay['checkpoint_images']==images
            and replay['work_plan']==admission['component_work'] and replay['parent_work_plan']==admission['parent_work']
            and replay['planned_entries']==admission['entries'] and replay['planned_payload_bits']==admission['payload_bits'],
            'saved replay differs from authenticated producer')
    require(snapshot(SOURCE)==hashes and snapshot(REPLAY_SOURCE)==corrected
            and all(identity(Path(path))==binding for path,binding in observed_inputs.items()),
            'source or saved evidence changed during recovery')
    save(OUT/'source-after.json',corrected)
    save(OUT/'completion.json',{'head':HEAD,'recovery_head':recovery_head,'original_exit':original_exit,
        'original_terminal':failure,'replay_exit':exit_receipt,'training_invocations':1,
        'native_producer_calls_during_recovery':0,'raw_source_revalidated':True,
        'admission':admission,'checkpoint_inputs':inputs,'sweep_capture':capture,
        'sweep_capture_process_sha256':sha(COHORT/'train_proof9_t4/process.json'),
        'paging':paging,'row_directory':directory,'policy_spill':spill,'proof9_t4_comparison':comparison,
        'independent_stage_schedule':schedule,'saved_only_replay':replay,'quality_gate':None})
    print(json.dumps({'head':HEAD,'recovery_head':recovery_head,'native_producer_calls_during_recovery':0,
                      'replay_exit':exit_receipt,'status':replay['status'],
                      'exploitability':replay['profile_and_br']['exploitability']['approx']}))


if __name__=='__main__':
    main()
