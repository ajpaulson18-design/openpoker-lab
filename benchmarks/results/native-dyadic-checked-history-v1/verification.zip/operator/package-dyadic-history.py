"""Package the frozen compact-wire training, replay, and timing receipts."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

WORK=Path(__file__).resolve().parent
ROOT=WORK/"dyadic-phase-payload-repo"
HEAD="8bd8274d19b15aace0c8f6e238be1a46fbcf9fc9"
COHORT=WORK/"dyhistory-cohort2"
OPERATOR=WORK/"dyhistory-launch2"
RESULT=ROOT/"benchmarks/results/native-dyadic-checked-history-v1"


def require(value,message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def main():
    final=read(COHORT/"result.json")
    source=read(COHORT/"source.json")
    hashes={name:item["raw_sha256"] for name,item in source["files"].items()}
    outer=read(OPERATOR/"completion.json")
    require(final["head"]==source["head"]==outer["head"]==HEAD and
            final["training_invocations"]==1 and read(COHORT/"terminal.json")["status"]=="complete" and
            outer["actual_exit_observed"] and outer["returncode"]==0 and not outer["failures"] and
            outer["raw_source_stable"] and
            read(OPERATOR/"source-before.json")==read(OPERATOR/"source-after.json")==hashes,
            "compact study source or terminal status differs")
    launcher=WORK/"trusted-virtual-dyadic-training-launch-v31.py"
    require(read(OPERATOR/"operator-launch.json")["operator_sha256"]==sha(launcher),
            "compact launcher differs")
    for name in (OPERATOR/"bootstrap.json",COHORT/"saved-review-bootstrap.json"):
        boot=read(name)
        require(boot["initial_cache_scan"]["project_bytecode_files"]==
                boot["final_cache_scan"]["project_bytecode_files"]==0 and
                all(hashes[name]==digest for name,digest in boot["compiled"].items()),
                "compact source-only closure differs")
    build_path=COHORT/"build/native-exact-build-manifest.json"
    build=read(build_path)
    require(sha(Path(build["executable"]))==build["executable_sha256"] and
            all(hashes[name]==digest for name,digest in build["source_sha256"].items()),
            "compact native source or executable differs")
    for child in ("admit_ten_checked_history","train_ten_checked_history","saved-review"):
        process=read(COHORT/child/"process.json")
        require(process["actual_exit_observed"] and process["returncode"]==0 and
                not process["failures"] and process["automatic_retries"]==0,
                "compact process observation differs")
    native=read(COHORT/"train_ten_checked_history/process.json")
    compact=COHORT/"train_ten_checked_history/stdout.bin"
    expanded=COHORT/"train_ten_checked_history/expanded.bin"
    capture=final["compact_sweep_capture"]
    require(native["sweep_capture"]==capture and compact.stat().st_size==3_103_848 and
            sha(compact)==capture["retained_sha256"]==native["streams"][0]["sha256"] and
            expanded.stat().st_size==9_833_076 and
            sha(expanded)==final["saved_only_replay"]["saved_output_sha256"]==
                final["comparison"]["retained_sha256"],
            "compact or expanded output identity differs")
    baseline="benchmarks/results/native-dyadic-factored-training-v1"
    frozen=WORK/"dyhistory-src2"/baseline
    prior=read(frozen/"manifest.json")
    require(sha(frozen/"manifest.json")==hashes[baseline+"/manifest.json"] and
            sha(frozen/"verification.zip")==hashes[baseline+"/verification.zip"]==prior["archive"]["sha256"] and
            capture["frames"]==prior["compact_sweep_capture"]["frames"] and
            final["comparison"]["expected_history_footer_changes"]==2 and
            final["factored_execution"]==prior["factored_execution"] and
            final["admission"]["component_work"]["history"]==
                final["saved_only_replay"]["work_actual"]["history"]==62_890_960 and
            final["saved_only_replay"]["status"]=="saved_two_sweep_exact_replay_pass" and
            final["saved_only_replay"]["native_producer_calls"]==0 and
            read(COHORT/"factored-execution.json")==final["factored_execution"],
            "factored exact comparison differs")
    files={"operator/package-dyadic-history.py":Path(__file__),
           "operator/trusted-virtual-dyadic-training-launch-v31.py":launcher}
    for prefix,folder in (("operator",OPERATOR),("cohort",COHORT)):
        for path in sorted(folder.rglob("*")):
            require(not path.is_symlink(),"linked compact evidence")
            if not path.is_file():
                continue
            rel=path.relative_to(folder)
            if prefix=="cohort" and (rel.parts[0]=="source" or
                    (rel.parts[0]=="build" and path!=build_path) or
                    rel.as_posix() in ("page-images/committed.bin","page-images/staged.bin",
                                      "train_ten_checked_history/expanded.bin")):
                continue
            files[f"{prefix}/{rel.as_posix()}"]=path
    controls=WORK/"dyhistory-controls2"
    controls_head="3dabbca904cab1064d11d4dbcf0a4fdc09b680aa"
    test_path="tests/native/virtual_dyadic_history_controls.cpp"
    changed_test=WORK/"dyhistory-src3"/test_path
    control_hashes=dict(hashes,**{test_path:sha(changed_test)})
    require(sha(changed_test)!=hashes[test_path],"control correction missing")
    validated=read(controls/"completion.json")
    require(validated["head"]==controls_head and validated["tests_per_mode"]==54 and validated["skips"]==0 and
            validated["raw_source_stable"] and
            read(controls/"source-before.json")==read(controls/"source-after.json")==control_hashes,
            "frozen focused controls differ")
    files["controls/check-dyadic-history-controls2.py"]=WORK/"check-dyadic-history-controls2.py"
    files["earlier-controls/stderr.log"]=WORK/"dyhistory-controls1/normal/stderr.log"
    files["earlier-controls/exit.json"]=WORK/"dyhistory-controls1/normal/exit.json"
    files["controls/source-before.json"]=controls/"source-before.json"
    files["controls/source-after.json"]=controls/"source-after.json"
    files["earlier-build/build.log"]=WORK/"dyhistory-cohort1/build/build.log"
    files["earlier-build/terminal.json"]=WORK/"dyhistory-cohort1/terminal.json"
    files["earlier-build/build-failure.json"]=WORK/"dyhistory-cohort1/build/build-failure.json"
    files["earlier-build/operator-exit.json"]=WORK/"dyhistory-launch1/exit.json"
    files["earlier-build/controls-build.log"]=WORK/"dyhistory-build1/virtual-dyadic-history-controls/build.log"
    require(read(files["earlier-build/terminal.json"])["receipt"]["training_invocations_entered"]==0,
            "first build attempt entered training")
    files["projection/forecast.json"]=WORK/"dyhistory-projection-frozen.json"
    files["projection/project_virtual_dyadic_history.py"]=ROOT/"scripts/project_virtual_dyadic_history.py"
    projection=read(files["projection/forecast.json"])
    require(projection["n10"]["checked"]["work"]==62_890_960 and
            projection["n11"]["work"]==185_692_384 and projection["native_producer_calls"]==0 and
            projection["forecast_sha256"]==hashes["benchmarks/results/native-dyadic-eleven-card-forecast-v1/forecast.json"],
            "rank-free projection input differs")
    files["controls/completion.json"]=controls/"completion.json"
    for kind in ("normal","optimized"):
        for name in ("bootstrap.json","command.json","exit.json","stderr.log","stdout.log"):
            files[f"controls/{kind}/{name}"]=controls/kind/name
    for target in ("virtual-dyadic-history-controls","virtual-dyadic-state-controls"):
        folder=WORK/"dyhistory-build3/history" if target=="virtual-dyadic-history-controls" else WORK/"dyhistory-build2"/target
        identity=read(folder/"native-exact-build-manifest.json")
        require(sha(Path(identity["executable"]))==identity["executable_sha256"] and
                all(control_hashes[name]==digest for name,digest in identity["source_sha256"].items()),
                "component closure differs")
        files[f"controls/build/{target}.json"]=folder/"native-exact-build-manifest.json"
    timing_dir=WORK/"dyhistory-timing-pairs1"
    timing=read(timing_dir/"result.json")
    require(timing["source_head"]==HEAD and timing["training_invocations"]==8 and
            timing["raw_source_stable"] and timing["all_complete_streams_and_checkpoint_images_exact"] and
            read(timing_dir/"terminal.json")=={"status":"complete","training_invocations":8} and
            read(timing_dir/"source-before.json")==read(timing_dir/"source-after.json")==hashes and
            read(timing_dir/"configuration.json")["executable_sha256"]==build["executable_sha256"],
            "compact timing evidence differs")
    files["timing/compare-dyadic-history-timing.py"]=WORK/"compare-dyadic-history-timing.py"
    for name in ("configuration.json","result.json","terminal.json","source-before.json","source-after.json"):
        files[f"timing/{name}"]=timing_dir/name
    for item in timing["observations"]:
        label=f"pair-{item['pair']}-{item['mode']}"
        for name in ("verified.json","process/process.json","page-images/quantizer.json"):
            files[f"timing/{label}/{name}"]=timing_dir/label/name
        if item["mode"] in ("baseline","checked"):
            files[f"timing/{label}/factored-execution.json"]=timing_dir/label/"factored-execution.json"

    RESULT.mkdir(exist_ok=False)
    archive=RESULT/"verification.zip"
    inventory={name:{"bytes":path.stat().st_size,"sha256":sha(path)} for name,path in files.items()}
    with ZipFile(archive,"x",ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr("inventory.json",json.dumps(inventory,indent=2,sort_keys=True)+"\n")
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,"compact archive CRC differs")
        for name,record in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==record["bytes"] and
                        hashlib.file_digest(stream,"sha256").hexdigest()==record["sha256"],
                        "compact archive member differs")
    manifest={"version":"native-dyadic-checked-history-v1","source_head":HEAD,"source_files":len(hashes),
               "training_invocations":1,
              "prior_factored_evidence_source":prior["source_head"],
              "prior_manifest_sha256":sha(frozen/"manifest.json"),
              "admission":final["admission"],"factored_execution":final["factored_execution"],
              "focused_controls":validated["tests_per_mode"],"control_source_head":controls_head,
              "compact_sweep_capture":capture,"expansion":final["expansion"],
              "host_retained_bytes":final["host_retained_bytes"],
              "native_seconds":native["duration_seconds"],"native_memory":native.get("memory"),
               "quality_gate":final["quality_gate"],"comparison":final["comparison"],
              "compact_encoding_receipt":final["compact_encoding_receipt"],
              "compact_composed_work":final["admission"]["compact_composed_work"],
              "compact_composed_entries":final["admission"]["compact_composed_entries"],
              "compact_composed_payload_bits":final["admission"]["compact_composed_payload_bits"],
              "wire_reconstruction":final["wire_reconstruction"],
              "work_plan":final["saved_only_replay"]["work_plan"],
              "timing":timing,"history_projection":projection,
              "archive":{"path":"verification.zip","bytes":archive.stat().st_size,
                         "sha256":sha(archive),"members":len(inventory)+1}}
    with (RESULT/"manifest.json").open("x",encoding="utf-8") as stream:
        json.dump(manifest,stream,indent=2,sort_keys=True)
        stream.write("\n")
    print(json.dumps({"source_head":HEAD,"archive":manifest["archive"],"timing":timing["median_seconds"]}))


if __name__=="__main__":
    main()
