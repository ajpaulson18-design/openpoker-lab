# Card-independent betting-template seam

This is a source inventory only. The v2 public-tree census failed its existing
work limit before materialization, so this note does not describe a completed
fixture or successful capacity admission.

## Independent rules source

- `scripts/matrix_free_four_street_rules.py:303` — `_actions_for` builds the
  legal menu from the current actor, street, stack, blinds, pot/origin,
  commitments, owed amount, raise count/increment, checks/reopen state, and
  configured stage sizes. It does not rank cards or inspect private holdings.
- `scripts/matrix_free_four_street_rules.py:430` — `_next_decision` applies
  fold, call, check, bet, raise, and all-in actions to the public money state,
  including termination and response handling.
- `scripts/matrix_free_four_street_rules.py:511` — `_initial_state` applies
  the two blinds and creates the preflop state.
- `scripts/matrix_free_four_street_rules.py:595` — `_state_after_reveal`
  advances the street, resets street-local betting fields, and appends the
  canonical `flop@`, `turn@`, or `river@` history token. This is the boundary
  where public card IDs enter.
- `scripts/matrix_free_four_street_rules.py:626` — `build_public_model`
  currently enumerates the supplied runouts and materializes a full
  card-bearing public tree. It is not a virtual-chance trainer.
- `scripts/matrix_free_selected_payoffs.py:181` — `PayoffModel.prefix_support`
  supplies rank-free physical support for the fixture census.
  `PayoffModel.terminal` at line 201 ranks hands and was not called.

## Smallest native reuse seam

Extract the immutable stage rules and money-state transition/menu logic from
the public board enumerator. A native template needs the complete money state
(actor, street, stacks, blinds, committed amounts, street origin/pot, owed
amount, raise count/increment, checks and reopen state) and must return the
same ordered action fields and tokens. A separate chance provider can reveal a
canonical flop and then ordered turn and river cards. Policy identity remains
global actor, own holding, and the complete visible history. Distinct histories
must remain distinct even when their money state and menu coincide.

The current v2 census used the accepted `tests/test_four_street_validation.py`
case's betting fields: stack 8, blinds 0.5/1, preflop raise size 0.5 with one
raise and no explicit all-in, and postflop 0.5-pot bets with no raises. It
failed while charging `_charge_action_menu` in the dry census at the existing
500,000,000 work ceiling for 60 boards. This is preserved in
`first-failure.json`; no alternative configuration or cap was tried.

This source inventory does not authorize reuse of the selected-board graph or
router for one-board training: those paths can prune earlier support using a
future board. No sampler, training, update-expectation proof, rank evaluation,
best-response result, or full-52-card solve was performed.
