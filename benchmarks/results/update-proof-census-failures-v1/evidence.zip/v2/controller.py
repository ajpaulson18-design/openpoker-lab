#!/usr/bin/env python3
"""One-shot, rank-free census for the bounded nine-card update-proof fixture.

This is an external development helper.  It authenticates the complete frozen
checkout before importing its independent public-model or payoff code.  It
never trains, ranks hands, builds private-pair/world rows, or calls native code.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from collections import Counter, defaultdict
from contextlib import redirect_stderr, redirect_stdout
from decimal import Decimal
from fractions import Fraction


BASE = Path(r"C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work")
REPO = BASE / "full-deck-sampling-contract-repo"
SNAPSHOT = BASE / "native-public-chance-frozen-controls-v1" / "source-before.json"
OUTPUT = BASE / "full-deck-update-proof-fixture-v2"
HELPER = BASE / "full-deck-update-proof-fixture-v2.py"
FROZEN_COMMIT = "32ddc17409d7e56e012a9d749863af438a79a3d9"
PROOF_LABELS = (43, 48, 32, 24, 37, 16, 33, 35, 17)
RANKS, SUITS = "23456789TJQKA", "cdhs"
MONEY_CONTEXT = {"starting_stack": 8, "small_blind": 0.5, "big_blind": 1,
                 "raise_sizes": [0.5], "max_raises": 1, "include_all_in": False}
POSTFLOP = {"bet_sizes": [0.5], "raise_sizes": [],
            "max_raises": 0, "include_all_in": False}


def _run_git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True,
                                   stderr=subprocess.PIPE).strip()


def _authenticate():
    """Verify HEAD, clean status, raw file map, tree map, and filtered map."""
    snapshot = json.loads(SNAPSHOT.read_text(encoding="utf-8"))
    if snapshot.get("commit") != FROZEN_COMMIT or snapshot.get("status") != "":
        raise RuntimeError("frozen source snapshot has an unexpected commit/status")
    head = _run_git("rev-parse", "HEAD")
    status = _run_git("status", "--porcelain")
    if head != FROZEN_COMMIT or status:
        raise RuntimeError(f"frozen checkout changed: HEAD={head}, status={status!r}")
    raw_map = snapshot.get("sha256")
    tree_expected = snapshot.get("tree_blob_oid")
    filtered_expected = snapshot.get("git_normalized_blob_oid")
    if not all(type(value) is dict and len(value) == 2232
               for value in (raw_map, tree_expected, filtered_expected)):
        raise RuntimeError("frozen source maps are not the expected complete 2,232-file maps")

    raw_missing, raw_mismatch = [], []
    for rel, wanted in raw_map.items():
        path = REPO / rel
        if not path.is_file():
            raw_missing.append(rel)
            continue
        if hashlib.sha256(path.read_bytes()).hexdigest() != wanted:
            raw_mismatch.append(rel)
    if raw_missing or raw_mismatch:
        raise RuntimeError(f"frozen raw map differs: missing={raw_missing[:4]}, mismatch={raw_mismatch[:4]}")

    tree_raw = subprocess.check_output(["git", "-C", str(REPO), "ls-tree", "-r", "-z", "HEAD"])
    tree = {}
    for record in tree_raw.split(b"\0"):
        if record:
            meta, raw_path = record.split(b"\t", 1)
            tree[raw_path.decode("utf-8", "surrogateescape")] = meta.split()[2].decode("ascii")
    if tree != tree_expected:
        raise RuntimeError("committed Git tree map differs from the frozen tree map")

    # git-normalized entries may differ from committed tree blobs when the
    # checkout's path filters normalize text.  Tree-equal entries are already
    # proven; hash only the differing paths through Git's recorded filter path.
    filtered_diffs = [rel for rel, oid in filtered_expected.items() if tree.get(rel) != oid]
    filtered_mismatch = []
    for rel in filtered_diffs:
        got = _run_git("hash-object", "--path=" + rel, "--", rel)
        if got != filtered_expected[rel]:
            filtered_mismatch.append(rel)
    if filtered_mismatch:
        raise RuntimeError(f"path-filtered Git map differs: {filtered_mismatch[:4]}")
    if len(tree) != 2232:
        raise RuntimeError(f"frozen Git tree has {len(tree)} files, expected 2232")

    return {
        "commit": head, "status": "clean", "raw_files": len(raw_map),
        "raw_missing": 0, "raw_mismatches": 0, "tree_files": len(tree),
        "tree_mismatches": 0, "filtered_files": len(filtered_expected),
        "filtered_paths_checked_against_filter": len(filtered_diffs),
        "filtered_mismatches": 0,
        "snapshot_sha256": hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest(),
    }


def _card_name(card_id):
    return RANKS[card_id // 4] + SUITS[card_id % 4]


def _raw_ranges():
    a, b, c, d, e, f, *_ = PROOF_LABELS
    # This exactly mirrors tests/full_deck_public_chance_reference.py's
    # proof_ranges(), preserving its insertion order and physical weights.
    return (
        (((a, b), 0.25), ((a, c), 1.5)),
        (((d, e), 0.75), ((c, f), 2.0)),
    )


def _ordered_runout_ids(deck):
    for flop in itertools.combinations(deck, 3):
        flop_set = set(flop)
        remaining = tuple(card for card in deck if card not in flop_set)
        for turn, river in itertools.permutations(remaining, 2):
            yield (*flop, turn, river)


def _canon_prefix(board):
    return tuple(sorted(board[:3])) + tuple(board[3:])


def _fraction_text(value):
    return f"{value.numerator}/{value.denominator}"


def _policy_for(actor, hand, history, actions):
    """Stable mixed dyadic policy keyed only by actor, hand, visible history."""
    material = json.dumps([actor, hand, list(history)], ensure_ascii=True,
                          separators=(",", ":")).encode("ascii")
    digest = hashlib.sha256(material).digest()
    count = len(actions)
    if count == 1:
        numerators, denominator = (1,), 1
    elif count == 2:
        denominator = 8
        main = digest[0] % 2
        numerators = tuple(6 if i == main else 2 for i in range(2))
    else:
        denominator = 8
        zero = digest[0] % count
        main = (zero + 1 + digest[1] % (count - 1)) % count
        secondary = next(i for i in range(count) if i not in (zero, main))
        values = [0] * count
        values[main], values[secondary] = 6, 2
        numerators = tuple(values)
    if sum(numerators) != denominator:
        raise ArithmeticError("dyadic policy row failed exact normalization")
    return numerators, denominator, hashlib.sha256(material).hexdigest()


def _action_row(action):
    return {"name": action.name, "token": action.token,
            "amount_hex": float(action.amount).hex(),
            "raise_to_hex": float(action.raise_to).hex()}


def _walk_public(model, support_by_prefix, policy_by_key, initial_reach):
    from scripts.matrix_free_four_street_rules import Decision, Reveal, Terminal

    counts = Counter()
    occurrence_groups = defaultdict(set)
    policy_reaches = {"zero_own_reach_rows": 0, "reach_values": Counter(),
                      "opponent_reach_witness": None}
    terminal_money_mismatches = []
    max_decision_cache = {}

    def max_decision_street(node):
        cached = max_decision_cache.get(id(node))
        if cached is not None:
            return cached
        if isinstance(node, Decision):
            result = max([len(node.board), *(max_decision_street(child)
                                             for child in node.children)])
        elif isinstance(node, Reveal):
            result = max((max_decision_street(child) for child in node.branches.values()),
                         default=-1)
        elif isinstance(node, Terminal):
            result = -1
        else:
            raise TypeError(f"unknown independent public node {type(node).__name__}")
        max_decision_cache[id(node)] = result
        return result

    def walk(node, reaches, committed):
        if isinstance(node, Decision):
            street = len(node.board)
            counts[f"decision_occurrences_street_{street}"] += 1
            support = support_by_prefix[node.board]
            actor = node.player
            for index, hand_tuple in enumerate(model.ranges[actor]):
                hand = "".join(hand_tuple)
                if not support[actor][index]:
                    continue
                key = (actor, hand, tuple(node.history))
                policy = policy_by_key[key]
                own_reach = reaches[actor][index]
                opp_side = 1 - actor
                compatible = []
                board_set = set(node.board)
                for other_index, other_hand_tuple in enumerate(model.ranges[opp_side]):
                    if (support[opp_side][other_index] and
                            not board_set.intersection(other_hand_tuple) and
                            not set(hand_tuple).intersection(other_hand_tuple)):
                        compatible.append((other_index, "".join(other_hand_tuple),
                                           reaches[opp_side][other_index]))
                policy_reaches["reach_values"][str(own_reach)] += 1
                if own_reach == 0:
                    policy_reaches["zero_own_reach_rows"] += 1
                if policy_reaches["opponent_reach_witness"] is None and len(compatible) >= 2:
                    values = {item[2] for item in compatible}
                    if len(values) > 1:
                        policy_reaches["opponent_reach_witness"] = {
                            "actor": "sb" if actor == 0 else "bb", "hand": hand,
                            "history": list(node.history),
                            "compatible_opponent_reaches": [
                                {"hand": other, "reach": _fraction_text(value)}
                                for _, other, value in compatible],
                        }

            money_key = (node.player, tuple(node.board), tuple(committed))
            occurrence_groups[money_key].add(tuple(node.history))
            counts[f"action_slots_street_{street}"] += len(node.actions)
            for action_index, (action, child) in enumerate(zip(node.actions, node.children)):
                counts[f"action_edge_{action.name}"] += 1
                if action.name == "all_in" and max_decision_street(child) <= street:
                    counts["all_in_edges_without_later_street_decision"] += 1
                next_reach = [list(reaches[0]), list(reaches[1])]
                support_actor = support[actor]
                for index, hand_tuple in enumerate(model.ranges[actor]):
                    hand = "".join(hand_tuple)
                    if not support_actor[index]:
                        next_reach[actor][index] = Fraction(0)
                        continue
                    row_policy = policy_by_key[(actor, hand, tuple(node.history))]
                    next_reach[actor][index] *= Fraction(
                        row_policy["probability_numerators"][action_index],
                        row_policy["probability_denominator"])
                next_committed = list(committed)
                next_committed[actor] = (Decimal(str(next_committed[actor])) +
                                         Decimal(str(action.amount)))
                walk(child, next_reach, next_committed)
        elif isinstance(node, Reveal):
            counts[f"reveal_occurrences_board_length_{node.board_length}"] += 1
            counts[f"reveal_edges_board_length_{node.board_length}"] += len(node.branches)
            for child in node.branches.values():
                walk(child, reaches, committed)
        elif isinstance(node, Terminal):
            counts[f"terminal_{node.kind}"] += 1
            if node.winner is not None:
                counts[f"fold_winners_seat_{node.winner}"] += 1
            expected = tuple(float(x) for x in committed)
            if expected != node.committed:
                terminal_money_mismatches.append({
                    "history": list(node.history), "reconstructed": [str(x) for x in committed],
                    "terminal": [float(x).hex() for x in node.committed]})
        else:
            raise TypeError(f"unknown independent public node {type(node).__name__}")

    root_committed = [Decimal("0.5"), Decimal("1.0")]
    walk(model.root, initial_reach, root_committed)
    reconvergent = [
        {"actor": "sb" if key[0] == 0 else "bb", "board": list(key[1]),
         "committed": [str(value) for value in key[2]],
         "histories": [list(history) for history in sorted(histories)]}
        for key, histories in occurrence_groups.items() if len(histories) > 1
    ]
    return {
        "public_walk_counts": dict(sorted(counts.items())),
        "same_actor_board_committed_histories": len(reconvergent),
        "reconvergent_money_state_witnesses": reconvergent[:12],
        "policy_reach_census": {
            "zero_own_reach_supported_rows": policy_reaches["zero_own_reach_rows"],
            "own_reach_distinct_values": len(policy_reaches["reach_values"]),
            "opponent_reach_witness": policy_reaches["opponent_reach_witness"],
        },
        "terminal_commitment_reconstruction_mismatches": terminal_money_mismatches[:4],
        "terminal_commitment_mismatch_count": len(terminal_money_mismatches),
    }


def _build_fixture(out):
    # The imports below intentionally occur only after _authenticate() succeeds.
    sys.path.insert(0, str(REPO))
    from scripts.matrix_free_certificate_budget import Budget
    from scripts.matrix_free_four_street_rules import Decision, Reveal, Terminal, build_public_model
    import scripts.matrix_free_selected_payoffs as payoff_module
    from scripts.matrix_free_selected_payoffs import PayoffModel

    def forbidden_rank(*_args, **_kwargs):
        raise AssertionError("ranking was forbidden in this structural fixture census")

    payoff_module.independent_rank = forbidden_rank

    deck = tuple(sorted(PROOF_LABELS))
    raw_ranges = _raw_ranges()
    physical_pair_rows = []
    raw_z = Fraction(0)
    compatible_pairs = []
    for sb_hand, sb_weight in raw_ranges[0]:
        for bb_hand, bb_weight in raw_ranges[1]:
            if set(sb_hand).intersection(bb_hand):
                physical_pair_rows.append({"sb": list(sb_hand), "bb": list(bb_hand),
                                           "compatible": False})
                continue
            mass = Fraction.from_float(sb_weight) * Fraction.from_float(bb_weight)
            raw_z += mass
            compatible_pairs.append((sb_hand, sb_weight, bb_hand, bb_weight, mass))
            physical_pair_rows.append({"sb": list(sb_hand), "bb": list(bb_hand),
                                       "compatible": True, "raw_mass": _fraction_text(mass),
                                       "normalized_prior": _fraction_text(mass / Fraction(29, 16))})
    if raw_z != Fraction(29, 16) or len(compatible_pairs) != 3:
        raise AssertionError(f"fixture pair law changed: Z={raw_z}, pairs={len(compatible_pairs)}")

    accepted = set()
    pair_board_counts = []
    for sb_hand, _, bb_hand, _, _ in compatible_pairs:
        remaining = tuple(card for card in deck if card not in (*sb_hand, *bb_hand))
        boards = tuple(_ordered_runout_ids(remaining))
        pair_board_counts.append(len(boards))
        accepted.update(boards)
    all_proposals = tuple(_ordered_runout_ids(deck))
    if len(all_proposals) != 2520 or len(accepted) != 60 or pair_board_counts != [20, 20, 20]:
        raise AssertionError("PROOF9 board/proposal counts differ from the declared anchor")
    sorted_target = tuple(sorted(accepted))

    # Parser weights are capped at one.  Uniformly scaling every SB and BB
    # weight by 1/2 keeps all normalized private-pair probabilities unchanged;
    # PayoffModel below receives the exact original weights for Z=29/16.
    # Existing lexical holding order is retained in each range expression.
    card_ranges = []
    expressions = []
    for side in raw_ranges:
        mapping = {}
        tokens = []
        for hand_ids, weight in side:
            hand = tuple(sorted(_card_name(card) for card in hand_ids))
            scaled = weight / 2.0
            mapping[hand] = weight / 2.0
            tokens.append("".join(hand) + ":" + format(scaled, ".17g"))
        card_ranges.append(mapping)
        expressions.append(",".join(tokens))

    case = {
        "id": "proof9-frozen-four-street-update-fixture-v1",
        "sb_range": expressions[0], "bb_range": expressions[1],
        "config": dict(MONEY_CONTEXT),
        "runouts": ["".join(_card_name(card) for card in board) for board in sorted_target],
        "flop_config": dict(POSTFLOP), "turn_config": None,
        "river_config": None,
    }

    budget = Budget()
    model = build_public_model(case, budget=budget)
    if len(model.outcomes) != 60:
        raise AssertionError(f"independent public model retained {len(model.outcomes)} boards, expected 60")
    payoff_ranges = tuple(dict(side) for side in card_ranges)
    payoff_boards = tuple(tuple(_card_name(card) for card in board) for board in sorted_target)
    payoff = PayoffModel(payoff_ranges, payoff_boards, budget)
    scaled_z = sum((Fraction.from_float(sb_weight) * Fraction.from_float(bb_weight)
                    for sb_hand, sb_weight in payoff_ranges[0].items()
                    for bb_hand, bb_weight in payoff_ranges[1].items()
                    if not set(sb_hand).intersection(bb_hand)), Fraction(0))
    if scaled_z != Fraction(29, 64) or payoff.normalizerZ != Fraction(145, 16):
        raise AssertionError(
            f"scaled prior-law normalizers changed: Z={scaled_z}, selected={payoff.normalizerZ}")
    scaled_pair_priors = {}
    for sb_hand, sb_weight in payoff_ranges[0].items():
        for bb_hand, bb_weight in payoff_ranges[1].items():
            if set(sb_hand).intersection(bb_hand):
                continue
            scaled_pair_priors[(sb_hand, bb_hand)] = (
                Fraction.from_float(sb_weight) * Fraction.from_float(bb_weight) / scaled_z)
    raw_pair_priors = {
        (tuple(sorted(_card_name(c) for c in sb_hand)),
         tuple(sorted(_card_name(c) for c in bb_hand))): mass / raw_z
        for sb_hand, _, bb_hand, _, mass in compatible_pairs}
    if scaled_pair_priors != raw_pair_priors:
        raise AssertionError("uniform per-seat 1/2 scaling changed normalized private-pair priors")
    if payoff.compatible_pairs != 3 or payoff.physical_worlds != 60:
        raise AssertionError("PayoffModel selected-support census differs from PROOF9 anchor")

    prefix_set = {()}
    for board in payoff_boards:
        canonical = _canon_prefix(board)
        prefix_set.add(canonical[:3])
        prefix_set.add(canonical[:4])
        prefix_set.add(canonical[:5])
    prefixes = tuple(sorted(prefix_set, key=lambda p: (len(p), tuple(PROOF_LABELS.index(c) if c in PROOF_LABELS else c for c in p))))
    support_by_prefix = {}
    prefix_census = []
    prefix_law_equivalence_checks = []
    for prefix in prefixes:
        support = payoff.prefix_support(prefix)
        support_by_prefix[prefix] = support
        def normalized_prefix_mass(ranges, normalizer):
            total = Fraction(0)
            for board in payoff.boards:
                if board[:len(prefix)] != prefix:
                    continue
                blocked = set(board)
                for sb_hand, sb_weight in ranges[0].items():
                    if blocked.intersection(sb_hand):
                        continue
                    for bb_hand, bb_weight in ranges[1].items():
                        if blocked.intersection(bb_hand) or set(sb_hand).intersection(bb_hand):
                            continue
                        total += Fraction.from_float(sb_weight) * Fraction.from_float(bb_weight)
            return total / normalizer
        scaled_mass = normalized_prefix_mass(payoff_ranges, payoff.normalizerZ)
        original_ranges = tuple({
            tuple(sorted(_card_name(card) for card in hand)): float(weight)
            for hand, weight in side} for side in raw_ranges)
        original_selected_z = Fraction(145, 4)
        original_mass = normalized_prefix_mass(original_ranges, original_selected_z)
        if scaled_mass != original_mass:
            raise AssertionError(f"scaled prior changed normalized prefix law at {prefix}")
        prefix_law_equivalence_checks.append({
            "prefix": [_card_name(card) for card in prefix],
            "normalized_mass_original": _fraction_text(original_mass),
            "normalized_mass_scaled": _fraction_text(scaled_mass),
            "exactly_equal": True,
        })
        prefix_census.append({
            "prefix": [_card_name(card) for card in prefix],
            "length": len(prefix),
            "support_sb": list(support[0]), "support_bb": list(support[1]),
            "supported_hands_by_seat": [sum(support[0]), sum(support[1])],
            "matching_selected_boards": sum(board[:len(prefix)] == prefix for board in payoff.boards),
        })

    policies = {}
    policy_rows = []
    row_keys_seen = set()
    street_policy = Counter()
    policy_zero_actions = 0
    policy_nonuniform_rows = 0
    row_history_bytes = 0
    row_action_slots = 0
    for node in model.decisions:
        support = support_by_prefix[node.board]
        for hand_index, hand_tuple in enumerate(model.ranges[node.player]):
            if not support[node.player][hand_index]:
                continue
            hand = "".join(hand_tuple)
            history = tuple(node.history)
            key = (node.player, hand, history)
            if key in row_keys_seen:
                raise AssertionError(f"duplicate actor/hand/full-history row: {key}")
            row_keys_seen.add(key)
            action_values = tuple(_action_row(action) for action in node.actions)
            numerators, denominator, key_sha = _policy_for(
                node.player, hand, history, action_values)
            if 0 in numerators:
                policy_zero_actions += numerators.count(0)
            if len(set(numerators)) > 1:
                policy_nonuniform_rows += 1
            row = {
                "player": "sb" if node.player == 0 else "bb", "hand": hand,
                "visible_board": [_card_name(card) for card in node.board],
                "history": list(history), "actions": list(action_values),
                "probability_numerators": list(numerators),
                "probability_denominator": denominator,
                "normalization_exact": sum(numerators) == denominator,
                "policy_key_sha256": key_sha,
            }
            policies[key] = row
            policy_rows.append(row)
            street = len(node.board)
            street_policy[f"supported_rows_street_{street}"] += 1
            street_policy[f"action_slots_street_{street}"] += len(action_values)
            row_action_slots += len(action_values)
            row_history_bytes += sum(len(token.encode("ascii")) for token in history)

    if not policy_rows or not policy_zero_actions or not policy_nonuniform_rows:
        raise AssertionError("policy fixture lacks normalized mixed/zero-probability action rows")
    if not all(row["normalization_exact"] for row in policy_rows):
        raise AssertionError("frozen policy contains a non-normalized row")

    initial_reach = (tuple(Fraction(1) for _ in model.ranges[0]),
                     tuple(Fraction(1) for _ in model.ranges[1]))
    walk = _walk_public(model, support_by_prefix, policies, initial_reach)
    # Verify complete stage coverage and a real same-money distinct-history
    # witness; don't silently change the first chosen betting template.
    decision_streets = [street for street in (0, 3, 4, 5)
                         if walk["public_walk_counts"].get(
                             "decision_occurrences_street_" + str(street), 0)]
    if decision_streets != [0, 3, 4, 5]:
        raise AssertionError(f"fixture lacks a betting decision on every street: {decision_streets}")
    if walk["same_actor_board_committed_histories"] == 0:
        raise AssertionError("fixture did not produce a repeated money state with distinct histories")
    if walk["policy_reach_census"]["opponent_reach_witness"] is None:
        raise AssertionError("fixture did not produce unequal full-history opponent reaches")
    if not walk["public_walk_counts"].get("action_edge_fold", 0) or not walk["public_walk_counts"].get("action_edge_all_in", 0):
        raise AssertionError("fixture does not include fold and all-in legal actions")

    proposal_rows = []
    uniform_total = len(all_proposals)
    nonuniform_weights = []
    for board in all_proposals:
        canonical = _canon_prefix(board)
        encoded = "".join(f"{card:02d}" for card in canonical).encode("ascii")
        weight = 1 + (hashlib.sha256(encoded).digest()[0] & 1)
        nonuniform_weights.append(weight)
        proposal_rows.append({"board": [_card_name(card) for card in canonical],
                              "uniform_weight": 1, "nonuniform_weight": weight,
                              "target_compatible": canonical in accepted})
    nonuniform_total = sum(nonuniform_weights)
    if len(proposal_rows) != 2520 or nonuniform_total <= 0 or min(nonuniform_weights) <= 0:
        raise AssertionError("proposal profile must cover all 2,520 public outcomes positively")

    physical_outcome_counts = Counter()
    target_pair_support_counts = Counter()
    for board in proposal_rows:
        if board["target_compatible"]:
            physical_outcome_counts["target_compatible"] += 1
        else:
            physical_outcome_counts["zero_target_mass"] += 1
    for board in payoff.boards:
        compatible_here = []
        for p, (sb_hand, _, bb_hand, _, _) in enumerate(compatible_pairs):
            if not set(sb_hand + bb_hand).intersection(board):
                compatible_here.append(p)
        if len(compatible_here) != 1:
            raise AssertionError("selected target-board families must be disjoint pair-by-pair")
        target_pair_support_counts[compatible_here[0]] += 1

    receipt = payoff.receipt()
    if receipt["rank_calls"] != 0 or receipt["terminal_calls"] != 0 or receipt["stored_pairs"] or receipt["stored_worlds"]:
        raise AssertionError(f"rank/payoff/world work entered unexpectedly: {receipt}")
    # Exact completion counts by prefix length under a fixed private pair.
    prefix_completion_counts = {"0": 1, "3": 10, "4": 20, "5": 20}
    expected_scaled = {"0": Fraction(1), "3": Fraction(1, 10),
                       "4": Fraction(1, 20), "5": Fraction(1, 20)}

    result = {
        "schema": "full-deck-update-proof-fixture-census-v1",
        "scope": "rank-free structural fixture and frozen-policy census only; no update expectation, training, BR, or quality result",
        "case": case,
        "card_id_map": {str(card): _card_name(card) for card in PROOF_LABELS},
        "range_input_note": "The accepted independent rules case and PayoffModel both use the proof_ranges weights scaled by 1/2 per seat because the case range parser caps each token at 1. The scale is uniform by seat, so normalized pair priors and all normalized prefix masses exactly match the original proof9 law; no raw weight-bit parity is claimed.",
        "raw_ranges": [
            [{"hand": "".join(sorted(_card_name(c) for c in hand)),
              "weight_hex": float(weight).hex()} for hand, weight in side]
            for side in raw_ranges],
        "raw_compatible_pair_census": physical_pair_rows,
        "raw_private_pair_normalizer_Z": _fraction_text(raw_z),
        "normalized_compatible_pair_priors": [
            {"sb": "".join(sorted(_card_name(c) for c in sb)),
             "bb": "".join(sorted(_card_name(c) for c in bb)),
             "prior": _fraction_text(mass / raw_z)}
            for sb, _, bb, _, mass in compatible_pairs],
        "scaled_case_private_pair_normalizer_Z": _fraction_text(scaled_z),
        "scaled_case_selected_reference_normalizer": _fraction_text(payoff.normalizerZ),
        "original_private_pair_normalizer_Z": _fraction_text(raw_z),
        "original_selected_reference_normalizer": "145/4",
        "selected_reference_normalizer_identity": "scaled law: 20 * (29/64) = 145/16; original law: 20 * (29/16) = 145/4. Uniform 1/2 scaling on each seat changes units by 1/4 and leaves normalized pair/prefix masses exactly equal.",
        "compatible_pairs": len(compatible_pairs),
        "target_boards": len(payoff.boards),
        "target_boards_per_compatible_pair": pair_board_counts,
        "target_boards_by_private_pair": dict((str(i), int(v)) for i, v in target_pair_support_counts.items()),
        "proposal_outcomes": len(all_proposals),
        "proposal_zero_target_outcomes": physical_outcome_counts["zero_target_mass"],
        "proposal_target_outcomes": physical_outcome_counts["target_compatible"],
        "prefix_completion_counts_per_fixed_pair": prefix_completion_counts,
        "prefix_probability_under_uniform_runout_given_pair": {
            key: _fraction_text(value) for key, value in expected_scaled.items()},
        "proposal_profiles": {
            "uniform": {"numerator_per_outcome": 1, "normalizer": uniform_total,
                        "strictly_positive": True},
            "nonuniform_dyadic": {
                "weight_rule": "1 + low_bit(SHA256(ASCII concatenation of each canonical card's two-digit physical ID))",
                "normalizer": nonuniform_total,
                "minimum_weight": min(nonuniform_weights),
                "maximum_weight": max(nonuniform_weights),
                "strictly_positive": True,
            },
        },
        "proposal_outcomes_explicit": proposal_rows,
        "frozen_policy": {
            "contract": "deterministic dyadic behavioral policy keyed only by global actor, own holding, and full visible history",
            "policy_seed_rule": "SHA256(canonical JSON [actor,hand,history]); no hidden future or opponent holding is an input",
            "zero_visit_fallback": "first legal menu action receives probability 1; all other legal actions 0",
            "normalized_row_count": len(policy_rows),
            "zero_probability_legal_action_slots": policy_zero_actions,
            "nonuniform_rows": policy_nonuniform_rows,
            "action_slots": row_action_slots,
            "history_token_characters": row_history_bytes,
            "rows": policy_rows,
        },
        "prefix_support_census": prefix_census,
        "prefix_law_equivalence_checks": prefix_law_equivalence_checks,
        "street_policy_counts": dict(sorted(street_policy.items())),
        "public_tree_census": model.counts,
        "public_history_and_reach_census": walk,
        "payoff_model_rank_free_receipt": receipt,
        "budget_limits_and_receipt": budget.receipt(),
        "bet_template_inventory": {
            "source_files": [
                {"path": "scripts/matrix_free_four_street_rules.py",
                 "reusable_functions": ["_actions_for (line 303)",
                                        "_next_decision (line 430)",
                                        "_initial_state (line 511)"],
                 "scope": "street/action history, actor, stacks, blinds, pot, commitments, raise/check/reopen state and stage menu; no rank or private-card inputs"},
                {"path": "scripts/matrix_free_four_street_rules.py",
                 "reusable_functions": ["_state_after_reveal (line 595)",
                                        "build_public_model (line 626)"],
                 "scope": "reveal transition currently enumerates selected board prefixes and stores card-bearing public branches; virtual chance should separate that provider from card-independent money transitions"},
                {"path": "scripts/matrix_free_selected_payoffs.py",
                 "reusable_functions": ["PayoffModel.prefix_support (line 181)"],
                 "scope": "bounded rank-free physical support oracle for this census; terminal (line 201) ranks and is not called"},
            ],
            "native_virtual_plan_seam": [
                "Factor an immutable stage/action template and money-state transition/menu generator that accepts no card IDs.",
                "Represent reveals as separate canonical flop then ordered turn/river chance transitions supplied by a bounded proposal provider.",
                "Retain actor, own holding and full visible history as row identity; never merge equal money states reached by distinct histories.",
                "Carry all-in/fold settlement and matched-wager refund semantics unchanged; prove action tokens and money outputs against the independent rules anchor.",
            ],
            "not_reusable_as_virtual_solver": "build_public_model materializes every selected public board branch, and selected-board native graph/router code can future-board-prune support; no one-board trainer is authorized by this inventory.",
        },
        "resource_forecast_limits": {
            "independent_public_model_hands_per_seat": 16,
            "selected_board_cap": 64,
            "public_nodes_cap": 250000,
            "public_depth_cap": 64,
            "payoff_model_hands_per_seat": 16,
            "payoff_model_selected_board_cap": 64,
            "certificate_rows_reference_cap": 20000,
            "certificate_action_slots_reference_cap": 100000,
            "budget_limits": budget.limits,
            "private_pair_records_retained": 0,
            "deal_world_records_retained": 0,
            "rank_calls": 0,
            "training_calls": 0,
        },
        "warnings": [
            "PublicModel's support filtering is not used to prune its public graph; PayoffModel support only selects valid policy rows.",
            "This is a rank-free fixture/census and frozen policy, not the all-outcome update expectation proof.",
            "The supplied PROOF9 physical cards are included for a later varying-showdown-rank check; this census deliberately performs no ranking.",
            "No full-52-card, convergence, best-response, sampling-quality, or solver-performance claim is made.",
        ],
    }
    return result


def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    stdout_path, stderr_path = OUTPUT / "stdout.log", OUTPUT / "stderr.log"
    completion_path = OUTPUT / "completion.json"
    source_before_path = OUTPUT / "source-before.json"
    helper_sha_before = hashlib.sha256(HELPER.read_bytes()).hexdigest()
    result = {"status": "failed", "helper_sha256_before_math": helper_sha_before}
    exit_code = 1
    with stdout_path.open("w", encoding="utf-8", newline="\n") as out, \
            stderr_path.open("w", encoding="utf-8", newline="\n") as err, \
            redirect_stdout(out), redirect_stderr(err):
        try:
            auth_before = _authenticate()
            source_before_path.write_bytes(SNAPSHOT.read_bytes())
            result["source_authentication_before_math"] = auth_before
            (OUTPUT / "auth-before.json").write_text(
                json.dumps(auth_before, sort_keys=True, indent=2) + "\n", encoding="utf-8")
            print("FROZEN_SOURCE_AUTHENTICATED", json.dumps(auth_before, sort_keys=True))
            fixture = _build_fixture(OUTPUT)
            (OUTPUT / "fixture.json").write_text(
                json.dumps(fixture, sort_keys=True, indent=2, ensure_ascii=True) + "\n",
                encoding="utf-8")
            (OUTPUT / "bet-template-inventory.md").write_text(
                "# Card-independent betting-template seam\n\n"
                "The independent public rules in `scripts/matrix_free_four_street_rules.py` "
                "separate action/money logic from board evaluation. `_actions_for` (line 303) "
                "builds menus from actor, street, commitments, pot/origin, stacks, raise/check "
                "state and stage sizes. `_next_decision` (line 430) applies an action and handles "
                "fold/call/raise transitions; `_initial_state` (line 511) applies blinds. These "
                "operations do not rank cards.\n\n"
                "`_state_after_reveal` (line 595) and `build_public_model` (line 626) are not "
                "the reusable virtual path: they enumerate the supplied board prefixes and "
                "materialize card-bearing branches. A native virtual plan can instead expose an "
                "immutable betting template/state transition that takes no card IDs, with a "
                "separate bounded chance provider for canonical flop, ordered turn, and ordered "
                "river reveals. Preserve actor, own hand, and full visible history as row identity; "
                "do not merge identical-money states reached through different histories.\n\n"
                "`scripts/matrix_free_selected_payoffs.py:PayoffModel.prefix_support` (line 181) "
                "is used only for this fixture's rank-free support census. Its `terminal` method "
                "(line 201) ranks hands and was not called. No selected-board graph/router or "
                "one-board training path is authorized by this inventory.\n",
                encoding="utf-8")
            result["fixture_schema"] = fixture["schema"]
            result["fixture_sha256"] = hashlib.sha256((OUTPUT / "fixture.json").read_bytes()).hexdigest()
            result["status"] = "complete"
            exit_code = 0
            print("FIXTURE_CENSUS_COMPLETE", result["fixture_sha256"])
        except BaseException as exc:
            (OUTPUT / "first-failure.json").write_text(json.dumps({
                "exception_type": type(exc).__name__, "message": str(exc),
                "traceback": traceback.format_exc(),
            }, sort_keys=True, indent=2) + "\n", encoding="utf-8")
            print("FIRST_FAILURE", type(exc).__name__, str(exc), file=err)
            traceback.print_exc(file=err)
        finally:
            try:
                auth_after = _authenticate()
                result["source_authentication_after"] = auth_after
                result["source_before_after_equal"] = (
                    result.get("source_authentication_before_math") == auth_after)
            except BaseException as exc:
                result["source_after_error"] = {"type": type(exc).__name__, "message": str(exc)}
                result["status"] = "failed-source-after"
                exit_code = 1
            helper_sha_after = hashlib.sha256(HELPER.read_bytes()).hexdigest()
            result["helper_sha256_after_math"] = helper_sha_after
            if helper_sha_after != helper_sha_before:
                result["status"] = "failed-helper-drift"
                exit_code = 1
            result["exit_code"] = exit_code
            result["completed"] = True
            completion_path.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n",
                                       encoding="utf-8")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
