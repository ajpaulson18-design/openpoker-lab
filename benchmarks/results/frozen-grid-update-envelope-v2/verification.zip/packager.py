"""Package observed V2 and superseded V1 forecasts; no candidate execution."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,zipfile

WORK=Path(__file__).resolve().parent;ROOT=WORK/'dyprofile-repo'
PACKET=ROOT/'benchmarks/results/frozen-grid-update-envelope-v2'
files={}
def sha(raw):return sha256(raw).hexdigest()
def add(name,raw):
    if name in files:raise ValueError('duplicate archive member')
    files[name]=raw
def file(name,path):add(name,path.read_bytes())
def tree(name,path):
    for p in sorted(path.rglob('*')):
        if p.is_file():file(name+'/'+p.relative_to(path).as_posix(),p)
if PACKET.exists():raise ValueError('immutable packet exists')
for version in (1,2):
    prefix='formal' if version==2 else 'superseded-v1'
    for mode in ('normal','optimized'):
        directory=WORK/f'dygrid-update-envelope{version}-formal-{mode}'
        tree(prefix+'/'+mode,directory)
        file('logs/'+prefix+'-'+mode+'.log',WORK/f'dygrid-update-envelope{version}-formal-{mode}.log')
        if version==2:file('replay/'+mode+'.json',WORK/f'dygrid-update-envelope2-formal-{mode}-replay.log')
    build=WORK/f'dygrid-update-envelope{version}'
    manifest=json.loads((build/'native-exact-build-manifest.json').read_bytes())
    source=WORK/f'dygrid-update-envelope{version}-formal-normal/source'
    for name,digest in manifest['source_sha256'].items():
        if sha((source/name).read_bytes())!=digest:raise ValueError('build source closure drift '+name)
    executable=next(build.glob('*.exe'))
    if sha(executable.read_bytes())!=manifest['executable_sha256']:raise ValueError('native executable drift')
    file(f'build/v{version}/'+executable.name,executable)
    for name in ('native-exact-build-manifest.json','build.log','compiler-version.log'):file(f'build/v{version}/'+name,build/name)
for name in ('dygrid-update-envelope1-normal.log','dygrid-update-envelope1-observed1.log',
             'dygrid-update-envelope1-formal-normal-replay.log'):
    file('retained/'+name,WORK/name)
tree('retained/v1-first-geometry-observation',WORK/'dygrid-update-envelope1-observed1')
file('retained/pr329-windows-compiler-failure.zip',WORK/'native329-windows-compile-failure1.zip')
file('packager.py',Path(__file__))
for name in ('scripts/replay_frozen_grid_envelope.py','scripts/replay_native_frozen_policy_state.py',
             '.github/workflows/native-frozen-grid-preflight.yml','docs/frozen-grid-update-envelope.md'):
    file('maintained-source/'+name,ROOT/name)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
receipt={
 'version':'frozen-grid-update-envelope-v2-evidence','native_v2_source_head':'510576a56fc0ef077d7ac22034ea29d5d2ffb4dc',
 'maintained_replay_head':head,'scope':'provisional architecture envelope; raw-update producer not implemented or admitted',
 'native_v2_executable_sha256':'7bc08329cecd655dc71f17be63b34d1c89a802c2cddfecd0bb28cd765979f3d7',
 'formal_modes':['normal','optimized'],'tests_per_mode':2,'native_preflight_calls_per_mode':1,
 'forecasts_per_mode':5040,'native_policy_imports':0,'native_rank_calls':0,'native_contractions':0,'native_updates':0,'training_iterations':0,
 'update_admitted':False,'saved_replay_candidate_calls':0,'archived_source_executed':False,
 'retained_v1':'Superseded incomplete design omitted eight prefix marginal queries and retained results; equation agreement did not establish completeness',
 'v2_correction':{'prepared_prefix_fold_queries':8,'chance_work':5040,'parent_work':512,'entries':64,'payload_bits':5104},
 'retained_refusal':'source-cleanliness guard stopped before child launch while independent census was uncommitted',
 'retained_pr329_compiler_failure':{'job_id':135227084973,'artifact_id':14484101575,'archive_sha256':'e3bd78507b1a1cb210c4235c4e2c292b6be7fbd08438169b1062ec5b514932d4',
    'compiler_exit':3221225725,'paired_success_job':135227062893,'isolated_retry_success_job':135231850843,
    'note':'MSVC stack-overflow exit, original build.log contains only translation-unit name; no source change or full-workflow rerun'},
 'maximum':json.loads((WORK/'dygrid-update-envelope2-formal-normal-replay.log').read_bytes())['maximum'],
 'system_build_inputs':'SDK/runtime/standard headers are environmental, not exhaustively attested; no bit reproducibility claim',
}
add('receipt.json',(json.dumps(receipt,indent=2)+'\n').encode())
members={name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(files.items())}
add('members.json',(json.dumps(members,indent=2)+'\n').encode())
PACKET.mkdir(parents=True,exist_ok=False);archive=PACKET/'verification.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or set(z.namelist())!=set(files):raise ValueError('archive CRC/members')
    for name,expected in members.items():
        raw=z.read(name)
        if len(raw)!=expected['bytes'] or sha(raw)!=expected['sha256']:raise ValueError('archive member drift')
manifest={**receipt,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'archive_members':len(files),
          'archive_expanded_bytes':sum(map(len,files.values()))}
(PACKET/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
