from pathlib import Path
import json
import subprocess
from tests.test_native_exact_reach import authenticate
root=Path.cwd()
exe=(root/"../dyaverage-factor-opt1/native-virtual-dyadic-training-factored-average-probe.exe").resolve()
initial=authenticate(exe,root,"virtual-dyadic-training-factored-average")
observed=subprocess.run([str(exe)],input=b"DYADIC_T2_V1 FORECAST_ELEVEN\n",
                        capture_output=True,timeout=30,check=True)
if observed.stderr: raise ValueError("forecast stderr")
if authenticate(exe,root,"virtual-dyadic-training-factored-average")!=initial:
    raise ValueError("source or executable drift")
out=root/"../dyaverage-factor-forecast1"
out.mkdir()
(out/"native.json").write_bytes(observed.stdout)
(out/"process.json").write_text(json.dumps({"returncode":observed.returncode,
    "observed_exit":True,"stderr_bytes":len(observed.stderr),"training_invocations":0})+"\n")

