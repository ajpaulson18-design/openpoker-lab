from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
from tests.test_native_exact_reach import authenticate
ROOT=Path.cwd()
out=(ROOT/"../dyaverage-factor-controls2").resolve()
out.mkdir()
state=(ROOT/"../dyaverage-factor-state2/native-virtual-dyadic-state-controls.exe").resolve()
packed=(ROOT/"../dyaverage-factor-packed1/native-packed-signed-update-controls.exe").resolve()
initial=authenticate(state,ROOT,"virtual-dyadic-state-controls")
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
if subprocess.check_output(["git","status","--porcelain"]): raise ValueError("dirty source before controls")
records=[]
for mode,flags in (("normal",[]),("optimized",["-O"])):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",
             OPENPOKER_NATIVE_VIRTUAL_DYADIC_STATE_EXE=str(state),
             OPENPOKER_NATIVE_VIRTUAL_DYADIC_STATE_CONTROL_DIR=str(out/("state-"+mode)),
             OPENPOKER_NATIVE_PACKED_SIGNED_UPDATE_EXE=str(packed))
    cmd=[sys.executable,"-B",*flags,"-m","unittest",
         "tests.test_native_virtual_dyadic_state","tests.test_native_packed_signed_update",
         "tests.test_native_training_study_checks","tests.test_virtual_dyadic_factored_average_census","-v"]
    with (out/(mode+".stdout.log")).open("xb") as stdout,(out/(mode+".stderr.log")).open("xb") as stderr:
        p=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=env,timeout=180)
    record={"mode":mode,"command":cmd,"returncode":p.returncode,"actual_exit_observed":True}
    records.append(record)
    (out/"process.json").write_text(json.dumps(records,indent=2)+"\n")
    if p.returncode: raise ValueError("control failure: "+mode)
    print(mode+" controls passed",flush=True)
if authenticate(state,ROOT,"virtual-dyadic-state-controls")!=initial:
    raise ValueError("native State source or executable drift")
if subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()!=head or subprocess.check_output(["git","status","--porcelain"]):
    raise ValueError("source changed during controls")
(out/"identity.json").write_text(json.dumps({"source_head":head,
    "state_manifest_sha256":hashlib.sha256(initial[0]).hexdigest(),"state_source_sha256":initial[1]["source_sha256"],
    "native_training_invocations":0,"tests_per_mode":21,"skips":0},indent=2)+"\n")

