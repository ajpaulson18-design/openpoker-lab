from collections import Counter
from itertools import combinations, permutations
from functools import lru_cache
import json
from tests.full_deck_public_chance_reference import PROOF9
from tests.virtual_dyadic_training_reference import build_reference_template, _template_case, scaled_proof9_ranges

from pathlib import Path

def projection(cards, cap_probes=None, *, sparse=False):
    ranges = tuple(tuple(set(hand) for hand,_ in side) for side in scaled_proof9_ranges())
    legal = [(a,b) for a in ranges[0] for b in ranges[1] if a.isdisjoint(b)]
    prefixes = {k:set() for k in (0,3,4,5)}
    for a,b in legal:
        left = set(cards)-a-b
        for flop in combinations(sorted(left),3):
            for reveal in permutations(left-set(flop),2):
                board = flop+reveal
                for k in prefixes:
                    prefixes[k].add(board[:k])
    pops = {k:Counter(tuple(sum(h.isdisjoint(board) for h in side) for side in ranges) for board in boards)
            for k,boards in prefixes.items()}
    words=lambda bits:max(1,(bits+63)//64)
    add=lambda bits:2+3*words(bits)
    copy=lambda bits:1+2*words(bits)
    mul=lambda a,b:2+2*(words(a)+words(b))+words(a)*words(b)
    board_sets = {frozenset(board) for board in prefixes[5]}
    planes = len(board_sets)
    rank_calls = sum(h.isdisjoint(board) for side in ranges for h in side for board in board_sets)
    lookup = 2*planes if cap_probes is None else 2*cap_probes
    counts = Counter()

    @lru_cache(None)
    def cost(show,k,seat,exp):
        reach=exp+1
        acc=0
        for n,count in pops[k].items():
            own,opp=n[seat],n[1-seat]
            bucket=8+reach+max(0,opp-1).bit_length()
            unit=22+k+2*(4+2*words(reach))
            dynamic=(12+opp*mul(4,reach)+53*(2+own if show else 1)
                     +(9 if show else 3)*opp*add(bucket)
                     +own*((12 if show else 3)*add(bucket)+mul(4,bucket)+copy(bucket+4)+2*words(bucket))+128)
            if sparse:
                dynamic=(12+opp*mul(4,reach)+own*opp*((16 if show else 8)+add(bucket))
                         +own*mul(4,bucket)+2*(copy(bucket+4)+2))
            acc+=count*(unit+dynamic+(lookup if show else 0))
        return acc

    template=build_reference_template(_template_case())
    def walk(i,depth,first):
        n=template.nodes[i]
        if n.phase=='decision':
            p=n.state.player
            depth=tuple(x+int(seat==p) for seat,x in enumerate(depth))
            exp=1 if len(n.edges)==2 else 2 if len(n.edges)==4 else 52
            first=tuple(x+(exp if seat==p else 0) for seat,x in enumerate(first))
        elif n.phase=='reveal':
            base=sum(cost(False,n.state.board_length,seat,0) for seat in (0,1))
            counts['visible_reveal']+=len(prefixes[n.state.board_length])
            yield base,base
        else:
            show=n.phase=='showdown'
            size=5 if show else n.street
            if show:
                counts['showdown']+=len(prefixes[5])
                if n.street<5:
                    counts['hidden_showdown']+=len(prefixes[5])
            else:
                counts['fold']+=len(prefixes[n.street])
            yield tuple(sum(cost(show,size,seat,exp[1-seat]) for seat in (0,1))
                        for exp in (first,tuple(52*d for d in depth)))
        for edge in n.edges:
            yield from walk(edge.child,depth,first)

    base=sum(cost(False,0,seat,0) for seat in (0,1))
    first,grid=(sum(x)+base for x in zip(*walk(template.root,(0,0),(0,0))))
    fixed=65536+4096*rank_calls+planes*(512+64+4*planes)
    return {'deck_cards':len(cards),'prefixes':[len(p) for p in prefixes.values()],
            'rank_planes':planes,'expected_rank_calls':rank_calls,'projection_rank_calls':0,
            'first_sweep':first,'grid_sweep':grid,'rank_and_setup':fixed,
            'two_sweeps':first+grid+fixed,'lookup_work_per_query':lookup,
            'two_sweep_lookup_work':4*counts['showdown']*lookup,'contractions_per_target_sweep':dict(counts)}


if __name__=='__main__':
    result={}
    for n in (9,10,11):
        cards=(*PROOF9,*range(n-9))
        result[str(n)]={'buckets':projection(cards),'sparse_pairs':projection(cards,sparse=True)}
    path=Path.cwd().parent/'dyadic-sparse-chance-projection1.json'
    with path.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print(json.dumps({k:{label:record['two_sweeps'] for label,record in row.items()} for k,row in result.items()},sort_keys=True))