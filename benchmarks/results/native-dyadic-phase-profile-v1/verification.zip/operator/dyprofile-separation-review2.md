# Independent conditional-build review

Reviewed source commit: `53a4072c3bd055e1fca9b787556da170af3c3c6d`.

Exact baseline: `927e4a34563c76d83ba9fc6b5a923ef3a7c1bfe3` (`927e4a3`), using `TRAIN_TEN_BOUNDED_DIVISION`.

Conclusion: no actionable correctness, accounting, source-binding, or conditional-control-flow finding was identified in this review.

The review covered the conditional Driver hooks and probe collection, the dedicated native build target and compiler flag, host target selection and build binding, and malformed-request/CI guards. No repository files were changed by the reviewer.

Token comparisons were repeated directly against the two committed source versions. The comparison selected the normal branches of `OPENPOKER_TRAINING_PHASE_DIAGNOSTICS`, removed comments, and compared lexical word/punctuation tokens while ignoring whitespace. This was a targeted source comparison, not a compiler preprocessor or binary-equivalence proof.

- Entire `native/virtual_dyadic_training.hpp`: 26,108 tokens in each version, identical.
- `native/virtual_dyadic_training_probe.cpp`, from `int main(` through the end of the file: 3,064 tokens in each version, identical.

The normal Driver constructor and three-argument `train()` signature are restored. Diagnostic includes, namespace alias, hook parameter, local sweep marker and callback calls are conditional. The probe's additional `TrainMethod` assertion and type-traits include are compile-time checks; the assertion distinguishes the three-argument normal interface from the four-argument diagnostic interface.

Only `virtual-dyadic-training-profile` adds `/DOPENPOKER_TRAINING_PHASE_DIAGNOSTICS` on Windows or `-DOPENPOKER_TRAINING_PHASE_DIAGNOSTICS` on POSIX. Its executable name is distinct. The normal target does not receive that definition. The host consistently selects and binds the dedicated target when profiling is requested, including before/after execution and final build verification. The shared captured source inventory may include diagnostic headers; this does not mean the normal compiler includes them.

The diagnostic path preserves the reviewed exact-mode/argument guard, composed resource admission before training, 36 coarse events, 43 clock reads, and sidecar serialization after the measured receipts interval. No per-row timer was introduced. Training cleanup remains inside the outer train-call duration and its residual. The normal executable rejects the canonical profiling switch. Diagnostic malformed-scope guards run in the phase-profile workflow; the existing full-deck workflow runs normal admission guards. Both native build variants are built in CI.

Limits: this establishes source-level separation and reviewed control-flow/resource consistency. It does not establish identical generated machine code, identical binary layout, a performance improvement, a hardware-counter result, or a causal explanation for timing differences. Fresh source-frozen parity/replay and the predeclared timing gates remain necessary. Earlier missed studies and their artifacts remain valid preserved evidence.

If revised profiling confirms that inclusive training walks dominate, the next architectural step is bounded stack sampling of the hook-free winning baseline. Attribute samples to Chance, State/paging, History/routing, parent traversal/arithmetic, and runtime/I/O; retain unresolved samples and raw evidence. Walk wall time alone cannot distinguish those owners. Use that attribution to choose one owner-level change with an explicit exactness contract and a whole-run validation gate. Do not resume classifier tuning or infer a wider-game scaling result from this fixture.
