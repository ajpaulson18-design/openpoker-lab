"""Independently replay the first disabled profiling-study policy output."""
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'dyprofile-src2'
STUDY=WORK/'dyprofile-on-cohort2'
TIMING=WORK/'dyprofile-timing2'
OUT=WORK/'dyprofile-off-replay2'
HEAD='53a4072c3bd055e1fca9b787556da170af3c3c6d'
helpers=runpy.run_path(str(WORK/'trusted-virtual-dyadic-training-launch-v43.py'))
git,snapshot,save,sha,observe=(helpers[n] for n in ('git','snapshot','save','sha','observe'))

def require(ok,message):
    if not ok:raise RuntimeError(message)

def read(path):return json.loads(path.read_bytes())

def main():
    OUT.mkdir(exist_ok=False)
    require(sys.dont_write_bytecode,'source replay requires no bytecode')
    require(git(SOURCE,'rev-parse','HEAD').decode().strip()==HEAD,'replay source HEAD differs')
    before=snapshot(SOURCE)
    require(before=={n:r['raw_sha256'] for n,r in read(STUDY/'source.json')['files'].items()},
            'replay raw source differs')
    save(OUT/'source-before.json',before)
    timing=read(TIMING/'result.json')
    require(read(TIMING/'terminal.json')['status']=='complete' and timing['training_invocations']==32 and
            timing['all_complete_streams_and_checkpoint_images_exact'],'timing study incomplete')
    native=TIMING/'code_layout/pair-1-checked'
    first=read(native/'verified.json')
    current=read(STUDY/'result.json')
    compact=native/'process/stdout.bin'
    require(first['profile_enabled'] is False and sha(compact)==current['compact_sweep_capture']['retained_sha256'],
            'disabled compact input differs')
    sys.path.insert(0,str(SOURCE))
    from scripts.virtual_dyadic_compact_wire import expand_compact
    expanded=OUT/'expanded.bin'
    with compact.open('rb') as reader,expanded.open('x+b') as writer:
        expansion=expand_compact(reader,writer,source_size=compact.stat().st_size)
    digest=sha(expanded)
    require(digest==current['saved_only_replay']['saved_output_sha256'] and
            expanded.read_bytes()==(STUDY/'train_ten_bounded_division/expanded.bin').read_bytes(),
            'disabled expanded bytes differ')
    command=read(STUDY/'saved-review-command.json')
    command[command.index('--receipt')+1]=str(OUT/'bootstrap.json')
    command[command.index('--saved')+1]=str(expanded)
    command[command.index('--sha256')+1]=digest
    observed=observe(command,SOURCE,OUT)
    replay=json.loads((OUT/'stdout.log').read_bytes())
    require(replay['status']=='saved_two_sweep_exact_replay_pass' and replay['native_producer_calls']==0,
            'disabled saved-only replay failed')
    baseline=current['saved_only_replay']
    require({k:v for k,v in replay.items() if k!='duration_seconds'}==
            {k:v for k,v in baseline.items() if k!='duration_seconds'},'enabled/disabled replay differs')
    boot=read(OUT/'bootstrap.json')
    require(boot['initial_cache_scan']['project_bytecode_files']==0 and
            boot['final_cache_scan']['project_bytecode_files']==0,'bytecode appeared')
    for name,identity in boot['compiled'].items():
        raw=(SOURCE/name).read_bytes()
        committed=git(SOURCE,'show',HEAD+':'+name)
        require(before.get(name)==identity and sha(SOURCE/name)==identity and
                (raw==committed or raw.replace(b'\r\n',b'\n')==committed),'replay closure differs')
    imported={}
    for module in tuple(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(SOURCE):
                name=path.relative_to(SOURCE).as_posix()
                require(before.get(name)==sha(path),'parent import closure differs')
                imported[name]=before[name]
    after=snapshot(SOURCE)
    require(before==after,'source drift during disabled replay')
    save(OUT/'source-after.json',after)
    result={'source_head':HEAD,'status':'disabled_saved_only_replay_complete',
            'native_training_invocations':0,'exit':observed,'raw_source_stable':True,
            'compact_sha256':sha(compact),'expanded_sha256':digest,'expansion':expansion,
            'compiled_source_closure':boot['compiled'],'parent_imported_source_closure':imported,
            'saved_only_replay':replay}
    save(OUT/'result.json',result)
    print(json.dumps({'status':result['status'],'returncode':observed['returncode']}))
if __name__=='__main__':main()
