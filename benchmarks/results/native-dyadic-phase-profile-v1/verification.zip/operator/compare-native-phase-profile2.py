"""Alternate the two admitted ten-card modes using one authenticated executable."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
from statistics import median
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'dyprofile-src1'
STUDY=WORK/'dyprofile-on-cohort1'
PUBLICATION=WORK/'dyprofile-repo'
OUT=WORK/'dyprofile-timing1'
HEAD='aeaaa2e0ddac69ee293ee9f20835256b80aa7a9e'
PAIRS=8

def require(condition,message):
    if not condition:
        raise RuntimeError(message)

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    with path.open('rb') as stream:
        return {'bytes':path.stat().st_size,'sha256':file_digest(stream,'sha256').hexdigest()}

def save(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write('\n')

def snapshot(expected):
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD,
            'timing source HEAD differs')
    require(not subprocess.check_output(['git','-c','core.fsmonitor=false','status',
                                        '--porcelain=v1','--untracked-files=all'],cwd=SOURCE),
            'timing source must stay clean')
    actual={}
    for name,record in expected.items():
        path=SOURCE/name
        require(path.resolve().is_relative_to(SOURCE) and not path.is_symlink(),
                'timing source path differs')
        digest=identity(path)['sha256']
        require(digest==record['raw_sha256'],'timing source raw bytes differ')
        actual[name]=digest
    return actual


PRISTINE_SOURCE=WORK/'dydivision-src1'
PRISTINE_STUDY=WORK/'dydivision-cohort1'
PRISTINE_HEAD='e8a22cfb46d4c188a7468500f261e0c0e7a77d81'
BASE_HEAD='927e4a34563c76d83ba9fc6b5a923ef3a7c1bfe3'

def pristine_snapshot(expected):
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRISTINE_SOURCE).decode().strip()==PRISTINE_HEAD,
            'pristine HEAD differs')
    require(not subprocess.check_output(['git','-c','core.fsmonitor=false','status','--porcelain=v1',
                                        '--untracked-files=all'],cwd=PRISTINE_SOURCE),'pristine source must stay clean')
    actual={name:identity(PRISTINE_SOURCE/name)['sha256'] for name in expected}
    require(actual=={name:record['raw_sha256'] for name,record in expected.items()},'pristine raw source differs')
    return actual

def require_build(build,source_hashes):
    exe=Path(build['executable'])
    require(identity(exe)['sha256']==build['executable_sha256'] and
            all(source_hashes.get(name)==digest for name,digest in build['source_sha256'].items()),
            'build binary or source closure differs')
    return exe

def compare_artifacts(target,current):
    require(read(target/'compact-wire.json')==current['compact_encoding_receipt'],'encoder receipt differs')
    require(read(target/'factored-execution.json')==current['factored_execution'],'factored receipt differs')
    require(read(target/'equal-quantizer.json')==current['equal_quantizer'],'equal quantizer differs')
    require(read(target/'page-images/paging.json')==current['paging']['counts'],'pager counts differ')
    require(read(target/'page-images/quantizer.json')==current['quantizer'],'division receipt differs')
    for folder in ('page-images','page-images-rows'):
        reference=STUDY/folder
        require({p.name for p in (target/folder).iterdir()}=={p.name for p in reference.iterdir()},
                'artifact inventory differs')
        for path in reference.iterdir():
            if path.name in ('committed.bin','staged.bin'):
                require(identity(target/folder/path.name)==current['paging']['images'][path.name],
                        'checkpoint image differs')
            else:
                require(identity(target/folder/path.name)==identity(path),'artifact raw bytes differ')

def main():
    OUT.mkdir(exist_ok=False)
    observations=[]
    try:
        require(sys.dont_write_bytecode,'timing must disable project bytecode')
        require(shutil.disk_usage(OUT).free>1<<30,'timing disk reserve')
        expected=read(STUDY/'source.json')['files']
        before=snapshot(expected)
        save(OUT/'source-before.json',before)
        pristine_expected=read(PRISTINE_STUDY/'source.json')['files']
        pristine_before=pristine_snapshot(pristine_expected)
        save(OUT/'pristine-source-before.json',pristine_before)
        changed=subprocess.check_output(['git','diff','--name-only',PRISTINE_HEAD,BASE_HEAD],cwd=SOURCE).decode().splitlines()
        require(changed and all(name.startswith(('docs/','benchmarks/results/')) for name in changed),
                'pristine executable is not the unhooked production baseline')
        build=read(STUDY/'build/native-exact-build-manifest.json')
        pristine_build=read(PRISTINE_STUDY/'build/native-exact-build-manifest.json')
        exe=require_build(build,before)
        pristine_exe=require_build(pristine_build,pristine_before)
        from zipfile import ZipFile
        published=SOURCE/"benchmarks/results/native-dyadic-bounded-policy-division-v1"
        published_manifest=read(published/"manifest.json")
        require(identity(published/"verification.zip")["sha256"]==published_manifest["archive"]["sha256"],
                "published pristine archive differs")
        with ZipFile(published/"verification.zip") as archive:
            require(archive.read("cohort/build/native-exact-build-manifest.json")==
                    (PRISTINE_STUDY/"build/native-exact-build-manifest.json").read_bytes(),
                    "pristine build manifest differs from published evidence")
        for name,digest in pristine_build['source_sha256'].items():
            committed=subprocess.check_output(['git','show',BASE_HEAD+':'+name],cwd=SOURCE)
            actual=(PRISTINE_SOURCE/name).read_bytes()
            require(actual==committed or actual.replace(b'\r\n',b'\n')==committed,
                    'pristine native closure differs from base commit')
        require(build['compiler_sha256']==pristine_build['compiler_sha256'] and
                build['dependency_archive_sha256']==pristine_build['dependency_archive_sha256'],
                'timing compiler or bundled dependency differs')
        current=read(STUDY/'result.json')
        previous=read(PRISTINE_STUDY/'result.json')
        require(current['head']==HEAD and current['training_invocations']==1 and
                read(STUDY/'terminal.json')['status']=='complete' and
                read(WORK/'dyprofile-on-launch1/completion.json')['returncode']==0,
                'profiled quality study incomplete')
        for field in ('compact_sweep_capture','paging','quantizer','policy_spill','row_directory',
                      'factored_execution','equal_quantizer','rank_index','compact_encoding_receipt'):
            require(current[field]==previous[field],'pristine/reference artifact differs: '+field)
        sys.path.insert(0,str(SOURCE))
        from tests.virtual_frozen_run_control import run_bounded_dyadic_probe
        from scripts.verify_training_phase_profile import load_profile,verify_profile
        save(OUT/'configuration.json',{
            'source_head':HEAD,'pristine_source_head':PRISTINE_HEAD,'pristine_base_head':BASE_HEAD,
            'source_executable_sha256':build['executable_sha256'],
            'pristine_executable_sha256':pristine_build['executable_sha256'],
            'pairs_per_comparison':PAIRS,'comparisons':['instrumentation','code_layout'],
            'order':[['baseline','checked'] if k%2==0 else ['checked','baseline'] for k in range(PAIRS)],
            'median_ratio_limit':1.01,'scope':'one Windows host, complete native calls and streamed transport',
            'phase_scope':'walk times are inclusive; no per-owner attribution',
            'quality_gate':None})
        results={}
        for comparison in ('instrumentation','code_layout'):
            folder=OUT/comparison
            folder.mkdir()
            runs=[]
            for pair in range(PAIRS):
                order=('baseline','checked') if pair%2==0 else ('checked','baseline')
                for mode in order:
                    target=folder/f'pair-{pair+1}-{mode}'
                    target.mkdir()
                    instrumented=comparison=='instrumentation' and mode=='checked'
                    selected=pristine_exe if comparison=='code_layout' and mode=='baseline' else exe
                    selected_build=pristine_build if selected==pristine_exe else build
                    require(identity(selected)['sha256']==selected_build['executable_sha256'],'binary drift')
                    command=[str(selected),str(target/'page-images')]
                    if instrumented:command.append('--profile-phases')
                    observed=run_bounded_dyadic_probe(command,'TRAIN_TEN_BOUNDED_DIVISION',target/'process')
                    require(observed['actual_exit_observed'] and observed['returncode']==0 and
                            not observed['failures'] and observed['automatic_retries']==0,
                            'native timing call failed; preserve first result')
                    require(identity(selected)['sha256']==selected_build['executable_sha256'],'binary drift after call')
                    capture=current['compact_sweep_capture']
                    native=observed['streams'][0]
                    require(native['sha256']==capture['retained_sha256'] and
                            native['wire_sha256']==capture['wire_sha256'] and
                            native['saved_bytes']==capture['contract']['retained_bytes'] and
                            native['observed_bytes']==capture['contract']['wire_bytes'],
                            'timed native output differs')
                    compare_artifacts(target,current)
                    record={'comparison':comparison,'pair':pair+1,'mode':mode,
                            'profile_enabled':instrumented,'executable_sha256':selected_build['executable_sha256'],
                            'directory':target.relative_to(OUT).as_posix(),
                            'seconds':observed['duration_seconds'],'memory':observed['memory'],
                            'retained_sha256':native['sha256'],'wire_sha256':native['wire_sha256']}
                    sidecar=target/'phase-profile.json'
                    if instrumented:
                        summary=verify_profile(load_profile(sidecar),current['admission'])
                        totals={}
                        for item in summary['phases']:
                            totals[item['phase']]=totals.get(item['phase'],0)+item['ns']
                        ranking=sorted(totals,key=lambda name:(-totals[name],name))
                        record['phase_totals_ns']=totals
                        record['phase_ranking']=ranking
                        record['phase_fractions']={name:ns/summary['measured_interval_ns'] for name,ns in totals.items()}
                        record['phase_summary']=summary
                        save(target/'verified-phase-summary.json',summary)
                    else:require(not sidecar.exists(),'unprofiled call wrote phase diagnostics')
                    observations.append(record);runs.append(record)
                    save(target/'verified.json',record)
                    print(json.dumps({k:record[k] for k in ('comparison','pair','mode','seconds')}),flush=True)
            times={mode:[r['seconds'] for r in runs if r['mode']==mode] for mode in ('baseline','checked')}
            ratios=[next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='checked')/
                    next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='baseline') for p in range(1,PAIRS+1)]
            results[comparison]={'pairs':PAIRS,'training_invocations':len(runs),'seconds':times,
                'median_seconds':{mode:median(values) for mode,values in times.items()},
                'paired_checked_to_baseline_ratios':ratios,'median_paired_ratio':median(ratios),
                'overhead_acceptance':median(ratios)<=1.01,'observations':runs}
            print(json.dumps({'comparison':comparison,'median_paired_ratio':median(ratios)}),flush=True)
        enabled=[r for r in observations if r['profile_enabled']]
        top=[r['phase_ranking'][0] for r in enabled]
        stable=len(set(top))==1
        fractions={name:median(r['phase_fractions'][name] for r in enabled) for name in enabled[0]['phase_totals_ns']}
        closure={}
        for module in tuple(sys.modules.values()):
            filename=getattr(module,'__file__',None)
            if filename:
                path=Path(filename).resolve()
                if path.is_relative_to(SOURCE):
                    name=path.relative_to(SOURCE).as_posix()
                    require(name in before and identity(path)['sha256']==before[name],'imported source differs')
                    closure[name]=before[name]
        after=snapshot(expected);pristine_after=pristine_snapshot(pristine_expected)
        require(before==after and pristine_before==pristine_after,'source drift')
        save(OUT/'source-after.json',after);save(OUT/'pristine-source-after.json',pristine_after)
        result={'status':'phase_profile_timing_complete','source_head':HEAD,
            'pristine_source_head':PRISTINE_HEAD,'training_invocations':len(observations),
            'comparisons':results,'phase_top_by_run':top,'phase_ranking_stable':stable,
            'median_phase_fractions':fractions,'raw_source_stable':True,'pristine_raw_source_stable':True,
            'imported_source_closure':closure,'all_complete_streams_and_checkpoint_images_exact':True,
            'profiling_acceptance':stable and all(r['overhead_acceptance'] for r in results.values()),
            'quality_gate':None,'disabled_saved_replay':'required separately',
            'limits':'one Windows host, eight pairs per comparison; other host load uncontrolled'}
        save(OUT/'result.json',result)
        save(OUT/'terminal.json',{'status':'complete','training_invocations':len(observations)})
        print(json.dumps({k:result[k] for k in ('profiling_acceptance','phase_top_by_run','median_phase_fractions')}),flush=True)
    except BaseException as error:
        save(OUT/'terminal.json',{'status':'failed','training_invocations_completed':len(observations),
                                'first_error':type(error).__name__+': '+str(error)})
        raise

if __name__=='__main__':main()
