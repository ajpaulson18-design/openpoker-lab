"""Package both immutable phase studies, misses, raw source closure and parity."""
from hashlib import file_digest,sha256
import json
from math import isfinite
from pathlib import Path
import runpy
from statistics import median
import subprocess
from zipfile import ZipFile,ZIP_DEFLATED

WORK=Path(__file__).resolve().parent
ROOT=WORK/'dyprofile-repo'
RESULT=ROOT/'benchmarks/results/native-dyadic-phase-profile-v1'
H1='aeaaa2e0ddac69ee293ee9f20835256b80aa7a9e'
HC='6a6cc450feaf88bbd10dab94da296744556e33d6'
H2='53a4072c3bd055e1fca9b787556da170af3c3c6d'
files={}
closures={}
operator_provenance={}
def require(ok,message):
 if not ok:raise RuntimeError(message)
def read(path):return json.loads(path.read_bytes())
def digest(path):
 with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def add(name,path):
 require(name not in files and path.is_file(),'duplicate or absent artifact: '+name)
 files[name]=path
def tree(prefix,folder,filter=lambda p:True):
 require(folder.is_dir(),'artifact folder absent: '+str(folder))
 for p in sorted(folder.rglob('*')):
  if p.is_file() and filter(p.relative_to(folder)):add(prefix+'/'+p.relative_to(folder).as_posix(),p)
def stable(folder,expected=None):
 before,after=(read(folder/('source-'+when+'.json')) for when in ('before','after'))
 require(before==after and (expected is None or before==expected),'source map drift: '+str(folder))
 return before
def archive_source(label,source,head,hashes,names):
 require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head,'source HEAD differs')
 closure={}
 for name in sorted(names):
  path=source/name
  require(name in hashes and digest(path)==hashes[name],'archived raw source differs: '+name)
  committed=subprocess.check_output(['git','show',head+':'+name],cwd=source)
  raw=path.read_bytes()
  require(raw==committed or raw.replace(b'\r\n',b'\n')==committed,'committed source differs: '+name)
  add(label+'/source/'+name,path);closure[name]=hashes[name]
 closures[label]={'head':head,'raw_sha256':closure}
def observed_exit(record,label):
 require(record.get('actual_exit_observed') is True and type(record.get('returncode')) is int and
         record['returncode']==0 and record.get('failures')==[],label+' process incomplete')
 if 'automatic_retries' in record:require(record['automatic_retries']==0,label+' retried')

def closure_check(closure,hashes,label):
 require(type(closure) is dict and closure and all(hashes.get(n)==h for n,h in closure.items()),label+' source closure differs')

def build_check(path,hashes,target=None):
 b=read(path)
 require(b.get('contract')=='native-exact-build-v1' and (target is None or b.get('target')==target),'build target/contract differs')
 require(digest(Path(b['executable']))==b['executable_sha256'],'executable differs')
 require(digest(Path(b['compiler']))==b['compiler_sha256'],'compiler differs')
 closure_check(b['source_sha256'],hashes,'build')
 macros=[flag for flag in b['flags'] if 'OPENPOKER_TRAINING_PHASE_DIAGNOSTICS' in flag]
 require(macros in (['/DOPENPOKER_TRAINING_PHASE_DIAGNOSTICS'],['-DOPENPOKER_TRAINING_PHASE_DIAGNOSTICS'])
         if b['target']=='virtual-dyadic-training-profile' else not macros,'diagnostic compiler flag differs')
 require(b['command'][0]==b['compiler'] and b['command'][1:1+len(b['flags'])]==b['flags'],'compiler command/flags differ')
 return b

def timing_check(folder,result,final,config,build,standard,pristine,verify_profile):
 require(config['pairs_per_comparison']==8 and config['median_ratio_limit']==1.01 and
         config['comparisons']==['instrumentation','code_layout'] and
         config['order']==[['baseline','checked'] if k%2==0 else ['checked','baseline'] for k in range(8)],
         'timing predeclared configuration differs')
 require(set(result['comparisons'])=={'instrumentation','code_layout'},'timing comparisons differ')
 capture=final['compact_sweep_capture'];enabled=[];acceptances=[]
 for comparison in ('instrumentation','code_layout'):
  summary=result['comparisons'][comparison];runs=summary['observations']
  require(summary['pairs']==8 and summary['training_invocations']==len(runs)==16,'timing comparison census differs')
  expected=[(pair,mode) for pair in range(1,9) for mode in (('baseline','checked') if pair%2 else ('checked','baseline'))]
  require([(r['pair'],r['mode']) for r in runs]==expected,'timing pair order differs')
  for item in runs:
   pair,mode=item['pair'],item['mode'];instrumented=comparison=='instrumentation' and mode=='checked'
   relative=comparison+'/pair-'+str(pair)+'-'+mode
   require(item['comparison']==comparison and item['directory']==relative and item['profile_enabled'] is instrumented,'timing mode differs')
   run=folder/relative;process=read(run/'process/process.json');observed_exit(process,'timing')
   require(type(item['seconds']) in (int,float) and isfinite(item['seconds']) and item['seconds']>0 and
           item['seconds']==process['duration_seconds'] and item['memory']==process['memory'],'timing duration/memory differs')
   selected=pristine if comparison=='code_layout' and mode=='baseline' else standard if comparison=='code_layout' else build
   require(item['executable_sha256']==selected['executable_sha256'],'timing executable differs')
   native=process['streams'][0]
   require(item['retained_sha256']==native['sha256']==capture['retained_sha256']==digest(run/'process/stdout.bin') and
           item['wire_sha256']==native['wire_sha256']==capture['wire_sha256'] and
           native['saved_bytes']==capture['contract']['retained_bytes'] and native['observed_bytes']==capture['contract']['wire_bytes'] and
           process['sweep_capture']==capture,'timing retained/wire/frame parity differs')
   require((run/'process/stderr.bin').read_bytes()==b'','timing stderr differs')
   for name,identity in final['paging']['images'].items():
    path=run/'page-images'/name
    require(path.stat().st_size==identity['bytes'] and digest(path)==identity['sha256'],'timing checkpoint bytes differ')
   for name,key in (('compact-wire.json','compact_encoding_receipt'),('factored-execution.json','factored_execution'),('equal-quantizer.json','equal_quantizer')):
    require(read(run/name)==final[key],'timing execution receipt differs')
   for directory in ('page-images','page-images-rows'):
    reference=folder.parent/('dyprofile-on-cohort'+folder.name[-1])/directory
    require({p.name for p in (run/directory).iterdir()}=={p.name for p in reference.iterdir()},'timing receipt inventory differs')
    for path in reference.iterdir():
     if path.name not in ('committed.bin','staged.bin'):
      require(digest(run/directory/path.name)==digest(path),'timing owner receipt bytes differ')
   require(read(run/'verified.json')==item,'timing saved observation differs')
   sidecar=run/'phase-profile.json'
   if instrumented:
    phase=verify_profile(read(sidecar),final['admission'])
    require(item['phase_summary']==phase==read(run/'verified-phase-summary.json'),'timing phase summary differs')
    totals={}
    for leaf in phase['phases']:totals[leaf['phase']]=totals.get(leaf['phase'],0)+leaf['ns']
    ranking=sorted(totals,key=lambda n:(-totals[n],n))
    fractions={name:ns/phase['measured_interval_ns'] for name,ns in totals.items()}
    require(item['phase_totals_ns']==totals and item['phase_ranking']==ranking and item['phase_fractions']==fractions,'timing phase ranking differs')
    enabled.append(item)
   else:require(not sidecar.exists(),'disabled timing wrote phase profile')
  times={mode:[r['seconds'] for r in runs if r['mode']==mode] for mode in ('baseline','checked')}
  ratios=[next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='checked')/
          next(r['seconds'] for r in runs if r['pair']==p and r['mode']=='baseline') for p in range(1,9)]
  accepted=median(ratios)<=config['median_ratio_limit'];acceptances.append(accepted)
  require(summary['seconds']==times and summary['median_seconds']=={m:median(v) for m,v in times.items()} and
          summary['paired_checked_to_baseline_ratios']==ratios and summary['median_paired_ratio']==median(ratios) and
          summary['overhead_acceptance'] is accepted,'timing aggregate or acceptance differs')
 top=[r['phase_ranking'][0] for r in enabled];stable_top=len(set(top))==1
 fractions={name:median(r['phase_fractions'][name] for r in enabled) for name in enabled[0]['phase_totals_ns']}
 require(len(enabled)==8 and result['phase_top_by_run']==top and result['phase_ranking_stable'] is stable_top and
         result['median_phase_fractions']==fractions and result['profiling_acceptance'] is (stable_top and all(acceptances)),
         'timing final acceptance/ranking differs')
def main():
 operator_input=read(WORK/'dyprofile-package-final-input.json')
 require(operator_input['operator_sha256']==digest(Path(__file__)),'packager execution source differs')
 add('operator/package-input.json',WORK/'dyprofile-package-final-input.json')
 baseline=ROOT/'benchmarks/results/native-dyadic-bounded-policy-division-v1'
 bm=read(baseline/'manifest.json')
 require(digest(baseline/'verification.zip')==bm['archive']['sha256'],'baseline archive differs')
 with ZipFile(baseline/'verification.zip') as z:
  published_inventory=json.loads(z.read('inventory.json'))
  for name in z.namelist():
   if name.startswith('source/') or name=='cohort/build/native-exact-build-manifest.json':
    require(sha256(z.read(name)).hexdigest()==published_inventory[name]['sha256'],'published baseline member differs')
  published_build_raw=z.read('cohort/build/native-exact-build-manifest.json')
 pristine_folder=WORK/'dydivision-cohort1'
 pristine_frozen=read(pristine_folder/'source.json')
 pristine_hashes={n:v['raw_sha256'] for n,v in pristine_frozen['files'].items()}
 pristine_path=pristine_folder/'build/native-exact-build-manifest.json'
 require(pristine_path.read_bytes()==published_build_raw,'timing baseline build differs from published #309')
 pristine=build_check(pristine_path,pristine_hashes,'virtual-dyadic-training')
 add('baseline/native-exact-build-manifest.json',pristine_path)
 summaries=[]
 for index,head,control_head,control_id,vector_id in ((1,H1,HC,2,2),(2,H2,H2,3,3)):
  prefix='study'+str(index)
  source=WORK/('dyprofile-src'+str(index))
  cohort=WORK/('dyprofile-on-cohort'+str(index))
  launch=WORK/('dyprofile-on-launch'+str(index))
  timing=WORK/('dyprofile-timing'+str(index))
  controls=WORK/('dyprofile-controls'+str(control_id))
  vectors=WORK/('dyprofile-native-vectors'+str(vector_id))
  replay=WORK/('dyprofile-off-replay'+str(index))
  final=read(cohort/'result.json');frozen=read(cohort/'source.json')
  hashes={n:v['raw_sha256'] for n,v in frozen['files'].items()}
  require(final['head']==frozen['head']==head and final['training_invocations']==1 and read(cohort/'terminal.json')['status']=='complete','cohort incomplete')
  source_final=final['source_final']
  require(source_final['head']==head and source_final['raw_bytes_identical'] is True and
          source_final['files']==len(hashes) and source_final['bytes']==frozen['bytes'],'cohort final source differs')
  outer=read(launch/'completion.json');observed_exit(outer,'outer')
  require(outer['head']==head and outer['raw_source_stable'],'outer incomplete')
  operator=read(launch/'operator-launch.json')
  require(operator['head']==head and operator['operator_sha256']==digest(WORK/'trusted-virtual-dyadic-training-launch-v43.py') and
          operator['bootstrap_sha256']==hashes['scripts/run_virtual_frozen_source_only.py'] and
          operator['first_stage_sha256']==sha256(operator['first_stage'].encode()).hexdigest(),'outer operator identity differs')
  operator_provenance['study'+str(index)+'/launch']={'path':'trusted-virtual-dyadic-training-launch-v43.py','recorded_sha256':operator['operator_sha256']}
  stable(launch,hashes);stable(timing,hashes);stable(vectors,hashes);stable(replay,hashes)
  t=read(timing/'result.json');v=read(vectors/'result.json');c=read(controls/'completion.json');r=read(replay/'result.json')
  require(t['status']=='phase_profile_timing_complete' and t['source_head']==head and t['training_invocations']==32 and
          t['raw_source_stable'] and t['all_complete_streams_and_checkpoint_images_exact'] and
          read(timing/'terminal.json')=={'status':'complete','training_invocations':32} and t['quality_gate'] is None,
          'timing incomplete')
  require(v['source_head']==head and v['raw_source_stable'] and v['deterministic_events']==26 and v['stdout_sha256']==digest(vectors/'process/stdout.bin'),'vectors differ')
  require(v['status']=='independent_phase_vectors_pass' and v['training_invocations']==0 and
          v['operator_sha256']==digest(WORK/('capture-native-phase-vectors'+str(vector_id)+'.py')),'vector operator/census differs')
  observed_exit(read(vectors/'process/process.json'),'vectors')
  operator_provenance[prefix+'/vectors']={'path':'capture-native-phase-vectors'+str(vector_id)+'.py','recorded_sha256':v['operator_sha256']}
  require(c['head']==control_head and c['tests_per_mode']==(88 if index==1 else 89) and c['skips']==0 and c['raw_source_stable'],'controls incomplete')
  chashes=stable(controls)
  require(c['whole_game_training_invocations']==0 and set(c['exits'])=={'normal','optimized'},'controls invocation census differs')
  for mode,observed in c['exits'].items():observed_exit(observed,'controls '+mode)
  require(r['source_head']==head and r['native_training_invocations']==0 and r['raw_source_stable'] and r['exit']['returncode']==0,'disabled replay incomplete')
  require(r['status']=='disabled_saved_only_replay_complete','disabled replay status differs')
  observed_exit(r['exit'],'disabled replay')
  observed_exit(read(cohort/'saved-review/process.json'),'enabled replay')
  require(r['compact_sha256']==final['compact_sweep_capture']['retained_sha256'] and
          r['expanded_sha256']==final['saved_only_replay']['saved_output_sha256'],'disabled replay input identity differs')
  require(r['saved_only_replay']['native_producer_calls']==0 and final['saved_only_replay']['native_producer_calls']==0,'replay called producer')
  require(final['quality_gate'] is None and final['saved_only_replay']['status']=='saved_two_sweep_exact_replay_pass',
          'named T2 replay/quality scope differs')
  require({k:v for k,v in r['saved_only_replay'].items() if k!='duration_seconds'}==
          {k:v for k,v in final['saved_only_replay'].items() if k!='duration_seconds'},'replay semantic fields differ')
  names=set()
  for boot_path in (launch/'bootstrap.json',cohort/'saved-review-bootstrap.json',replay/'bootstrap.json'):
   boot=read(boot_path)
   require(boot['initial_cache_scan']['project_bytecode_files']==boot['final_cache_scan']['project_bytecode_files']==0,'bytecode present')
   require(all(hashes.get(n)==h for n,h in boot['compiled'].items()),'bootstrap source differs')
   names.update(boot['compiled'])
  bpath=cohort/'build/native-exact-build-manifest.json'
  target='virtual-dyadic-training' if index==1 else 'virtual-dyadic-training-profile'
  build=build_check(bpath,hashes,target);names.update(build['source_sha256'])
  config=read(timing/'configuration.json')
  require(config['source_head']==head and config['source_executable_sha256']==build['executable_sha256'] and
          config['pristine_base_head']=='927e4a34563c76d83ba9fc6b5a923ef3a7c1bfe3' and
          config['pristine_source_head']==pristine_frozen['head']==t['pristine_source_head'] and
          config['pristine_executable_sha256']==pristine['executable_sha256'] and t['pristine_raw_source_stable'] is True,
          'timing baseline configuration differs')
  require(read(timing/'pristine-source-before.json')==read(timing/'pristine-source-after.json')==pristine_hashes,
          'timing pristine raw source drift')
  pristine_source=WORK/'dydivision-src1'
  require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=pristine_source).decode().strip()==pristine_frozen['head'],
          'pristine source HEAD differs')
  for name,identity in pristine['source_sha256'].items():
   raw=(pristine_source/name).read_bytes()
   committed=subprocess.check_output(['git','show',config['pristine_base_head']+':'+name],cwd=source)
   require(sha256(raw).hexdigest()==identity and (raw==committed or raw.replace(b'\r\n',b'\n')==committed),
           'pristine compiled source bridge differs: '+name)
  standard=build
  if index==2:
   standard_path=WORK/'dyprofile-standard-build2/native-exact-build-manifest.json'
   standard=build_check(standard_path,hashes,'virtual-dyadic-training')
   require(config['standard_executable_sha256']==standard['executable_sha256'],'timing standard executable differs')
   names.update(standard['source_sha256'])
   add(prefix+'/standard-build/native-exact-build-manifest.json',standard_path)
  require(build['compiler_sha256']==standard['compiler_sha256']==pristine['compiler_sha256'] and
          build['dependency_archive_sha256']==standard['dependency_archive_sha256']==pristine['dependency_archive_sha256'],
          'timing compiler/dependency bridge differs')
  verifier_path=source/'scripts/verify_training_phase_profile.py'
  raw=verifier_path.read_bytes();committed=subprocess.check_output(['git','show',head+':scripts/verify_training_phase_profile.py'],cwd=source)
  require(digest(verifier_path)==hashes['scripts/verify_training_phase_profile.py'] and
          (raw==committed or raw.replace(b'\r\n',b'\n')==committed),'profile verifier source differs')
  verify_profile=runpy.run_path(str(verifier_path))['verify_profile']
  require(verify_profile(final['phase_profile'],final['admission'])==final['phase_profile_summary'],
          'enabled profile summary differs')
  require(read(cohort/'phase-profile.json')==final['phase_profile'],'enabled profile sidecar differs')
  timing_check(timing,t,final,config,build,standard,pristine,verify_profile)
  control_names=set()
  for rel,meta in c['builds'].items():
   bp=WORK/rel/'native-exact-build-manifest.json'
   require(digest(bp)==meta['manifest_sha256'],'control build manifest differs')
   expected_target=('virtual-dyadic-training-profile' if rel.endswith('dyprofile-on-cohort2/build') else
                    'virtual-dyadic-training' if rel.endswith('dyprofile-on-cohort1/build') or rel.endswith('dyprofile-standard-build2') else Path(rel).name)
   b=build_check(bp,chashes,expected_target)
   require(b['executable_sha256']==meta['executable_sha256'],'control executable record differs')
   if expected_target=='training-phase-profile-controls':
    require(v['build_manifest_sha256']==meta['manifest_sha256'] and v['executable_sha256']==b['executable_sha256'],
            'vector/control build bridge differs')
   control_names.update(b['source_sha256'])
   add(prefix+'/controls/builds/'+rel.replace('/','_')+'.json',bp)
  for mode in ('normal','optimized'):
   boot=read(controls/mode/'bootstrap.json')
   observed_exit(read(controls/mode/'exit.json'),'saved controls '+mode)
   require(read(controls/mode/'exit.json')==c['exits'][mode],'control exit record differs')
   log=(controls/mode/'stderr.log').read_text()
   require('Ran '+str(c['tests_per_mode'])+' tests' in log and '\nOK\n' in log and 'skipped' not in log,
           'control test log census differs')
   require(boot['initial_cache_scan']['project_bytecode_files']==boot['final_cache_scan']['project_bytecode_files']==0 and
           boot['interpreter']['optimize']==int(mode=='optimized'),'control bootstrap mode/cache differs')
   require(all(chashes.get(n)==h for n,h in boot['compiled'].items()),'control bootstrap differs')
   control_names.update(boot['compiled'])
  for obj,key in ((t,'imported_source_closure'),(v,'imported_source_closure'),(r,'parent_imported_source_closure'),(r,'compiled_source_closure')):
   closure_check(obj[key],hashes,key);names.update(obj[key])
  if control_head==head:
   require(all(chashes[n]==hashes[n] for n in control_names),'control source differs')
   names.update(control_names)
  archive_source(prefix,source,head,hashes,names)
  if control_head!=head:archive_source(prefix+'/controls',WORK/'dyprofile-controls-src2',control_head,chashes,control_names)
  tree(prefix+'/operator',launch)
  tree(prefix+'/cohort',cohort,lambda p:p.parts[0]!='source' and (p.parts[0]!='build' or p.name=='native-exact-build-manifest.json') and p.name!='expanded.bin' and (index==2 or p.name not in ('committed.bin','staged.bin')))
  # Study2 archives one full pair of raw checkpoint images; all other copies match their identities,
  # and archive one study's retained compact stream and full packet receipts.
  tree(prefix+'/controls',controls)
  tree(prefix+'/vectors',vectors)
  tree(prefix+'/disabled-replay',replay,lambda p:p.name!='expanded.bin')
  tree(prefix+'/timing',timing,lambda p:p.suffix=='.json' and p.parts[0] not in ('unused',))
  summaries.append({'source_head':head,'control_source_head':control_head,'focused_controls_per_mode':c['tests_per_mode'],
   'timing':t,'profile':final['phase_profile'],'profile_summary':final['phase_profile_summary'],
   'saved_only_replay':final['saved_only_replay'],'disabled_saved_only_replay':r['saved_only_replay'],
   'native_build':{'target':build['target'],'executable_sha256':build['executable_sha256']},
   'source_files':len(hashes),'quality_gate':final['quality_gate']})
 # Preserve the first failed controls and auxiliary failures rather than replacing them.
 tree('preserved-failures/controls1',WORK/'dyprofile-controls1')
 tree('preserved-failures/vectors1',WORK/'dyprofile-native-vectors1')
 for name in ('check-dyadic-profile-controls1.py','check-dyadic-profile-controls2.py','check-dyadic-profile-controls3.py',
              'capture-native-phase-vectors.py','capture-native-phase-vectors2.py','capture-native-phase-vectors3.py',
              'compare-native-phase-profile.py','compare-native-phase-profile2.py','compare-native-phase-profile3.py',
              'replay-native-phase-disabled.py','replay-native-phase-disabled2.py',
              'trusted-virtual-dyadic-training-launch-v43.py','dyprofile-separation-review2.md'):
  add('operator/'+name,WORK/name)
 add('operator/packager.py',Path(__file__))
 for p in sorted(WORK.glob('dyprofile-*.log')):
  if not p.name.startswith('dyprofile-package-'):add('operator/logs/'+p.name,p)
 # Capture the unhooked baseline source closure from the already published #309 packet.
 baseline=ROOT/'benchmarks/results/native-dyadic-bounded-policy-division-v1'
 bm=read(baseline/'manifest.json')
 require(digest(baseline/'verification.zip')==bm['archive']['sha256'],'baseline archive differs')
 with ZipFile(baseline/'verification.zip') as z:
  inventory=read_inventory=json.loads(z.read('inventory.json'))
  for name in z.namelist():
   if name.startswith('source/') or name=='cohort/build/native-exact-build-manifest.json':
    require(sha256(z.read(name)).hexdigest()==inventory[name]['sha256'],'published baseline member differs')
 # Baseline is content-addressed by manifest and archive, already tracked in same checkout.
 baseline_ref={'manifest_sha256':digest(baseline/'manifest.json'),'archive_sha256':digest(baseline/'verification.zip'),
               'path':baseline.relative_to(ROOT).as_posix(),'archived_elsewhere_in_same_repository':True}
 require(operator_input['operator_sha256']==digest(Path(__file__)),'packager changed during verification')
 inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
 require(not RESULT.exists(),'immutable packet already exists')
 RESULT.mkdir()
 archive_path=RESULT/'verification.zip'
 with ZipFile(archive_path,'x',ZIP_DEFLATED) as z:
  for n,p in sorted(files.items()):z.write(p,n)
  z.writestr('inventory.json',json.dumps(inventory,indent=2,sort_keys=True))
 with ZipFile(archive_path) as z:
  require(z.testzip() is None,'archive integrity failure')
  for n,meta in inventory.items():
   with z.open(n) as f:require(file_digest(f,'sha256').hexdigest()==meta['sha256'] and z.getinfo(n).file_size==meta['bytes'],'archive member differs')
 manifest={'version':RESULT.name,'source_head':H2,'studies':summaries,
  'archived_source_closures':closures,'baseline':baseline_ref,
  'recorded_external_operator_identities':operator_provenance,
  'external_operator_identity_limit':'Launch and vector operators are bound to recorded execution-time hashes; other external operator copies are inventoried packaging-time bytes and lack recorded execution-time self-hashes.',
  'phase_attribution':'walk inclusive of Chance/State/History/parent; no per-owner causal claim',
  'quality_gate':None,'eleven_card_training':False,
  'preserved_failures':['initial recorder test reused existing temporary folder; corrected test-only at 6a6cc45',
   'first vector operator shadowed source map; corrected fresh operator completed',
   'first timing operator had syntax error before any timed calls',
   'first full study code_layout median ratio 1.0185718803835289 missed preset 1.01 limit'],
  'omissions':'Native binaries, duplicate expanded streams and duplicate checkpoint images omitted; one raw checkpoint pair and compact streams plus exact hash records retained; #309 archive is shared baseline',
  'archive':{'path':'verification.zip','sha256':digest(archive_path),'bytes':archive_path.stat().st_size,'members':len(inventory)+1}}
 (RESULT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 print(json.dumps(manifest['archive']))
if __name__=='__main__':main()
