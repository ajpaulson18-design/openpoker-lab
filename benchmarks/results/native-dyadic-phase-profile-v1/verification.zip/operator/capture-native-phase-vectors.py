"""Capture independently checked deterministic coarse phase events."""
from hashlib import file_digest
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'dyprofile-src1'
STUDY=WORK/'dyprofile-on-cohort1'
OUT=WORK/'dyprofile-native-vectors1'
HEAD='aeaaa2e0ddac69ee293ee9f20835256b80aa7a9e'

def require(value,message):
    if not value: raise RuntimeError(message)

def digest(path):
    with path.open('rb') as stream: return file_digest(stream,'sha256').hexdigest()

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write('\n')

def main():
    OUT.mkdir(exist_ok=False)
    require(sys.dont_write_bytecode,'no bytecode required')
    frozen=json.loads((STUDY/'source.json').read_bytes())
    expected={name:item['raw_sha256'] for name,item in frozen['files'].items()}
    require(frozen['head']==HEAD and subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD,'source head differs')
    before={name:digest(SOURCE/name) for name in expected}
    require(before==expected,'raw source differs')
    save('source-before.json',before)
    build_path=WORK/'dyprofile-controls-build1/training-phase-profile-controls/native-exact-build-manifest.json'
    build=json.loads(build_path.read_bytes())
    exe=Path(build['executable'])
    require(build['target']=='training-phase-profile-controls' and digest(exe)==build['executable_sha256'],'binary differs')
    for name,identity in build['source_sha256'].items():
        require(before[name]==identity,'native source differs')
        committed=subprocess.check_output(['git','show',HEAD+':'+name],cwd=SOURCE)
        actual=(SOURCE/name).read_bytes()
        require(actual==committed or actual.replace(b'\r\n',b'\n')==committed,'committed source differs')
    sys.path.insert(0,str(SOURCE))
    from tests.virtual_frozen_run_control import run_bounded_child
    observed=run_bounded_child([str(exe)],b'',OUT/'process',stdout_limit=131072)
    require(observed['actual_exit_observed'] and observed['returncode']==0 and not observed['failures'],'native controls failed')
    require((OUT/'process/stderr.bin').read_bytes()==b'','unexpected stderr')
    lines=(OUT/'process/stdout.bin').read_text(encoding='ascii').splitlines()
    names=('plan_preflight','chance_setup','owners_setup','row_registration','freeze',
           'prelude','policy_build','policy_emit','walk','commit','checkpoint','average_export','footer')
    expected=[f'EVENT {2*i+j} {name} {edge} {i} {10*(2*i+j+1)}'
              for i,name in enumerate(names) for j,edge in enumerate(('begin','end'))]
    require(lines==expected+['PROFILE_CONTROLS PASS'],'deterministic phase vectors differ')
    closure={}
    for module in tuple(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(SOURCE):
                name=path.relative_to(SOURCE).as_posix()
                require(name in before and digest(path)==before[name],'import closure differs')
                closure[name]=before[name]
    after={name:digest(SOURCE/name) for name in expected}
    require(after==before and digest(exe)==build['executable_sha256'],'source or executable drift')
    save('source-after.json',after)
    result={'source_head':HEAD,'deterministic_events':26,
        'status':'independent_phase_vectors_pass','raw_source_stable':True,
        'build_manifest_sha256':digest(build_path),'executable_sha256':digest(exe),
        'operator_sha256':digest(Path(__file__)),'imported_source_closure':closure,
        'stdout_sha256':digest(OUT/'process/stdout.bin'),'training_invocations':0}
    save('result.json',result)
    print(json.dumps(result))

if __name__=='__main__':main()
