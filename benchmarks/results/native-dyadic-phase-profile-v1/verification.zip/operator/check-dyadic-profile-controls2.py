"""External source-frozen component operator; no whole-game TRAIN calls."""
import ast
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

WORK=Path(__file__).resolve().parent
REPO=WORK/'dyprofile-controls-src2'
HEAD='6a6cc450feaf88bbd10dab94da296744556e33d6'
OUT=WORK/'dyprofile-controls2'
helpers=runpy.run_path(str(WORK/'trusted-virtual-dyadic-training-launch-v43.py'))
git,snapshot,save,sha,observe=(helpers[n] for n in ('git','snapshot','save','sha','observe'))


def committed(name,digest):
    raw=git(REPO,'show',HEAD+':'+name)
    actual=(REPO/name).read_bytes()
    if hashlib.sha256(actual).hexdigest()!=digest or (actual!=raw and actual.replace(b'\r\n',b'\n')!=raw):
        raise RuntimeError('committed executable source differs: '+name)


def main():
    if git(REPO,'rev-parse','HEAD').decode().strip()!=HEAD:
        raise RuntimeError('component source HEAD differs')
    OUT.mkdir(exist_ok=False)
    before=snapshot(REPO)
    save(OUT/'source-before.json',before)
    bootstrap=REPO/'scripts/run_virtual_frozen_source_only.py'
    raw=bootstrap.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    committed(bootstrap.relative_to(REPO).as_posix(),digest)
    stages=[ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Name) and t.id=='FIRST_STAGE' for t in n.targets)]
    if len(stages)!=1:raise RuntimeError('trusted first-stage literal differs')
    builds={}
    for name,target,environment in (
        ('dyprofile-controls-build1/virtual-dyadic-state-controls','virtual-dyadic-state-controls','OPENPOKER_NATIVE_VIRTUAL_DYADIC_STATE_EXE'),
        ('dyprofile-controls-build1/dyadic-policy-controls','dyadic-policy-controls','OPENPOKER_NATIVE_DYADIC_POLICY_EXE'),
        ('dyprofile-controls-build1/packed-signed-update-controls','packed-signed-update-controls','OPENPOKER_NATIVE_PACKED_SIGNED_UPDATE_EXE'),
        ('dyprofile-controls-build1/dyadic-policy-division-controls','dyadic-policy-division-controls','OPENPOKER_NATIVE_DYADIC_POLICY_DIVISION_EXE'),
        ('dyprofile-controls-build1/training-phase-profile-controls','training-phase-profile-controls','OPENPOKER_NATIVE_TRAINING_PHASE_PROFILE_EXE'),
        ('dyprofile-on-cohort1/build','virtual-dyadic-training','OPENPOKER_NATIVE_VIRTUAL_DYADIC_TRAINING_EXE')):
        path=WORK/name/'native-exact-build-manifest.json'
        build=json.loads(path.read_bytes())
        if build['target']!=target or sha(Path(build['executable']))!=build['executable_sha256']:
            raise RuntimeError('component build identity differs')
        for source,identity in build['source_sha256'].items():
            if before.get(source)!=identity:raise RuntimeError('component build input differs')
            committed(source,identity)
        os.environ[environment]=build['executable']
        builds[name]={'manifest_sha256':sha(path),'executable_sha256':build['executable_sha256']}
    exits={}
    for mode in ('normal','optimized'):
        target=OUT/mode
        target.mkdir()
        os.environ['OPENPOKER_NATIVE_DYADIC_POLICY_CONTROL_DIR']=str(target/'history')
        os.environ['OPENPOKER_NATIVE_VIRTUAL_DYADIC_STATE_CONTROL_DIR']=str(target/'state')
        os.environ['OPENPOKER_NATIVE_VIRTUAL_DYADIC_TRAINING_CONTROL_DIR']=str(target/'training')
        receipt=target/'bootstrap.json'
        command=[sys.executable,'-I','-S','-B',*(['-O'] if mode=='optimized' else []),'-c',stages[0],
                 str(bootstrap),digest,'--module','unittest','--receipt',str(receipt),'--',
                 'tests.test_native_virtual_dyadic_state','tests.test_native_virtual_dyadic_training',
                 'tests.test_native_dyadic_policy','tests.test_native_packed_signed_update',
                 'tests.test_virtual_dyadic_factored_receipt','tests.test_virtual_dyadic_compact_wire',
                 'tests.test_virtual_dyadic_sweep_capture','tests.test_native_dyadic_policy_division',
                 'tests.test_virtual_dyadic_directory','tests.test_native_training_phase_profile',
                 'tests.test_training_phase_profile','-v']
        exits[mode]=observe(command,REPO,target)
        if not exits[mode]['actual_exit_observed'] or exits[mode]['returncode'] or exits[mode]['failures']:
            raise RuntimeError('control process outcome differs')
        boot=json.loads(receipt.read_bytes())
        if boot['initial_cache_scan']['project_bytecode_files'] or boot['final_cache_scan']['project_bytecode_files']:
            raise RuntimeError('project bytecode appeared')
        if boot['interpreter']['optimize']!=int(mode=='optimized'):raise RuntimeError('optimization differs')
        for source,identity in boot['compiled'].items():
            if before.get(source)!=identity:raise RuntimeError('compiled source differs')
            committed(source,identity)
        log=(target/'stderr.log').read_text()
        if 'Ran 88 tests' not in log or '\nOK\n' not in log or 'skipped' in log:
            raise RuntimeError('component tests incomplete')
    after=snapshot(REPO)
    if before!=after:raise RuntimeError('component source drift')
    save(OUT/'source-after.json',after)
    result={'head':HEAD,'tests_per_mode':88,'skips':0,'exits':exits,'builds':builds,
            'raw_source_stable':True,'files':len(before),'whole_game_training_invocations':0}
    save(OUT/'completion.json',result)
    print(json.dumps(result))


if __name__=='__main__':main()
