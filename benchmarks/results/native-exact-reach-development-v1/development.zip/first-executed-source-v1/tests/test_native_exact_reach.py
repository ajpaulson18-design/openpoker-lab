"""Independent rational-reach component controls; no training claim."""
from fractions import Fraction
from itertools import combinations, permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import os
import unittest
from scripts.preflop_validation import independent_rank
from tests.virtual_frozen_run_control import run_bounded_child
from tests.full_deck_public_chance_reference import card_name

ROOT = Path(__file__).resolve().parents[1]
DECK = (16,17,24,32,33,35,37,43,48)
RANGES = ((((43,48), Fraction(1,8)), ((32,43), Fraction(3,4))),
          (((24,37), Fraction(3,8)), ((16,32), Fraction(1))))
NORMALIZER = sum(w0*w1 for h0,w0 in RANGES[0] for h1,w1 in RANGES[1] if not set(h0)&set(h1))


def reaches(profile):
    if profile == 0:
        return Fraction(1,4), Fraction(3,4)
    if profile == 1:
        return Fraction(((1<<53)-1)**2, 1<<106), Fraction(((1<<52)+1)**3, 1<<159)
    if profile == 2:
        d = ((1<<89)-1)*((1<<83)-1)
        return Fraction(d//3+1,d), Fraction(d-7,d)
    if profile == 3:
        return Fraction(0), Fraction(0)
    if profile == 4:
        return Fraction(1,1<<2200), Fraction(3,1<<2200)
    if profile == 5:
        return Fraction(1), Fraction(1)
    raise ValueError('unknown exact reach fixture')


def boards():
    for flop in combinations(DECK,3):
        for turn,river in permutations([c for c in DECK if c not in flop],2):
            yield (*flop,turn,river)


def literal(player, board, mode, reach):
    """Physical pair sum with independent best-five rank; never float(reach)."""
    answer = []
    payoff = (Fraction(-3,4), Fraction(5,2), Fraction(5,4))[mode]
    blocked = set(board)
    denominator = NORMALIZER * 20 * Fraction(1,2520)
    for own,wi in RANGES[player]:
        value = Fraction(0)
        if not set(own)&blocked:
            for (opponent,wj),sequence in zip(RANGES[1-player],reach):
                if sequence == 0 or set(opponent)&(blocked|set(own)):
                    continue
                sign = 1
                if mode == 2:
                    r0 = independent_rank(tuple(map(card_name,(*own,*board))))
                    r1 = independent_rank(tuple(map(card_name,(*opponent,*board))))
                    sign = (r0>r1)-(r0<r1)
                value += wi*wj*sequence*payoff*sign
        answer.append(value/denominator)
    return answer


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def authenticate(exe, root, target):
    from scripts.build_native_exact_four_street import TARGETS
    exe,root = Path(exe).resolve(),Path(root).resolve()
    path = exe.parent/'native-exact-build-manifest.json'
    raw = path.read_bytes()
    manifest = json.loads(raw)
    required = {*TARGETS[target][1], 'scripts/build_native_exact_four_street.py',
                'third_party/boost-multiprecision-1.92.0/manifest.json',
                'third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt',
                'third_party/boost-multiprecision-1.92.0/headers.zip'}
    if (manifest.get('target') != target or set(manifest['source_sha256']) != required or
            Path(manifest['executable']).resolve() != exe or sha(exe) != manifest['executable_sha256'] or
            sha(manifest['compiler']) != manifest['compiler_sha256']):
        raise AssertionError('explicit exact-reach build identity differs')
    for name,value in manifest['source_sha256'].items():
        if sha(root/name) != value:
            raise AssertionError('exact-reach source/build drift: '+name)
    dependency = json.loads((root/'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
    for name,value in dependency['headers_sha256'].items():
        if sha(exe.parent/'boost-include'/name) != value:
            raise AssertionError('extracted exact-reach header drift')
    return raw,manifest


class ExactReachReferenceTests(unittest.TestCase):
    def test_fixture_requires_more_than_binary64_reach_transport(self):
        self.assertEqual(NORMALIZER,Fraction(29,64))
        for value in reaches(1):
            self.assertGreater(value.numerator.bit_length(),53)
            self.assertNotEqual(value,Fraction.from_float(float(value)))
        self.assertGreater(reaches(4)[0],0)
        self.assertEqual(float(reaches(4)[0]),0.0)
        self.assertEqual(len(tuple(boards())),2520)


@unittest.skipUnless(os.environ.get('OPENPOKER_NATIVE_EXACT_REACH_EXE'),
                     'explicit source-built exact-reach component controls required')
class NativeExactReachTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exe = Path(os.environ['OPENPOKER_NATIVE_EXACT_REACH_EXE']).resolve()
        cls.identity = authenticate(cls.exe,ROOT,'full-deck-exact-reach-controls')
        cls.temp = None
        destination = os.environ.get('OPENPOKER_NATIVE_EXACT_REACH_CONTROL_DIR')
        if destination is None:
            cls.temp = TemporaryDirectory()
            destination = cls.temp.name
        cls.output = Path(destination)
        cls.output.mkdir(parents=True,exist_ok=True)

    @classmethod
    def tearDownClass(cls):
        if authenticate(cls.exe,ROOT,'full-deck-exact-reach-controls') != cls.identity:
            raise AssertionError('exact-reach build/source changed during controls')
        if cls.temp is not None:
            cls.temp.cleanup()

    def invoke(self, name, selectors, *, cap=2_100_000):
        directory = self.output/name
        observed = run_bounded_child([str(self.exe),*selectors],b'',directory,stdout_limit=cap)
        self.assertEqual(observed['status'],'exited')
        self.assertTrue(observed['actual_exit_observed'])
        self.assertEqual(observed['returncode'],0,(directory/'stderr.bin').read_bytes())
        self.assertEqual((directory/'stderr.bin').read_bytes(),b'')
        return (directory/'stdout.bin').read_text(encoding='ascii').splitlines()

    def test_all_boards_exact_values_for_six_reaches_both_players_and_signed_payoffs(self):
        count = 0
        for profile in range(6):
            reach = reaches(profile)
            for player in (0,1):
                for mode in range(3):
                    name = f'p{profile}-seat{player}-mode{mode}'
                    lines = self.invoke(name,list(map(str,(profile,player,mode))))
                    self.assertEqual(lines[0],f'EXACT_REACH_CASES_V1 {profile} {player} {mode}')
                    self.assertEqual(len(lines),2522)
                    total_work = 0
                    for index,(board,line) in enumerate(zip(boards(),lines[1:-1])):
                        values = line.split()
                        self.assertEqual(len(values),8)
                        self.assertEqual(int(values[0]),index)
                        d = int(values[1],16)
                        self.assertGreater(d,0)
                        actual = [Fraction(int(x,16),d) for x in values[2:4]]
                        self.assertEqual(actual,literal(player,board,mode,reach),(profile,player,mode,board))
                        work,bits,payload,ranks = map(int,values[4:])
                        self.assertLessEqual(work,500_000_000)
                        self.assertLessEqual(bits,65536)
                        self.assertLessEqual(payload,1<<30)
                        expected_ranks = 0
                        if mode == 2 and any(reach):
                            expected_ranks = sum(not set(h)&set(board) for h,_ in RANGES[player])
                            expected_ranks += sum(r!=0 and not set(h)&set(board)
                                                  for (h,_),r in zip(RANGES[1-player],reach))
                        self.assertEqual(ranks,expected_ranks)
                        total_work += work
                        count += 1
                    self.assertEqual(lines[-1],f'END 2520 {total_work}')
        self.assertEqual(count,90720)

    def test_rejected_inputs_and_resources_enter_no_rank_or_complete_terminal(self):
        lines = self.invoke('guards',['guards'],cap=65536)
        self.assertEqual(len(lines),13)
        for line in lines:
            fields = line.split()
            self.assertEqual(fields[0],'GUARD')
            self.assertEqual(fields[2],'PASS',line)
            self.assertEqual(fields[-2:],['0','0'])


if __name__ == '__main__':
    unittest.main()
