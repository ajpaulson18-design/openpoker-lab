"""External stdlib-only source-buffer operator for development controls."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

work = Path(__file__).resolve().parent
root = work / 'exact-policy-reach-repo'
out = work / 'exact-reach-development-run-v2'
out.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory():
    raw = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root)
    names = [n.decode() for n in raw.split(b'\0') if n]
    if len(names) > 4096:
        raise RuntimeError('development source path cap')
    return {name:sha(root/name) for name in names}

before = inventory()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
script = root / 'scripts/run_virtual_frozen_source_only.py'
raw = script.read_bytes()
stage = next(ast.literal_eval(n.value) for n in ast.parse(raw).body
             if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FIRST_STAGE' for t in n.targets))
identity = hashlib.sha256(raw).hexdigest()
records = []
for label,flags in [('normal',[]),('optimized',['-O'])]:
    environment = dict(os.environ)
    environment.update({
        'OPENPOKER_NATIVE_FULL_DECK_CHANCE_EXE':str(work/'exact-reach-legacy-build-v2/native-full-deck-public-chance-probe.exe'),
        'OPENPOKER_NATIVE_FULL_DECK_CONTROL_DIR':str(out/(label+'-old-controls')),
        'OPENPOKER_NATIVE_EXACT_REACH_EXE':str(work/'exact-reach-controls-build-v2/native-full-deck-exact-reach-controls.exe'),
        'OPENPOKER_NATIVE_EXACT_REACH_BASELINE_EXE':str(work/'exact-reach-baseline-build-v1/native-full-deck-public-chance-probe.exe'),
        'OPENPOKER_NATIVE_EXACT_REACH_BASELINE_REPO':str(work/'exact-reach-baseline-src1'),
        'OPENPOKER_NATIVE_EXACT_REACH_CONTROL_DIR':str(out/(label+'-exact-controls')),
    })
    receipt = out/(label+'-bootstrap.json')
    command = [sys.executable,'-I','-S','-B',*flags,'-c',stage,str(script),identity,
        '--module','unittest','--receipt',str(receipt),'--',
        'tests.test_build_native_full_deck_public_chance','tests.test_native_full_deck_public_chance',
        'tests.test_native_exact_reach','-v']
    (out/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    with (out/(label+'.stdout.log')).open('xb') as stdout, (out/(label+'.stderr.log')).open('xb') as stderr:
        observed = subprocess.run(command,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    record = {'mode':label,'returncode':observed.returncode,'actual_exit_observed':True}
    (out/(label+'-exit.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if observed.returncode:
        sys.exit(observed.returncode)
    boot = json.loads(receipt.read_bytes())
    for name,value in boot['compiled'].items():
        if before.get(name) != value:
            raise RuntimeError('development executed source differs from initial raw snapshot')
    records.append(record)
after = inventory()
if before != after:
    raise RuntimeError('development source changed during source-only controls')
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'completion.json').write_text(json.dumps({'scope':'source-only DEVELOPMENT controls; uncommitted tree; not a full-game update/training result',
    'runs':records,'raw_source_stable':True},indent=2)+'\n')
