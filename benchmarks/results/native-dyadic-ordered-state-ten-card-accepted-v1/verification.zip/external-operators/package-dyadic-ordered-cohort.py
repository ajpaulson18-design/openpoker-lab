"""Publish ordered State parity and reference the identical packed sweep images."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
RESULTS = WORK / 'dyadic-training-repo/benchmarks/results'
DEST = RESULTS / 'native-dyadic-ordered-state-ten-card-accepted-v1'
COHORT = WORK / 'dyt2-ordered-cohort1'
OPERATOR = WORK / 'dyt2-ordered-launch1'
HEAD = 'a249872badf5a1949dddfae815b5a61f0f7319f0'
BASE_PUBLICATION = 'cbc774d60139dd7b25c6295bd0699874c6a08a0f'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def main():
    run = read(COHORT / 'result.json')
    outer = read(OPERATOR / 'completion.json')
    require(run['head'] == outer['head'] == HEAD and run['training_invocations'] == 1
            and outer['mode'] == 'train_ten_ordered_state' and outer['raw_source_stable']
            and outer['actual_exit_observed'] and outer['returncode'] == 0 and not outer['failures']
            and read(COHORT / 'terminal.json')['status'] == 'complete', 'ordered cohort exit differs')
    source = read(COHORT / 'source.json')['files']
    hashes = {name: record['raw_sha256'] for name, record in source.items()}
    require(read(OPERATOR / 'source-before.json') == read(OPERATOR / 'source-after.json') == hashes,
            'source inventories differ')
    for path in (OPERATOR / 'bootstrap.json', COHORT / 'saved-review-bootstrap.json'):
        receipt = read(path)
        require(all(hashes.get(name) == digest for name, digest in receipt['compiled'].items())
                and not receipt['initial_cache_scan']['project_bytecode_files']
                and not receipt['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    for label in ('admit_ten_ordered_state', 'train_ten_ordered_state', 'saved-review'):
        receipt = read(COHORT / label / 'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode'] == 0
                and not receipt['failures'] and receipt['automatic_retries'] == 0, 'child exit differs')
    replay, inputs = run['saved_only_replay'], run['checkpoint_inputs']
    candidate = COHORT / 'train_ten_ordered_state/stdout.bin'
    require(identity(candidate) == inputs['stream'] and replay['saved_output_sha256'] == inputs['stream']['sha256']
            and replay['native_producer_calls'] == 0 and replay['status'] == 'saved_two_sweep_exact_replay_pass'
            and all(identity(COHORT/'page-images'/row['name']) == {k:row[k] for k in ('bytes','sha256')}
                    for row in inputs['sweep_images']), 'saved ordered packet differs')
    base = RESULTS / 'native-dyadic-virtual-zero-ten-card-accepted-v1'
    root = RESULTS.parents[1]
    for item in (base/'manifest.json',base/'verification.zip'):
        require(identity(item)['sha256'] == hashes[item.relative_to(root).as_posix()], 'baseline source changed')
    baseline = read(base / 'manifest.json')
    require(baseline['status'] == 'accepted_recovered_virtual_zero_ten_card_training_and_replay'
            and identity(base/'verification.zip')['sha256'] == baseline['archive']['sha256'],
            'baseline archive differs')
    prior = baseline['saved_only_replay']
    require(inputs['sweep_images'] == replay['checkpoint_images'] == prior['checkpoint_images']
            and all(replay[k] == prior[k] for k in ('shape','sweeps','profile_and_br','chance_actual',
                'changed_current_rows','quality_gate')) and run['paging']['counts'] == baseline['paging']['counts'],
            'numerical or pager parity differs')
    old_actual = dict(prior['work_actual'])
    path_work = run['admission']['registration_path_work']
    old_actual['history'] += path_work
    require(replay['work_actual'] == old_actual and path_work == 3_814_272
            and (prior['planned_entries'],replay['planned_entries']) == (1_559_639,1_159_382),
            'phase storage or work ledger differs')
    numeric_length = inputs['stream']['bytes'] - 520
    with ZipFile(base/'verification.zip') as saved, saved.open('cohort/train_ten_virtual_zero/stdout.bin') as old:
        previous = old.read(inputs['stream']['bytes'] + 1)
    with candidate.open('rb') as current:
        require(len(previous) == inputs['stream']['bytes'] and sha256(previous).hexdigest() == prior['saved_output_sha256']
                and current.read(numeric_length) == previous[:numeric_length], 'ordered numeric stream differs')
    require(sha256(previous[:numeric_length]).hexdigest() == run['ordered_state_comparison']['numeric_sha256'],
            'independent numeric prefix digest differs')
    packed = baseline['packed_replay_images']
    require([row['raw'] for row in packed['images']] == inputs['sweep_images'], 'reusable packed image binding differs')
    for row in packed['images']:
        info = row['packed']
        path = root / Path(packed['manifest']).parent / info['name']
        require(identity(path) == {k:info[k] for k in ('bytes','sha256')}, 'published packed image changed')
    capacity_file = WORK/'dyadic-ordered-capacity-projection.json'
    capacity = read(capacity_file)['fixtures']
    n10, n11 = capacity[1:]
    require((n10['rows'],n10['slots']) == (run['admission']['rows'],run['admission']['slots'])
            and (n10['average_words'],n10['regret_words']) ==
                (run['admission']['packed_average_limbs'],run['admission']['packed_regret_limbs'])
            and n10['ordered_frozen_entries_excluding_pager'] +
                (run['admission']['page_resident_bytes']+88+7)//8 + 159089 == replay['planned_entries']
            and (n11['ordered_frozen_entries_excluding_pager'],n11['staging_bitmap_bytes']) ==
                (2796837,1215526), 'independent storage projection differs')

    files = {}
    for label, directory in (('cohort',COHORT),('operator',OPERATOR)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(), 'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label == 'cohort' and (rel.parts[0] == 'source' or
                    (rel.parts[0] == 'build' and path.name != 'native-exact-build-manifest.json') or
                    (rel.parts[0] == 'page-images' and path.suffix == '.bin')):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__), WORK/'trusted-virtual-dyadic-training-launch-v14.py',
                 WORK/'project-dyadic-ordered-capacity.py', capacity_file):
        files[f'external-operators/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST / 'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as saved:
        for name,path in files.items():
            saved.write(path,name)
        saved.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as saved:
        require(saved.testzip() is None, 'archive CRC differs')
        for name,expected in inventory.items():
            with saved.open(name) as data:
                require(saved.getinfo(name).file_size == expected['bytes']
                        and file_digest(data,'sha256').hexdigest() == expected['sha256'], 'archive entry differs')
    observations = {'virtual_zero':baseline['virtual_zero_comparison']['virtual_zero_native_observation'],
                    'ordered_state':run['ordered_state_comparison']['ordered_state_native_observation']}
    manifest = {'status':'accepted_ordered_state_ten_card_training_and_replay','source_head':HEAD,'operator':outer,
                'baseline_publication':BASE_PUBLICATION,'observations':observations,
                'independent_capacity_projection':capacity,
                **{key:run[key] for key in ('admission','checkpoint_inputs','paging','ordered_state_comparison',
                    'independent_stage_schedule','saved_only_replay','training_invocations','quality_gate')},
                'packed_replay_images':packed,
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observations':observations},sort_keys=True))


if __name__ == '__main__':
    main()
