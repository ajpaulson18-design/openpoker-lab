"""Run the rank-free Q32 projection against an authenticated committed source closure."""
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('repo',type=Path)
p.add_argument('--head',required=True)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--source-inventory',type=Path)
a=p.parse_args()
repo=a.repo.resolve(strict=True)
projector=Path(__file__).with_name('project-dyadic-q32.py').resolve(strict=True)
def git(*args):
    return subprocess.check_output(['git','-C',str(repo),'-c','core.fsmonitor=false',*args])
def inventory():
    head=git('rev-parse','HEAD').decode().strip()
    if head!=a.head: raise ValueError('source HEAD changed or differs from requested commit')
    if git('status','--porcelain=v1','--untracked-files=all').strip():
        raise ValueError('source must match committed HEAD and contain no untracked files')
    files={}
    for raw in git('ls-files','-z').split(b'\0'):
        if not raw: continue
        name=raw.decode('utf-8'); path=repo / name
        for parent in (path,*path.parents):
            if parent==repo: break
            if parent.is_symlink(): raise ValueError('symlink in source path: '+name)
        if not path.is_file() or not path.resolve().is_relative_to(repo):
            raise ValueError('invalid tracked source: '+name)
        data=path.read_bytes()
        files[name]={'raw_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    return {'head':head,'files':files,'external_projector_sha256':hashlib.sha256(projector.read_bytes()).hexdigest()}
before=inventory()
if a.source_inventory:
    expected=json.loads(a.source_inventory.read_bytes())
    if expected['head']!=a.head or set(expected['files'])!=set(before['files']):
        raise ValueError('provided source inventory differs')
    if any(expected['files'][name]['raw_sha256']!=record['raw_sha256'] for name,record in before['files'].items()):
        raise ValueError('provided source inventory raw hash differs')
required=('tests/full_deck_public_chance_reference.py','tests/virtual_betting_template_reference.py',
          'tests/virtual_frozen_update_reference.py','tests/virtual_dyadic_stage_schedule.py',
          'tests/virtual_dyadic_directory_trace.py','scripts/census_virtual_dyadic_storage.py',
          'benchmarks/results/native-dyadic-proof9-four-sweep-accepted-v1/manifest.json')
if any(path not in before['files'] for path in required):
    raise ValueError('reference or calibration manifest is not tracked')
runner=r'''import hashlib, importlib.abc, importlib.machinery, json, runpy, sys
from pathlib import Path
projector,root,head=sys.argv[1:]
root=Path(root).resolve(); expected=json.loads(sys.stdin.read()); loaded={}
class SourceOnly(importlib.machinery.SourceFileLoader):
    def get_code(self,fullname):
        path=Path(self.path)
        name=path.relative_to(root).as_posix()
        if name not in expected: raise ImportError('untracked project source: '+name)
        raw=path.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
        if digest!=expected[name]['raw_sha256']: raise ImportError('project source hash changed: '+name)
        loaded[name]=digest
        return compile(raw,str(path),'exec',dont_inherit=True)
class Guard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec and spec.origin:
            origin=Path(spec.origin).resolve()
            if origin.is_relative_to(root):
                if not origin.suffix=='.py' or not isinstance(spec.loader,importlib.machinery.SourceFileLoader):
                    raise ImportError('project import is not source: '+fullname)
                spec.loader=SourceOnly(fullname,str(origin))
        return spec
sys.meta_path.insert(0,Guard())
sys.argv=[projector,str(root),'--expected-head',head]
runpy.run_path(projector,run_name='__main__')
print('MODULE_CLOSURE='+json.dumps(loaded,sort_keys=True),file=sys.stderr)
'''
run=subprocess.run([sys.executable,'-I','-S','-B','-c',runner,str(projector),str(repo),a.head],
                   input=json.dumps(before['files']).encode(),capture_output=True,check=True)
result=json.loads(run.stdout)
closure=[line.removeprefix('MODULE_CLOSURE=') for line in run.stderr.decode().splitlines() if line.startswith('MODULE_CLOSURE=')]
if len(closure)!=1: raise ValueError('missing imported source closure')
modules=json.loads(closure[0])
after=inventory()
if before!=after: raise ValueError('source inventory drifted during projection')
canonical=json.dumps(before['files'],sort_keys=True,separators=(',',':')).encode()
result.update(raw_source_stable=True,source_files=len(before['files']),
    source_bytes=sum(x['bytes'] for x in before['files'].values()),
    source_inventory_sha256=hashlib.sha256(canonical).hexdigest(),
    imported_source_sha256=modules,external_script_sha256=before['external_projector_sha256'],
    native_producer_calls=0,hand_rank_calls=0)
with a.output.open('x',encoding='utf-8',newline='\n') as out:
    json.dump({'source_closure':before,'forecast':result},out,indent=2,sort_keys=True)
    out.write('\n')
