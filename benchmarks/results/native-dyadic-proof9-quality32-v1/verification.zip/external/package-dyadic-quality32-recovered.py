"""Package one source-frozen Q32 exactness run and preserve its quality result."""
import argparse, hashlib, json, subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
W=Path(__file__).resolve().parent
R=W/'dyadic-phase-payload-repo'
C=W/'dyq32-nine-cohort1'
I=W/'dyq32-nine-launch1'
O=W/'dyq32-nine-recovery-launch1'
REC=W/'dyq32-nine-recovery1'
D=R/'benchmarks/results/native-dyadic-proof9-quality32-v1'
def req(ok,msg):
    if not ok: raise ValueError(msg)
def read(p): return json.loads(p.read_bytes())
def ident(p):
    with p.open('rb') as f: return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
def main():
    a=argparse.ArgumentParser()
    a.add_argument('--head',required=True)
    a.add_argument('--control-log',type=Path,action='append',required=True)
    x=a.parse_args()
    run=read(REC/'completion.json'); outer=read(O/'completion.json')
    req(run['head']==outer['head']==x.head and run['training_invocations']==1 and
        run['status']=='recovered_quality32_exact_replay_pass' and run['raw_source_revalidated'] and
        run['native_producer_calls_during_recovery']==outer['native_producer_calls']==0 and
        not run['original_outer_exit_observed'] and outer['raw_source_stable'] and outer['returncode']==0 and
        outer['actual_exit_observed'] and not outer['failures'],'saved-only recovery incomplete')
    operator_identity=read(O/'operator.json')
    req(operator_identity['source_head']==x.head and operator_identity['native_producer_calls']==0 and
        operator_identity['recovery_script_sha256']==ident(W/'recover-dyadic-quality32.py')['sha256'] and
        operator_identity['operator_sha256']==ident(W/'trusted-dyadic-quality32-recovery-v1.py')['sha256'] and
        read(I/'operator-launch.json')['operator_sha256']==ident(W/'trusted-virtual-dyadic-training-launch-v26.py')['sha256'],
        'archived recovery/operator source differs from observed launch')
    interruption=read(REC/'interruption.json')
    req(interruption['original_native_exit_observed'] and interruption['original_native_returncode']==0 and
        not interruption['original_outer_exit_observed'] and not interruption['original_replay_exit_observed'] and
        not (C/'terminal.json').exists() and not (I/'exit.json').exists(),
        'original interruption state differs')
    source=read(C/'source.json')
    hashes={k:v['raw_sha256'] for k,v in source['files'].items()}
    req(read(O/'source-before.json')==read(O/'source-after.json')==read(I/'source-before.json')==
        read(REC/'source-before.json')==read(REC/'source-after.json')==hashes,'raw source changed')
    req(all(hashes.get(k)==v for k,v in read(REC/'imported-source.json').items()),
        'recovery helper imported source differs')
    for p in (REC/'saved-review-bootstrap.json',):
        b=read(p)
        req(not b['initial_cache_scan']['project_bytecode_files'] and not b['final_cache_scan']['project_bytecode_files'] and
            all(hashes.get(k)==v for k,v in b['compiled'].items()),'executed source differs')
    build=read(C/'build/native-exact-build-manifest.json')
    req(all(hashes[k]==v for k,v in build['source_sha256'].items()) and
        ident(Path(build['executable']))['sha256']==build['executable_sha256'],'native source or binary changed')
    for label in ('admit_proof9_q32','train_proof9_q32','saved-review'):
        directory=(REC if label=='saved-review' else C)/label
        p=read(directory/'process.json')
        req(p['returncode']==0 and p['actual_exit_observed'] and not p['failures'] and
            p['automatic_retries']==0,'child exit differs')
        if label!='saved-review':
            b=read(C/label/'binary-identity.json')
            req(b['before_sha256']==b['after_sha256']==build['executable_sha256'] and
                b['build_manifest_sha256']==ident(C/'build/native-exact-build-manifest.json')['sha256'],'binary identity differs')
    replay=run['saved_only_replay']; capture=run['sweep_capture']
    stream=C/'train_proof9_q32/stdout.bin'
    req(ident(C/'train_proof9_q32/process.json')['sha256']==run['sweep_capture_process_sha256'] and
        read(C/'train_proof9_q32/process.json')['sweep_capture']==capture and
        ident(stream)==run['checkpoint_inputs']['stream'] and
        replay['saved_output_sha256']==capture['retained_sha256']==ident(stream)['sha256'] and
        replay['native_producer_calls']==0 and replay['checkpoint_verification']=='independent_compact_digest' and
        replay['checkpoint_epochs']==capture['frames'] and len(capture['frames'])==32 and
        replay['wire_sha256']==capture['wire_sha256'] and replay['wire_bytes']==capture['contract']['wire_bytes']==171408812 and
        run['quality_gate']==replay['quality_gate'],'independent replay binding differs')
    for p in run['checkpoint_inputs']['sweep_images']:
        req(ident(C/'page-images'/p['name'])=={k:p[k] for k in ('bytes','sha256')},'final image differs')
    from fractions import Fraction
    ev=replay['profile_and_br']['exploitability']; gate=run['quality_gate']
    passed=Fraction(int(ev['numerator']),int(ev['denominator']))<=Fraction(1,10)
    req(gate=={'metric':'exploitability_bb','threshold':{'numerator':'1','denominator':'10'},
        'status':'pass' if passed else 'miss','passed':passed},'quality threshold changed')
    projection_file=read(W/'dyadic-q32-source-closed.json')
    projection=projection_file['forecast']
    closure=projection_file['source_closure']
    req(closure['head']==x.head and {k:v['raw_sha256'] for k,v in closure['files'].items()}==hashes,
        'forecast full raw source inventory differs from native cohort')
    req(projection['source_head']==x.head and projection['raw_source_stable'] and
        projection['native_producer_calls']==projection['hand_rank_calls']==0 and
        projection['external_script_sha256']==ident(W/'project-dyadic-q32.py')['sha256'],'forecast provenance differs')
    q=projection['q32_composed_candidate']
    req(q['components']==run['admission']['component_work'] and
        q['projected_total_entries']==run['admission']['entries'] and
        q['projected_composed_payload_bits']==run['admission']['payload_bits'] and
        q['wire_bytes']==capture['contract']['wire_bytes'],'forecast differs from admission')
    comparison_path=W/'dyadic-quality32-prefix-comparison.json'
    comparison=read(comparison_path)
    req(comparison['source_head']==x.head and comparison['native_producer_calls']==0 and
        comparison['numeric_stream_sha256']==ident(stream)['sha256'] and
        comparison['first_four_checkpoint_epochs']==capture['frames'][:4] and
        comparison['quality32']==ev and comparison['quality_gate']==gate,
        'T4 prefix comparison binding differs')
    files={}
    for label,root in (('cohort',C),('interrupted-operator',I),('recovery',REC),('recovery-operator',O)):
        for p in sorted(root.rglob('*')):
            req(not p.is_symlink(),'linked evidence')
            if not p.is_file(): continue
            rel=p.relative_to(root)
            if label=='cohort' and (rel.parts[0]=='source' or
                rel.parts[0]=='build' and p.name!='native-exact-build-manifest.json' or
                rel.parts[0]=='page-images' and p.name in ('committed.bin','staged.bin')): continue
            files[f'{label}/{rel.as_posix()}']=p
    for target in ('state','policy','training'):
        name={'state':'dyq32-state-build3','policy':'dyq32-policy-build1','training':'dyq32-training-build6'}[target]
        p=W/name/'native-exact-build-manifest.json'; b=read(p)
        req(ident(Path(b['executable']))['sha256']==b['executable_sha256'],'control executable changed')
        files[f'controls/{target}/native-exact-build-manifest.json']=p
        for k,v in b['source_sha256'].items():
            req(ident(R/k)['sha256']==v,'control source changed')
            raw=(R/k).read_bytes()
            committed=subprocess.check_output(['git','show',x.head+':'+k],cwd=R)
            req(raw==committed or raw.replace(b'\r\n',b'\n')==committed,'control source differs from frozen commit')
            files['controls/source/'+k]=R/k
    for mode in ('normal3','optimized1'):
        for target in ('trainer','state','policy'):
            root=W/f'dyq32-controls-{mode}-{target}'
            req(root.is_dir() and any(root.rglob('process.json')),'missing control process evidence')
            for p in sorted(root.rglob('*')):
                if not p.is_file():continue
                rel=p.relative_to(root)
                if p.suffix=='.bin' and (p.name in ('committed.bin','staged.bin','rows.bin') or p.stat().st_size>100000):continue
                files[f'controls/{mode}/{target}/{rel.as_posix()}']=p
    external=(Path(__file__),W/'trusted-virtual-dyadic-training-launch-v26.py',
        W/'recover-dyadic-quality32.py',W/'trusted-dyadic-quality32-recovery-v1.py',
        W/'compare-dyadic-quality32-prefix.py',comparison_path,
        W/'project-dyadic-q32.py',W/'project-dyadic-q32-source-closed.py',W/'dyadic-q32-source-closed.json',
        *x.control_log)
    req(len(x.control_log)==2 and {p.name for p in x.control_log}==
        {'dyq32-controls-normal3.log','dyq32-controls-optimized1.log'},'final normal and optimized logs required')
    for p in x.control_log:
        raw=p.read_bytes()
        req(b'\nOK' in raw and b'FAILED' not in raw and b'skipped=' not in raw,'controls did not all pass')
    for p in external: files['external/'+p.name]=p
    req(files.get('cohort/train_proof9_q32/stdout.bin')==stream and stream.stat().st_size==16084908,
        'retained all-sweep numerical stream missing from archive')
    # Preserve the first compile/admission/control failures rather than overwriting them.
    for name in ('dyq32-training-build1','dyq32-training-build2','dyq32-training-build3'):
        root=W/name
        for p in root.iterdir():
            if p.name in ('build.log','build-failure.json'):files[f'preserved-failures/{name}/{p.name}']=p
    for p in (W/'dyq32-controls-normal1.log',W/'dyq32-controls-normal2.log',W/'dyq32-initial-admission1-trainer/admit_proof9_q32/stderr.bin'):
        files['preserved-failures/'+p.parent.name+'/'+p.name]=p
    inventory={k:ident(v) for k,v in files.items()}
    D.mkdir(exist_ok=False)
    archive=D/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as z:
        for k,v in files.items():z.write(v,k)
        z.writestr('inventory.json',json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    req(archive.stat().st_size<50<<20,'archive allowance')
    with ZipFile(archive) as z:
        req(z.testzip() is None,'archive CRC')
        for k,v in inventory.items():
            with z.open(k) as f:
                req(z.getinfo(k).file_size==v['bytes'] and hashlib.file_digest(f,'sha256').hexdigest()==v['sha256'],'archive member differs')
    manifest={'version':'native-dyadic-quality32-evidence-v1','source_head':x.head,
        'status':'accepted_proof9_quality32_recovered_training_and_replay','scope':'Fixed N9 game only; exact replay and quality target are separate.',
        'training_invocations':1,'quality_gate':gate,'admission':run['admission'],
        'first_four_sweep_comparison':comparison,
        'checkpoint_inputs':run['checkpoint_inputs'],'sweep_capture':capture,'saved_only_replay':replay,
        'paging':run['paging'],'policy_spill':run['policy_spill'],'row_directory':run['row_directory'],
        'quantizer':run['quantizer'],'recovery_operator':outer,'interrupted_original_attempt':interruption,
        'native_producer_calls_during_recovery':0,'source_files':len(hashes),
        'source_inventory_sha256':ident(C/'source.json')['sha256'],
        'native_process':read(C/'train_proof9_q32/process.json'),
        'independent_forecast':{'path':'external/dyadic-q32-source-closed.json',**ident(W/'dyadic-q32-source-closed.json')},
        'archive':{'path':'verification.zip',**ident(archive),'members':len(inventory)+1}}
    with (D/'manifest.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({'destination':str(D),'archive':manifest['archive'],'quality_gate':gate}))
if __name__=='__main__':main()
