"""External observer for saved-only Q32 recovery; no native producer."""
import json,runpy,sys
from pathlib import Path
W=Path(__file__).resolve().parent
S=W/'dyq32-nine-src1'
R=W/'dyq32-nine-recovery1'
O=W/'dyq32-nine-recovery-launch1'
def main():
    ops=runpy.run_path(str(W/'trusted-virtual-dyadic-training-launch-v26.py'))
    sha,snapshot,save,observe=(ops[k] for k in ('sha','snapshot','save','observe'))
    recovery=W/'recover-dyadic-quality32.py';before=snapshot(S)
    script_sha=sha(recovery)
    O.mkdir(exist_ok=False)
    save(O/'operator.json',{'source_head':'38f77e49cf2271e5400ee439a6141d86f5161e47',
        'recovery_script_sha256':script_sha,'operator_sha256':sha(Path(__file__)),
        'native_producer_calls':0})
    save(O/'source-before.json',before)
    result=observe([sys.executable,'-I','-S','-B',str(recovery)],S,O)
    after=snapshot(S)
    if before!=after or sha(recovery)!=script_sha:raise RuntimeError('recovery source changed')
    final=json.loads((R/'completion.json').read_bytes())
    if final['native_producer_calls_during_recovery']!=0 or not final['raw_source_revalidated']:
        raise RuntimeError('recovery completion differs')
    save(O/'source-after.json',after)
    save(O/'completion.json',{'head':final['head'],**result,'raw_source_stable':True,
        'native_producer_calls':0,'recovery_status':final['status']})
    print(json.dumps({'observed_recovery_exit':result,'recovery_status':final['status'],
        'quality_gate':final['quality_gate'],'exploitability':final['saved_only_replay']['profile_and_br']['exploitability']}))
if __name__=='__main__':main()
