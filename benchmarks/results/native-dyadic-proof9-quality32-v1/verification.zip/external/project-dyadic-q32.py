"""Independent rank-free indexed sparse Chance forecast; no native producer."""
import argparse, hashlib, json, subprocess, sys
from collections import Counter
from functools import lru_cache
from itertools import combinations
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('repo',type=Path)
p.add_argument('--expected-head',required=True)
args=p.parse_args()
repo=args.repo.resolve(strict=True)
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
if head!=args.expected_head: raise ValueError('source HEAD differs')
sys.path.insert(0,str(repo))
from tests.full_deck_public_chance_reference import PROOF9,proof_ranges
from tests.virtual_betting_template_reference import build_reference_template
from tests.virtual_frozen_update_reference import _template_case
T=build_reference_template(_template_case()); ranges=proof_ranges()
pairs=[frozenset(a+b) for a,_ in ranges[0] for b,_ in ranges[1] if set(a).isdisjoint(b)]
def words(bits): return max(1,(bits+63)//64)
def logceil(n): return (n-1).bit_length() if n else 0
def add(bits): return 2+3*words(bits)
def copy(bits): return 1+2*words(bits)
def mul(a,b):
    x,y=words(a),words(b)
    return 2+2*(x+y)+x*y
def uniform_exp(m):
    units=[(1<<52)//m+(a<(1<<52)%m) for a in range(m)]
    return 52-min((x&-x).bit_length()-1 for x in units)
@lru_cache(None)
def suffix(id):
    node=T.nodes[id]
    return (uniform_exp(len(node.edges)) if node.phase=='decision' else 0)+max((suffix(e.child) for e in node.edges),default=0)

def forecast(size,indexed,sweeps=32,sparse=True):
    deck=tuple(PROOF9) if size==9 else tuple(sorted((*PROOF9,0))) if size==10 else tuple(sorted((*PROOF9,0,1)))
    if len(deck)!=size: raise ValueError('fixture deck size')
    live={0:{()}}
    populations={}
    for street in (0,3,4,5):
        if street:
            old=0 if street==3 else street-1
            candidates=(combinations(deck,3) if street==3 else
                        (board+(card,) for board in live[old] for card in deck if card not in board))
            live[street]={b for b in candidates if any(private.isdisjoint(b) for private in pairs)}
        populations[street]=Counter(tuple(sum(set(hand).isdisjoint(board) for hand,_ in side) for side in ranges)
                                    for board in live[street])
    planes={frozenset(board) for board in live[5]}
    n=len(planes)
    ranks=sum(set(hand).isdisjoint(board) for board in planes for side in ranges for hand,_ in side)
    costs=Counter(); queries=Counter(); literals=0
    def charge(showdown,street,target,exp,mult=1,group='terminal'):
        reach=exp+1
        for counts,pop in populations[street].items():
            own,opp=counts[target],counts[1-target]
            bucket=8+reach+logceil(opp); out=4+bucket
            units=pop*mult
            input_cost=12+6+street+2*(4+2*words(reach))+4
            dynamic=((12+opp*mul(4,reach)+own*opp*((16 if showdown else 8)+add(bucket))
                     +own*mul(4,bucket)+2*(copy(out)+2)) if sparse else
                     (12+opp*mul(4,reach)+53*(2+own if showdown else 1)+(9 if showdown else 3)*opp*add(bucket)
                     +own*((12 if showdown else 3)*add(bucket)+mul(4,bucket)+copy(out)+2*words(bucket))+128))
            costs['input']+=units*input_cost
            costs['contraction']+=units*dynamic
            queries[group]+=units
            if showdown:
                costs['lookup']+=units*((6+8*n.bit_length()) if indexed else 2*n)
                queries['showdown']+=units
    def visit(id,past,first):
        nonlocal literals
        literals+=1
        node=T.nodes[id];street=node.street
        if node.phase=='decision':
            actor=node.state.player
            past=list(past);first=list(first)
            past[actor]+=1;first[actor]+=uniform_exp(len(node.edges))
        elif node.phase=='reveal':
            for target in (0,1): charge(False,node.state.board_length,target,0,sweeps,'marginal')
        else:
            showdown=node.phase=='showdown'
            for target in (0,1):
                query_street=5 if showdown else street
                charge(showdown,query_street,target,first[1-target],group='terminal_first')
                charge(showdown,query_street,target,52*past[1-target],mult=sweeps-1,group='terminal_second')
        for edge in node.edges: visit(edge.child,past,first)
    for target in (0,1): charge(False,0,target,0,sweeps,'marginal')
    visit(T.root,(0,0),(0,0))
    if literals!=1105: raise ValueError('literal geometry differs')
    costs['setup']=65536
    costs['rank']=4096*ranks
    costs['sort']=512*n
    costs['fill_and_lru']=n*(64+4*n)
    if indexed:
        costs['index_setup']=4*n+16
        costs['index_updates']=n*(8*n+16*n.bit_length()+32)
    return {'deck':deck,'value_bits':644 if size in (9,10) else 646,'prefix_populations':{str(k):{str(key):v for key,v in sorted(pop.items())} for k,pop in populations.items()},
            'prefix_counts':{str(k):len(v) for k,v in live.items()},'planes':n,'rank_calls':ranks,
            'queries':dict(queries),'costs':dict(costs),'chance_total':sum(costs.values())}

from scripts.census_virtual_dyadic_storage import supported_prefixes
@lru_cache(None)
def decisions(id):
    node=T.nodes[id]
    return int(node.phase=='decision')+max((decisions(e.child) for e in node.edges),default=0)

def quant_cost(menu,e,bits,division):
    sm=e+logceil(menu)+1;scaled=e+52;high=max(53,sm,scaled)
    return (64+16*menu+4*menu*(words(bits)+1)+256+16*menu*(words(high)+1)+
            8*menu*(division*words(scaled)*words(sm)+4*words(high)+8)+4*menu*menu*(words(sm)+1))

def geometry(bits,division,sweeps):
    deck=tuple(PROOF9)
    supported={(k,p):sum(supported_prefixes(deck,p,hand,k,ranges) for hand,_ in ranges[p])
               for k in (0,3,4,5) for p in (0,1)}
    terms=Counter(); A=G=R=S=0
    def walk(id,past,first):
        nonlocal A,G,R,S
        node=T.nodes[id]
        if node.phase=='decision':
            player=node.state.player;m=len(node.edges);rows=supported[node.street,player];slots=rows*m
            R+=rows;S+=slots
            a_shift=625-52*(past[player]+1)
            r_shift=52*(12-past[1-player]-decisions(id))
            A+=slots*words(bits-a_shift);G+=slots*words(bits-r_shift)
            E=first[1-player]+suffix(id);EA=52*(past[player]+1)
            terms['initial_uniform']+=rows*(320+48*m)
            terms['first_regret']+=rows*quant_cost(m,10+2+4+1+E,bits,division)
            terms['final_average_t2']+=rows*quant_cost(m,10+2+EA,bits,division)
            terms['final_average_t32_bound']+=rows*quant_cost(m,10+EA+5,bits,division)
            terms['later_regret_each']+=rows*quant_cost(m,bits-r_shift,bits,division)
            p=list(past);p[player]+=1;f=list(first);f[player]+=uniform_exp(m)
            past,first=p,f
        for edge in node.edges: walk(edge.child,past,first)
    walk(T.root,(0,0),(0,0))
    return {'rows':R,'slots':S,'average_words':A,'regret_words':G,'terms':dict(terms),
            'quantizer_work':terms['initial_uniform']+terms['first_regret']+
              terms['final_average_t32_bound' if sweeps==32 else 'final_average_t2']+
              max(0,sweeps-2)*terms['later_regret_each']}

def trace_modules(sweeps):
    # Reuse the separately implemented bounded trace APIs without patching them.
    from tests.virtual_dyadic_stage_schedule import stage_schedule
    from tests.virtual_dyadic_directory_trace import directory_trace
    q32=sweeps==32
    return (stage_schedule(virtual_zero=True,sweeps=sweeps,batch_rows=q32,quality32=q32),
            directory_trace(ten_card=False,sweeps=sweeps,quality32=q32))

def composed(q,stage,directory,anchor,T,bits,chance):
    R,S,A,G=q['rows'],q['slots'],q['average_words'],q['regret_words'];L=A+G
    shape={'visits':61099,'actions':57363,'reveals':3735,'candidates':15662,'hidden':22168,'folds':16631,'showdowns':17356}
    requests=stage['logical_read_calls']+T*stage['per_sweep_stage_calls']
    paging=16*requests+T*(5*A+6*G)+8*T*L+8*(2*T*(R if T==32 else S))+2*T*L+160*stage['batched_write_calls']+2*(4096+64+1)
    directory_work=4*4608+16*R+16*(2+4*T)*R+4*directory['misses']*128
    spill=T*(32*R+16*(S-R)+4*S)+64
    codecA=T*(32*R+36*A+(6*words(bits)+70)*S)//2
    codecG=T*(32*R+44*G+(16*words(bits)+88)*S)//2
    old=anchor['parent_work']
    parent={'geometry':3000000,
      'visit':(8+T*12)*shape['visits'],
      'support':64*((T+1)*shape['candidates']+T*shape['hidden']),
      'reach':old['reach']*T//4,'value_add':old['value_add']*T//4,
      'terminal_scale':old['terminal_scale']*T//4,'average':old['average']*T//4,
      'route':T*16*R+16*R+4*S+codecG+paging+directory_work+spill,
      'output':6*S+24*R+T*(6*S+32*R)+160*1105+65536}
    history=4096*1105+1280+(T+1)*(40*shape['actions']+72*shape['reveals']+48*shape['visits']+40*R)-8*R+24*146+16*371+32*R
    registration=64*146+16*371+16*R
    state=1024+8*R+16*S+4*words(635)+(128+32)*R+registration+8*S+2*R+T*(4*R+16*R+4*S+64*R+128*S+(16*S+8*R)*words(bits+58)+4*R)+(4*words(bits)+4)*S+20*R+4*S
    components={'template':42556544,'chance':chance,'history':history,'state':state,'quantizer':q['quantizer_work'],'parent':sum(parent.values())}
    retained=3045420+(T-4)*(8*S+4*12*8)
    wire=retained+T*(32+8*L)
    copywork=T*(2*L+64*((8*L+32767)//32768)+32)
    if T==32:
        parent['output']+=2048
        components['parent']+=2048
    # Existing legacy reservation extended by T bounded PolicySpillSweep receipts.
    payload=(5*S+256)*(bits+58)+640*S+16*R+T*64*8+(264*8 if T==32 else 0)
    return {'components':components,'parent_work':parent,'paging_work':paging,'directory_work':directory_work,'policy_spill_work':spill,
            'numerical_total':sum(components.values()),'transport_work':copywork,'composed_total':sum(components.values())+copywork,
            'retained_bytes':retained,'checkpoint_bytes_per_image':8*L,'wire_bytes':wire,'state_payload_bits_legacy':payload,
            'pager':stage,'directory':directory,
            'projected_total_entries':anchor['entries']+(T-4)*8+(33-8+256 if T==32 else 0),
            'projected_composed_payload_bits':payload+13637280+(262400+16384 if T==32 else 0),
            'limits_note':'Q32 named lifecycle and owner limits required; independently projected closure, subject to native admission.'}

result={'scope':'Independent rank-free Chance work forecast only; no production builder, hand ranks, training or native calls.',
        'source_head':head,'fixtures':{}}
for size in (9,):
    result['fixtures'][str(size)]={mode:forecast(size,mode=='indexed') for mode in ('linear','indexed')}
legacy=geometry(642,2,4)
result['t4_quantizer_anchor']=legacy
result['q32_geometry_and_combined_quantizer']=geometry(644,1,32)
result_chance=result['fixtures']['9']['linear']['chance_total']
anchor=json.loads((repo/'benchmarks/results/native-dyadic-proof9-four-sweep-accepted-v1/manifest.json').read_text())['admission']
if legacy['quantizer_work']!=anchor['component_work']['quantizer'] or (legacy['average_words'],legacy['regret_words'])!=(anchor['packed_average_limbs'],anchor['packed_regret_limbs']):
    raise ValueError('T4 calibration mismatch')
legacy_chance=forecast(9,False,sweeps=4,sparse=False)
if legacy_chance['chance_total']!=anchor['component_work']['chance']:
    raise ValueError('T4 chance forecast mismatch')
result['t4_chance_validation']=legacy_chance
t4stage,t4directory=trace_modules(4)
t4model=composed(legacy,t4stage,t4directory,anchor,4,642,anchor['component_work']['chance'])
for family in ('state','history','quantizer','parent'):
    if t4model['components'][family]!=anchor['component_work'][family]:
        raise ValueError(f'T4 composed mismatch: {family}: {t4model["components"][family]} != {anchor["component_work"][family]}')
if t4model['parent_work']!=anchor['parent_work']:
    raise ValueError('T4 parent component mismatch')
result['t4_composed_validation']='all State/history/quantizer/parent terms and packed geometry match saved T4'
stage,directory=trace_modules(32)
result['q32_composed_candidate']=composed(result['q32_geometry_and_combined_quantizer'],stage,directory,anchor,32,644,result_chance)
result['scope']='Rank-free Q32 candidate forecast calibrated to accepted T4 quantizer and geometry; named profile and full live-entry/payload closure not admitted.'
print(json.dumps(result,indent=2,sort_keys=True))
