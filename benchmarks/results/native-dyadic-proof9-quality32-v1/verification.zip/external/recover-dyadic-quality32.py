"""Recover saved Q32 verification after an externally interrupted controller.
No build or native producer is invoked. The incomplete original attempt is preserved.
"""
import hashlib, importlib.abc, importlib.machinery, json, runpy, subprocess, sys
from fractions import Fraction
from pathlib import Path

W=Path(__file__).resolve().parent
S=W/'dyq32-nine-src1'
C=W/'dyq32-nine-cohort1'
O=W/'dyq32-nine-launch1'
R=W/'dyq32-nine-recovery1'
HEAD='38f77e49cf2271e5400ee439a6141d86f5161e47'

def req(ok,msg):
    if not ok: raise ValueError(msg)
def read(p): return json.loads(p.read_bytes())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(p): return {'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')

def main():
    req(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,'isolated recovery required')
    operator=W/'trusted-virtual-dyadic-training-launch-v26.py'
    ops=runpy.run_path(str(operator))
    snapshot,git=ops['snapshot'],ops['git']
    source=read(C/'source.json')
    hashes={k:v['raw_sha256'] for k,v in source['files'].items()}
    req(source['head']==read(C/'claim.json')['head']==HEAD and
        git(S,'rev-parse','HEAD').decode().strip()==HEAD and
        snapshot(S)==hashes==read(O/'source-before.json'),'captured original source changed')
    req(all(sha(C/'source'/k)==v for k,v in hashes.items()),'captured source copy changed')
    req(not (O/'completion.json').exists() and not (O/'exit.json').exists() and
        not (C/'terminal.json').exists() and not (C/'result.json').exists() and
        not (C/'saved-review/process.json').exists(),'original lifecycle differs from interrupted state')
    req(all((C/'saved-review'/n).stat().st_size==0 for n in ('request.bin','stdout.bin','stderr.bin')),
        'original unfinished review stream changed')
    launch=read(O/'operator-launch.json')
    req(launch['head']==HEAD and launch['mode']=='train_proof9_q32' and
        launch['operator_sha256']==sha(operator),'original launch identity differs')
    boot_name='scripts/run_virtual_frozen_source_only.py'
    bootstrap=S/boot_name
    req(sha(bootstrap)==hashes[boot_name]==launch['bootstrap_sha256'] and
        hashlib.sha256(launch['first_stage'].encode()).hexdigest()==launch['first_stage_sha256'] and
        bootstrap.read_bytes().replace(b'\r\n',b'\n')==git(S,'show',HEAD+':'+boot_name),
        'committed bootstrap differs')
    build_path=C/'build/native-exact-build-manifest.json'
    build=read(build_path)
    req(build['target']=='virtual-dyadic-training' and
        sha(Path(build['executable']))==build['executable_sha256'] and
        all(hashes[k]==v==sha(C/'source'/k) for k,v in build['source_sha256'].items()),
        'native build closure differs')
    for mode in ('admit_proof9_q32','train_proof9_q32'):
        d=C/mode;p=read(d/'process.json');b=read(d/'binary-identity.json')
        req(p['status']=='exited' and p['returncode']==0 and p['actual_exit_observed'] and
            not p['automatic_retries'] and not p['failures'] and
            b['before_sha256']==b['after_sha256']==build['executable_sha256'] and
            b['build_manifest_sha256']==sha(build_path) and
            (d/'request.bin').read_bytes()==('DYADIC_T32_V1 '+mode.upper()+'\n').encode() and
            sha(d/'request.bin')==p['request_sha256'] and not (d/'stderr.bin').stat().st_size,
            'native observed exit or request identity differs')
        for name,item in zip(('stdout.bin','stderr.bin'),p['streams'],strict=True):
            req(identity(d/name)=={'bytes':item['saved_bytes'],'sha256':item['sha256']},
                'saved native stream differs')
    loaded={}
    class SourceOnly(importlib.machinery.SourceFileLoader):
        def get_code(self,fullname):
            p=Path(self.path);name=p.relative_to(S).as_posix();raw=p.read_bytes()
            req(name in hashes and hashlib.sha256(raw).hexdigest()==hashes[name],'import source changed')
            loaded[name]=hashes[name]
            return compile(raw,str(p),'exec',dont_inherit=True)
    class Guard(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            spec=importlib.machinery.PathFinder.find_spec(fullname,path,target)
            if spec and spec.origin:
                p=Path(spec.origin).resolve()
                if p.is_relative_to(S):
                    req(p.suffix=='.py' and isinstance(spec.loader,importlib.machinery.SourceFileLoader),
                        'project import is not verified source')
                    spec.loader=SourceOnly(fullname,str(p))
            return spec
    sys.path.insert(0,str(S));sys.meta_path.insert(0,Guard())
    from scripts import run_virtual_dyadic_training_cohort as controller
    from tests.virtual_dyadic_stage_schedule import stage_schedule
    from tests.virtual_frozen_run_control import run_bounded_quality32_replay
    admission=read(C/'admission.json')
    req(admission==read(C/'admit_proof9_q32/stdout.bin'),'saved admission differs')
    controller.validate_admission(admission,proof9_quality32=True)
    inputs=read(C/'checkpoint-inputs.json');data=C/'train_proof9_q32/stdout.bin'
    pages=C/'page-images';row_path=C/'page-images-rows'
    process=read(C/'train_proof9_q32/process.json')
    schedule=stage_schedule(virtual_zero=True,sweeps=32,batch_rows=True,quality32=True)
    paging=controller.verify_paging(pages,admission,schedule)
    images=[{'name':name,**paging['images'][name]} for name in ('staged.bin','committed.bin')]
    capture=controller.verify_sweep_capture(process,admission,images,inputs['stream']['sha256'])
    req(inputs=={'stream':identity(data),'sweep_images':images,'sweep_epochs':capture['frames']},
        'original inputs or generation frames differ')
    spill=controller.verify_policy_spill(pages,data,admission)
    directory=controller.verify_row_directory(row_path,data,admission)
    quantizer=controller.verify_division_receipt(pages,admission)
    observed={str(p):identity(p) for p in
        (data,C/'train_proof9_q32/process.json',C/'admit_proof9_q32/process.json',
         C/'checkpoint-inputs.json',*(pages/n for n in ('committed.bin','staged.bin','policy.bin','policy.json','paging.json','quantizer.json')),
         row_path/'rows.bin',row_path/'rows.json')}
    R.mkdir(exist_ok=False)
    save(R/'source-before.json',hashes);save(R/'inputs.json',observed)
    save(R/'interruption.json',{'original_outer_exit_observed':False,
        'original_replay_exit_observed':False,'original_terminal_receipt_present':False,
        'original_native_exit_observed':True,'original_native_returncode':0,
        'reason':'Original parent and replay processes absent when resumed; no terminal receipt. Cause is unverified.',
        'original_attempt_preserved':True,'new_native_producer_calls':0})
    arguments=['--saved',str(data),'--sha256',inputs['stream']['sha256'],
        '--paired','--rank-sets','--count-policy-divisions','--proof9-quality32',
        '--sweep-checkpoint-digest',*(f['sha256'] for f in capture['frames'])]
    original=controller.source_only_command(bootstrap,hashes[boot_name],
        'scripts.verify_virtual_dyadic_training',C/'saved-review-bootstrap.json',arguments)
    req(read(C/'saved-review-command.json')==original,'original exact source-only command differs')
    command=controller.source_only_command(bootstrap,hashes[boot_name],
        'scripts.verify_virtual_dyadic_training',R/'saved-review-bootstrap.json',arguments)
    save(R/'saved-review-command.json',command)
    result=run_bounded_quality32_replay(command,b'',R/'saved-review')
    req(result['status']=='exited' and result['returncode']==0 and result['actual_exit_observed'] and
        not result['failures'] and not result['automatic_retries'],'saved-only recovery child failed')
    boot=read(R/'saved-review-bootstrap.json')
    req(boot['entry_module']=='scripts.verify_virtual_dyadic_training' and boot['root']==str(S) and
        boot['trusted_first_stage']=={'bootstrap_path':str(bootstrap),'bootstrap_sha256':hashes[boot_name],
            'command_sha256':launch['first_stage_sha256']} and
        boot['initial_cache_scan']['project_bytecode_files']==boot['final_cache_scan']['project_bytecode_files']==0 and
        all(hashes.get(k)==v for k,v in boot['compiled'].items()) and
        {'scripts/verify_virtual_dyadic_training.py','tests/virtual_dyadic_training_reference.py'}<=set(boot['compiled']),
        'recovery executed source closure differs')
    replay=read(R/'saved-review/stdout.bin')
    req(replay['status']=='saved_quality32_exact_replay_pass' and replay['native_producer_calls']==0 and
        replay['checkpoint_verification']=='independent_compact_digest' and
        replay['saved_output_sha256']==inputs['stream']['sha256'] and
        replay['checkpoint_epochs']==capture['frames'] and replay['checkpoint_images']==images and
        replay['wire_sha256']==capture['wire_sha256'] and replay['wire_bytes']==171408812 and
        replay['work_plan']==admission['component_work'] and replay['parent_work_plan']==admission['parent_work'] and
        replay['planned_entries']==admission['entries'] and replay['planned_payload_bits']==admission['payload_bits'] and
        replay['combined_divisions']==quantizer['combined_divisions'],'independent recovery replay differs')
    value=replay['profile_and_br']['exploitability'];passed=Fraction(int(value['numerator']),int(value['denominator']))<=Fraction(1,10)
    req(replay['quality_gate']=={'metric':'exploitability_bb','threshold':{'numerator':'1','denominator':'10'},
        'status':'pass' if passed else 'miss','passed':passed},'fixed quality threshold differs')
    req(snapshot(S)==hashes and all(identity(Path(p))==v for p,v in observed.items()),
        'source or producer evidence drift during recovery')
    save(R/'source-after.json',hashes);save(R/'imported-source.json',loaded)
    save(R/'completion.json',{'head':HEAD,'status':'recovered_quality32_exact_replay_pass',
        'training_invocations':1,'native_producer_calls_during_recovery':0,'raw_source_revalidated':True,
        'original_outer_exit_observed':False,'replay_exit':result,'admission':admission,
        'checkpoint_inputs':inputs,'sweep_capture':capture,
        'sweep_capture_process_sha256':sha(C/'train_proof9_q32/process.json'),
        'paging':paging,'row_directory':directory,'policy_spill':spill,'quantizer':quantizer,
        'independent_stage_schedule':schedule,'saved_only_replay':replay,'quality_gate':replay['quality_gate']})
    print(json.dumps({'head':HEAD,'status':'recovered_quality32_exact_replay_pass',
        'exploitability':value,'quality_gate':replay['quality_gate'],'new_native_producer_calls':0}))
if __name__=='__main__':main()
