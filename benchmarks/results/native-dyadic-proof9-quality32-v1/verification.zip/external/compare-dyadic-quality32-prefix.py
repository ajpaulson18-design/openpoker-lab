"""Compare the accepted N9 T4 prefix with the saved Q32 stream; no producer."""
import hashlib,json
from pathlib import Path
from zipfile import ZipFile
W=Path(__file__).resolve().parent;R=W/'dyadic-phase-payload-repo';C=W/'dyq32-nine-cohort1'
def req(ok,msg):
    if not ok:raise ValueError(msg)
def read(p):return json.loads(p.read_bytes())
def ident(p):
    with p.open('rb') as f:return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
def main():
    baseline=R/'benchmarks/results/native-dyadic-proof9-four-sweep-accepted-v1'
    old=read(baseline/'manifest.json');archive=baseline/'verification.zip'
    source=read(C/'source.json')['files']
    req(ident(archive)=={k:old['archive'][k] for k in ('bytes','sha256')} and
        ident(archive)['sha256']==source[archive.relative_to(R).as_posix()]['raw_sha256'] and
        ident(baseline/'manifest.json')['sha256']==source[(baseline/'manifest.json').relative_to(R).as_posix()]['raw_sha256'],
        'baseline archive/source closure differs')
    with ZipFile(archive) as z:
        matches=[n for n in z.namelist() if n.endswith('/train_proof9_t4/stdout.bin')]
        req(len(matches)==1,'ambiguous baseline numerical member')
        previous=z.read(matches[0])
    current=(C/'train_proof9_q32/stdout.bin').read_bytes()
    req(hashlib.sha256(previous).hexdigest()==old['saved_only_replay']['saved_output_sha256'] and
        len(previous)==3045420 and len(current)==16084908,'numerical stream binding differs')
    prelude=8+16*8+11*8+1105*96+24420*24
    end=prelude+4*(58164*8+4*12*8)
    req(previous[136:end]==current[136:end],'N9 source/rows/first4 grids or roots changed')
    q32=read(W/'dyq32-nine-recovery1/completion.json')
    req(q32['sweep_capture']['frames'][:4]==old['sweep_capture']['frames'],
        'first four exact checkpoint images changed')
    report={'source_head':q32['head'],'baseline_source_head':old['source_head'],
        'baseline_archive':ident(archive),'numeric_stream_sha256':ident(C/'train_proof9_q32/stdout.bin')['sha256'],
        'equal_prefix_offset':136,'equal_prefix_bytes':end-136,
        'first_four_checkpoint_epochs':q32['sweep_capture']['frames'][:4],
        'baseline_quality':old['saved_only_replay']['profile_and_br']['exploitability'],
        'quality32':q32['saved_only_replay']['profile_and_br']['exploitability'],
        'quality_gate':q32['quality_gate'],'native_producer_calls':0}
    with (W/'dyadic-quality32-prefix-comparison.json').open('x',encoding='utf-8') as f:
        json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({'first_four_sweeps_equal':True,'equal_prefix_bytes':end-136,
        'baseline_exploitability':report['baseline_quality']['approx'],
        'quality32_exploitability':report['quality32']['approx'],'quality_gate':report['quality_gate']}))
if __name__=='__main__':main()
