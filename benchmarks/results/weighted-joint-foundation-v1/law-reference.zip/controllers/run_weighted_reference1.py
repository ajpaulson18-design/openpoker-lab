"""Frozen-source first weighted-law reference execution; retain every exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parent / 'dyprofile-repo'
out = root.parent / 'weighted-law-reference2'
out.mkdir(exist_ok=False)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
tree = {}
for entry in git('ls-tree', '-r', '-z', 'HEAD').decode().split('\0'):
    if entry:
        metadata, name = entry.split('\t', 1)
        if name.endswith('.py'):
            tree[name] = metadata.split()[2]
names = tuple(tree)
# Let Git expand the pathspec: passing every source path exceeds Windows'
# command-line limit before any reference code can run.
if git('status', '--porcelain', '--untracked-files=no', '--', '*.py'):
    raise ValueError('Python closure must be committed and clean')
head = git('rev-parse', 'HEAD').decode().strip()
captured = {}
for name in names:
    raw = (root / name).read_bytes()
    captured[name] = {'sha256': digest(raw), 'bytes': len(raw),
                      'git_blob': tree[name]}
source = {'head': head, 'source_capture': 'All tracked Python source captured before first execution; native/C++ not executed.',
          'captured_utc': datetime.now(timezone.utc).isoformat(), 'sources': captured}
(out / 'sources-before.json').write_text(json.dumps(source, indent=2) + '\n', encoding='utf-8')
records = []
for mode in ('normal', 'optimized'):
    command = [sys.executable, *(['-O'] if mode == 'optimized' else []), '-B', '-X',
               'pycache_prefix=' + str(out / (mode + '-empty-cache')),
               '-m', 'unittest', 'tests.test_weighted_joint_reference', '-v']
    started = datetime.now(timezone.utc).isoformat()
    with (out / (mode + '.stdout.log')).open('xb') as stdout, (out / (mode + '.stderr.log')).open('xb') as stderr:
        process = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, check=False)
    record = {'command': command, 'started_utc': started, 'ended_utc': datetime.now(timezone.utc).isoformat(),
              'observed_exit_code': process.returncode, 'mode': mode, 'python': sys.version}
    for stream in ('stdout', 'stderr'):
        raw = (out / (mode + '.' + stream + '.log')).read_bytes()
        record[stream] = {'bytes': len(raw), 'sha256': digest(raw)}
    records.append(record)
    (out / (mode + '.process.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
after = {name: digest((root / name).read_bytes()) for name in names}
stable = (git('rev-parse', 'HEAD').decode().strip() == head and
          all(after[name] == record['sha256'] for name, record in captured.items()))
(out / 'sources-after.json').write_text(json.dumps({'head': head, 'all_raw_sources_unchanged': stable,
                                                   'source_sha256': after}, indent=2) + '\n', encoding='utf-8')
if not stable or any(record['observed_exit_code'] != 0 for record in records):
    sys.exit(1)
