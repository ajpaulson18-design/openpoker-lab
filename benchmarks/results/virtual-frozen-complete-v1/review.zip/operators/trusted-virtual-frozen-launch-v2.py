"""Trusted operator stdlib launcher: no project imports before -c first stage."""
from pathlib import Path
import argparse,ast,hashlib,json,os,subprocess,sys,threading,time


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            block=f.read(1<<20)
            if not block:break
            h.update(block)
    return h.hexdigest()


def git(repo,*args):
    return subprocess.check_output(['git','-c','core.fsmonitor=false',*args],cwd=repo)


def snapshot(repo):
    if git(repo,'status','--porcelain=v1','--untracked-files=all'):raise RuntimeError('dirty operator cohort')
    names=[n.decode() for n in git(repo,'ls-files','-z').split(b'\0') if n]
    if len(names)>4096:raise RuntimeError('operator source inventory cap')
    return {name:sha(repo/name) for name in names}


def observe(command,repo,path):
    path.mkdir(exist_ok=False)
    (path/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    process=subprocess.Popen(command,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
    (path/'live-handle.json').write_text(json.dumps({'pid':process.pid,'created_epoch':time.time(),'command':command})+'\n')
    failures=[]
    def drain(pipe,destination):
        total=0
        with destination.open('xb') as f:
            while True:
                chunk=pipe.read(65536)
                if not chunk:break
                total+=len(chunk)
                if total>2*(1<<20):
                    failures.append('outer stream bound')
                    if process.poll() is None:process.kill()
                    break
                f.write(chunk)
        pipe.close()
    threads=[threading.Thread(target=drain,args=(process.stdout,path/'stdout.log')),
             threading.Thread(target=drain,args=(process.stderr,path/'stderr.log'))]
    for t in threads:t.start()
    code=process.wait()
    for t in threads:t.join()
    result={'returncode':code,'actual_exit_observed':True,'failures':failures}
    (path/'exit.json').write_text(json.dumps(result,indent=2)+'\n')
    if code or failures:raise RuntimeError('outer process failed; preserve attempt')
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--head',required=True);parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--study-output',type=Path)
    args=parser.parse_args();repo=args.repo.resolve();args.out.mkdir(exist_ok=False)
    if git(repo,'rev-parse','HEAD').decode().strip()!=args.head:raise RuntimeError('operator HEAD mismatch')
    before=snapshot(repo);(args.out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
    script=repo/'scripts/run_virtual_frozen_source_only.py';raw=script.read_bytes()
    committed=git(repo,'show',args.head+':scripts/run_virtual_frozen_source_only.py')
    if raw!=committed and raw.replace(b'\r\n',b'\n')!=committed:raise RuntimeError('bootstrap differs from committed source')
    values=[ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FIRST_STAGE' for t in n.targets)]
    if len(values)!=1 or type(values[0]) is not str:raise RuntimeError('trusted first-stage literal missing')
    stage=values[0];identity=hashlib.sha256(raw).hexdigest()
    (args.out/'operator-launch.json').write_text(json.dumps({'head':args.head,'bootstrap_sha256':identity,'first_stage':stage,'first_stage_sha256':hashlib.sha256(stage.encode()).hexdigest(),'trust_anchor':'this external standard-library operator launcher and recorded Python/runtime'},indent=2)+'\n')
    modules=['tests.test_virtual_frozen_bootstrap','tests.test_virtual_frozen_controller','tests.test_virtual_frozen_execution_closure','tests.test_virtual_frozen_source_guard','tests.test_virtual_frozen_run_control','tests.test_virtual_frozen_shared_preparation','tests.test_virtual_frozen_value_reference','tests.test_virtual_frozen_sample_reference','tests.test_virtual_frozen_update_reference','tests.test_virtual_frozen_study_admission','tests.test_virtual_frozen_update_comparison','tests.test_virtual_frozen_expectation','tests.test_virtual_frozen_reference_artifact','tests.test_virtual_frozen_whole_study']
    runs=[('study',[],'scripts.run_virtual_frozen_update_study',['--output',str(args.study_output),'--expected-head',args.head])] if args.study_output else [('normal',[],'unittest',modules+['-v']),('optimized',['-O'],'unittest',modules+['-v'])]
    statuses=[]
    for label,flags,module,arguments in runs:
        receipt=args.out/(label+'-bootstrap.json')
        command=[sys.executable,'-I','-S','-B',*flags,'-c',stage,str(script),identity,'--module',module,'--receipt',str(receipt),'--',*arguments]
        result=observe(command,repo,args.out/label)
        if not receipt.exists() or receipt.stat().st_size>1<<20:raise RuntimeError('final bootstrap receipt absent/oversize')
        boot=json.loads(receipt.read_bytes())
        if boot['trusted_first_stage']['bootstrap_sha256']!=identity:raise RuntimeError('bootstrap identity differs')
        for name,value in boot['compiled'].items():
            if name not in before or value!=before[name]:raise RuntimeError('executed source bytes differ from operator snapshot')
            blob=git(repo,'show',args.head+':'+name);working=(repo/name).read_bytes()
            if working!=blob and working.replace(b'\r\n',b'\n')!=blob:raise RuntimeError('executed source differs from committed source')
        statuses.append({'mode':label,**result,'compiled_project_files':len(boot['compiled'])})
    after=snapshot(repo)
    if after!=before:raise RuntimeError('operator raw source drift')
    (args.out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    result={'head':args.head,'runs':statuses,'raw_source_stable':True,'scope':'source-only control corpus' if not args.study_output else 'outer observed numerical study; saved-only acceptance remains required'}
    (args.out/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()
