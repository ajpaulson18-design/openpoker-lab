$ErrorActionPreference = 'Stop'
$taskWork = $PSScriptRoot
$watchDirectory = Join-Path $taskWork 'vfu-review-watch1'
New-Item -ItemType Directory -Path $watchDirectory -ErrorAction Stop | Out-Null
function Save-WatchReceipt([string]$Name, $Value) {
    $destination = Join-Path $watchDirectory $Name
    if (Test-Path -LiteralPath $destination) { throw 'Existing watcher receipt must be preserved' }
    $Value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $destination -Encoding UTF8
}
try {
    $controls = Get-Content -LiteralPath (Join-Path $taskWork 'vfu-review-controls1/completion.json') -Raw | ConvertFrom-Json
    if ($controls.head -ne '6b49057bc62a6599bfc23086ecda52576d755908' -or -not $controls.raw_source_stable -or $controls.runs.Count -ne 2) { throw 'Frozen verifier controls are incomplete' }
    foreach ($run in $controls.runs) {
        if ($run.returncode -ne 0 -or -not $run.actual_exit_observed -or $run.failures.Count -ne 0) { throw 'Verifier control exit failed' }
    }
    $live = Get-Content -LiteralPath (Join-Path $taskWork 'vfu-launch2/study/live-handle.json') -Raw | ConvertFrom-Json
    $producerProcess = Get-Process -Id $live.pid -ErrorAction Stop
    [void]$producerProcess.Handle
    $creationSeconds = ([DateTimeOffset]$producerProcess.StartTime).ToUnixTimeMilliseconds() / 1000
    if ([Math]::Abs($creationSeconds - $live.created_epoch) -gt 5) { throw 'Producer PID creation time differs; do not follow a reused PID' }
    Save-WatchReceipt 'waiting.json' @{ producer_pid = $live.pid; actual_creation_epoch = $creationSeconds; expected_creation_epoch = $live.created_epoch; producer_head = '174b66645a05d5f050d4361ce81b06ea9a4e5ac3'; verifier_head = $controls.head; behavior = 'Wait for original process and successful operator completion; start saved review once; no producer or review retry' }
    Write-Output 'Waiting on the original producer process; saved-only review is armed.'
    while (-not $producerProcess.WaitForExit(15000)) { }
    $producerExit = $producerProcess.ExitCode
    Save-WatchReceipt 'producer-exit.json' @{ actual_exit_observed = $true; returncode = $producerExit; producer_pid = $live.pid }
    if ($null -eq $producerExit -or $producerExit -ne 0) { throw 'Original producer did not exit successfully; retain attempt without review' }
    $completionPath = Join-Path $taskWork 'vfu-launch2/completion.json'
    $deadline = [DateTime]::UtcNow.AddSeconds(300)
    while (-not (Test-Path -LiteralPath $completionPath)) {
        if ([DateTime]::UtcNow -gt $deadline) { throw 'Producer operator did not finalize; preserve evidence and inspect original handle' }
        Start-Sleep -Seconds 5
    }
    $completion = Get-Content -LiteralPath $completionPath -Raw | ConvertFrom-Json
    if ($completion.head -ne '174b66645a05d5f050d4361ce81b06ea9a4e5ac3' -or -not $completion.raw_source_stable -or $completion.runs.Count -ne 1) { throw 'Original producer operator completion is invalid' }
    if ($completion.runs[0].returncode -ne 0 -or -not $completion.runs[0].actual_exit_observed -or $completion.runs[0].failures.Count -ne 0) { throw 'Original producer operator observed failure' }
    Save-WatchReceipt 'review-start.json' @{ started_utc = [DateTime]::UtcNow.ToString('o'); source_head = $controls.head; numerical_producer_calls = 0 }
    $taskPython = 'C:\Users\pauls\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    Push-Location (Join-Path $taskWork 'vfu-review-src1')
    try {
        & $taskPython -I -S -B (Join-Path $taskWork 'trusted-virtual-frozen-review-launch-v1.py') --repo (Join-Path $taskWork 'vfu-review-src1') --head 6b49057bc62a6599bfc23086ecda52576d755908 --out (Join-Path $taskWork 'vfu-review-launch1') --review-study (Join-Path $taskWork 'vfu2') --review-operator (Join-Path $taskWork 'vfu-launch2') --review-frozen-repo (Join-Path $taskWork 'vfu-src2') --producer-head 174b66645a05d5f050d4361ce81b06ea9a4e5ac3 --review-output (Join-Path $taskWork 'vfu-review1') 1> (Join-Path $watchDirectory 'review.stdout.log') 2> (Join-Path $watchDirectory 'review.stderr.log')
        $reviewExit = $LASTEXITCODE
    } finally { Pop-Location }
    Save-WatchReceipt 'review-exit.json' @{ actual_exit_observed = $true; returncode = $reviewExit }
    if ($reviewExit -ne 0) { throw 'Saved-only review failed; preserve all outputs and do not rerun producer' }
    Save-WatchReceipt 'completion.json' @{ status = 'saved_review_operator_exited_successfully'; final_acceptance = 'Inspect complete numeric/corruption receipts and final verifier bootstrap'; utc = [DateTime]::UtcNow.ToString('o') }
    Write-Output 'Saved-only review operator completed; final evidence acceptance remains required.'
} catch {
    Save-WatchReceipt 'failure.json' @{ first_error = $_.Exception.Message; details = $_.ScriptStackTrace; utc = [DateTime]::UtcNow.ToString('o'); automatic_retries = 0 }
    Write-Error $_
    exit 1
}
