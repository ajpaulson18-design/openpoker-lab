"""Preserve accepted saved evidence, without importing or running a producer."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,os,zipfile

W=Path(__file__).resolve().parent
P=W/'vfu2';PO=W/'vfu-launch2';R=W/'vfu-review1';RO=W/'vfu-review-launch1'
RS=W/'vfu-review-src1'
D=W/'virtual-frozen-update-repo/benchmarks/results/virtual-frozen-complete-v1'
PH='174b66645a05d5f050d4361ce81b06ea9a4e5ac3'
RH='6b49057bc62a6599bfc23086ecda52576d755908'

def read(p): return json.loads(p.read_bytes())
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def record(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def plain(p):
    if p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&1024:raise RuntimeError('linked path: '+str(p))
    return p
def walk(root):
    for here,dirs,files in os.walk(root):
        here=Path(here)
        for name in sorted(dirs):plain(here/name)
        for name in sorted(files):yield plain(here/name)
def require(b,message):
    if not b: raise RuntimeError(message)
def outer(root,head,label):
    comp=read(root/'completion.json');runs=comp['runs']
    require(comp['head']==head and comp['raw_source_stable'] and len(runs)==1,'outer source receipt')
    require(runs[0]['mode']==label and runs[0]['actual_exit_observed'] and runs[0]['returncode']==0 and not runs[0]['failures'],'outer exit')
    before=read(root/'source-before.json');after=read(root/'source-after.json')
    require(before==after,'outer raw source drift')
    boot=read(root/(label+'-bootstrap.json'))
    require(len(boot['compiled'])==runs[0]['compiled_project_files'] and all(before.get(n)==h for n,h in boot['compiled'].items()),'outer final compiled bytes')
    require(boot['initial_cache_scan']['project_bytecode_files']==0 and boot['final_cache_scan']['project_bytecode_files']==0,'outer caches')
    return comp,before,boot
def main():
    p=read(P/'result.json');r=read(R/'result.json')
    pc,ps,pb=outer(PO,PH,'study');rc,rs,rb=outer(RO,RH,'review')
    require(p['status']=='exact_update_identity_pass' and p['source_head']==PH and p['native_eval_attempts']==p['native_eval_completions']==5040,'producer completion')
    require(r['status']=='complete_saved_numeric_replay_pass' and r['source_head']==PH and r['verifier_head']==RH and r['calls']==5040,'saved replay completion')
    require(r['native_producer_calls']==r['reference_producer_calls']==0,'saved review producer replay')
    require(r['laws']==p['laws'] and set(r['laws'])=={'uniform','river_weighted'},'law receipts')
    require(all(x['boards']==2520 and x['rows']==24420 and x['action_slots']==58164 and x['exact_scalar_comparisons']==140748 for x in r['laws'].values()),'whole-law dimensions')
    require(r['native_mutation_witnesses']['all_detected'] and len(r['native_mutation_witnesses']['witnesses'])==3 and r['q_free_mutation_witness']['detected'],'four saved corruption witnesses')
    require(read(P/'terminal.json')['status']==read(R/'terminal.json')['status']=='complete','terminal claims')
    ss=read(P/'source.json')['files'];vs=read(R/'verifier-source.json')['files']
    require({n:v['raw_sha256'] for n,v in ss.items()}==ps,'producer capture vs operator inventory')
    require({n:v['raw_sha256'] for n,v in vs.items()}==rs,'verifier capture vs operator inventory')
    groups=defaultdict(dict);omitted={}
    def place(group,key,path):
        require(key not in groups[group],'duplicate archive member')
        groups[group][key]=path
    for f in walk(P):
        rel=f.relative_to(P);parts=rel.parts;key='study/'+rel.as_posix()
        if parts[:3]==('source','benchmarks','results'):
            ident=ss[Path(*parts[1:]).as_posix()];omitted[key]={'bytes':ident['bytes'],'sha256':ident['raw_sha256']};continue
        if parts[0] in ('uniform','river_weighted'):
            index=int(parts[1]);require(0<=index<2520,'out of range call archive')
            start=(index//252)*252
            place(f'{parts[0]}-{start:04d}-{start+251:04d}',key,f)
        else:place('producer',key,f)
    for label,root in [('producer-operator',PO),('saved-review',R),('review-operator',RO),('review-watcher',W/'vfu-review-watch1')]:
        for f in walk(root):place('producer' if label=='producer-operator' else 'review',label+'/'+f.relative_to(root).as_posix(),f)
    for name,ident in vs.items():
        key='verifier-source/'+name
        if name.startswith('benchmarks/results/'):
            omitted[key]={'bytes':ident['bytes'],'sha256':ident['raw_sha256']};continue
        place('review',key,plain(RS/name))
    for n in ['trusted-virtual-frozen-launch-v2.py','trusted-virtual-frozen-review-launch-v1.py','wait-and-review-vfu1.ps1',Path(__file__).name]:
        place('review','operators/'+n,W/n)
    require(len(groups)==22,'expected20 call groups and2 metadata groups')
    D.mkdir(exist_ok=False)
    archives=[]
    for group,files in sorted(groups.items()):
        archive=D/(group+'.zip');inventory={}
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for n,f in sorted(files.items()):
                v=record(f);inventory[n]=v
                source_name=None
                if n.startswith('study/source/'): source_name=ss[n.removeprefix('study/source/')]
                if n.startswith('verifier-source/'): source_name=vs[n.removeprefix('verifier-source/')]
                if source_name is not None:require((v['bytes'],v['sha256'])==(source_name['bytes'],source_name['raw_sha256']),'archive source identity: '+n)
                z.write(f,n)
            z.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
        require(archive.stat().st_size<50*(1<<20),'individual archive publication bound')
        with zipfile.ZipFile(archive) as z:
            require(z.testzip() is None,'archive CRC')
            for n,v in inventory.items():
                raw=z.read(n)
                require(len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],'archive raw identity: '+n)
        archives.append({'path':archive.name,**record(archive),'members':len(inventory)+1})
        print(group,archive.stat().st_size,flush=True)
    omitted_path=D/'omitted-prior-evidence.json'
    omitted_path.write_text(json.dumps(omitted,sort_keys=True,indent=2)+'\n')
    result={'version':'virtual-frozen-complete-saved-v1','producer_head':PH,'verifier_head':RH,
            'status':'accepted_fixed_profile_exact_update_identity','producer_outer':pc,'review_outer':rc,
            'producer_evaluations':5040,'saved_replayed_evaluations':5040,'saved_review_producer_calls':0,
            'laws':r['laws'],'native_mutation_witnesses':r['native_mutation_witnesses'],
            'q_free_mutation_witness':r['q_free_mutation_witness'],'archives':archives,
            'omitted_prior_evidence':{'path':omitted_path.name,**record(omitted_path),'files':len(omitted),
                'scope':'historical benchmarks/results payloads from producer and verifier source snapshots only; reconstruct from pinned commits; full raw inventories retained'},
            'scope':'fixed procedural profile update identity in PROOF9 only; no actual training, quality, or broader scalability result',
            'training_calls':0,'quality_gate':None}
    (D/'manifest.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')

if __name__=='__main__':main()
