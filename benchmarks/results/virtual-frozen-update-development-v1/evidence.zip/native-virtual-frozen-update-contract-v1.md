# Next native integration: complete frozen-profile update proof

Architecture handoff only; no sampler, new training, regret proof or policy-quality
run has been executed. Preserve the full user goal. Source candidate `94b4f5f`
and PR #283 compile card-free betting continuations; PR #281 supplies the exact
unconditioned private-prior/prefix/single-board-payoff boundary. Their component
controls do not establish a full four-street update.

## Owners and information

Join one immutable betting template and one immutable original-range/deck chance
kernel. Never build a one-board selected-game Plan/Router or borrow its selected
normalizer. Preserve original SB/BB identities after the actor changes postflop.

The new history owner interns `(parent identity, exact visible token)` with full
collision-safe equality and owned bounded bytes. A cursor carries template node,
already-visible canonical prefix and history lease. Every distinct action path
remains distinct even when its numeric continuation reconverges. Foreign/stale
leases reject. Complete history plus original actor/holding identifies a policy
row; template node never does. Sampled hidden cards cannot pick an earlier row,
prune its physical support, remove an action or select a prior.

First use a complete procedural frozen policy with exact dyadic probabilities,
unequal frequencies and legal zero-probability alternatives. It can be evaluated
for every legal history without storing a full table. This is an explicit test
policy, not trained quality or an implicit abstraction. Later lazy row pages need
complete export/fallback semantics, immutable owner identity, menu checks and
reduce-only persistent/staging/output limits; no eviction, reset or row aliasing.

## Candidate exact frozen update

For each exogenous complete public board B with positive exact proposal q(B),
walk every legal action in the card-free template. Reveal its canonical flop,
then ordered turn and river only at symbolic reveal boundaries. Early folds and
all-ins still use B for integration; never redraw a zero-target B.

At a terminal for target player p use the full-deck kernel's exact vector:

`wi * sum_j compatible(wj * opponent_action_reach_j * utility_ij) / (Z*d5*q(B))`.

At own decisions, each hand uses its visible-history policy to mix child values;
stage `child_value[a] - mixed_value` for every legal alternative, including own
zero-probability actions. Own preceding policy reach is absent from regrets.
At opponent decisions multiply only that opponent's action-reach vector and sum
children. Keep both players' policy frozen throughout the proof pass. Do not use
a maximum over sampled hidden outcomes or claim CFR+ clipping commutes with
expectation.

For averaging at an acting player's visible prefix P stage:

`denominator_i += own_action_reach_i * absolute_prefix_mass_i(P) / q(P)`;

`numerator_i,a += denominator_increment_i * sigma_i,a`.

Opponent action reach does not enter this formula. All opponent action branches
remain relevant to distinct own-history average rows even behind zero opponent
policy reach. q(P) is the proposal prefix probability, not target-conditional
chance and not q(B). A zero-target complete board can still contribute a positive
earlier-prefix average. Keep exact prior, proposal correction and reach factors
once each. The proof operates on exact rational/dyadic snapshots; later floating
reduction and stochastic convergence need separate acceptance.

Stage/validate a complete intended update before mutating persistent regrets or
averages. Admission or conversion failure must leave the policy and accumulators
unchanged; alternatively use an independently tested transaction/checkpoint with
equivalent behavior. Bound staging keys, tokens, numeric payload and output too.

## Fixed complete proof game

Retain original v1 betting fields: stacks 8, blinds .5/1, preflop raises [1] with
one raise and explicit all-in; all three later streets bets [.5,1], raises [.25],
one raise and explicit all-in. The accepted v2 betting configuration remains a
second control, not a replacement. Both old 60-board census failures stay immutable.

Use the nine physical cards `(43,48,32,24,37,16,33,35,17)`, the three compatible
private-pair prior probabilities 3/29,8/29,18/29, and all 2,520 exogenous public
proposal boards. Only 60 complete boards have target support; all 2,460 others
must remain in expectation and averaging checks. If the independent case parser
requires priors <=1, scale both seats by the same exact power of two, bind the
actual input bits, and report the changed raw Z units. Do not silently mix the
original Z=29/16 with the scaled Z=29/64. Normalized prior equivalence is distinct
from byte-identical inputs.

Compare uniform and positive nonuniform rational proposals with independently
derived q(B) and q(P). For every both-player full-history/own-hand/action row,
compare expected raw regret increments and average numerator/denominator against
an independently admitted physical pair/future reference. Compare each per-board
contribution before aggregate expectations where possible. Candidate policy
routing or the candidate DAG is not its own complete oracle. Existing independent
numeric rules and literal action-history walks provide separate transition and
history anchors; no old public-tree cap may be raised to disguise the barrier.

Negative controls must detect missing/wrong q or d5, selected-board normalization,
duplicated prior/reach, own reach entering regrets, opponent reach entering
averages, hidden-future support filtering or maxima, conditional zero-target
redraw, omitted zero-own-policy actions, wrong postflop role, and reconvergent
history aliasing. Include early folds/all-in, unequal priors, wins/losses/ties,
short raises/refunds and nonzero prefix averages behind zero-target boards.

## Admission and later gates

Before execution census the real action-history traversal, per-hand positive
prefix rows, action slots, history tokens, exact arithmetic bit growth, all
proposal enumeration/serialization, current/frozen/staging policy storage and
failure cleanup. The compact template's 388 vertices do not make 1,105 symbolic
history occurrences, per-hand/public-prefix expansion, 2,520 proof outcomes or
adaptive persistent storage free. Exact sparse nine-card support can be counted
as a bounded reference; arbitrary-range/full52 support counting stays separate.

Only after this complete update identity and failure-atomicity proof may one
explicit native virtual-chance vanilla training path be integrated, initially
G=1. Then prove the actual sampler's law, deterministic seed/version and conditional
unbiasedness under changing policy, preserve every miss, and independently replay
saved complete policies under visible-information best response. Variance,
convergence, broader-game capacity, full52 strategy growth, complete artifact EV
contracts and product readiness remain unresolved. Existing two passes/26 misses
and old default paths are unchanged.

## Exact frozen-policy reach constraint

The existing chance seam accepts binary64 opponent action reach. Arbitrary
dyadic strategy products can need more than 53 significand bits, so a generic
dyadic profile is not automatically an exact-composition proof. For the first
anchor require every nonzero action probability to be a power of two. For m
active alternatives use `1/2,1/4,...,1/2^(m-1),1/2^(m-1)`, rotate by a stable
own-hand/full-visible-history function, and sometimes remove one alternative
with exact probability zero. A one-active-action row is pure. All probabilities
sum exactly to one, and every nonzero reach is exactly `2^-exponent`.

Bind a deterministic, documented byte encoding for any profile selector. Hashes
may select probabilities but never establish row identity; use full equality
for actor/holding/history. Admit the largest summed reach exponent before
binary64 transport, rejecting nonnormal nonzero reach instead of silently
rounding. Preserve the literal exact rational reference separately. Nontrivial
mixture-value arithmetic remains exact rational; its terms need not fit doubles.

Do not reset a persistent kernel/run's cumulative work meter to evade admission.
Each separately admitted frozen-board proof call and the complete 2,520-call
study need explicit distinct envelopes before execution. A future multi-iteration
training request needs one full requested-run allowance, not unaccounted per-call
resets. Logical study enumeration is not training capacity.

Visible-prefix support may justify skipping a subtree only when that currently
visible prefix has zero physical mass; do not use a later prefix or opponent
policy reach to drop earlier average rows. First implement the simple complete
walk and preserve its measured admission outcome before optimizing this rule.

## Pinned profile/proposal protocol for the first proof

Profile version is `frozen-pow2-profile-v1`. Hash selector bytes in this exact
order: ASCII `OPL-FROZEN-POLICY-V1` plus NUL; one actor byte (global 0/1); two
numeric physical card-ID bytes in increasing order; uint16 little-endian history
token count; then, for each ordered visible token, uint16 little-endian ASCII
byte length followed by its exact bytes; finally one legal-action-count byte.
Use FNV-1a64 offset 14695981039346656037, prime 1099511628211, and wrap modulo
2^64 after each multiply. Hand string lexical order is not the byte protocol.
All history/menu/frame lengths must be validated before constructing or hashing
these bytes. A selector hash never establishes equality of histories or rows.

For m ordered legal actions, rotate cyclic action order by `(hash>>32)%m`.
If m>1 and `(hash & 3)==0`, exclude action `(hash>>8)%m` with probability zero.
Assign the remaining n cyclic alternatives power-of-two probabilities:
n=1 gives probability 1; n>=2 gives exponent `min(j+1,n-1)` for cyclic position
j=0..n-1, hence `1/2,1/4,...,1/2^(n-1),1/2^(n-1)`. This sums exactly to one.
Menus of width one are pure. Profile inputs contain only the original acting
own holding and already-visible full history. FrozenGame owns the immutable
configuration, deck, ranges and template; arbitrary policy callbacks and
separately supplied foreign hand snapshots are not part of this first API.

Uniform PROOF9 proposal has q(B)=1/2520 and prefix q=1,1/84,1/504,1/2520.
For the second proposal let w(c)=1+index(c) in the sorted nine-card deck;
q(B)=w(river)/12600. Every river card appears 280 times, so the total is
280*(1+...+9)=12600. At a flop F, q(F)=5*sum_{c outside F}w(c)/12600;
after turn T, q(F,T)=sum_{c outside F,T}w(c)/12600; root q=1. Derive and
independently verify these identities against all proposal outcomes. Do not
replace global deck indices with the changing index among remaining cards.

Target normalized prefix mass is `wi*sum_compatible_unblocked(wj)/(Z*d_k)`
with d_k=1,10,20,20. Equivalently suffix-count weighted products use counts
20,2,1,1 and denominator Z*20. The unfiltered public proposal completion counts
are 2520,30,5,1. Raw weighted support sums, normalized target masses and proposal
prefix probabilities are distinct fields. Each target-player regret walk stages
averages only at that target's own rows, avoiding duplicate averaging across the
two responder walks.
