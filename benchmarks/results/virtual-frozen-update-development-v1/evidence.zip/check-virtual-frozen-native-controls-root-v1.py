import hashlib,json,subprocess,sys
from pathlib import Path
base=Path.cwd();repo=base/'work/virtual-frozen-update-repo';out=base/'work/virtual-frozen-root-controls-run-v1';out.mkdir(exist_ok=False)
build=base/'work/virtual-frozen-root-controls-build-v1';manifest=json.loads((build/'native-exact-build-manifest.json').read_bytes())
def auth():
    for p,h in manifest['source_sha256'].items():
        if hashlib.sha256((repo/p).read_bytes()).hexdigest()!=h:raise RuntimeError('source drift '+p)
    dep=json.loads((repo/'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
    for p,h in dep['headers_sha256'].items():
        if hashlib.sha256((build/'boost-include'/p).read_bytes()).hexdigest()!=h:raise RuntimeError('header drift '+p)
    if hashlib.sha256(Path(manifest['executable']).read_bytes()).hexdigest()!=manifest['executable_sha256']:raise RuntimeError('executable drift')
auth();result=subprocess.run([manifest['executable']],capture_output=True,check=False,timeout=60)
(out/'stdout.log').write_bytes(result.stdout);(out/'stderr.log').write_bytes(result.stderr);auth()
receipt={'exit_code':result.returncode,'source_stable':True,'executable_sha256':manifest['executable_sha256'],'headers':198,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),'scope':'bounded primitive,admission,ownership,zero-target controls; no PROOF9 EVAL'}
(out/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(result.stdout.decode());sys.exit(result.returncode)
