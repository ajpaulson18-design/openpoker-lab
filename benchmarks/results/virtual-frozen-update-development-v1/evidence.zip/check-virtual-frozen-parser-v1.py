import hashlib,json,subprocess,sys
from pathlib import Path
base=Path.cwd(); repo=base/'work/virtual-frozen-update-repo'; out=base/'work/virtual-frozen-parser-controls-v1'; out.mkdir(exist_ok=False)
files=['tests/virtual_frozen_probe_protocol.py','tests/test_virtual_frozen_probe_protocol.py']
def pins():return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files}
before=pins(); receipt={'before':before,'runs':[]}
for mode,args in [('normal',[]),('optimized',['-O'])]:
    result=subprocess.run([sys.executable,'-B',*args,'-m','unittest','tests.test_virtual_frozen_probe_protocol','-v'],cwd=repo,capture_output=True,check=False)
    (out/(mode+'.stdout.log')).write_bytes(result.stdout);(out/(mode+'.stderr.log')).write_bytes(result.stderr)
    receipt['runs'].append({'mode':mode,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
receipt['after']=pins();receipt['stable']=before==receipt['after'];(out/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));sys.exit(0 if receipt['stable'] and all(r['returncode']==0 for r in receipt['runs']) else 1)
