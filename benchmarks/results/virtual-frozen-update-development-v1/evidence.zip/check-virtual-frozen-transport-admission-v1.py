"""One development transport/admission check; never evaluate an update."""
import hashlib
import json
from pathlib import Path
import subprocess
import traceback

WORK = Path(__file__).resolve().parent
REPO = WORK / 'virtual-frozen-update-repo'
BUILD = WORK / 'virtual-frozen-root-probe-build-v2'
OUTPUT = WORK / 'virtual-frozen-root-transport-admission-v1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def authenticate():
    raw = (BUILD / 'native-exact-build-manifest.json').read_bytes()
    manifest = json.loads(raw)
    if manifest['target'] != 'virtual-frozen-update':
        raise RuntimeError('Wrong original build target')
    for name, expected in manifest['source_sha256'].items():
        if sha((REPO / name).read_bytes()) != expected:
            raise RuntimeError('Original compiled source changed: ' + name)
    dependency = json.loads((REPO / 'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
    for name, expected in dependency['headers_sha256'].items():
        if sha((BUILD / 'boost-include' / name).read_bytes()) != expected:
            raise RuntimeError('Original extracted header changed')
    if sha(Path(manifest['executable']).read_bytes()) != manifest['executable_sha256']:
        raise RuntimeError('Original executable changed')
    return {'manifest_sha256': sha(raw), 'executable_sha256': manifest['executable_sha256'],
            'sources': manifest['source_sha256'], 'headers_verified': len(dependency['headers_sha256'])}


def main():
    OUTPUT.mkdir(exist_ok=False)
    status = {'scope': 'transport and rank-free admission only; no EVAL requests',
              'failure': None, 'cases': []}
    before = None
    try:
        before = authenticate()
        (OUTPUT / 'build-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
        manifest = json.loads((BUILD / 'native-exact-build-manifest.json').read_bytes())
        good = 'FROZEN_UPDATE_V1 ADMIT UNIFORM 16 17 32 33 35 500000000 2000000 384 1073741824\n'
        weighted = 'FROZEN_UPDATE_V1 ADMIT RIVER_WEIGHTED 16 17 24 32 48 500000000 2000000 384 1073741824\n'
        cases = [('uniform', good, True), ('weighted_worst', weighted, True),
                 ('tiny_work', good.replace('500000000', '1'), False),
                 ('tiny_entries', good.replace('2000000', '512'), False),
                 ('tiny_integer_width', good.replace(' 384 ', ' 180 '), False),
                 ('tiny_integer_payload', good.replace('1073741824', '8'), False),
                 ('foreign_card', good.replace('16 17 32 33 35', '1 17 32 33 35'), False),
                 ('flop_order', good.replace('16 17 32 33 35', '17 16 32 33 35'), False),
                 ('unknown_proposal', good.replace('UNIFORM', 'SELECTED'), False),
                 ('trailing', good.rstrip() + ' extra\n', False)]
        for name, request, accepted in cases:
            (OUTPUT / (name + '.request.txt')).write_bytes(request.encode('ascii'))
            result = subprocess.run([manifest['executable']], input=request.encode('ascii'),
                                    capture_output=True, check=False, timeout=30)
            (OUTPUT / (name + '.stdout.log')).write_bytes(result.stdout)
            (OUTPUT / (name + '.stderr.log')).write_bytes(result.stderr)
            text = result.stdout.decode('ascii')
            receipt = {'name': name, 'returncode': result.returncode, 'response_bytes': len(result.stdout),
                       'stdout_sha256': sha(result.stdout), 'expected_admission': accepted}
            status['cases'].append(receipt)
            if result.returncode or result.stderr:
                raise RuntimeError('Unexpected probe process result in ' + name)
            if accepted:
                if not text.startswith('FROZEN_UPDATE_RESULT_V1\r\n') and not text.startswith('FROZEN_UPDATE_RESULT_V1\n'):
                    raise RuntimeError('Missing successful transport response in ' + name)
                lines = text.splitlines()
                if 'status ADMITTED' not in lines or 'calls 0 0 0 0' not in lines or 'rows 0' not in lines:
                    raise RuntimeError('Admission failed or a callback entered in ' + name)
                probe = next(line.split() for line in lines if line.startswith('probe '))
                forecast = next(line.split() for line in lines if line.startswith('forecast '))
                if len(result.stdout) > int(probe[2]) or int(forecast[2]) + int(probe[3]) > 500000000:
                    raise RuntimeError('Combined transport/native work or response cap exceeded')
            elif not text.startswith('FROZEN_UPDATE_ERROR_V1'):
                raise RuntimeError('Negative control did not reject in ' + name)
    except BaseException:
        status['failure'] = traceback.format_exc()
        (OUTPUT / 'first-failure.txt').write_text(status['failure'], encoding='utf-8')
    finally:
        try:
            after = authenticate()
            status['build_stable'] = before == after
            (OUTPUT / 'build-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf-8')
            if before != after:
                status['failure'] = status['failure'] or 'Original build drift'
        except BaseException:
            status['failure'] = status['failure'] or traceback.format_exc()
        (OUTPUT / 'completion.json').write_text(json.dumps(status, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(status))
    return 1 if status['failure'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
