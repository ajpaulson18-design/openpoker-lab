"""Package the alternating timing study without changing its frozen numerical evidence."""
from hashlib import file_digest
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

WORK=Path(__file__).resolve().parent
REPO=WORK/'dyadic-phase-payload-repo'
ROOT=WORK/'dyrow-timing-pairs1'
DEST=REPO/'benchmarks/results/native-dyadic-row-batched-ten-card-timing-v1'

def require(condition,message):
    if not condition:
        raise RuntimeError(message)

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    with path.open('rb') as stream:
        return {'bytes':path.stat().st_size,'sha256':file_digest(stream,'sha256').hexdigest()}

def main():
    result=read(ROOT/'result.json')
    require(read(ROOT/'terminal.json')=={'status':'complete','training_invocations':8} and
            result['status']=='same_executable_alternating_timing_complete' and
            result['source_head']=='7a85266f488ad66849cdc67c98aefd4006f7902b' and
            result['pairs']==4 and result['training_invocations']==8 and result['raw_source_stable'] and
            result['all_complete_streams_and_checkpoint_images_exact'],
            'alternating timing study incomplete')
    before=read(ROOT/'source-before.json')
    require(before==read(ROOT/'source-after.json') and len(before)==result['source_files']==2536,
            'timing source inventory differs')
    config=read(ROOT/'configuration.json')
    paths={}
    for path in sorted(ROOT.rglob('*')):
        require(not path.is_symlink(),'linked timing evidence')
        if not path.is_file():
            continue
        rel=path.relative_to(ROOT)
        if len(rel.parts)>1 and rel.parts[1]=='page-images' and path.name in ('committed.bin','staged.bin'):
            continue
        paths['timing/'+rel.as_posix()]=path
    for item in result['observations']:
        label=f"pair-{item['pair']}-{item['mode']}"
        trial=ROOT/label
        observed=read(trial/'process/process.json')
        require(read(trial/'verified.json')==item and observed['actual_exit_observed'] and
                observed['returncode']==0 and observed['automatic_retries']==0 and not observed['failures'] and
                observed['duration_seconds']==item['seconds'] and observed['memory']==item['memory'] and
                observed['streams'][0]['sha256']==item['retained_sha256'] and
                observed['streams'][0]['wire_sha256']==item['wire_sha256'] and
                identity(trial/'process/stdout.bin')=={'bytes':9833076,'sha256':item['retained_sha256']} and
                read(trial/'page-images/paging.json')==item['paging'],
                'timing process or retained bytes differ')
    for path in (Path(__file__),WORK/'compare-dyadic-row-timing.py',WORK/'dyrow-timing-pairs1.log'):
        paths['external/'+path.name]=path
    paths['native-build-manifest.json']=WORK/'dyrow-ten-cohort1/build/native-exact-build-manifest.json'
    manifest=REPO/'benchmarks/results/native-dyadic-row-batched-ten-card-accepted-v1/manifest.json'
    require(identity(manifest)==config['source_study_manifest'],'accepted numerical evidence changed')
    paths['numerical-evidence-manifest.json']=manifest
    inventory={name:identity(path) for name,path in paths.items()}
    DEST.mkdir(exist_ok=False)
    archive=DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in paths.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    require(archive.stat().st_size<=50<<20,'timing archive allowance')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'timing archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes'] and
                        file_digest(stream,'sha256').hexdigest()==expected['sha256'],
                        'timing archive member differs')
    report={**result,'configuration':config,
        'numerical_evidence_publication':'bc1819a2f298854ef8fd04e73352c114f2e5a33e',
        'numerical_evidence_manifest':identity(manifest),
        'outer_exit_observation':'Codex process session 13321 completed with exit code zero',
        'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    with (DEST/'manifest.json').open('x',encoding='utf-8') as stream:
        json.dump(report,stream,sort_keys=True,indent=2)
        stream.write('\n')
    print(json.dumps({'archive':report['archive'],'median_seconds':result['median_seconds'],
        'median_paired_ratio':result['median_paired_ratio']}))

if __name__=='__main__':
    main()
