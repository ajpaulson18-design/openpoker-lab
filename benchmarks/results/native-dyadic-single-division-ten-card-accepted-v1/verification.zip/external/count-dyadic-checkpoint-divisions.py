"""Count exact division sites from authenticated compact checkpoints."""
import json
from hashlib import sha256
from pathlib import Path
from struct import unpack_from

root=Path.cwd()
run=root.parent/'dysp-ten-cohort1'
base=root/'benchmarks/results/native-dyadic-sparse-chance-ten-card-accepted-v1/manifest.json'
prior=json.loads(base.read_bytes())
inputs=prior['checkpoint_inputs']
admission=prior['admission']

def data(path,identity):
    content=path.read_bytes()
    if len(content)!=identity['bytes'] or sha256(content).hexdigest()!=identity['sha256']:
        raise ValueError(f'checkpoint input differs: {path.name}')
    return content

scaffold=data(run/'train_ten_sparse_chance/stdout.bin',inputs['stream'])
rows=data(run/'page-images-rows/rows.bin',{'bytes':prior['row_directory']['rows_bytes'],
    'sha256':prior['row_directory']['rows_sha256']})
first,last=(data(run/'page-images'/image['name'],image) for image in inputs['sweep_images'])
counts={'first_policy':0,'second_policy':0,'average_export':0}
groups={'second_policy':0,'average_export':0}
prelude=8+16*8+11*8+1105*96
slots=avg=reg=0
for row in range(admission['rows']):
    _,flags,offset=unpack_from('<3Q',scaffold,prelude+24*row)
    _,w1,w2,w3=unpack_from('<4Q',rows,32*row)
    actions=(flags>>16)&255
    assert 2<=actions<=4 and offset==slots and w1&0xffffffff==slots
    assert w1>>32==avg and w2&0xffffffff==reg
    avg_stride=(644-(w2>>48)+63)//64
    reg_stride=(644-(w3&0xffff)+63)//64
    assert avg_stride>0 and reg_stride>0
    for key,raw,at,stride in (
        ('second_policy',first,admission['packed_average_limbs']+reg,reg_stride),
        ('average_export',last,avg,avg_stride),
    ):
        positive=sum(any(raw[8*(at+i*stride):8*(at+(i+1)*stride)]) for i in range(actions))
        if positive>1:
            counts[key]+=positive
            groups[key]+=1
    slots+=actions
    avg+=actions*avg_stride
    reg+=actions*reg_stride
assert (slots,avg,reg)==(admission['slots'],admission['packed_average_limbs'],admission['packed_regret_limbs'])
result={'scope':'accepted sparse ten-card checkpoint bytes','source_head':prior['source_head'],
        'rank_calls':0,'native_calls':0,'combined_helpers_by_phase':counts,
        'nontrivial_rows_by_phase':groups,'combined_helpers':sum(counts.values()),
        'separate_helpers':2*sum(counts.values())}
out=root.parent/'dyqr-prior-checkpoint-division-count1.json'
with out.open('x',encoding='utf-8') as file:
    json.dump(result,file,indent=2,sort_keys=True)
    file.write('\n')
print(json.dumps(result,sort_keys=True))