"""Rank-free sensitivity of quantizer reservation to one quotient/remainder division."""
from functools import lru_cache
import json
from pathlib import Path
from scripts.census_virtual_dyadic_storage import supported_prefixes
from tests.full_deck_public_chance_reference import PROOF9, proof_ranges
from tests.virtual_betting_template_reference import build_reference_template
from tests.virtual_frozen_update_reference import _template_case

template=build_reference_template(_template_case())
ranges=proof_ranges()
words=lambda bits:(bits+63)//64
uniform_exp=lambda m:1 if m==2 else 2 if m==4 else 52

@lru_cache(None)
def tail(i):
    node=template.nodes[i]
    return (uniform_exp(len(node.edges)) if node.phase=='decision' else 0)+max(
        (tail(edge.child) for edge in node.edges),default=0)

def cost(m,e,bits,divisions):
    total=e+(m-1).bit_length()+1
    scaled=e+52
    high=max(53,total,scaled)
    return (64+16*m+4*m*(words(bits)+1)+256+16*m*(words(high)+1)
            +8*m*(divisions*words(scaled)*words(total)+4*words(high)+8)
            +4*m*m*(words(total)+1))

def forecast(n,bits,base_bits,divisions):
    deck=tuple(sorted((*PROOF9,*range(n-9))))
    r={(street,p):sum(supported_prefixes(deck,p,hand,street,ranges) for hand,_ in ranges[p])
       for street in (0,3,4,5) for p in (0,1)}
    out=[0,0,0]
    def visit(i,past,first):
        node=template.nodes[i]
        if node.phase=='decision':
            p=node.state.player
            m=len(node.edges)
            rows=r[node.street,p]
            e=first[1-p]+tail(i)
            ea=52*(past[p]+1)
            out[0]+=rows*(320+48*m)
            out[1]+=rows*cost(m,base_bits+2+4+1+e,bits,divisions)
            out[2]+=rows*cost(m,base_bits+2+ea,bits,divisions)
            past=tuple(v+int(j==p) for j,v in enumerate(past))
            first=tuple(v+(uniform_exp(m) if j==p else 0) for j,v in enumerate(first))
        for edge in node.edges:
            visit(edge.child,past,first)
    visit(template.root,(0,0),(0,0))
    return out

prior=Path('benchmarks/results/native-dyadic-sweep-stream-ten-card-accepted-v1/manifest.json')
expected=json.loads(prior.read_bytes())['admission']['quantizer_terms']
assert forecast(10,644,12,2)==expected
result={'status':'model_sensitivity_only','no_producer_calls':True,'scope':'T2, fixed ranges and exact largest remainder',
        'note':'One division term is hypothetical; it requires proof of the bundled algorithm and bounded scratch.',
        'models':{str(n):{'two_division_terms':forecast(n,bits,base,2),'one_division_term':forecast(n,bits,base,1)}
                  for n,bits,base in ((9,642,10),(10,644,12),(11,645,13))}}
out=Path.cwd().parent/'dyadic-quantizer-divrem-projection1.json'
with out.open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2,sort_keys=True)
    stream.write('\n')
print(json.dumps({n:{label:sum(vals) for label,vals in models.items()} for n,models in result['models'].items()}))