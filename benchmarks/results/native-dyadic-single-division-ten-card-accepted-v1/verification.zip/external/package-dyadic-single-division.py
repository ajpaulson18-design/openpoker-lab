"""Preserve the source-frozen combined division study and exact digest replay."""
import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-sparse-chance-repo'
RESULTS = REPO/'benchmarks/results'
COHORT = WORK/'dyqr-ten-cohort1'
OPERATOR = WORK/'dyqr-ten-launch1'
DEST = RESULTS/'native-dyadic-single-division-ten-card-accepted-v1'
BASE = RESULTS/'native-dyadic-sparse-chance-ten-card-accepted-v1'
BASE_PUBLICATION = '936d76869f62be7ffd92f2c0fdb34e591cb4c492'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def reconstructed_wire(numeric, images):
    digest = sha256()
    total = 0

    def consume(stream, size):
        nonlocal total
        remaining = size
        while remaining:
            block = stream.read(min(1<<20, remaining))
            require(block, 'wire reconstruction truncated')
            digest.update(block)
            remaining -= len(block)
        total += size

    with numeric.open('rb') as stream:
        consume(stream, 8+16*8+11*8+1105*96+119196*24)
        for sweep, image in enumerate(images, 1):
            consume(stream, 281066*8+4*12*8)
            header = struct.pack('<8sQQQ', b'OPLCPG01', sweep, sweep%2, image['bytes'])
            digest.update(header)
            total += len(header)
            with (COHORT/'page-images'/image['name']).open('rb') as checkpoint:
                consume(checkpoint, image['bytes'])
                require(not checkpoint.read(1), 'wire checkpoint trailing bytes')
        consume(stream, numeric.stat().st_size-stream.tell())
        require(not stream.read(1), 'wire numerical trailing bytes')
    return {'bytes': total, 'sha256': digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--head',required=True)
    parser.add_argument('--control-log',type=Path,action='append',required=True)
    args = parser.parse_args()
    run = read(COHORT/'result.json')
    outer = read(OPERATOR/'completion.json')
    require(run['head'] == outer['head'] == args.head and run['training_invocations']==1
            and outer['mode']=='train_ten_single_division' and outer['raw_source_stable']
            and outer['actual_exit_observed'] and outer['returncode']==0 and not outer['failures']
            and read(COHORT/'terminal.json')['status']=='complete', 'source-frozen cohort incomplete')
    source = read(COHORT/'source.json')['files']
    hashes = {name: record['raw_sha256'] for name,record in source.items()}
    require(read(OPERATOR/'source-before.json') == read(OPERATOR/'source-after.json') == hashes,
            'source inventories differ')
    for path in (OPERATOR/'bootstrap.json', COHORT/'saved-review-bootstrap.json'):
        boot = read(path)
        require(all(hashes.get(name)==digest for name,digest in boot['compiled'].items())
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    build_path = COHORT/'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(identity(Path(build['executable']))['sha256']==build['executable_sha256']
            and all(hashes[name]==digest for name,digest in build['source_sha256'].items()), 'native build differs')
    build_hash = identity(build_path)['sha256']
    for label in ('admit_ten_single_division','train_ten_single_division','saved-review'):
        receipt = read(COHORT/label/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures']
                and receipt['automatic_retries']==0, 'child exit differs')
        if label!='saved-review':
            binary = read(COHORT/label/'binary-identity.json')
            require(binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                    and binary['build_manifest_sha256']==build_hash, 'observed native executable differs')
    trained = COHORT/'train_ten_single_division'
    process = read(trained/'process.json')
    capture = run['sweep_capture']
    inputs = run['checkpoint_inputs']
    replay = run['saved_only_replay']
    require(identity(trained/'process.json')['sha256']==run['sweep_capture_process_sha256']
            and process['sweep_capture']==capture and identity(trained/'stdout.bin')==inputs['stream']
            and capture['retained_sha256']==inputs['stream']['sha256']==replay['saved_output_sha256']
            and replay['checkpoint_verification']=='independent_compact_digest'
            and replay['native_producer_calls']==0, 'digest replay binding differs')
    for item in (BASE/'manifest.json', BASE/'verification.zip'):
        require(identity(item)['sha256']==hashes[item.relative_to(REPO).as_posix()], 'baseline source differs')
    baseline = read(BASE/'manifest.json')
    prior = baseline['saved_only_replay']
    require(baseline['status']=='accepted_ten_card_sparse_chance_training_and_replay'
            and identity(BASE/'verification.zip')['sha256']==baseline['archive']['sha256']
            and inputs['sweep_images']==baseline['checkpoint_inputs']['sweep_images']
            and run['paging']==baseline['paging'] and run['policy_spill']==baseline['policy_spill']
            and run['row_directory']==baseline['row_directory']
            and all(replay[key]==prior[key] for key in ('sweeps','profile_and_br','shape',
                'parent_work_actual','changed_current_rows','quality_gate','checkpoint_images'))
            and all(replay['work_actual'][key]==value for key,value in prior['work_actual'].items() if key!='quantizer')
            and replay['chance_actual']==prior['chance_actual']
            and replay['work_actual']['quantizer']<prior['work_actual']['quantizer']
            and run['quantizer']==read(COHORT/'page-images/quantizer.json')==
                {'combined_divisions':replay['combined_divisions']}
            and 0<replay['combined_divisions']<=2*run['admission']['slots'],
            'combined division baseline parity or measured work differs')
    member='cohort/train_ten_sparse_chance/stdout.bin'
    with ZipFile(BASE/'verification.zip') as zipped:
        require(zipped.getinfo(member).file_size==9_833_076,'baseline stream extent differs')
        earlier=zipped.read(member)
    saved=(trained/'stdout.bin').read_bytes()
    require(sha256(earlier).hexdigest()==prior['saved_output_sha256']
            and earlier[:-520]==saved[:-520] and earlier[-520:-512]==saved[-520:-512]==b'OPLDTP02',
            'saved exact policy/checkpoint scaffold differs outside work receipt')
    census=read(WORK/'dyqr-prior-checkpoint-division-count1.json')
    require(census['source_head']==baseline['source_head'] and census['rank_calls']==census['native_calls']==0
            and census['combined_helpers']==replay['combined_divisions']
            and census['separate_helpers']==2*replay['combined_divisions'],
            'rank-free checkpoint invocation census differs')
    compared={'baseline_native_observation':baseline['measured_comparison']['sparse_native_observation'],
              'single_division_native_observation':run['single_division_comparison']['single_division_native_observation'],
              'separate_quantizer_work':prior['work_actual']['quantizer'],
              'combined_quantizer_work':replay['work_actual']['quantizer'],
              'combined_helper_invocations':replay['combined_divisions'],
              'separate_helper_invocations_for_same_rows':2*replay['combined_divisions']}
    images = inputs['sweep_images']
    require(reconstructed_wire(trained/'stdout.bin',images)==
            {'bytes': capture['contract']['wire_bytes'], 'sha256': capture['wire_sha256']},
            'independent full wire reconstruction differs')
    for image in images:
        require(identity(COHORT/'page-images'/image['name'])=={key:image[key] for key in ('bytes','sha256')},
                'retained final slot identity differs')
    files = {}
    for label, directory in (('cohort',COHORT),('operator',OPERATOR)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(), 'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label=='cohort' and (rel.parts[0]=='source' or
                    (rel.parts[0]=='build' and path.name!='native-exact-build-manifest.json') or
                    (rel.parts[0]=='page-images' and path.name in ('committed.bin','staged.bin'))):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__), WORK/'trusted-virtual-dyadic-training-launch-v22.py',
                 WORK/'project-dyadic-quantizer-divrem.py', WORK/'dyadic-quantizer-divrem-projection1.json',
                 WORK/'count-dyadic-checkpoint-divisions.py', WORK/'dyqr-prior-checkpoint-division-count1.json',
                 *args.control_log):
        files[f'external/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes']
                        and file_digest(stream,'sha256').hexdigest()==expected['sha256'],'archive member differs')
    manifest = {'status':'accepted_ten_card_single_division_training_and_replay','source_head':args.head,
                'baseline_publication':BASE_PUBLICATION,'operator':outer,
                'exact_numerical_parity_outside_work_footer':True,'independent_wire_reconstruction':True,
                'measured_comparison':compared,'packed_replay_images':baseline['packed_replay_images'],
                **{key:run[key] for key in ('admission','sweep_capture','sweep_capture_process_sha256','checkpoint_inputs',
                    'paging','row_directory','policy_spill','single_division_comparison','quantizer','saved_only_replay',
                    'training_invocations','quality_gate')},
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observation':compared,
                      'wire':capture['wire_sha256']},sort_keys=True))


if __name__=='__main__':
    main()
