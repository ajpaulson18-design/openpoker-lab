"""Package observed raw matrices without compiling/running any candidate."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,zipfile

WORK=Path(__file__).resolve().parent;ROOT=WORK/'dyprofile-repo'
PACKET=ROOT/'benchmarks/results/native-frozen-grid-raw-v1'
def sha(raw):return sha256(raw).hexdigest()
def package(path,files):
    members={n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())}
    files['members.json']=(json.dumps(members,indent=2)+'\n').encode()
    expanded=sum(map(len,files.values()))
    if expanded>80<<20:raise ValueError('existing expanded archive ceiling')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,raw in sorted(files.items()):z.writestr(n,raw)
    if path.stat().st_size>8<<20:raise ValueError('existing compressed archive ceiling')
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None or set(z.namelist())!=set(files):raise ValueError('archive CRC/members')
        for n,v in members.items():
            raw=z.read(n)
            if len(raw)!=v['bytes'] or sha(raw)!=v['sha256']:raise ValueError('archive member drift')
    return {'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':len(files),'expanded_bytes':expanded}
if PACKET.exists():raise ValueError('immutable packet already exists')
PACKET.mkdir(parents=True,exist_ok=False)
receipts={};reports={}
for mode in ('normal','optimized'):
    directory=WORK/('dygrid-raw-matrix1-'+mode);files={}
    for p in sorted(directory.rglob('*')):
        if p.is_file():files['matrix/'+p.relative_to(directory).as_posix()]=p.read_bytes()
    report=json.loads((directory/'matrix-results.json').read_bytes());reports[mode]=report
    if len(report['cases'])!=20 or report['rejected_calls']!=6:raise ValueError('complete matrix census')
    for p in directory.glob('*/process.json'):
        record=json.loads(p.read_bytes())
        if record['status']!='exited' or record['actual_exit_observed'] is not True or record['automatic_retries']!=0 or record['failures']:
            raise ValueError('unaccepted process receipt')
    build=WORK/'dygrid-raw-candidate2';manifest=json.loads((build/'native-exact-build-manifest.json').read_bytes())
    for n,digest in manifest['source_sha256'].items():
        if sha((directory/'source'/n).read_bytes())!=digest:raise ValueError('introduced native source drift '+n)
    exe=next(build.glob('*.exe'))
    if sha(exe.read_bytes())!=manifest['executable_sha256']:raise ValueError('native executable drift')
    for p in (exe,build/'native-exact-build-manifest.json',build/'build.log',build/'compiler-version.log'):
        files['build/'+p.name]=p.read_bytes()
    files['logs/conformance.log']=(WORK/('dygrid-raw-matrix1-'+mode+'.log')).read_bytes()
    files['replay.json']=(WORK/('dygrid-raw-matrix1-'+mode+'-replay.log')).read_bytes()
    for n in ('scripts/replay_native_grid_raw.py','docs/native-frozen-grid-raw.md'):
        files['maintained-source/'+n]=(ROOT/n).read_bytes()
    files['packager.py']=Path(__file__).read_bytes()
    receipts[mode]=package(PACKET/(mode+'.zip'),files)
normal=WORK/'dygrid-raw-matrix1-normal';optimized=WORK/'dygrid-raw-matrix1-optimized'
if any((normal/p.parent.name/'stdout.bin').read_bytes()!=p.read_bytes() for p in optimized.glob('*/stdout.bin')):
    raise ValueError('mode output parity')
development={}
for p in (WORK/'dygrid-raw-first-positive1').rglob('*'):
    if p.is_file():development['first-positive/'+p.relative_to(WORK/'dygrid-raw-first-positive1').as_posix()]=p.read_bytes()
development['first-positive.log']=(WORK/'dygrid-raw-first-positive1.log').read_bytes()
for n in ('build.log','build-failure.json','compiler-version.log'):
    p=WORK/'dygrid-raw-candidate1'/n
    if p.exists():development['refused-64-bit-assumption/'+n]=p.read_bytes()
for n in ('native/virtual_frozen_grid_raw.hpp','tests/native/virtual_frozen_grid_raw_probe.cpp'):
    development['refused-64-bit-assumption/source/'+n]=subprocess.check_output(['git','show','17b3e6f17c5938ecfe5e78e0b9def204e2cfaa6a:'+n],cwd=ROOT)
receipts['development']=package(PACKET/'development.zip',development)
all_cases=[x for r in reports.values() for x in r['cases']]
summary={'version':'native-frozen-grid-raw-v1','native_source_head':'40470425ce55602245cb83abfde580f45b3dd85e',
 'observed_source_head':'4c643855b83f09e3c9e92a18dd3204d2b502679b','maintained_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'native_executable_sha256':'4f50ca01bde937d51179cc55c21041e244ac0c039d737d5b71595cedf57a6e07',
 'scope':'fixed-policy four-street raw arithmetic only; no clipping, State update, sampled training, quality or wider capacity acceptance',
 'modes':['normal','optimized'],'successful_cases_per_mode':20,'rejected_requests_per_mode':6,
 'exact_mode_output_parity':True,'maximum_actual_work':max(x['work_actual'] for x in all_cases),
 'maximum_forecast_work':max(x['work_forecast'] for x in all_cases),'work_ceiling_per_request':500_000_000,
 'observed_peak_integer_bits':max(x['peak_integer_bits'] for x in all_cases),'existing_integer_carrier_bits':704,
 'native_state_regret_updates':0,'training_iterations':0,'saved_replay_candidate_calls':0,'archived_source_executed':False,
 'retained_build_refusal':'64-bit-only Boost limb assumption rejected at compile time before any raw invocation; corrected for 32/64-bit internals',
 'timing':'no runtime acceptance; optimized host controller interval overlapped a tool-host interruption, all native exits revalidated',
 'archives':receipts,'system_build_inputs':'SDK/runtime/standard headers not exhaustively byte-attested; bit reproducibility unproven'}
(PACKET/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
