from pathlib import Path
import sys,json
from hashlib import sha256
checkout=Path(__file__).resolve().parent/'dyprofile-repo'
sys.path.insert(0,str(checkout))
from scripts.run_frozen_grid_update_study import source_identity,pair
from tests.virtual_grid_update_reference import *

destination=checkout.parent/'dygrid-width-study1'
if destination.exists():raise ValueError('width witness must be fresh')
before=source_identity()
context=build_sampled_reference_context();budget=new_experiment_budget(context)
fixture=Fixture();grid=freeze_grid(fixture,fixture.grid())
board=fixture.worlds[0].board
admission=admit_sampled_board(context,board,'uniform')
rows,root=sampled_grid_update(context,admission,grid,budget)
witness={'bits':0}
records=[]
for key,(regrets,averages) in sorted(rows.items()):
    records.append({'key':key,'regret':list(map(pair,regrets)),'average':list(map(pair,averages))})
    for family,values in (('regret',regrets),('average',averages)):
        for index,value in enumerate(values):
            bits=max(abs(value.numerator).bit_length(),value.denominator.bit_length())
            if bits>witness['bits']:
                witness={'key':key,'family':family,'action_index':index,'value':pair(value),'bits':bits}
assert source_identity()==before
destination.mkdir()
raw=(json.dumps(records,separators=(',',':'))+'\n').encode()
(destination/'rows.json').write_bytes(raw)
result={'source':before,'board':board,'grid_sha256':grid.digest,'proposal_law':'uniform',
        'rows':len(rows),'root':pair(root),'widest_saved_fraction':witness,
        'rows_sha256':sha256(raw).hexdigest(),'resource_accounting':budget.receipt(),
        'reference_candidate_calls':1,'native_calls':0,
        'scope':'one per-board raw field width witness, not a maximum forecast or native admission'}
(destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'board':board,'rows':len(rows),'widest':witness}))
