from pathlib import Path
from hashlib import sha256
import json,sys,zipfile

base=Path(__file__).resolve().parent
checkout=base/'dyprofile-repo'
sys.path.insert(0,str(checkout))
from scripts.run_frozen_grid_update_study import source_identity

packet=checkout/'benchmarks/results/frozen-q52-update-reference-v1'
if packet.exists():raise ValueError('evidence packet must be fresh')
before=source_identity()
formal=base/'dygrid-frozen-study1'
cases=sorted(formal.glob('*/result.json'))
assert len(cases)==4
for path in cases:
    result=json.loads(path.read_text())
    assert result['source']==before and result['all_rows_exact']
    assert json.loads((formal/(path.parent.name+'-verify.log')).read_text())['independent_saved_replay']
    assert sha256((path.parent/'rows.jsonl.gz').read_bytes()).hexdigest()==result['rows_sha256']
for mode in ('normal','optimized'):
    text=(formal/('controls-'+mode+'.log')).read_text()
    assert 'Ran 11 tests' in text and text.rstrip().endswith('OK')
corrupt=json.loads((base/'dygrid-corruption-study1/result.json').read_text())
assert len(corrupt['witnesses'])==4 and all(w['detected'] for w in corrupt['witnesses'])
width=json.loads((base/'dygrid-width-study1/result.json').read_text())
assert width['source']==before and width['widest_saved_fraction']['bits']==421
packet.mkdir(parents=True)
development={
    'status':'development observations, not accepted frozen producer evidence',
    'provenance':'transcribed from retained tool outputs in the active chat',
    'observations':[
        {'output_chunk':'acf0d7','error':"TypeError: 'Fraction' object is not subscriptable",
         'stage':'before first proposal, uncommitted source',
         'correction':'uniform law stores one constant board probability; use recomputed admission.board_probability'},
        {'output_chunk':'38422f','uniform_full_row_equality':True,'stage':'exploratory uncommitted source'},
        {'output_chunk':'7903f1','tests':10,'mode':'normal','status':'passed before final controls'},
        {'output_chunk':'639d03','tests':10,'mode':'optimized','status':'passed before final controls'}]}
(packet/'development.json').write_text(json.dumps(development,indent=2)+'\n')
review={'mathematical_review':{'reviewer':'changing_draw_oracle','read_only':True,'producer_calls':0,
          'findings':['snapshot consistency and late reservations corrected before frozen runs',
                      'positive-translation and full-board/prefix equations sound under fixed fixture assumptions',
                      'local exact unit/probability checks added before source freeze'],
          'scope':'source inspection, not an executed independent study'},
        'evidence_review':{'reviewer':'review_study_ci','read_only':True,'producer_calls':0,
          'finding':'no materially unsupported claim in four saved experiments or reviewed source/docs',
          'scope':'source/result/log inspection; normal and optimized test completion verified separately by lead'}}
(packet/'review.json').write_text(json.dumps(review,indent=2)+'\n')
inputs={}
for folder,label in ((formal,'formal'),(base/'dygrid-corruption-study1','corruption'),
                     (base/'dygrid-width-study1','width')):
    for path in folder.rglob('*'):
        if path.is_file():inputs[label+'/'+path.relative_to(folder).as_posix()]=path
for name in before['files']:
    path=checkout/name
    assert sha256(path.read_bytes()).hexdigest()==before['files'][name]
    inputs['source/'+name]=path
for operator in ('dygrid-corruption-controls1.py','dygrid-width-witness1.py','dygrid-package1.py'):
    inputs['operators/'+operator]=base/operator
for name in ('development.json','review.json'):
    inputs['review/'+name]=packet/name
archive=packet/'verification.zip'
hashes={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,path in sorted(inputs.items()):
        data=path.read_bytes();hashes[name]=sha256(data).hexdigest()
        info=zipfile.ZipInfo(name,(2026,11,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        output.writestr(info,data)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None and set(saved.namelist())==set(hashes)
    assert all(sha256(saved.read(name)).hexdigest()==digest for name,digest in hashes.items())
assert source_identity()==before
summary=[]
for path in cases:
    result=json.loads(path.read_text())
    summary.append({k:result[k] for k in ('profile','law','grid_sha256','rows_sha256','rows','action_slots',
                                         'all_rows_exact','uncompressed_bytes','resource_accounting')})
manifest={'version':'frozen-q52-update-reference-evidence-v1','source_head':before['head'],
          'status':'four frozen experiments and separate saved replay passed',
          'scope':'PROOF9 fixed-policy raw-update reference; no native-grid input, sampled training, runtime or capacity gain',
          'experiments':summary,'controls':{'normal':11,'optimized':11,'corruption_witnesses':4},
          'width_witness':{k:width[k] for k in ('board','grid_sha256','widest_saved_fraction','reference_candidate_calls')},
          'archive':{'path':'verification.zip','sha256':sha256(archive.read_bytes()).hexdigest(),
                     'bytes':archive.stat().st_size,'members':len(hashes),'source_files':len(before['files']),
                     'member_sha256':hashes},
          'historical_probe_integer_bits':384,'limits_raised':False,'native_calls':0,
          'training_iterations':0,'quality_gate':None,
          'limitations':['dynamic cumulative proposal guards plus static component reservations, not complete prior composition proof',
                         'no stochastic CFR+ convergence proof','421 bits is an observed witness, not a maximum width forecast',
                         'metadata parser intended for this locally produced packet, not general untrusted inputs']}
(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest['archive'].items() if k!='member_sha256'}))
