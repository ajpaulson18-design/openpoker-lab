from pathlib import Path
import gzip,json,shutil,sys
from hashlib import sha256
from fractions import Fraction

checkout=Path(__file__).resolve().parent/'dyprofile-repo'
sys.path.insert(0,str(checkout))
from scripts.run_frozen_grid_update_study import verify

root=Path(__file__).resolve().parent/'dygrid-corruption-study1'
if root.exists():raise ValueError('corruption evidence root must be fresh')
root.mkdir()
original=root.parent/'dygrid-frozen-study1'/'uniform-uniform'
results=[]
for mode,needle in (('signed_regret','saved raw update mismatch'),
                    ('policy_unit','saved policy/menu drift'),
                    ('missing_row','saved row inventory/order'),
                    ('source_hash','saved study source closure drift')):
    destination=root/mode
    shutil.copytree(original,destination)
    manifest=json.loads((destination/'result.json').read_text())
    if mode=='source_hash':
        key=next(iter(manifest['source']['files']))
        manifest['source']['files'][key]='0'*64
    else:
        artifact=destination/'rows.jsonl.gz'
        lines=gzip.decompress(artifact.read_bytes()).splitlines(keepends=True)
        if mode=='missing_row':lines=lines[1:]
        else:
            row=json.loads(lines[0])
            if mode=='policy_unit':row['units'][0]+=1
            else:
                v=Fraction(*map(int,row['actual_regret'][0]))+1
                row['actual_regret'][0]=[str(v.numerator),str(v.denominator)]
            lines[0]=json.dumps(row,separators=(',',':')).encode()+b'\n'
        artifact.write_bytes(gzip.compress(b''.join(lines),mtime=0))
        # Update transport checksums so this exercises semantic rejection.
        manifest['rows_sha256']=sha256(artifact.read_bytes()).hexdigest()
        manifest['uncompressed_bytes']=sum(map(len,lines))
    (destination/'result.json').write_text(json.dumps(manifest,indent=2)+'\n')
    try:verify(destination)
    except ValueError as error:
        if needle not in str(error):raise
        results.append({'case':mode,'detected':True,'error':str(error)})
    else:raise ValueError('corrupted evidence accepted: '+mode)
(root/'result.json').write_text(json.dumps({'witnesses':results,'native_calls':0,
                                         'sampled_estimator_calls':0},indent=2)+'\n')
print(json.dumps(results))
