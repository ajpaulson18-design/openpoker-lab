"""Frozen owned-child observations of the staged-page trainer; no CPU-time claim."""
from collections import Counter
from pathlib import Path
import ctypes
import hashlib
import io
import json
import ntpath
import os
import runpy
import subprocess
import sys
from statistics import median

ROOT=Path.cwd()
WORK=ROOT.parent
OBSERVER=WORK/"dywalk-repo"
OUT=WORK/"dystaged-walk-study1"
NATIVE=WORK/"dyaverage-factor-base1/native-virtual-dyadic-training-staged-pages-probe.exe"
HELPER=WORK/"dywalk-build7/owned-child-stack-sample/native-owned-child-stack-sample.exe"
MAPPED=WORK/"dystaged-walk-map1/mapped-staged.exe"
MAP=WORK/"dystaged-walk-map1/mapped-staged.map"
HEAD="7c10ea680e2075e8592cb978f2a0fa09c0c6b867"
OBSERVER_HEAD="c3fe3535ce25e68db1ad946cc87305be460fb509"
REF=WORK/"dyprofile-staged-page-timing1/warm-reuse"
PAIRS=8
def need(ok,message):
    if not ok: raise ValueError(message)
def sha(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def save(path,data):
    with path.open("x",encoding="utf8",newline="\n") as f:
        f.write(json.dumps(data,indent=2,sort_keys=True)+"\n")
def norm(p): return ntpath.normcase(ntpath.normpath(str(p)))
def head(root):
    need(not subprocess.check_output(["git","status","--porcelain"],cwd=root),"dirty source: "+str(root))
    return subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()
def snapshot(root):
    paths=subprocess.check_output(["git","ls-files","-z"],cwd=root).decode().split("\0")
    return {name:sha(root/name) for name in paths
            if name and (Path(name).suffix in (".py",".cpp",".hpp") or name=="scripts/build_native_exact_four_street.py")}
def helper_identity():
    manifest_path=HELPER.parent/"native-exact-build-manifest.json"
    manifest=json.loads(manifest_path.read_bytes())
    expected={"native/owned_child_stack_sample.cpp","scripts/build_native_exact_four_street.py",
        "third_party/boost-multiprecision-1.92.0/manifest.json",
        "third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt",
        "third_party/boost-multiprecision-1.92.0/headers.zip"}
    need(manifest["target"]=="owned-child-stack-sample" and set(manifest["source_sha256"])==expected and
         sha(HELPER)==manifest["executable_sha256"] and
         sha(Path(manifest["compiler"]))==manifest["compiler_sha256"],"observer build identity")
    for name,digest in manifest["source_sha256"].items():
        raw=(OBSERVER/name).read_bytes()
        need(hashlib.sha256(raw).hexdigest()==digest,"observer raw source drift")
        committed=subprocess.check_output(["git","show",OBSERVER_HEAD+":"+name],cwd=OBSERVER)
        need(raw==committed or raw.replace(b"\r\n",b"\n")==committed,"observer committed source differs")
    return manifest_path.read_bytes()

OUT.mkdir()
observations=[]
try:
    need(sys.dont_write_bytecode,"bytecode suppression required")
    need(head(ROOT)==HEAD and head(OBSERVER)==OBSERVER_HEAD,"frozen heads differ")
    import shutil
    need(shutil.disk_usage(OUT).free>4<<30,"four GiB diagnostic disk reserve")
    before=snapshot(ROOT)
    observer_before=snapshot(OBSERVER)
    save(OUT/"source-before.json",before)
    save(OUT/"observer-source-before.json",observer_before)
    from tests.test_native_exact_reach import authenticate
    from tests.virtual_frozen_run_control import run_bounded_dyadic_probe
    from tests.virtual_dyadic_sweep_capture import SweepCapture
    native_identity=authenticate(NATIVE,ROOT,"virtual-dyadic-training-staged-pages")
    observer_identity=helper_identity()
    verifier_path=OBSERVER/"scripts/verify_owned_child_stack_sample.py"
    map_verifier_path=OBSERVER/"scripts/verify_native_public_map.py"
    verify=runpy.run_path(str(verifier_path))
    map_api=runpy.run_path(str(map_verifier_path))
    correspondence=map_api["bind_public_map"](NATIVE.read_bytes(),MAPPED.read_bytes(),MAP.read_bytes())
    save(OUT/"public-map.json",correspondence)
    fixed={str(p):sha(p) for p in (NATIVE,HELPER,MAPPED,MAP,verifier_path,map_verifier_path)}
    fixed[str(Path(__file__))]=sha(Path(__file__))
    save(OUT/"input-identities.json",fixed)
    source_protocol=json.loads((ROOT/"benchmarks/results/native-dyadic-staged-pages-v1/protocol.json").read_bytes())
    sidecars=source_protocol["stable_sidecars"]
    sidecars["page-images/paging.json"]=sha(REF/"page-images/paging.json")
    need(sha(REF/"stdout.bin")=="bc0496571953a80fd6b1a0f321ed903e11691c5ae5328ed532853ded264ffa49","reference wire drift")
    need(all(sha(REF/name)==digest for name,digest in sidecars.items()),"reference sidecar drift")
    capture=SweepCapture(compact_wire=True)
    numeric=io.BytesIO()
    with (REF/"stdout.bin").open("rb") as f:
        while block:=f.read(65536): capture.feed(block,numeric)
    expected_capture=capture.finish()
    save(OUT/"protocol.json",{"trainer_source_head":HEAD,"observer_source_head":OBSERVER_HEAD,
        "scope":"fixed ten-card two-sweep staged-page trainer; one Windows host",
        "measurement":"bounded primary-thread wall-time stack observations, including I/O waits",
        "prior_observer_packet":"native-owned-child-walk-v1",
        "changed_baseline":"accepted two-dirty-page layout and current exact arithmetic code",
        "pairs_per_comparison":PAIRS,"comparisons":["wrapper","instrumentation"],
        "median_paired_ratio_max":1.01,"interval_ms":20,"minimum_enabled_samples":50,
        "required_enabled_calls":8,"automatic_retries":0,"expected_capture":expected_capture,
        "expected_owner_sha256":sidecars,"quality_gate":None})
    old=json.loads((WORK/"dywalk-race-controls-normal-2/enabled-report.json").read_bytes())
    system={norm(m["path"]):Path(m["path"]) for m in old["modules"] if m["path"] and
        norm(m["path"])!=norm(WORK/"dywalk-build7/owned-child-stack-sample-controls/native-owned-child-stack-sample-controls.exe")}
    system_before={name:sha(path) for name,path in system.items()}
    save(OUT/"system-module-identities-before.json",system_before)
    dbg=ctypes.WinDLL(str(Path(os.environ["SystemRoot"])/"System32/dbghelp.dll"))
    render=dbg.UnDecorateSymbolName
    render.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint32,ctypes.c_uint32]
    render.restype=ctypes.c_uint32
    groups={}
    for item in correspondence["proven_function_ranges"]:
        aliases=[]
        for alias in item["aliases"]:
            buf=ctypes.create_string_buffer(65536)
            n=render(alias["name"].encode("ascii"),buf,len(buf),0x1000)
            aliases.append({"decorated":alias["name"],"name":buf.value.decode("ascii") if n else alias["name"],
                            "object":alias["object"]})
        groups[str(item["begin_rva"])]={"begin_rva":item["begin_rva"],"end_rva":item["end_rva"],"aliases":aliases}
    save(OUT/"function-groups.json",groups)
    tracked={
        "walk":("?visit@?$Walk@",""),
        "terminal":("?terminal@?$Walk@",""),
        "state_stage_row":("??$stage_row_impl@","@State@virtual_dyadic_state@"),
        "state_stage_direct":("??$stage_direct_row@","@State@virtual_dyadic_state@"),
        "pager_stage":("?stage_impl@Image@","@virtual_dyadic_paged_image@"),
        "pager_flush_dirty":("?flush_dirty@Image@","@virtual_dyadic_paged_image@"),
        "chance_contract":("?contract@PreparedPublicChance@","@prepared_public_chance@"),
        "chance_contraction":("?contraction@PreparedPublicChance@","@prepared_public_chance@"),
    }
    def locate(address,modules,returned):
        query=address-int(returned and address!=0)
        matches=[m for m in modules if int(m["base"],16)<=query<int(m["base"],16)+m["size"]]
        need(len(matches)<=1,"overlapping process module mapping")
        if not matches: return "unknown_module",None
        module=matches[0]
        if norm(module["path"])!=norm(NATIVE): return "external_module:"+Path(module["path"]).name,None
        item=map_api["locate_public_function"](correspondence,query-int(module["base"],16))
        return ("main_unresolved_extent",None) if item is None else ("main",str(item["begin_rva"]))
    def summarize(report):
        nearest=Counter()
        inclusive=Counter()
        seeds=Counter()
        walk=Counter({label:0 for label in tracked})
        for sample in report["samples"]:
            addresses=[(int(sample["seed_rip"],16),False)]+[(int(f["pc"],16),True) for f in sample["frames"]]
            found=[locate(address,report["modules"],returned) for address,returned in addresses]
            seeds[found[0][1] or found[0][0]]+=1
            project=[key for _,key in found if key is not None and any(
                a["name"].startswith("openpoker::") for a in groups[key]["aliases"])]
            nearest[project[0] if project else "unresolved_project_context"]+=1
            inclusive.update(set(project))
            labels={label for key in set(project) for label,(prefix,owner) in tracked.items()
                if any(a["decorated"].startswith(prefix) and owner in a["decorated"] for a in groups[key]["aliases"])}
            if "walk" in labels: walk.update(labels)
        return {"samples":len(report["samples"]),"seed_groups":dict(seeds),"nearest_project_context":dict(nearest),
                "inclusive_project_context":dict(inclusive),"walk_inclusive_counts":dict(walk)}
    results={}
    for comparison in ("wrapper","instrumentation"):
        folder=OUT/comparison
        folder.mkdir()
        runs=[]
        for pair in range(1,PAIRS+1):
            for mode in (("baseline","checked") if pair%2 else ("checked","baseline")):
                case=folder/(f"{pair:02}-"+mode)
                case.mkdir()
                wrapped=comparison=="instrumentation" or mode=="checked"
                enabled=comparison=="instrumentation" and mode=="checked"
                if wrapped:
                    symbols=case/"symbols-empty"
                    symbols.mkdir()
                    command=[str(HELPER),"--child",str(NATIVE),"--scratch",str(case/"page-images"),
                        "--report",str(case/"observation.json"),"--symbols",str(symbols),"--interval-ms","20"]
                    if not enabled: command.append("--disabled")
                else: command=[str(NATIVE),str(case/"page-images")]
                save(case/"command.json",command)
                need(all(sha(Path(p))==digest for p,digest in fixed.items()),"binary, verifier or operator drift")
                observed=run_bounded_dyadic_probe(command,"TRAIN_TEN_BOUNDED_DIVISION",case/"process")
                save(case/"observed.json",observed)
                need(observed["actual_exit_observed"] and observed["returncode"]==0 and not observed["failures"] and
                     observed["automatic_retries"]==0,"complete child failed")
                need(observed["sweep_capture"]==expected_capture and
                     (case/"process/stderr.bin").read_bytes()==b"","numerical stream or stderr differs")
                need(all(sha(case/name)==digest for name,digest in sidecars.items()),"owner artifacts differ")
                record={"comparison":comparison,"pair":pair,"mode":mode,"wrapped":wrapped,"enabled":enabled,
                        "seconds":observed["duration_seconds"],"directory":case.relative_to(OUT).as_posix()}
                if wrapped:
                    report=verify["load_report"](case/"observation.json")
                    checked=verify["verify_report"](report,str(NATIVE),
                        "periodic_stack_observation" if enabled else "disabled",0)
                    save(case/"verified-observation.json",checked)
                    record["observation_summary"]=checked
                    if enabled:
                        need(all(norm(m["path"]) in system_before or norm(m["path"])==norm(NATIVE)
                            for m in report["modules"] if m["path"]),"unadmitted child module identity")
                        record["contexts"]=summarize(report)
                        save(case/"contexts.json",record["contexts"])
                save(case/"verified.json",record)
                observations.append(record)
                runs.append(record)
                print(json.dumps({"comparison":comparison,"pair":pair,"mode":mode,"seconds":record["seconds"]}),flush=True)
        ratios=[next(r["seconds"] for r in runs if r["pair"]==p and r["mode"]=="checked")/
                next(r["seconds"] for r in runs if r["pair"]==p and r["mode"]=="baseline") for p in range(1,PAIRS+1)]
        results[comparison]={"observations":runs,"ratios":ratios,"median_paired_ratio":median(ratios),
                             "overhead_gate_passed":median(ratios)<=1.01}
        save(folder/"summary.json",results[comparison])
    enabled=[r for r in observations if r["enabled"]]
    coverage=len(enabled)==8 and all(r["contexts"]["samples"]>=50 for r in enabled)
    need(head(ROOT)==HEAD and head(OBSERVER)==OBSERVER_HEAD and snapshot(ROOT)==before and
         snapshot(OBSERVER)==observer_before,"source drift")
    need(authenticate(NATIVE,ROOT,"virtual-dyadic-training-staged-pages")==native_identity and
         helper_identity()==observer_identity,"build identity drift")
    need(all(sha(Path(p))==digest for p,digest in fixed.items()) and
         {name:sha(path) for name,path in system.items()}==system_before,"tool or module drift")
    save(OUT/"source-after.json",snapshot(ROOT))
    save(OUT/"observer-source-after.json",snapshot(OBSERVER))
    totals=Counter()
    for r in enabled: totals.update(r["contexts"]["walk_inclusive_counts"])
    result={"status":"complete","trainer_source_head":HEAD,"observer_source_head":OBSERVER_HEAD,
        "comparisons":results,"minimum_coverage_passed":coverage,"enabled_samples":sum(
            r["contexts"]["samples"] for r in enabled),"walk_inclusive_counts":dict(totals),
        "complete_training_invocations":len(observations),"all_numerical_and_owner_artifacts_equal":True,
        "overhead_acceptance":coverage and all(r["overhead_gate_passed"] for r in results.values()),
        "scope":"primary-thread periodic wall-time observations only; no CPU or exclusive owner attribution"}
    save(OUT/"result.json",result)
    print(json.dumps({k:result[k] for k in ("enabled_samples","minimum_coverage_passed","overhead_acceptance",
                                           "walk_inclusive_counts")}),flush=True)
except BaseException as e:
    save(OUT/"failure.json",{"error":str(e),"type":type(e).__name__,"completed_calls":len(observations),
                            "automatic_retries":0})
    raise

