"""Bind current staged-page code to a public symbol map without executing it."""
from pathlib import Path
import hashlib,json,runpy,subprocess
from tests.test_native_exact_reach import authenticate

ROOT=Path.cwd()
OBSERVER=(ROOT/"../dywalk-repo").resolve()
BUILD=(ROOT/"../dyaverage-factor-base1").resolve()
OUT=(ROOT/"../dystaged-walk-map1").resolve()
HEAD="7c10ea680e2075e8592cb978f2a0fa09c0c6b867"
def need(ok,message):
    if not ok: raise ValueError(message)
def sha(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def save(name,data):
    with (OUT/name).open("x",encoding="utf8",newline="\n") as f:
        f.write(json.dumps(data,indent=2,sort_keys=True)+"\n")
need(subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==HEAD and
     not subprocess.check_output(["git","status","--porcelain"]),"frozen trainer source drift")
need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=OBSERVER,text=True).strip()=="c3fe3535ce25e68db1ad946cc87305be460fb509" and
     not subprocess.check_output(["git","status","--porcelain"],cwd=OBSERVER),"observer source drift")
OUT.mkdir()
manifest=json.loads((BUILD/"native-exact-build-manifest.json").read_bytes())
exe=Path(manifest["executable"])
initial=authenticate(exe,ROOT,"virtual-dyadic-training-staged-pages")
obj=BUILD/"native-virtual-dyadic-training-staged-pages-probe.obj"
compiler=Path(manifest["compiler"])
linker=compiler.parent/"link.exe"
fixed={str(p):sha(p) for p in (exe,obj,compiler,linker)}
verifier=OBSERVER/"scripts/verify_native_public_map.py"
verifier_hash=sha(verifier)
save("inputs-before.json",fixed)
mapped=OUT/"mapped-staged.exe"
symbols=OUT/"mapped-staged.map"
command=[str(compiler),"/nologo",str(obj),"/Fe"+str(mapped),"/link","/MAP:"+str(symbols),
         "/INCREMENTAL:NO","/VERBOSE:LIB"]
save("command.json",command)
p=subprocess.run(command,cwd=OUT,capture_output=True,timeout=180)
(OUT/"stdout.log").write_bytes(p.stdout)
(OUT/"stderr.log").write_bytes(p.stderr)
save("process.json",{"returncode":p.returncode,"observed_exit":True})
need(p.returncode==0,"map-only relink failed")
api=runpy.run_path(str(verifier))
bound=api["bind_public_map"](exe.read_bytes(),mapped.read_bytes(),symbols.read_bytes())
save("correspondence.json",bound)
need(authenticate(exe,ROOT,"virtual-dyadic-training-staged-pages")==initial and
     all(sha(Path(path))==digest for path,digest in fixed.items()) and
     sha(verifier)==verifier_hash,"source, object, tool or binary drift")
save("inputs-after.json",fixed)
save("result.json",{"trainer_source_head":HEAD,"compiled_target":"virtual-dyadic-training-staged-pages",
     "trainer_build":manifest,"map_verifier_source_head":"c3fe3535ce25e68db1ad946cc87305be460fb509",
     "map_verifier_sha256":verifier_hash,"mapped_sha256":sha(mapped),"map_sha256":sha(symbols),
     "correspondence":bound["correspondence"],
     "operator_sha256":sha(Path(__file__)),
     "object_provenance":"object identity recorded before relink; original build manifest does not attest object bytes",
     "training_invocations":0,"scope":"all PE bytes correspond after structural timestamp normalization; public labels only"})
print(json.dumps({"proven_function_ranges":len(bound["proven_function_ranges"]),
                  "correspondence":bound["correspondence"]}),flush=True)

