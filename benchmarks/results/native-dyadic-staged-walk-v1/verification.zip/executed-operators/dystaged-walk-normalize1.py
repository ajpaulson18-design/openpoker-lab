"""Normalize owned-child reports using admitted image correspondence."""
from pathlib import Path
import gzip,hashlib,json,ntpath,runpy
ROOT=Path.cwd()
WORK=ROOT.parent
DATA=WORK/"dystaged-walk-study1"
OUT=WORK/"dystaged-walk-replay1"
OBSERVER=WORK/"dywalk-repo"
def sha(raw): return hashlib.sha256(raw).hexdigest()
def norm(p): return ntpath.normcase(ntpath.normpath(str(p)))
def need(ok,message):
    if not ok: raise ValueError(message)
def save(path,data):
    with path.open("x",encoding="utf8",newline="\n") as f: f.write(json.dumps(data,indent=2,sort_keys=True)+"\n")
OUT.mkdir()
protocol=json.loads((DATA/"protocol.json").read_bytes())
result=json.loads((DATA/"result.json").read_bytes())
mapping=json.loads((WORK/"dystaged-walk-map1/result.json").read_bytes())
original=Path(mapping["trainer_build"]["executable"])
mapped=WORK/"dystaged-walk-map1/mapped-staged.exe"
mapfile=WORK/"dystaged-walk-map1/mapped-staged.map"
fixed=json.loads((DATA/"input-identities.json").read_bytes())
need(all(sha(Path(p).read_bytes())==digest for p,digest in fixed.items()),"capture input identity drift")
schema=runpy.run_path(str(OBSERVER/"scripts/verify_owned_child_stack_sample.py"))
bind=runpy.run_path(str(OBSERVER/"scripts/verify_native_public_map.py"))
image=bind["Image"](original.read_bytes())
correspondence=bind["bind_public_map"](original.read_bytes(),mapped.read_bytes(),mapfile.read_bytes())
need(correspondence==json.loads((DATA/"public-map.json").read_bytes()),"image or map binding drift")
from scripts.replay_native_walk_contexts import replay
def where(address,modules):
    matched=[m for m in modules if int(m["base"],16)<=address<int(m["base"],16)+m["size"]]
    need(len(matched)<=1,"overlapping child modules")
    if not matched: return "unknown",None
    module=matched[0]
    if norm(module["path"])!=norm(original): return "external",None
    return "main",address-int(module["base"],16)
receipts={}
for record in result["comparisons"]["instrumentation"]["observations"]:
    if not record["enabled"]: continue
    directory=DATA/record["directory"]
    path=directory/"observation.json"
    report=schema["load_report"](path)
    schema["verify_report"](report,str(original),"periodic_stack_observation",0)
    samples=[]
    external_seeds=unknown_seeds=0
    for sample in report["samples"]:
        kind,seed=where(int(sample["seed_rip"],16),report["modules"])
        external_seeds+=kind=="external"
        unknown_seeds+=kind=="unknown"
        native=[]
        external=unknown=0
        for frame in sample["frames"]:
            address=int(frame["pc"],16)
            kind,rva=where(address-1 if address else 0,report["modules"])
            if kind=="main": native.append(rva)
            elif kind=="external": external+=1
            else: unknown+=1
        samples.append({"elapsed_ms":sample["elapsed_ms"],"seed_rva":seed,"native_return_rvas":native,
                        "external_return_frames":external,"unknown_return_frames":unknown,
                        "status":sample["status"],"stop_reason":sample["stop_reason"]})
    normalized={"format":"owned-child-wall-contexts-v1","native_image_sha256":sha(original.read_bytes()),
        "image_size":image.image_size,"raw_report_sha256":sha(path.read_bytes()),"map_sha256":sha(mapfile.read_bytes()),
        "return_pc_adjusted_before_module_lookup":True,"interval_ms":report["interval_ms"],
        "external_seed_samples":external_seeds,"unknown_seed_samples":unknown_seeds,
        "ranges":correspondence["proven_function_ranges"],"samples":samples}
    target=OUT/(f"capture-{record['pair']}.json.gz")
    with target.open("xb") as f:
        f.write(gzip.compress(json.dumps(normalized,separators=(",",":")).encode(),mtime=0))
    receipts[target.name]=replay(target)
totals={}
for receipt in receipts.values():
    for key,value in receipt["nested_walk_context_counts"].items(): totals[key]=totals.get(key,0)+value
for key,value in result["walk_inclusive_counts"].items():
    if key!="chance_contract":
        need(totals[key]==value,"saved recount differs outside corrected contract label")
need(sum(x["samples"] for x in receipts.values())==result["enabled_samples"],"sample count differs")
save(OUT/"replay.json",{"captures":receipts,"totals":totals,"producer_calls":0,
    "classification_correction":"The initial controller matched only a non-template Chance contract prefix. Saved-only replay additionally matches the current template contract symbol. Initial counts remain retained."})
print(json.dumps({"samples":sum(x["samples"] for x in receipts.values()),"counts":totals,
                 "matching_groups":next(iter(receipts.values()))["matching_public_ranges"]}),flush=True)

