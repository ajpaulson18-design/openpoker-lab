from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd()
out=(root/"../dystaged-walk-replay-controls1").resolve()
out.mkdir()
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
if subprocess.check_output(["git","status","--porcelain"]): raise ValueError("dirty source")
sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
    ("scripts/replay_native_walk_contexts.py","tests/test_native_walk_contexts.py")}
records=[]
for mode,flags in (("normal",[]),("optimized",["-O"])):
    command=[sys.executable,"-B",*flags,"-m","unittest","tests.test_native_walk_contexts","-v"]
    with (out/(mode+".stdout.log")).open("xb") as stdout,(out/(mode+".stderr.log")).open("xb") as stderr:
        p=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120,
                         env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"))
    records.append({"mode":mode,"command":command,"returncode":p.returncode,"actual_exit_observed":True})
    if p.returncode: raise ValueError("replay controls failed")
files=sorted((root/"benchmarks/results/native-dyadic-staged-walk-v1").glob("capture-*.json.gz"))
command=[sys.executable,"-B","-O","-m","scripts.replay_native_walk_contexts",*map(str,files)]
with (out/"replay.stdout.json").open("xb") as stdout,(out/"replay.stderr.log").open("xb") as stderr:
    p=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120)
records.append({"mode":"saved-only","returncode":p.returncode,"actual_exit_observed":True,"producer_calls":0})
if p.returncode: raise ValueError("saved replay failed")
r=json.loads((out/"replay.stdout.json").read_bytes())
reference=json.loads((root/"benchmarks/results/native-dyadic-staged-walk-v1/saved-replay.json").read_bytes())
if r!=reference["captures"]: raise ValueError("published saved-only replay differs")
if subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()!=head or subprocess.check_output(["git","status","--porcelain"]):
    raise ValueError("source changed")
if any(hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest for name,digest in sources.items()):
    raise ValueError("raw analysis source drift")
(out/"process.json").write_text(json.dumps({"source_head":head,"raw_source_sha256":sources,
    "observations":records,"tests_per_mode":8,"skips":0,"saved_samples":811,"saved_walk_observations":504,
    "native_producer_calls":0},indent=2)+"\n")
print("8 controls per mode and all 811 saved observations verified")

