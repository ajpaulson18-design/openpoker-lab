"""Package frozen initial-policy training receipts and verify the saved-byte comparison."""
from hashlib import file_digest, sha256
import io
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / "dyadic-phase-payload-repo"
HEAD = "c94c8c753ccdd0d5ab8b8a3b2785b4be281dd0aa"
COHORT = WORK / "dybootstrap-cohort4"
OPERATOR = WORK / "dybootstrap-launch4"
CONTROLS = WORK / "dybootstrap-controls1"
RESULT = ROOT / "benchmarks/results/native-dyadic-initial-policy-v1"
BASELINE = "benchmarks/results/native-dyadic-owned-snapshot-v1"
MODE = "ten_zero_policy_bootstrap"

sys.path.insert(0, str(ROOT))
from scripts.virtual_dyadic_compact_wire import expand_compact
from scripts.project_virtual_dyadic_history import history_schedule
from tests.virtual_dyadic_stage_schedule import stage_schedule


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    final = read(COHORT / "result.json")
    source = read(COHORT / "source.json")
    hashes = {name: item["raw_sha256"] for name, item in source["files"].items()}
    outer = read(OPERATOR / "completion.json")
    controls = read(CONTROLS / "completion.json")
    require(final["head"] == source["head"] == outer["head"] == controls["head"] == HEAD and
            final["training_invocations"] == 1 and read(COHORT / "terminal.json")["status"] == "complete" and
            outer["actual_exit_observed"] and outer["returncode"] == 0 and not outer["failures"] and
            outer["raw_source_stable"] and controls["raw_source_stable"] and
            controls["tests_per_mode"] == 62 and controls["skips"] == 0 and
            all(read(path / ("source-" + phase + ".json")) == hashes
                for path in (OPERATOR, CONTROLS) for phase in ("before", "after")),
            "frozen execution, control or source identity differs")
    launcher = WORK / "trusted-virtual-dyadic-training-launch-v35.py"
    require(read(OPERATOR / "operator-launch.json")["operator_sha256"] == digest(launcher),
            "outer launcher identity differs")
    for boot_path in (OPERATOR / "bootstrap.json", COHORT / "saved-review-bootstrap.json"):
        boot = read(boot_path)
        require(boot["initial_cache_scan"]["project_bytecode_files"] ==
                boot["final_cache_scan"]["project_bytecode_files"] == 0 and
                all(hashes[name] == value for name, value in boot["compiled"].items()),
                "source-only closure identity differs")
    for child in ("admit_" + MODE, "train_" + MODE, "saved-review"):
        process = read(COHORT / child / "process.json")
        require(process["actual_exit_observed"] and process["returncode"] == 0 and
                not process["failures"] and process["automatic_retries"] == 0,
                "child exit or retry count differs")
    build_path = COHORT / "build/native-exact-build-manifest.json"
    build = read(build_path)
    require(digest(Path(build["executable"])) == build["executable_sha256"] and
            all(hashes[name] == value for name, value in build["source_sha256"].items()),
            "native build differs")
    links = {}
    for name in ("manifest.json", "verification.zip"):
        path = ROOT / BASELINE / name
        links[name] = digest(path)
        require(links[name] == hashes[BASELINE + "/" + name], "snapshot baseline identity differs")
    prior = read(ROOT / BASELINE / "manifest.json")
    require(prior["archive"]["sha256"] == links["verification.zip"], "snapshot archive hash differs")
    with ZipFile(ROOT / BASELINE / "verification.zip") as archive:
        prior_replay = json.loads(archive.read("cohort/saved-review/stdout.bin"))
        prior_compact = archive.read("cohort/train_ten_reuse_snapshot/stdout.bin")
        prior_paging = json.loads(archive.read("cohort/page-images/paging.json"))
    capture = final["compact_sweep_capture"]
    require(capture["frames"] == prior["compact_sweep_capture"]["frames"] and
            sha256(prior_compact).hexdigest() == prior["compact_sweep_capture"]["retained_sha256"] and
            final["row_directory"] == prior["row_directory"] and
            final["policy_spill"] == prior["policy_spill"] and
            final["factored_execution"] == prior["factored_execution"], "exact checkpoint or I/O identity differs")
    with io.BytesIO() as writer:
        expand_compact(io.BytesIO(prior_compact), writer, source_size=len(prior_compact))
        previous = writer.getvalue()
    expanded = (COHORT / ("train_" + MODE) / "expanded.bin").read_bytes()
    replay = final["saved_only_replay"]
    require(sha256(previous).hexdigest() == prior_replay["saved_output_sha256"] and
            sha256(expanded).hexdigest() == replay["saved_output_sha256"] and
            replay["status"] == "saved_two_sweep_exact_replay_pass" and replay["native_producer_calls"] == 0,
            "expanded replay identity differs")
    r, s = replay["shape"]["rows"], replay["shape"]["slots"]
    q, state, route = 320*r+48*s, 32*r, -16*r
    expected = bytearray(previous)
    for key, offset, delta in (("work_plan", 488, state), ("work_actual", 440, state),
                               ("work_plan", 480, -q), ("work_actual", 432, -q),
                               ("work_plan", 472, route), ("work_actual", 424, route),
                               ("parent_work_plan", 360, route), ("parent_work_actual", 288, route)):
        value = int.from_bytes(previous[-offset:-offset+8], "little") + delta
        expected[-offset:-offset+8] = value.to_bytes(8, "little")
    require(expanded == expected, "expanded bytes differ outside the eight work footer words")
    counts = dict(prior_paging)
    for key in ("read_calls", "synthetic_read_calls"):
        counts[key] -= r
    for key in ("logical_read_words", "synthetic_read_words"):
        counts[key] -= 1_666_910
    require(final["paging"]["counts"] == counts, "initial policy pager counters differ")

    forecast_name = "benchmarks/results/native-dyadic-eleven-card-forecast-v1/forecast.json"
    forecast_path = WORK / "dybootstrap-src4" / forecast_name
    require(digest(forecast_path) == hashes[forecast_name], "eleven-card forecast identity differs")
    eleven = read(forecast_path)["n11_prospective"]
    pages = stage_schedule(eleven_card=True, virtual_zero=True, batch_rows=True, zero_policy_bootstrap=True)
    r11, s11 = pages["rows"], pages["slots"]
    require((r11,s11) == (eleven["shape"]["rows"],eleven["shape"]["slots"]) and
            320*r11+48*s11 == eleven["quantizer_terms"][0], "eleven-card geometry differs")
    q11, state11, route11 = eleven["quantizer_terms"][0], 32*r11, -16*r11
    projected = {
        "scope": "rank-free eleven-card projection, no training or rank calls",
        "removed_quantizer_work": q11, "added_state_work": state11, "removed_route_work": -route11,
        "net_work_removed": q11-state11-route11, "removed_logical_reads": r11,
        "removed_logical_words": pages["regret_words"], "pager": pages,
        "history_work": history_schedule(eleven, True, reuse_visit=True)["work"],
        "state_work": eleven["component_work"]["state"]+state11, "state_cap": 300_000_000,
        "quantizer_work": eleven["component_work"]["quantizer"]+2*(16*r11+48*s11)-q11,
        "quantizer_cap": 520_000_000,
    }
    native = read(COHORT / ("train_" + MODE) / "process.json")
    require(read(WORK / "dybootstrap-cohort1/terminal.json")["receipt"]["training_invocations_entered"] == 0,
            "failed attempt entered training")
    files = {
        "operator/packager.py": Path(__file__), "operator/launcher.py": launcher,
        "controls/runner.py": WORK / "check-dyadic-zero-policy-controls1.py",
    }
    for attempt in (1, 2, 3):
        failed = WORK / f"dybootstrap-cohort{attempt}"
        failed_operator = WORK / f"dybootstrap-launch{attempt}"
        first = read(failed / "terminal.json")
        exit_record = read(failed_operator / "exit.json")
        require(first["status"] == "failed" and exit_record["actual_exit_observed"] and
                exit_record["returncode"] != 0, "earlier attempt did not fail as recorded")
        for name, path in (("terminal.json", failed / "terminal.json"),
                           ("admission.json", failed / ("admit_" + MODE) / "stdout.bin"),
                           ("exit.json", failed_operator / "exit.json")):
            files[f"earlier/{attempt}/{name}"] = path
    for prefix, folder in (("operator", OPERATOR), ("cohort", COHORT), ("controls", CONTROLS)):
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(folder)
            if prefix == "cohort" and (relative.parts[0] == "source" or
                    relative.parts[0] == "build" and path != build_path or
                    path.name in ("committed.bin", "staged.bin", "expanded.bin")):
                continue
            files[f"{prefix}/{relative.as_posix()}"] = path
    for control in ("virtual-dyadic-state-controls", "dyadic-policy-controls"):
        relative = f"dybootstrap-controls-build1/{control}"
        path = WORK / relative / "native-exact-build-manifest.json"
        require(digest(path) == controls["builds"][relative]["manifest_sha256"], "control build identity differs")
        files[f"controls/builds/{control}.json"] = path
    inventory = {name: {"bytes": path.stat().st_size, "sha256": digest(path)} for name, path in files.items()}
    RESULT.mkdir()
    archive_path = RESULT / "verification.zip"
    with ZipFile(archive_path, "x", ZIP_DEFLATED) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, name)
        archive.writestr("inventory.json", json.dumps(inventory, indent=2, sort_keys=True))
    with ZipFile(archive_path) as archive:
        require(archive.testzip() is None, "archive failed integrity check")
        for name, meta in inventory.items():
            with archive.open(name) as stream:
                require(archive.getinfo(name).file_size == meta["bytes"] and
                        file_digest(stream, "sha256").hexdigest() == meta["sha256"], "archive member differs")
    manifest = {
        "version": RESULT.name, "source_head": HEAD, "source_files": len(hashes),
        "prior_manifest_sha256": links["manifest.json"], "training_invocations": 1,
        "admission": final["admission"], "focused_controls_per_mode": controls["tests_per_mode"],
        "native_seconds": native["duration_seconds"], "quality_gate": final["quality_gate"],
        "paging_before": prior_paging, "paging_after": counts, "compact_sweep_capture": capture,
        "saved_only_replay": replay, "changed_footer_words": 8,
        "work_before": prior_replay["work_plan"], "work_after": replay["work_plan"],
        "actual_work_before": prior_replay["work_actual"], "actual_work_after": replay["work_actual"],
        "composed_work_before": prior["admission"]["factored_composed_work"],
        "composed_work_after": final["admission"]["factored_composed_work"],
        "eleven_card_projection": projected,
        "archive": {"path": archive_path.name, "bytes": archive_path.stat().st_size,
                    "sha256": digest(archive_path), "members": len(inventory)+1},
    }
    (RESULT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps(manifest["archive"], sort_keys=True))


if __name__ == "__main__":
    main()

