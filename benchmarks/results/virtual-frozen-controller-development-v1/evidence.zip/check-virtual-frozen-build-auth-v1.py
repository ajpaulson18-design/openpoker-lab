from pathlib import Path
import sys,json,hashlib,traceback,copy
repo=Path.cwd();sys.path.insert(0,str(repo));work=repo.parent
from tests.virtual_frozen_build_guard import authenticate_build
build=work/'virtual-frozen-controller-build-v1';out=work/'virtual-frozen-build-auth-controls-v1';out.mkdir(exist_ok=False)
manifest_path=build/'native-exact-build-manifest.json';manifest_raw=manifest_path.read_bytes();manifest=json.loads(manifest_raw)
source={'files':{name:{'raw_sha256':digest} for name,digest in manifest['source_sha256'].items()}}
status={'scope':'actual fresh build/input/compiler/header authentication controls; not full committed-tree admission','native_calls':0,'negative_controls':[]}
try:
    before=authenticate_build(repo,build,source)
    (out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
    wrong=copy.deepcopy(source);wrong['files']['native/virtual_frozen_update.hpp']['raw_sha256']='0'*64
    try:authenticate_build(repo,build,wrong)
    except ValueError as e:status['negative_controls'].append({'case':'frozen_raw_source_mismatch','error':str(e)})
    else:raise RuntimeError('source mutation accepted')
    dependency=json.loads((repo/'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
    header=build/'boost-include'/next(iter(dependency['headers_sha256']))
    original=header.read_bytes();header.write_bytes(original+b'\n')
    try:
        try:authenticate_build(repo,build,source)
        except ValueError as e:status['negative_controls'].append({'case':'actual_header_drift','error':str(e)})
        else:raise RuntimeError('header mutation accepted')
    finally:header.write_bytes(original)
    executable=Path(manifest['executable']);original=executable.read_bytes();executable.write_bytes(original+b'\0')
    try:
        try:authenticate_build(repo,build,source)
        except ValueError as e:status['negative_controls'].append({'case':'actual_executable_drift','error':str(e)})
        else:raise RuntimeError('executable mutation accepted')
    finally:executable.write_bytes(original)
    altered=dict(manifest);del altered['compiler_sha256'];manifest_path.write_text(json.dumps(altered)+'\n')
    try:
        try:authenticate_build(repo,build,source)
        except ValueError as e:status['negative_controls'].append({'case':'missing_compiler_byte_identity','error':str(e)})
        else:raise RuntimeError('missing compiler identity accepted')
    finally:manifest_path.write_bytes(manifest_raw)
    after=authenticate_build(repo,build,source);(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
    if before!=after:raise RuntimeError('restored build identity differs')
    status.update(status='pass',original_build_restored=True,compiler_sha256=before['compiler_sha256'])
except BaseException:
    status.update(status='failed',first_error=traceback.format_exc())
(out/'completion.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status));sys.exit(0 if status['status']=='pass' else 1)
