"""One saved-only pass; preserve authoritative terminal status without retries."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
repo = work / 'matrix-free-certificate-repo'
process = work / 'matrix-free-certificate-study-process-v1'
output = work / 'matrix-free-certificate-study-v1'
process.mkdir(exist_ok=False)
if output.exists():
    raise ValueError('refusing to replace previous saved-study output')
command = [sys.executable, '-B', '-m', 'scripts.benchmark_matrix_free_certificate',
           '--output', str(output), '--producer-repo', str(work / 'native-fold-mask-repo')]
(process / 'request.json').write_text(json.dumps({'command': command,
    'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2)+'\n')
with (process / 'stdout.log').open('xb') as stdout, (process / 'stderr.log').open('xb') as stderr:
    completed = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
status = {'returncode':completed.returncode, 'command':command,
          'output':str(output), 'retries':0}
(process / 'status.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(status),flush=True)
raise SystemExit(completed.returncode)
