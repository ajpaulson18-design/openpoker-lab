"""Package frozen evidence only; never execute archived source."""
import hashlib
import json
from pathlib import Path
import zipfile

work = Path(__file__).resolve().parent
repo = work / 'matrix-free-certificate-repo'
study = work / 'matrix-free-certificate-study-v1'
review = work / 'matrix-free-certificate-independent-review-v1'
process = work / 'matrix-free-certificate-study-process-v1'
output = work / 'matrix-free-certificate-evidence-v1.zip'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def parse(path): return json.loads(path.read_bytes())
def require(condition, message):
    if not condition: raise ValueError(message)

require(not output.exists(), 'refusing to replace evidence archive')
report = parse(study / 'report.json')
source = parse(study / 'source-before.json')
require(report['failure'] is None and all(report[k] == 28 for k in
    ('records_planned', 'records_attempted', 'records_captured')), 'incomplete saved-only pass')
require(parse(study / 'source-after.json') == source and not source['status'], 'source drift/dirty freeze')
process_status = parse(process / 'status.json')
process_request = parse(process / 'request.json')
observation = parse(process / 'process-observation.json')
require(process_status['returncode'] == observation['terminal_exit_code'] == 0 and
    process_status['command'] == process_request['command'] and process_status['retries'] == 0 and
    Path(process_status['output']).resolve() == study.resolve() and
    process_request['wrapper_sha256'] == sha((work / 'run-matrix-free-saved-study-v1.py').read_bytes()) and
    observation['stdout_sha256'] == sha((process / 'stdout.log').read_bytes()) and
    observation['stderr_sha256'] == sha((process / 'stderr.log').read_bytes()) and
    observation['confirmed_terminal_handle'], 'saved-study process binding')
receipts = [p for p in review.rglob('receipt.json') if parse(p).get('status') == 'passed']
require(len(receipts) == 1, 'require exactly one independent passed receipt')
receipt = parse(receipts[0])
require(receipt['source_commit'] == source['commit'] and
    receipt['candidate_manifest_sha256'] == sha((study / 'manifest.json').read_bytes()) and
    receipt['producer_or_candidate_calls'] == 0 and receipt['terminal_exit_code'] == 0,
    'independent source/manifest/call/terminal binding')
require(sha((review / 'review.py').read_bytes()) == receipt['helper_sha256'], 'review helper drift')
require(set(receipt['independent_six']) == set(parse(study / 'protocol.json')['old_exact_unknown_labels']),
    'independent six-policy inventory')
for label, result in receipt['independent_six'].items():
    require(type(result.get('scalar_sha256')) is str and len(result['scalar_sha256']) == 64,
        'missing independent scalar result hash: '+label)
    require(sha((receipts[0].parent / (label+'-scalar.json')).read_bytes()) == result['scalar_sha256'],
        'independent scalar-result drift: '+label)
review_process = review / 'saved-process-v1'
review_request = parse(review_process / 'request.json')
review_status = parse(review_process / 'status.json')
review_observation = parse(review_process / 'process-observation.json')
require(review_observation['terminal_exit_code'] == 0 and review_observation['confirmed_terminal_handle'],
    'independent reviewer outer terminal confirmation')
require(review_status['returncode'] == 0 and review_status['retries'] == review_request['retries'] == 0 and
    review_status['command'] == review_request['command'] and
    review_status['helper_sha256'] == review_request['helper_sha256'] == receipt['helper_sha256'] and
    review_status['helper_sha256_after'] == review_status['expected_helper_sha256'] == receipt['helper_sha256'] and
    review_request['expected_helper_sha256'] == receipt['helper_sha256'] and review_status['error'] is None and
    review_status['request_sha256'] == sha((review_process / 'request.json').read_bytes()) and
    review_status['wrapper_sha256'] == review_request['wrapper_sha256'] == sha((review / 'run-review-v1.py').read_bytes()) and
    review_status['receipt_sha256'] == sha(receipts[0].read_bytes()) and
    review_status['stdout_sha256'] == sha((review_process / 'stdout.log').read_bytes()) and
    review_status['stderr_sha256'] == sha((review_process / 'stderr.log').read_bytes()),
    'independent reviewer actual-process binding')
manifest = parse(study / 'manifest.json')
study_bytes = {p.relative_to(study).as_posix():p.read_bytes() for p in study.rglob('*') if p.is_file()}
require(set(study_bytes) == set(manifest['files']) | {'manifest.json'} and
    all(sha(study_bytes[n]) == h for n,h in manifest['files'].items()), 'saved-study manifest drift')
old_archive = work / 'native-fold-classes-evidence-v1.zip'
require(sha(old_archive.read_bytes()) == 'f0a840055b9a9ebabb0909a8dd92a1c855531ab568b64e7fe57b725329c70f88',
    'original accepted evidence archive drift')
members = {}
def add(name, path):
    require(name not in members and path.is_file() and not path.is_symlink(), 'duplicate/nonordinary package input: '+name)
    members[name] = path.read_bytes()

for directory in (study, review, process, work / 'matrix-free-certificate-development-controls-v2'):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('evidence/'+directory.name+'/'+path.relative_to(directory).as_posix(), path)
require(all(members['evidence/'+study.name+'/'+n] == raw for n,raw in study_bytes.items()),
    'study drift while capturing')
for name, digest in source['sha256'].items():
    path = repo / name
    require(sha(path.read_bytes()) == digest, 'full committed raw source drift: '+name)
    selected = ((name.startswith(('scripts/', 'pokerlab/', 'tests/', 'native/')) and
                 path.suffix in ('.py', '.hpp', '.cpp')) or
                name.startswith('third_party/boost-multiprecision-') or name in
                ('AGENTS.md', '.gitattributes', 'docs/matrix-free-certificate.md',
                 '.github/workflows/tests.yml', '.github/workflows/native-exact-four-street.yml'))
    if selected: add('source/'+name, path)
add('original-evidence/'+old_archive.name, old_archive)
for name in ('exact-selected-independent-review.py', 'package-matrix-free-certificate-v1.py',
             'audit-matrix-free-certificate-archive-v1.py',
             'run-matrix-free-saved-study-v1.py', 'run-matrix-free-certificate-controls-v2.py'):
    add('helpers/'+name, work / name)
# Keep authentication-only failures and successes separate from mathematical runs.
for path in sorted(work.glob('matrix-free-certificate-auth-check-v*.*')):
    if path.is_file(): add('development/'+path.name, path)
for path in sorted(work.glob('matrix-free-certificate-runner-root-v1.*')):
    if path.is_file(): add('development/'+path.name, path)
inner = {'contract':'matrix-free-certificate-evidence-v1', 'source_commit':source['commit'],
    'source_scope':'Full tracked raw/Git identity maps; current executable mathematics/tests and pinned dependency sources archived as evidence only. Original accepted fold archive is independently pinned. Archived source is never executed.',
    'files':{name:sha(raw) for name,raw in sorted(members.items())}}
inner_raw = (json.dumps(inner,indent=2,sort_keys=True)+'\n').encode()
with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(members.items()): archive.writestr(name,raw)
    archive.writestr('manifest.json',inner_raw)
result = {'archive':output.name, 'sha256':sha(output.read_bytes()),
    'bytes':output.stat().st_size, 'entries':len(members)+1,
    'manifest_sha256':sha(inner_raw), 'source_commit':source['commit']}
with (work / 'matrix-free-certificate-package-v1.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result),flush=True)
