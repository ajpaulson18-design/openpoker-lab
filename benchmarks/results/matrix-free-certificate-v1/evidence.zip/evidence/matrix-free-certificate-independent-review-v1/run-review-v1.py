"""One saved-only reviewer attempt with durable raw process provenance.

This wrapper never runs until explicitly invoked with the frozen study pins.
It neither trains nor invokes the candidate certificate or native executable.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
HELPER = ROOT / 'review.py'
PROCESS = ROOT / 'saved-process-v1'
OUTPUT = ROOT / 'attempt1'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False)
        stream.write('\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('repo','old-repo','study','candidate-study'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('source-commit','manifest-sha256','report-sha256',
                 'source-after-sha256','confirmed-terminal-handle','helper-sha256'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--terminal-exit-code',type=int,required=True)
    args=parser.parse_args()
    # Every invoked attempt, including a preflight failure, gets a fresh
    # request, both streams and final status; existing evidence is never replaced.
    PROCESS.mkdir(exist_ok=False)
    helper_before=sha(HELPER.read_bytes()) if HELPER.is_file() else None
    command=[sys.executable,'-B',str(HELPER),
        '--repo',str(args.repo.resolve()),'--old-repo',str(args.old_repo.resolve()),
        '--study',str(args.study.resolve()),'--candidate-study',str(args.candidate_study.resolve()),
        '--output-dir',str(OUTPUT),'--source-commit',args.source_commit,
        '--manifest-sha256',args.manifest_sha256,'--report-sha256',args.report_sha256,
        '--source-after-sha256',args.source_after_sha256,
        '--confirmed-terminal-handle',args.confirmed_terminal_handle,
        '--terminal-exit-code',str(args.terminal_exit_code)]
    wrapper_hash=sha(Path(__file__).read_bytes())
    request={'schema':'matrix-free-saved-review-process-request-v1',
        'command':command,'helper_sha256':helper_before,'expected_helper_sha256':args.helper_sha256,'wrapper_sha256':wrapper_hash,
        'output':str(OUTPUT),'retries':0}
    write(PROCESS/'request.json',request)
    returncode=None;error=None
    try:
        with (PROCESS/'stdout.log').open('xb') as stdout, (PROCESS/'stderr.log').open('xb') as stderr:
            if args.terminal_exit_code != 0 or not args.confirmed_terminal_handle:
                raise ValueError('confirmed successful study terminal required')
            if not re.fullmatch(r'[0-9a-f]{40}',args.source_commit):
                raise ValueError('invalid source commit pin')
            for name in ('manifest_sha256','report_sha256','source_after_sha256','helper_sha256'):
                if not re.fullmatch(r'[0-9a-f]{64}',getattr(args,name)):
                    raise ValueError('invalid SHA-256 pin')
            if helper_before != args.helper_sha256:
                raise ValueError('review helper differs from supplied pin')
            if OUTPUT.exists():
                raise ValueError('refusing to replace previous reviewer attempt')
            completed=subprocess.run(command,cwd=ROOT.parent,stdout=stdout,stderr=stderr,check=False)
            returncode=completed.returncode
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
    stdout_path,stderr_path=PROCESS/'stdout.log',PROCESS/'stderr.log'
    helper_after=sha(HELPER.read_bytes()) if HELPER.is_file() else None
    receipt=OUTPUT/'receipt.json'
    receipt_hash=sha(receipt.read_bytes()) if receipt.is_file() else None
    status={'schema':'matrix-free-saved-review-process-status-v1',
        'command':command,'helper_sha256':helper_before,'expected_helper_sha256':args.helper_sha256,'helper_sha256_after':helper_after,
        'wrapper_sha256':wrapper_hash,'request_sha256':sha((PROCESS/'request.json').read_bytes()),
        'retries':0,'stdout_sha256':sha(stdout_path.read_bytes()) if stdout_path.is_file() else None,
        'stderr_sha256':sha(stderr_path.read_bytes()) if stderr_path.is_file() else None,
        'returncode':returncode,'receipt_sha256':receipt_hash,'error':error}
    write(PROCESS/'status.json',status)
    print(json.dumps(status,sort_keys=True,allow_nan=False),flush=True)
    if error is not None or returncode != 0 or helper_after != helper_before or receipt_hash is None:
        return 1
    return 0

if __name__=='__main__': raise SystemExit(main())
