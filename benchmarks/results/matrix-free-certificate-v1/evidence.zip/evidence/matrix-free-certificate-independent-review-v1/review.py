"""Saved-only literal streaming certificate reference; never trains or calls candidate.

Public legal rules and independent best-five ranking are authenticated shared
inputs. All chance mass, blocker tests, policy normalization, terminal payoff,
and best-response recursion below are separately implemented. No world or
private-pair rows are retained. This is not an unrestricted poker certificate.
"""
import argparse
from collections import Counter
from decimal import Decimal, localcontext
from contextlib import ExitStack
from fractions import Fraction
import hashlib
import json
from math import fsum, isfinite
from pathlib import Path
import re
import sys
import types
from unittest.mock import patch

OLD_REVIEW_SHA = '0bf743caae0d347b2cfd1f1cbac6c12d55abff6d359a355d71fc5b0f7c74e4dc'
AUTH_SHA = '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
OLD_COMMIT = '946671d8da38102aff4c7d901d02d58158888a68'
OLD_MANIFEST = 'e520dbeb8011b247041e13d63eeddf1423bba0dc340ebb8072250af664ef19ac'
OLD_REPORT = '41096b7db81e62111bec209905c35c04f99542473313b0d29d5458986fa3b1ef'
OLD_BUILD = '40c75343ae7c6d3b9f5d0010f0da977ecea096e6aadeb9afb13535492abf6412'
OLD_EXE = '065217920a79e9d4b6378e09a3ad4371332eb863b363e911f20dd18ac64475d9'
NAMES = ('balanced-4x4-unit','balanced-8x8-unit','asymmetric-2x16-unit')
MODES = ('board-sweep','fold-mask-classes-v1')
OLD_RECEIPT = '88e5a8cc68dae468338ba854158bc4f1c0467e0e364e059b5917acab76664e33'
OLD_OBSERVATION = '798a0f906f180a284a1b25932e575d7c1656bbfd2069bc3be4b11bffdb5dd078'
EXACT_NUMERIC = {'value_sb':'value_sb','value_bb':'value_bb',
    'sb_best_response_value':'sb_best_response_value','bb_best_response_value':'bb_best_response_value',
    'sb_best_response_gain':'sb_gain','bb_best_response_gain':'bb_gain',
    'nash_conv':'nash_conv','exploitability':'exploitability'}
RESOURCE_PATTERNS = tuple(re.compile(p) for p in (
    r'(?:[^\n:]{1,80}: )?certificate work limit exceeded',
    r'(?:[^\n:]{1,80}: )?certificate integer bit limit exceeded',
    r'(?:[^\n:]{1,80}: )?certificate cumulative integer bit limit exceeded',
    r'.+: certificate entry limit exceeded',r'certificate JSON node/depth limit exceeded',
    r'(?:[^\n:]{1,80}: )?certificate JSON (?:integer width|input string length|sequence|mapping) exceeded',
    r'certificate canonical JSON byte limit exceeded',
    r'certificate whole-request walk forecast exceeds (?:work|entry) limit',
    r'certificate public traversal depth exceeded',r'certificate final Fraction text forecast exceeds byte limit',
    r'(?:[^\n:]{1,80}: )?Fraction text integer bit limit exceeded',
    r'(?:[^\n:]{1,80}: )?cumulative Fraction text byte limit exceeded',
    r'(?:[^\n:]{1,80}: )?certificate policy-row limit exceeded',
    r'(?:[^\n:]{1,80}: )?certificate action-slot limit exceeded',
    r'public graph exceeds (?:[0-9]+ nodes|depth [0-9]+)',
    r'.+ exceeds the [0-9]+-holding research cap',
    r'public action menu exceeds bounded per-decision width',
    r'certificate public occurrence census exceeded'))
ZERO, ONE = Fraction(0), Fraction(1)


def check(ok, message):
    if not ok: raise ValueError(message)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def digest(path): return sha(Path(path).read_bytes())
def parse_fraction(text):
    # Decimal avoids Python's process-global int/string digit limit; refuse
    # exponents, Unicode digits, and excess length before integer conversion.
    check(type(text) is str and re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?',text,flags=re.ASCII) is not None,
          'invalid exact rational text')
    parts=text.split('/')
    check(parts[0]!='-0','negative zero is not canonical')
    limit=(65536*30103)//100000+1
    check(all(len(part.lstrip('-'))<=limit for part in parts),'rational decimal length cap')
    values=[int(Decimal(part)) for part in parts]
    check(all(value.bit_length()<=65536 for value in values),'rational bit cap')
    check(len(values)==1 or values[1]>0,'invalid exact rational denominator')
    return Fraction(values[0],values[1] if len(values)==2 else 1)
def load_external(path,pin,name):
    raw=path.read_bytes();check(sha(raw)==pin,'external helper pin '+name)
    mod=types.ModuleType(name);mod.__file__=str(path)
    exec(compile(raw,str(path),'exec'),mod.__dict__)
    return mod,raw

class Guard:
    """Reference-only conservative pre-arithmetic Fraction width and work cap."""
    def __init__(self):
        self.work=0;self.bits=0;self.counts=Counter();self.max_bits=0;self.entries_used=0;self.text_bytes=0
    def charge(self, kind, n=1):
        check(type(n) is int and n>=0 and self.work+n<=500_000_000,'reference work cap')
        self.work+=n;self.counts[kind]+=n
    def hash_json(self,value):
        size=0;count=0;self.entries(1);stack=[(value,0)]
        while stack:
            item,depth=stack.pop();count+=1
            self.charge('normalized_json_nodes')
            check(count<=2_000_000 and depth<=40,'reference JSON shape cap')
            kind=type(item)
            if kind is str:
                self.charge('normalized_json_characters',len(item)+2)
                size+=2+sum(2 if c in ('"','\\') or ord(c) in (8,9,10,12,13)
                            else 6 if ord(c)<32 or 127<=ord(c)<=65535
                            else 12 if ord(c)>65535 else 1 for c in item)
            elif kind is dict:
                n=len(item);self.charge('normalized_json_sort',n*(1+n.bit_length())*(1+max(map(len,item),default=0)))
                size+=2+2*n;self.entries(2*n);stack.extend((x,depth+1) for pair in item.items() for x in pair)
            elif kind in (list,tuple):
                size+=2+len(item);self.entries(len(item));stack.extend((x,depth+1) for x in item)
            elif kind in (int,float,bool) or item is None: size+=32
            else: raise ValueError('unsupported normalized JSON')
            check(size<=64*1024*1024,'reference normalized JSON byte cap')
        self.charge('normalized_json_encoding',2*size)
        return sha(canon(value))
    def entries(self,n):
        check(type(n) is int and n>=0 and self.entries_used+n<=8_000_000,'reference logical entry cap')
        self.entries_used+=n
    def reserve(self, sizes):
        sizes=tuple(max(1,n) for n in sizes); largest=max(sizes)
        check(largest<=65536,'reference Fraction width cap')
        check(self.bits+sum(sizes)<=16_000_000_000,'reference cumulative Fraction forecast cap')
        self.charge('fraction');self.bits+=sum(sizes);self.max_bits=max(self.max_bits,largest)
    def snap(self,x):
        if type(x) is float:
            check(isfinite(x),'nonfinite probability');self.reserve((1075,1075));return Fraction.from_float(x)
        check(type(x) is Fraction,'expected Fraction');self.reserve((x.numerator.bit_length(),x.denominator.bit_length()));return x
    def op(self,a,b,kind):
        an,ad=max(1,a.numerator.bit_length()),a.denominator.bit_length()
        bn,bd=max(1,b.numerator.bit_length()),b.denominator.bit_length()
        if kind in ('add','sub'):
            x,y,d=an+bd,bn+ad,ad+bd;self.reserve((x,y,max(x,y)+1,d,max(x,y)+1,d))
            return a+b if kind=='add' else a-b
        if kind=='div': check(b.numerator!=0,'zero denominator')
        n,d=(an+bn,ad+bd) if kind=='mul' else (an+bd,ad+bn)
        self.reserve((n,d,n,d));return a*b if kind=='mul' else a/b
    def compare(self,a,b):
        self.reserve((a.numerator.bit_length()+b.denominator.bit_length(),b.numerator.bit_length()+a.denominator.bit_length()))
        x=a.numerator*b.denominator;y=b.numerator*a.denominator
        return (x>y)-(x<y)
    def text(self,a):
        nb,db=a.numerator.bit_length(),a.denominator.bit_length()
        check(max(nb,db)<=65536,'reference output bit cap')
        chars=2+(nb*30103)//100000+1+(db*30103)//100000+1
        check(self.text_bytes+chars<=64*1024*1024,'reference fraction output byte cap')
        self.text_bytes+=chars
        self.entries(1)
        self.charge('fraction_output_characters',16*chars)
        with localcontext() as ctx:
            ctx.prec=1
            n=format(Decimal(a.numerator),'f')
            result=n if a.denominator==1 else n+'/'+format(Decimal(a.denominator),'f')
        check(len(result)<=chars,'reference fraction text bound')
        return result
    def neg(self,a): self.reserve((a.numerator.bit_length(),a.denominator.bit_length()));return -a
    def add(self,a,b): return self.op(a,b,'add')
    def sub(self,a,b): return self.op(a,b,'sub')
    def mul(self,a,b): return self.op(a,b,'mul')
    def div(self,a,b): return self.op(a,b,'div')

class ScalarReference:
    def __init__(self, model, ranker):
        self.model,self.ranker,self.g=model,ranker,Guard()
        self.hands=tuple(tuple(side) for side in model.ranges)
        self.weights=tuple(tuple(self.g.snap(float(v)) for v in side.values()) for side in model.ranges)
        self.boards=tuple(model.outcomes);self.ranks={};self.support={}
        check(max(map(len,self.hands))<=16 and len(self.boards)<=64 and model.counts['public_nodes']<=250000,'reference shape caps')
        self.g.charge('literal_world_scan',len(self.hands[0])*len(self.hands[1])*len(self.boards))
        z=ZERO;self.world_count=0;reachable=[]
        for board in self.boards:
            before=self.world_count
            for i,a in enumerate(self.hands[0]):
                if set(a)&set(board): continue
                for j,b in enumerate(self.hands[1]):
                    if set(b)&(set(board)|set(a)): continue
                    self.world_count+=1;z=self.g.add(z,self.g.mul(self.weights[0][i],self.weights[1][j]))
            if self.world_count>before: reachable.append(board)
        self.reachable=tuple(reachable)
        check(z.numerator>0,'empty physical game');self.z=z
    def supported(self,hand,player,prefix):
        key=(player,tuple(prefix))
        if key not in self.support:
            side=[];others=self.hands[1-player]
            self.g.entries(len(self.hands[player])+2)
            self.g.charge('literal_support_scan',len(self.boards)*len(self.hands[player])*len(others))
            for own in self.hands[player]:
                found=False
                for board in self.boards:
                    if board[:len(prefix)]!=tuple(prefix) or set(own)&set(board): continue
                    for other in others:
                        if not set(other)&(set(board)|set(own)):
                            found=True;break
                    if found: break
                side.append(found)
            self.support[key]=tuple(side)
        return self.support[key][self.hands[player].index(hand)]
    def rank(self,board,hand):
        key=(board,hand);self.g.charge('rank_lookup')
        if key not in self.ranks:
            check(len(self.ranks)<len(self.boards)*sum(map(len,self.hands)),'rank cache bound')
            self.g.entries(12);self.g.charge('independent_rank',4096);self.ranks[key]=self.ranker(hand+board)
        return self.ranks[key]
    def terminal(self,node,player,own_i,reach):
        g=self.g;own=self.hands[player][own_i];out=ZERO
        g.charge('literal_terminal_scan',len(self.boards)*len(self.hands[1-player]))
        for board in self.boards:
            if board[:len(node.board)]!=node.board or set(own)&set(board): continue
            for j,other in enumerate(self.hands[1-player]):
                if set(other)&(set(board)|set(own)): continue
                if node.winner is not None: sign=1 if node.winner==player else -1
                else:
                    a=self.rank(board,own);b=self.rank(board,other);sign=(a>b)-(a<b)
                if not sign: continue
                mass=g.mul(self.weights[player][own_i], self.weights[1-player][j])
                amount=g.mul(g.mul(g.mul(mass,reach[j]),g.snap(float(node.matched))),g.snap(Fraction(sign)))
                out=g.add(out,amount)
        return g.div(out,self.z)
    def prepare_policy(self,payload,Decision):
        g=self.g;lookup={};normalized=[];expected={}
        check(payload.get('chance_contract')=='exact-product-selected-v1' and
              payload.get('conversion_contract')=='exact-product-vectors-binary64-v1' and
              payload.get('pair_diagnostics')=='compact-exact-product-inputs-v1' and
              payload.get('selected_runouts')==[list(x) for x in self.boards] and
              payload.get('reachable_runouts')==[list(x) for x in self.reachable], 'physical chance contract')
        chance=payload.get('chance_input_snapshot')
        check(type(chance) is dict and chance.get('contract')=='exact-product-selected-v1' and
              type(chance.get('ranges')) is list and len(chance['ranges'])==2,'prior snapshot')
        for rows,side in zip(chance['ranges'],self.model.ranges):
            check(type(rows) is list and len(rows)==len(side),'prior width')
            observed={r['hand']:r['weight_hex'] for r in rows}
            expected_prior={''.join(hand):float(weight).hex() for hand,weight in side.items()}
            check(len(observed)==len(rows) and observed==expected_prior,'prior identities or weights')
        for node in self.model.decisions:
            for hand in self.hands[node.player]:
                if self.supported(hand,node.player,node.board):
                    key=(node.player,''.join(hand),node.history)
                    check(key not in expected,'aliased public information set');g.entries(4);expected[key]=node
        check(len(expected)<=20000 and sum(len(n.actions) for n in expected.values())<=100000,'policy shape cap')
        rows=payload['strategy'];check(type(rows) is list and len(rows)==len(expected) and payload['info_sets']==len(expected),'row count')
        check(payload['worlds']==self.world_count,'physical world count')
        supplied={}
        for row in rows:
            check(type(row) is dict and set(row)=={'player','hand','street','revealed_board','history','actions'} and row['player'] in ('sb','bb'),'row fields')
            key=(0 if row['player']=='sb' else 1,row['hand'],tuple(row['history']))
            check(key not in supplied and key in expected,'invalid policy row identity');g.entries(2);supplied[key]=row
        check(set(supplied)==set(expected),'policy coverage')
        streets={0:'preflop',3:'flop',4:'turn',5:'river'}
        for key in sorted(expected):
            node,row=expected[key],supplied[key]
            g.entries(16+12*len(node.actions))
            check(row['street']==streets[len(node.board)] and row['revealed_board']==list(node.board),'board or street')
            check(len(row['actions'])==len(node.actions),'menu length')
            probs=[]
            for x,a in zip(row['actions'],node.actions):
                check(type(x) is dict and set(x)=={'name','amount','raise_to','history_key','probability'},'action fields')
                check((x['name'],x['history_key'],x['amount'],x['raise_to'])==(a.name,a.token,a.amount,a.raise_to),'menu identity')
                v=x['probability'];check(type(v) in (int,float) and 0<=v<=1,'invalid probability');probs.append(float(v))
            check(abs(fsum(probs)-1)<=1e-10,'policy sum')
            exact=[g.snap(x) for x in probs];total=ZERO
            for x in exact: total=g.add(total,x)
            exact=tuple(g.div(x,total) for x in exact);lookup[key]=exact
            normalized.append({'player':row['player'],'hand':row['hand'],'street':row['street'],
                'revealed_board':row['revealed_board'],'history':row['history'],
                'actions':[{'name':x['name'],'amount':x['amount'],'raise_to':x['raise_to'],
                            'history_key':x['history_key'],'probability_fraction':g.text(p)} for x,p in zip(row['actions'],exact)]})
        return lookup,normalized
    def evaluate(self,payload,Decision,Reveal,Terminal):
        g=self.g;policies,normalized=self.prepare_policy(payload,Decision)
        # Bound all scalar walks before rank or terminal calls. Every own hand
        # gets a full public walk; terminal scans use the full board list.
        normalized_hash=g.hash_json(normalized)
        nodes=edges=terminals=0;stack=[self.model.root]
        while stack:
            node=stack.pop();nodes+=1
            check(nodes<=250000,'reference public census cap')
            if isinstance(node,Terminal): terminals+=1
            elif isinstance(node,Decision): edges+=len(node.children);stack.extend(node.children)
            elif isinstance(node,Reveal): edges+=len(node.branches);stack.extend(node.branches.values())
            else: raise ValueError('unknown census node')
        h0,h1=map(len,self.hands);board_count=len(self.boards)
        forecast=(4096*board_count*(h0+h1)+
                  16*terminals*board_count*3*h0*h1+
                  8*edges*(2*h0+h1)*(1+max(h0,h1))+
                  nodes*(2*h0+h1)+16*10*(2*((65536*30103)//100000+1)+2)+4096)
        check(g.work+forecast<=500_000_000,'reference whole-walk work forecast')
        # Live recursion frames/reach vectors and independent best-five cache.
        # Public graph/policy snapshots are admitted separately by their owners.
        g.entries(64*(4*max(h0,h1)+64)+12*board_count*(h0+h1))
        def walk(node,player,own_i,reach,br,depth):
            g.charge('scalar_public_visit');check(depth<=64,'reference recursion depth')
            if not any(reach): return ZERO
            if isinstance(node,Terminal): return self.terminal(node,player,own_i,reach)
            if isinstance(node,Reveal):
                total=ZERO
                for child in node.branches.values(): total=g.add(total,walk(child,player,own_i,reach,br,depth+1))
                return total
            check(isinstance(node,Decision),'invalid reference node')
            if node.player==player:
                hand=self.hands[player][own_i];key=(player,''.join(hand),node.history)
                if key not in policies: return ZERO
                vals=[walk(child,player,own_i,reach,br,depth+1) for child in node.children]
                if br:
                    best=vals[0]
                    for v in vals[1:]:
                        if g.compare(v,best)>0: best=v
                    return best
                total=ZERO
                for p,v in zip(policies[key],vals):total=g.add(total,g.mul(p,v))
                return total
            total=ZERO
            for index,child in enumerate(node.children):
                next_reach=[]
                for hand,old in zip(self.hands[1-player],reach):
                    key=(1-player,''.join(hand),node.history)
                    p=policies[key][index] if key in policies else ZERO
                    next_reach.append(g.mul(old,p))
                total=g.add(total,walk(child,player,own_i,tuple(next_reach),br,depth+1))
            return total
        def root(player,br):
            total=ZERO;reach=(ONE,)*len(self.hands[1-player])
            for i in range(len(self.hands[player])):
                total=g.add(total,walk(self.model.root,player,i,reach,br,0))
            return total
        value,sb,bb=root(0,False),root(0,True),root(1,True)
        sbgain=g.sub(sb,value);bbgain=g.add(bb,value)
        check(sbgain.numerator>=0 and bbgain.numerator>=0,'negative exact response gain')
        nash=g.add(sbgain,bbgain)
        metrics={'value_sb':value,'value_bb':g.neg(value),'sb_best_response_value':sb,'bb_best_response_value':bb,
                 'sb_best_response_gain':sbgain,'bb_best_response_gain':bbgain,'nash_conv':nash,
                 'exploitability':g.div(nash,Fraction(2)), 'lower_value_bound':g.neg(bb),'upper_value_bound':sb}
        return {'metrics':{k:g.text(v) for k,v in metrics.items()},'threshold':'1/1000',
                'threshold_met':g.compare(nash,Fraction(1,1000))<=0,
                'normalized_policy_rows':normalized,'normalized_policy_sha256':normalized_hash,
                'physical_worlds':self.world_count,'rank_cache_entries':len(self.ranks),
                'work':g.work,'prewalk_work_upper':forecast,'logical_entries':g.entries_used,'fraction_text_bytes_upper':g.text_bytes,'fraction_forecast_bits':g.bits,'max_fraction_forecast_bits':g.max_bits,
                'work_by_kind':dict(g.counts),'retained_worlds':0,'retained_private_pairs':0}


def self_test():
    from dataclasses import dataclass
    @dataclass(frozen=True)
    class Action: name:str; token:str; amount:float; raise_to:float
    @dataclass(frozen=True)
    class Terminal: board:tuple; matched:float; winner:int|None
    @dataclass(frozen=True)
    class Decision: player:int; history:tuple; board:tuple; actions:tuple; children:tuple
    @dataclass(frozen=True)
    class Reveal: branches:dict
    class Model: pass
    m=Model();m.ranges=({('Ac','Ad'):1.0},{('Kc','Kd'):1.0})
    m.outcomes=(('2c','3d','4h','5s','9c'),);m.counts={'public_nodes':3}
    actions=(Action('fold','fold',0.,0.),Action('check','check',0.,0.))
    m.root=Decision(0,(),(),actions,(Terminal((),1.,1),Terminal((),1.,0)));m.decisions=(m.root,)
    row={'player':'sb','hand':'AcAd','street':'preflop','revealed_board':[],'history':[],
         'actions':[{'name':a.name,'history_key':a.token,'amount':a.amount,'raise_to':a.raise_to,'probability':.5} for a in actions]}
    def policy(worlds):
        return {'strategy':[row],'info_sets':1,'worlds':worlds,
                'chance_contract':'exact-product-selected-v1',
                'conversion_contract':'exact-product-vectors-binary64-v1',
                'pair_diagnostics':'compact-exact-product-inputs-v1',
                'selected_runouts':[list(x) for x in m.outcomes],
                'reachable_runouts':[list(x) for x in m.outcomes],
                'chance_input_snapshot':{'contract':'exact-product-selected-v1','ranges':[
                    [{'hand':''.join(h),'weight_hex':float(w).hex()} for h,w in side.items()] for side in m.ranges]}}
    result=ScalarReference(m,lambda cards:(0,)).evaluate(policy(1),Decision,Reveal,Terminal)
    check(result['metrics']['value_sb']=='0' and result['metrics']['nash_conv']=='1' and not result['threshold_met'], 'synthetic scalar profile/BR')
    check(result['retained_worlds']==result['retained_private_pairs']==0,'synthetic no world tables')
    large='9'*5000+'/'+('1'+'0'*4999)
    check(parse_fraction(large)>1,'large decimal rational')
    for invalid in ('1/0','1e3','NaN','١/2','-0','01','1/01','9'*19730):
        try: parse_fraction(invalid)
        except ValueError: pass
        else: raise ValueError('invalid large rational accepted')
    # Opposite winners on two hidden boards: choosing after revelation would
    # give one chip; legal pre-reveal response has zero for either action.
    board1=m.outcomes[0];board2=('2c','3d','4h','5s','Tc');m.outcomes=(board1,board2)
    left=Reveal({board1:Terminal(board1,1.,0),board2:Terminal(board2,1.,1)})
    right=Reveal({board1:Terminal(board1,1.,1),board2:Terminal(board2,1.,0)})
    m.root=Decision(0,(),(),actions,(left,right));m.decisions=(m.root,);m.counts={'public_nodes':7}
    hidden=ScalarReference(m,lambda cards:(0,)).evaluate(policy(2),Decision,Reveal,Terminal)
    check(hidden['metrics']['sb_best_response_value']=='0' and hidden['metrics']['nash_conv']=='0','hidden-board legal response')
    print('synthetic independent scalar sanity: PASS')

def inventory(root):
    check(root.is_dir() and not root.is_symlink(),'ordinary evidence directory required')
    result={}
    for path in root.rglob('*'):
        check(not path.is_symlink(),'symlink evidence rejected')
        if path.is_file():
            check(path.stat().st_size<=256*1024*1024,'artifact size cap')
            result[path.relative_to(root).as_posix()]=path.read_bytes()
    check(sum(map(len,result.values()))<=2*1024*1024*1024,'total artifact cap')
    return result

def write_json(path,value):
    with path.open('xb') as f: f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('repo','old-repo','study','candidate-study','output-dir'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('source-commit','manifest-sha256','report-sha256','source-after-sha256','confirmed-terminal-handle'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--terminal-exit-code',type=int,required=True)
    args=parser.parse_args()
    check(args.terminal_exit_code==0 and args.confirmed_terminal_handle,'confirmed producer terminal required')
    check(re.fullmatch('[0-9a-f]{40}',args.source_commit) is not None,'candidate source commit')
    check(all(re.fullmatch('[0-9a-f]{64}',getattr(args,name)) for name in ('manifest_sha256','report_sha256','source_after_sha256')),'candidate artifact pins')
    repo,oldrepo,study,candidate,out=(getattr(args,name).resolve() for name in ('repo','old_repo','study','candidate_study','output_dir'))
    check(not out.exists() and all(root not in out.parents for root in (repo,oldrepo,study,candidate)),'new external output required')
    out.mkdir(parents=True);stage='authentication';self_hash=digest(Path(__file__))
    try:
        work=Path(__file__).resolve().parents[1]
        auth,authraw=load_external(work/'exact-selected-independent-review.py',AUTH_SHA,'frozen_auth')
        old,oldraw=load_external(work/'native-fold-classes-independent-review-v1'/'review.py',OLD_REVIEW_SHA,'prior_review')
        old.BUILD,old.EXE=OLD_BUILD,OLD_EXE
        oldfiles=old.manifested(study,OLD_MANIFEST,auth.parse)
        check(sha(oldfiles['report.json'])==OLD_REPORT,'original study report pin')
        oldsource=auth.parse(oldfiles['source-before.json'])
        check(oldsource==auth.parse(oldfiles['source-after.json']) and oldsource['commit']==OLD_COMMIT,'original before/after source')
        auth.FROZEN=OLD_COMMIT;oldidentity=auth.source_identity(oldrepo,oldsource)
        oldbuild=auth.parse(oldfiles['build-before.json'])
        check(oldbuild==auth.parse(oldfiles['build-after.json']),'original build snapshot')
        oldbuild_identity=old.build_identity(oldrepo,oldbuild,auth.parse)
        receipt_path=work/'native-fold-classes-independent-review-v1'/'attempt1'/'receipt.json'
        observation_path=work/'native-fold-classes-independent-review-v1'/'process-observation.json'
        oldreceipt=receipt_path.read_bytes();oldobservation=observation_path.read_bytes()
        check(sha(oldreceipt)==OLD_RECEIPT and sha(oldobservation)==OLD_OBSERVATION,'prior reviewer receipt/provenance')
        files=inventory(candidate)
        check(sha(files['manifest.json'])==args.manifest_sha256,'candidate manifest pin')
        manifest=auth.parse(files['manifest.json'])
        check(manifest['version']=='matrix-free-saved-certificate-manifest-v1' and
              manifest['current_source_commit']==args.source_commit and manifest['producer_commit']==OLD_COMMIT,'candidate manifest identity')
        check(set(files)==set(manifest['files'])|{'manifest.json'},'complete candidate artifact inventory')
        for name,pin in manifest['files'].items(): check(sha(files[name])==pin,'candidate artifact hash '+name)
        check(sha(files['report.json'])==args.report_sha256 and sha(files['source-after.json'])==args.source_after_sha256,'candidate report/source-after pins')
        source=auth.parse(files['source-before.json'])
        check(source==auth.parse(files['source-after.json']) and source['commit']==args.source_commit,'candidate clean before/after source')
        auth.FROZEN=args.source_commit;identity=auth.source_identity(repo,source)
        oldreport=auth.parse(oldfiles['report.json']);report=auth.parse(files['report.json'])
        oldmanifest=auth.parse(oldfiles['manifest.json'])
        after=auth.parse(files['producer-artifact-after.json'])
        check(after['stable'] is True and after['manifest_sha256']==OLD_MANIFEST and after['report_sha256']==OLD_REPORT and after['files']==oldmanifest['files'],'old producer artifact after-check')
        protocol=auth.parse(files['protocol.json']);captured=auth.parse(files['capture-time-sha256.json'])
        check(type(captured) is dict and captured and all(name in files and sha(files[name])==pin for name,pin in captured.items()),'capture-time bytes')
        required_captures={'source-before.json','producer-source-before.json','producer-artifact-auth.json','producer-build-identity.json','protocol.json'}
        check(required_captures.issubset(captured),'initial source/build/protocol capture pins')
        check(protocol['current_source_commit']==args.source_commit and protocol['producer_commit']==OLD_COMMIT and
              protocol['current_source_sha256']==source['sha256'] and protocol['producer_source_sha256']==oldsource['sha256'] and
              protocol['producer_manifest_sha256']==OLD_MANIFEST and protocol['producer_report_sha256']==OLD_REPORT and
              protocol['old_review_receipt_sha256']==OLD_RECEIPT,'protocol source provenance')
        check(report['records_planned']==report['records_attempted']==report['records_captured']==28 and
              report['failure'] is None and report['historical_exact_unknowns_retained']==6 and
              report['producer_rejections_not_certified']==6 and not any(report['forbidden_calls'].values()),'candidate report completeness')
        build_saved=auth.parse(files['producer-build-identity.json'])
        check(build_saved['schema']=='frozen-native-build-identity-v1' and build_saved['manifest_sha256']==OLD_BUILD and
              build_saved['executable_sha256']==OLD_EXE and build_saved['source_sha256']==oldbuild_identity['sources'] and
              build_saved['dependency']['headers_sha256']==build_saved['actual_include_headers_sha256']==oldbuild_identity['headers'] and
              build_saved['dependency']['header_count']==198 and build_saved['source_count']==11 and
              build_saved['executable_invoked'] is False,'candidate bound old build identity')
        check(auth.parse(files['producer-build-identity-after.json'])==build_saved,'candidate old build before/after')
        old_before=auth.parse(files['producer-source-before.json']);old_after=auth.parse(files['producer-source-after.json'])
        check(old_before==old_after and old_before['commit']==OLD_COMMIT and old_before['sha256']==oldsource['sha256'] and old_before['status']=='','candidate old source before/after')
        check(oldreport['calls_planned']==oldreport['calls_attempted']==oldreport['calls_captured']==34 and oldreport['failure'] is None,'original attempt inventory')
        expected_labels={old.label(entry) for entry in old.SCHEDULE if old.label(entry)+'.raw.json' in oldfiles and auth.parse(oldfiles[old.label(entry)+'.raw.json'])['status']=='complete'}
        check(len(expected_labels)==28,'original completed policy inventory')
        records=manifest['records']
        check(type(records) is list and len(records)==28 and {item['label'] for item in records}==expected_labels,'candidate record inventory')
        cases=old.cases_from_data(oldrepo,auth.parse)
        decoded={};prior_counts=Counter();candidate_counts=Counter()
        report_rows={row['label']:row for row in report['records']}
        check(len(report_rows)==28,'candidate report row uniqueness')
        for item in records:
            label=item['label'];path=item['record_artifact']
            check(path in captured and sha(files[path])==item['record_sha256']==captured[path],'candidate record digest')
            record=auth.parse(files[path])
            check(record['schema']=='matrix-free-saved-certificate-record-v1' and record['label']==record['producer_label']==label and record['producer_commit']==OLD_COMMIT,'candidate record source identity')
            check(record==report_rows[label] and item['status']==record['status'] and item['previous_exact_status']==record['previous_exact_status'],'manifest/report record binding')
            rawname=label+'.raw.json';priorname=label+'-verification.json'
            check(record['source_raw_artifact']==rawname and record['source_raw_sha256']==sha(oldfiles[rawname]),'original raw identity')
            check(record['old_exact_artifact']==record['old_numeric_artifact']==priorname and
                  record['old_exact_sha256']==record['old_numeric_sha256']==sha(oldfiles[priorname]),'original verifier identity')
            check(record['producer_build_identity_artifact']=='producer-build-identity.json' and
                  record['producer_build_identity_sha256']==sha(files['producer-build-identity.json']),'per-record build identity')
            raw=auth.parse(oldfiles[rawname]);prior=auth.parse(oldfiles[priorname]);payload=raw['payload']
            check(record['payload_sha256']==sha(canon(payload)),'payload canonical digest')
            oldstatus=prior['exact']['status'];check(oldstatus in ('complete','resource-unverified') and record['previous_exact_status']==oldstatus,'historical exact status')
            prior_counts[oldstatus]+=1;candidate_counts[record['status']]+=1
            check(record['status'] in ('complete','resource-unverified'),'candidate status')
            field='result' if record['status']=='complete' else 'error'
            artifact=record[field+'_artifact']
            check(artifact in captured and sha(files[artifact])==record[field+'_sha256']==captured[artifact],'candidate result/error digest')
            numeric_name=record['numeric_replay_artifact']
            check(numeric_name in captured and sha(files[numeric_name])==record['numeric_replay_sha256']==captured[numeric_name], 'fresh numeric replay digest')
            fresh=auth.parse(files[numeric_name]); oldbinding=record['old_numeric_binding']
            check(type(oldbinding) is dict and oldbinding['status']=='complete' and oldbinding['artifact_hash_bound'] is True and
                  oldbinding['metric_gaps']==prior['numeric_metric_gaps'] and oldbinding['tolerance']==1e-10 and
                  oldbinding['checked_information_sets']==payload['info_sets'],'old numeric replay binding')
            check(type(fresh) is dict and fresh['status']=='complete' and fresh['checked_information_sets']==payload['info_sets'] and
                  type(fresh['metrics']) is dict and set(fresh['metrics'])==set(EXACT_NUMERIC.values()) and
                  all(type(v) in (int,float) and isfinite(v) for v in fresh['metrics'].values()),'fresh numeric replay fields')
            candidate_result=auth.parse(files[artifact]) if field=='result' else None
            case=cases[raw['case']]
            check(raw['request_case']==case,'original request case binding '+label)
            if candidate_result is not None:
                check(candidate_result['input_case_canonical_sha256']==sha(canon(case)),
                      'new raw case fingerprint '+label)
                for value in candidate_result['metrics'].values(): parse_fraction(value)
                gaps={k:abs(float(parse_fraction(candidate_result['metrics'][k]))-fresh['metrics'][v]) for k,v in EXACT_NUMERIC.items()}
                check(record['numeric_metric_tolerance']==1e-9 and gaps==record['numeric_metric_gaps'] and
                      all(isfinite(v) and 0<=v<=1e-9 for v in gaps.values()),'fresh numeric replay agreement')
            else:
                error=auth.parse(files[artifact])
                check(type(error) is dict and error.get('type')=='ValueError' and type(error.get('message')) is str and
                      any(pattern.fullmatch(error['message']) for pattern in RESOURCE_PATTERNS), 'unrecognized candidate rejection')
                check(record['numeric_metric_gaps'] is None,'resource rejection cannot claim quality')
            if oldstatus=='complete' and candidate_result is not None:
                wrapper=prior['exact']['result'];literal=wrapper['exact_certificate']
                check(candidate_result['legacy_model_case_canonical_sha256']==literal['input_case_canonical_sha256'],
                      'legacy normalized case fingerprint '+label)
                check(wrapper['compact_input_canonical_sha256']==sha(canon(payload)) and
                      wrapper['verification_expansion_canonical_sha256']==literal['input_policy_canonical_sha256'],
                      'legacy compact/expanded policy fingerprint '+label)
                for k in ('metrics','threshold','threshold_met','normalized_policy_sha256','normalized_policy_rows'):
                    check(candidate_result[k]==literal[k],'pinned literal parity '+label+' '+k)
            check(type(record['certificate_wall_seconds']) in (int,float) and isfinite(record['certificate_wall_seconds']) and record['certificate_wall_seconds']>=0,'certificate duration')
            decoded[label]=(raw,candidate_result,record)
        expected_captures=set(required_captures)
        for label,(_,_,record) in decoded.items():
            expected_captures.add('records/'+label+'-certificate.json')
            expected_captures.add(record['numeric_replay_artifact'])
            expected_captures.add(record['result_artifact'] if record['status']=='complete' else record['error_artifact'])
        check(set(captured)==expected_captures,'complete capture-time record inventory')
        check(prior_counts==Counter({'complete':22,'resource-unverified':6}),'historical exact inventory')
        check(report['candidate_complete']==candidate_counts['complete'] and report['candidate_resource_unverified']==candidate_counts['resource-unverified'], 'candidate status counts')
        check([entry['label'] for entry in report['records']]==[entry['label'] for entry in records],'report record ordering')
        expected_six={f'{name}-t10-{mode}-p0' for name in NAMES for mode in MODES}
        check({label for label,(_,_,record) in decoded.items() if record['previous_exact_status']=='resource-unverified'}==expected_six,'six previously unknown labels')
        # No project math import occurs before both source trees, original build
        # and both complete saved-artifact inventories have been authenticated.
        stage='protected independent literal streaming';sys.dont_write_bytecode=True;sys.path.insert(0,str(repo))
        from scripts.matrix_free_four_street_rules import build_public_model,Decision,Reveal,Terminal
        from scripts.preflop_validation import independent_rank
        forbidden={name:0 for name in old.FORBIDDEN+('scripts.exact_selected_matrix_free_certificate.evaluate_exact',
                    'scripts.matrix_free_selected_payoffs.PayoffModel.__init__',
                    'scripts.matrix_free_selected_payoffs.PayoffModel.terminal',
                    'scripts.matrix_free_selected_payoffs.PayoffModel.prefix_support')}
        def reject(name):
            def blocked(*a,**kw): forbidden[name]+=1;raise AssertionError('forbidden '+name)
            return blocked
        results={}
        with ExitStack() as guards:
            for name in forbidden: guards.enter_context(patch(name,new=reject(name)))
            for label in sorted(expected_six):
                stage='scalar physical reference '+label
                raw,candidate_result,record=decoded[label]
                case=cases[raw['case']]
                check(raw['request_case']==case,'independent case reconstruction '+label)
                ref=ScalarReference(build_public_model(case),independent_rank)
                result=ref.evaluate(raw['payload'],Decision,Reveal,Terminal)
                if candidate_result is not None:
                    for key in ('metrics','threshold','threshold_met','normalized_policy_sha256','normalized_policy_rows'):
                        check(result[key]==candidate_result[key],'independent scalar mismatch '+label+' '+key)
                result['candidate_status']=record['status'];result['case']=raw['case']
                write_json(out/(label+'-scalar.json'),result)
                results[label]={'candidate_status':record['status'],'threshold_met':result['threshold_met'],
                                'nash_conv':result['metrics']['nash_conv'],'work':result['work'],
                                'scalar_sha256':digest(out/(label+'-scalar.json'))}
                print(label,record['status'],result['threshold_met'],flush=True)
        check(not any(forbidden.values()),'forbidden call in saved replay')
        stage='after authentication'
        auth.FROZEN=OLD_COMMIT
        check(auth.source_identity(oldrepo,oldsource)['raw_sha256']==oldidentity['raw_sha256'],'original source drift')
        check(old.build_identity(oldrepo,oldbuild,auth.parse)==oldbuild_identity and old.manifested(study,OLD_MANIFEST,auth.parse)==oldfiles,'original build/artifact drift')
        auth.FROZEN=args.source_commit
        check(auth.source_identity(repo,source)['raw_sha256']==identity['raw_sha256'] and inventory(candidate)==files,'candidate source/artifact drift')
        check(digest(Path(__file__))==self_hash and (work/'exact-selected-independent-review.py').read_bytes()==authraw and (work/'native-fold-classes-independent-review-v1'/'review.py').read_bytes()==oldraw and receipt_path.read_bytes()==oldreceipt and observation_path.read_bytes()==oldobservation,'helper/review provenance drift')
        receipt={'status':'passed','source_commit':args.source_commit,'source_files':identity['files'],
                 'old_commit':OLD_COMMIT,'old_manifest_sha256':OLD_MANIFEST,'candidate_manifest_sha256':args.manifest_sha256,
                 'helper_sha256':self_hash,'confirmed_terminal_handle':args.confirmed_terminal_handle,
                 'terminal_exit_code':0,'previous_exact_statuses':dict(prior_counts),'candidate_statuses':dict(candidate_counts),
                 'independent_six':results,'forbidden_calls':forbidden,'producer_or_candidate_calls':0,
                 'source_build_artifact_helpers_stable':True,
                 'scope':'Independent scalar streamed physical deal/payoff/BR; public legality and independent rank are shared authenticated dependencies. Literal enumeration is verification only. Finite selected boards only; no RSS, speed, full-deck or unrestricted claim.'}
        write_json(out/'receipt.json',receipt);print('passed',digest(out/'receipt.json'),flush=True)
    except BaseException as error:
        write_json(out/'first-failure.json',{'stage':stage,'type':type(error).__name__,'message':str(error),'helper_sha256':self_hash});raise

if __name__=='__main__':
    if sys.argv[1:]==['--self-test']: self_test()
    else: main()
