import sys, importlib.util
from pathlib import Path
from unittest.mock import patch
repo=Path('work/matrix-free-certificate-repo').resolve()
sys.path.insert(0,str(repo))
spec=importlib.util.spec_from_file_location('independent_scalar',Path('work/matrix-free-certificate-independent-review-v1/review.py'))
ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
from tests.test_exact_selected_matrix_free_certificate import _compact, _literal_payload
from tests.test_four_street_certificate import _case
from scripts.four_street_certificate_v3 import evaluate_exact as literal
from scripts.matrix_free_four_street_rules import build_public_model,Decision,Reveal,Terminal
from scripts.preflop_validation import independent_rank
case=_case(sb='AdKs',bb='AhQc',runouts=('2c3c4d7h8h',))
_,payload=_compact(case)
expected=literal(case,_literal_payload(case,payload))
model=build_public_model(case)
with patch('scripts.exact_selected_matrix_free_certificate.evaluate_exact',side_effect=AssertionError('candidate entered')), patch('scripts.matrix_free_selected_payoffs.PayoffModel',side_effect=AssertionError('candidate payoff entered')):
    observed=ref.ScalarReference(model,independent_rank).evaluate(payload,Decision,Reveal,Terminal)
for key in ('metrics','normalized_policy_sha256','normalized_policy_rows','threshold','threshold_met'):
    if observed[key]!=expected[key]: raise AssertionError('literal mismatch: '+key)
print('synthetic real public-rules/literal-v3 exact metric, policy, threshold equality: PASS')
print('streamed worlds:',observed['physical_worlds'],'rank cache:',observed['rank_cache_entries'],'work:',observed['work'])

