"""Independent phase peak payload projection for named paged State layouts."""
from pathlib import Path
import json

def project(rows,value_bits):
    common={'fixed_owner_and_path':16384,'row_directory':36864,
            'borrowed_menu_and_token_views':16*(388+410)}
    arithmetic={'logical_integer_scratch':256*((value_bits+58+63)//64)*8}
    streamed={'resident_pager':591008,'row_overlay':rows,'spill_and_policy_copy':1024,'codec':88}
    phases={'construction':common|arithmetic,'frozen_sweep':common|arithmetic|streamed,
            'streamed_export':common|arithmetic|streamed}
    peak=max(sum(p.values()) for p in phases.values())
    composed=8*peak+1_048_576+8_388_608+4_194_304+5_792
    return {'rows':rows,'value_bits':value_bits,'phases_bytes':phases,'state_bytes':peak,
            'state_bits':8*peak,'composed_bits_before_stream_scratch':composed}

result={'scope':'sealed ordered dual-packed paged directory and shared policy; logical integer/text payload',
        'rank_calls':0,'native_calls':0,'N10':project(119196,644),'N11_projection_only':project(380172,645)}
assert result['N10']['state_bits']==6_398_880
assert result['N10']['composed_bits_before_stream_scratch']==20_036_160
assert result['N11_projection_only']['state_bits']==8_486_688
out=Path.cwd().parent/'dyadic-phase-payload-projection1.json'
with out.open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2,sort_keys=True)
    stream.write('\n')
print(json.dumps({n:result[n]['composed_bits_before_stream_scratch'] for n in ('N10','N11_projection_only')}))