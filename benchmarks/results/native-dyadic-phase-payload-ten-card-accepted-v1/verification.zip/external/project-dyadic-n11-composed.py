"""Rank-free N11 two-sweep work forecast with explicit experimental prerequisites."""
from functools import lru_cache
import json
from pathlib import Path
from scripts.census_virtual_dyadic_storage import supported_prefixes
from tests.full_deck_public_chance_reference import PROOF9, proof_ranges
from tests.virtual_betting_template_reference import build_reference_template
from tests.virtual_frozen_update_reference import _template_case

template=build_reference_template(_template_case())
ranges=proof_ranges()
words=lambda bits:(bits+63)//64
uniform_exp=lambda m:1 if m==2 else 2 if m==4 else 52

@lru_cache(None)
def tail(i):
    node=template.nodes[i]
    return (uniform_exp(len(node.edges)) if node.phase=='decision' else 0)+max(
        (tail(edge.child) for edge in node.edges),default=0)

def cost(m,e,bits,divisions):
    total=e+(m-1).bit_length()+1
    scaled=e+52
    high=max(53,total,scaled)
    return (64+16*m+4*m*(words(bits)+1)+256+16*m*(words(high)+1)
            +8*m*(divisions*words(scaled)*words(total)+4*words(high)+8)
            +4*m*m*(words(total)+1))

def forecast(n,bits,base_bits,divisions):
    deck=tuple(sorted((*PROOF9,*range(n-9))))
    r={(street,p):sum(supported_prefixes(deck,p,hand,street,ranges) for hand,_ in ranges[p])
       for street in (0,3,4,5) for p in (0,1)}
    out=[0,0,0]
    def visit(i,past,first):
        node=template.nodes[i]
        if node.phase=='decision':
            p=node.state.player
            m=len(node.edges)
            rows=r[node.street,p]
            e=first[1-p]+tail(i)
            ea=52*(past[p]+1)
            out[0]+=rows*(320+48*m)
            out[1]+=rows*cost(m,base_bits+2+4+1+e,bits,divisions)
            out[2]+=rows*cost(m,base_bits+2+ea,bits,divisions)
            past=tuple(v+int(j==p) for j,v in enumerate(past))
            first=tuple(v+(uniform_exp(m) if j==p else 0) for j,v in enumerate(first))
        for edge in node.edges:
            visit(edge.child,past,first)
    visit(template.root,(0,0),(0,0))
    return out


from collections import Counter
from hashlib import sha256
from itertools import combinations, permutations
from math import comb

def collect(n,bits,base_bits):
    deck=tuple(sorted((*PROOF9,*range(n-9))))
    occupied=[set(a)|set(b) for a,_ in ranges[0] for b,_ in ranges[1] if set(a).isdisjoint(b)]
    prefixes={k:set() for k in (0,3,4,5)}
    for private in occupied:
        left=set(deck)-private
        for flop in combinations(sorted(left),3):
            for reveal in permutations(sorted(left-set(flop)),2):
                board=flop+reveal
                for k in prefixes:
                    prefixes[k].add(board[:k])
    np={k:len(rows) for k,rows in prefixes.items()}
    supported={(k,p):sum(supported_prefixes(deck,p,hand,k,ranges) for hand,_ in ranges[p])
               for k in np for p in (0,1)}
    shape=Counter()
    value_add=scaled_average=0
    add=lambda width:2+3*words(width)
    cp=lambda width:1+2*words(width)
    mul=lambda a,b:2+2*(words(a)+words(b))+words(a)*words(b)
    candidates=lambda k:comb(n,3) if k==0 else n-k
    visits_order=(0,3,4,5)
    def walk(i,past):
        nonlocal value_add,scaled_average
        node=template.nodes[i]
        k=node.street
        shape['visits']+=np[k]
        if node.phase=='decision':
            m=len(node.edges)
            p=node.state.player
            r=supported[k,p]
            shape['actions']+=np[k]*m
            shape['rows']+=r
            shape['slots']+=r*m
            value_add+=4*np[k]*m*add(bits)
            past_bits=52*past[p]
            row_bits=past_bits+base_bits
            scaled_average+=2*r*(32+mul(past_bits+1,base_bits)+cp(row_bits)+m*(8+mul(row_bits,53)))
            past=tuple(v+int(j==p) for j,v in enumerate(past))
        elif node.phase=='reveal':
            count=np[node.state.board_length]
            shape['reveals']+=count
            shape['candidates']+=np[k]*candidates(k)
            value_add+=8*count*add(bits)
        elif node.phase=='showdown':
            shape['showdowns']+=np[k]
            shape['showdown_contractions']+=np[5]
            if k<5:
                shape['hidden_candidates']+=sum(np[j]*candidates(j) for j in visits_order[visits_order.index(k):-1])
                value_add+=8*np[5]*add(bits)
        elif node.phase=='fold':
            shape['folds']+=np[k]
        else:
            raise ValueError(node.phase)
        for edge in node.edges:
            walk(edge.child,past)
    walk(template.root,(0,0))
    return dict(shape),np,scaled_average,value_add

def project(n,stage,directory):
    d5=comb(n-4,3)*(n-7)*(n-8)
    base=29*d5
    db=base.bit_length()+625
    bits=db+7
    shape,prefixes,scaled_average,value_add=collect(n,bits,base.bit_length())
    r,s=shape['rows'],shape['slots']
    A,G=stage['average_words'],stage['regret_words']
    L=A+G
    assert (stage['rows'],stage['slots'],stage['image_words'])==(r,s,L)
    assert directory['logical_reads']==10*r
    assert stage['logical_read_calls']+stage['direct_write_calls']==11*s
    pwork=(16*11*s+2*(5*A+6*G)+16*L+8*4*s+4*L+160*stage['batched_write_calls']
           +2*(4096+64+1))
    dwork=4*4608+16*r+16*10*r+4*directory['misses']*128
    spill=2*(32*r+16*(s-r)+4*s)+64
    codecA=32*r+36*A+(6*words(bits)+70)*s
    codecG=32*r+44*G+(16*words(bits)+88)*s
    add=lambda width:2+3*words(width)
    copy=lambda width:1+2*words(width)
    mul=lambda a,b:2+2*(words(a)+words(b))+words(a)*words(b)
    parent={'geometry':3_000_000,'visit':32*shape['visits'],
            'support':64*(3*shape['candidates']+2*shape['hidden_candidates']),
            'reach':2*shape['actions']*(24+2*(mul(365,53)+copy(365))),
            'value_add':value_add,
            'terminal_scale':8*(shape['showdowns']+shape['folds'])*(16+mul(bits,4)+mul(bits,6)+copy(bits)),
            'average':scaled_average+4*(shape['reveals']+1)*24+codecA,
            'route':48*r+4*s+codecG+pwork+dwork+spill,
            'output':6*s+24*r+2*(6*s+32*r)+160*1105+65536}
    history=4096*1105+1280+3*(40*shape['actions']+72*shape['reveals']+48*shape['visits']+40*r)-8*r+24*146+16*371+32*r
    registration=64*146+16*371+16*r
    state=(1024+8*r+16*s+4*words(db)+160*r+registration+8*s+2*r
           +2*(88*r+132*s+(16*s+8*r)*words(bits+58))+(4*words(bits)+4)*s+20*r+4*s)
    terms=forecast(n,bits,base.bit_length(),1)
    chance=127793144 if n==10 else 393834463
    components={'template':42556544,'chance':chance,'history':history,'state':state,
                'quantizer':sum(terms),'parent':sum(parent.values())}
    stream=8+16*8+11*8+1105*96+r*24+2*(8*s+4*12*8)+8*s+r+8+64*8
    transport=2*(2*L+64*((8*L+32767)//32768)+32)
    state_payload=8*(16_384+36_864+(410+388)*16+591_008+r+1_024+88+256*words(bits+58)*8)
    return {'deck_cards':n,'d5':d5,'denominator_base':base,'denominator_shift':625,'denominator_bits':db,
            'value_bits':bits,'shape':shape,'supported_prefixes':prefixes,'component_work':components,
            'parent_work':parent,'quantizer_terms':terms,'paging_work':pwork,'directory_work':dwork,
            'retained_numerical_bytes':stream,'wire_bytes':stream+2*(32+8*L),
            'numerical_work':sum(components.values()),'transport_work':transport,
            'composed_work_with_transport':sum(components.values())+transport,
            'state_payload_bits':state_payload,'composed_payload_bits':state_payload+13_637_280}

prior_path=Path('benchmarks/results/native-dyadic-single-division-ten-card-accepted-v1/manifest.json')
prior_raw=prior_path.read_bytes()
prior=json.loads(prior_raw)
n10=project(10,prior['independent_stage_schedule'] if 'independent_stage_schedule' in prior else
    __import__('tests.virtual_dyadic_stage_schedule',fromlist=['stage_schedule']).stage_schedule(ten_card=True,virtual_zero=True),
    prior['row_directory']['independent_trace'])
assert n10['component_work']==prior['admission']['component_work'], (n10['component_work'],prior['admission']['component_work'])
assert n10['parent_work']==prior['admission']['parent_work']
assert n10['quantizer_terms']==prior['admission']['quantizer_terms']
assert n10['wire_bytes']==prior['sweep_capture']['contract']['wire_bytes']
work=Path.cwd().parent
stage_path=work/'dyadic-n11-646-pager-projection.json'
dir_path=work/'dyadic-n11-645-directory-projection.json'
stage=json.loads(stage_path.read_bytes())
directory=json.loads(dir_path.read_bytes())
n11=project(11,stage,directory)
assert (n11['d5'],n11['denominator_bits'],n11['value_bits'])==(420,639,646)
result={'status':'rank_free_projection_only','native_producer_calls':0,'hand_rank_calls':0,
        'n10_combined_manifest_sha256':sha256(prior_raw).hexdigest(),
        'n11_stage_sha256':sha256(stage_path.read_bytes()).hexdigest(),
        'n11_directory_sha256':sha256(dir_path.read_bytes()).hexdigest(),
        'n10_reproduced':n10,'n11_prospective':n11,
        'assumptions':['Current T2 sparse chance and a proposed sorted exact index with 14 modeled units per lookup plus 6944 updates.',
                       'Same two-bank pager and independent geometry schedule. Current caps remain unchanged.',
                       'Phase payload and combined helper ledger extended to the named geometry. No new profile admitted.']}
out=work/'dyadic-n11-composed-projection1.json'
with out.open('x',encoding='utf-8') as f:
    json.dump(result,f,indent=2,sort_keys=True)
    f.write('\n')
print(json.dumps(n11,sort_keys=True))