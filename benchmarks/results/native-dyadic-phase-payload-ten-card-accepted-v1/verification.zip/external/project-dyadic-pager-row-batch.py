"""Independent action-to-row pager batching sensitivity on N10 and N11."""
import json
from pathlib import Path

work=Path.cwd().parent
raw=(work/'project-dyadic-n11-pager.py').read_text(encoding='utf-8')
code=raw.split('if __name__ == "__main__":')[0]
def replace(before,after):
    global code
    assert code.count(before)==1, before
    code=code.replace(before,after)
replace('def stage_schedule(*, ten_card=False, virtual_zero=False, sweeps=2):',
        'def stage_schedule(*, size, batch_rows=False, ten_card=True, virtual_zero=True, sweeps=2):')
replace('deck = tuple(sorted((*PROOF9, 0, 1))) if ten_card else tuple(PROOF9)',
        'deck = tuple(sorted((*PROOF9, *range(size-9))))')
replace('if len(set(deck)) != (11 if ten_card else 9):','if len(set(deck)) != size:')
replace('value_bits = 646 if ten_card else 642','value_bits = {10:644,11:646}[size]')
replace("""    expected = ((380172, 892910, 4188150, 5536052) if ten_card else
                (24420, 58164, 258694, 348036))""",
        "    expected = {10:(119196,281066,1295812,1666910),11:(380172,892910,4188150,5536052)}[size]")
replace("""        for action in range(menu):
            stage(1, average_words + regret_offset + action * regret_stride, regret_stride)
            stage(0, avg_offset + action * avg_stride, avg_stride)""",
        """        actions=((0,menu),) if batch_rows else ((action,1) for action in range(menu))
        for action, extent in actions:
            stage(1, average_words + regret_offset + action * regret_stride, extent*regret_stride)
            stage(0, avg_offset + action * avg_stride, extent*avg_stride)""")
replace('if (stage_calls, flushed_words) != (2 * slots, image_words):',
        'if (stage_calls, flushed_words) != (2 * (rows if batch_rows else slots), image_words):')
replace("""                for action in range(menu):
                    for field in fields:
                        if field == 0:
                            offset, count = avg_offset + action * avg_stride, avg_stride
                        else:
                            offset = average_words + regret_offset + action * regret_stride
                            count = regret_stride""",
        """                actions=((0,menu),) if batch_rows else ((action,1) for action in range(menu))
                for action, extent in actions:
                    for field in fields:
                        if field == 0:
                            offset, count = avg_offset + action * avg_stride, extent*avg_stride
                        else:
                            offset = average_words + regret_offset + action * regret_stride
                            count = extent*regret_stride""")
ns={}
exec(compile(code,'pager_row_batch_oracle','exec'),ns)
schedule=ns['stage_schedule']
accepted=json.loads(Path('benchmarks/results/native-dyadic-single-division-ten-card-accepted-v1/manifest.json').read_bytes())
p=accepted['paging']['counts']
n11=json.loads((work/'dyadic-n11-646-pager-projection.json').read_bytes())
out={}
for size in (10,11):
    old=schedule(size=size)
    new=schedule(size=size,batch_rows=True)
    if size==10:
        assert (old['logical_read_calls'],old['physical_read_words'],old['batched_write_calls'],old['written_words'])==(
            p['read_calls'],p['read_words'],p['physical_write_requests'],p['write_words'])
    else:
        assert old==n11
    for key in ('physical_read_words','logical_read_words','cache_misses','written_words','batched_write_calls'):
        assert old[key]==new[key],(size,key,old[key],new[key])
    r,s=old['rows'],old['slots']
    before=old['logical_read_calls']+old['direct_write_calls']
    after=new['logical_read_calls']+new['direct_write_calls']
    assert (before,after)==(11*s,11*r)
    out[str(size)]={'per_action':old,'per_row':new,'old_logical_requests':before,'new_logical_requests':after,
                    'request_and_stage_bookkeeping_credit_before_new_codec':208*(s-r)}
result={'status':'rank_free_sensitivity_only','native_calls':0,'rank_calls':0,
        'scope':'fully contiguous compact field ranges per row, same per-field order and fixed cache',
        'sizes':out}
dest=work/'dyadic-pager-row-batch-projection1.json'
with dest.open('x',encoding='utf-8') as file:
    json.dump(result,file,indent=2,sort_keys=True)
    file.write('\n')
print(json.dumps({n:{k:v for k,v in record.items() if k not in ('per_action','per_row')} for n,record in out.items()}))