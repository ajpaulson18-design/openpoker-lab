"""Package frozen initial-policy training receipts and verify the saved-byte comparison."""
from hashlib import file_digest, sha256
import io
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / "dyadic-phase-payload-repo"
HEAD = "8536efc9655bc4d6fe8ddb746035248f5102789a"
COHORT = WORK / "dyfirstreg-cohort1"
OPERATOR = WORK / "dyfirstreg-launch1"
CONTROLS = WORK / "dyfirstreg-controls2"
CONTROL_HEAD = "b8fe7d24e5a0bfb5de9ba4124f6d1a82a4b6639d"
RESULT = ROOT / "benchmarks/results/native-dyadic-first-regret-bound-v1"
BASELINE = "benchmarks/results/native-dyadic-initial-policy-v1"
MODE = "ten_first_regret_bound"

sys.path.insert(0, str(ROOT))
from scripts.virtual_dyadic_compact_wire import expand_compact
from scripts.project_virtual_dyadic_eleven import forecast


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    final = read(COHORT / "result.json")
    source = read(COHORT / "source.json")
    hashes = {name: item["raw_sha256"] for name, item in source["files"].items()}
    outer = read(OPERATOR / "completion.json")
    controls = read(CONTROLS / "completion.json")
    require(final["head"] == source["head"] == outer["head"] == HEAD and controls["head"] == CONTROL_HEAD and
            final["training_invocations"] == 1 and read(COHORT / "terminal.json")["status"] == "complete" and
            outer["actual_exit_observed"] and outer["returncode"] == 0 and not outer["failures"] and
            outer["raw_source_stable"] and controls["raw_source_stable"] and
            controls["tests_per_mode"] == 63 and controls["skips"] == 0 and
            all(read(OPERATOR / ("source-" + phase + ".json")) == hashes for phase in ("before", "after")) and
            read(CONTROLS / "source-before.json") == read(CONTROLS / "source-after.json"),
            "frozen execution, control or source identity differs")
    launcher = WORK / "trusted-virtual-dyadic-training-launch-v36.py"
    require(read(OPERATOR / "operator-launch.json")["operator_sha256"] == digest(launcher),
            "outer launcher identity differs")
    for boot_path in (OPERATOR / "bootstrap.json", COHORT / "saved-review-bootstrap.json"):
        boot = read(boot_path)
        require(boot["initial_cache_scan"]["project_bytecode_files"] ==
                boot["final_cache_scan"]["project_bytecode_files"] == 0 and
                all(hashes[name] == value for name, value in boot["compiled"].items()),
                "source-only closure identity differs")
    for child in ("admit_" + MODE, "train_" + MODE, "saved-review"):
        process = read(COHORT / child / "process.json")
        require(process["actual_exit_observed"] and process["returncode"] == 0 and
                not process["failures"] and process["automatic_retries"] == 0,
                "child exit or retry count differs")
    build_path = COHORT / "build/native-exact-build-manifest.json"
    build = read(build_path)
    require(digest(Path(build["executable"])) == build["executable_sha256"] and
            all(hashes[name] == value for name, value in build["source_sha256"].items()),
            "native build differs")
    links = {}
    for name in ("manifest.json", "verification.zip"):
        path = ROOT / BASELINE / name
        links[name] = digest(path)
        require(links[name] == hashes[BASELINE + "/" + name], "snapshot baseline identity differs")
    prior = read(ROOT / BASELINE / "manifest.json")
    require(prior["archive"]["sha256"] == links["verification.zip"], "snapshot archive hash differs")
    with ZipFile(ROOT / BASELINE / "verification.zip") as archive:
        prior_replay = json.loads(archive.read("cohort/saved-review/stdout.bin"))
        prior_result = json.loads(archive.read("cohort/result.json"))
        prior_compact = archive.read("cohort/train_ten_zero_policy_bootstrap/stdout.bin")
        prior_paging = json.loads(archive.read("cohort/page-images/paging.json"))
    capture = final["compact_sweep_capture"]
    require(capture["frames"] == prior["compact_sweep_capture"]["frames"] and
            sha256(prior_compact).hexdigest() == prior["compact_sweep_capture"]["retained_sha256"] and
            final["row_directory"] == prior_result["row_directory"] and
            final["policy_spill"] == prior_result["policy_spill"] and
            final["factored_execution"] == prior_result["factored_execution"], "exact checkpoint or I/O identity differs")
    with io.BytesIO() as writer:
        expand_compact(io.BytesIO(prior_compact), writer, source_size=len(prior_compact))
        previous = writer.getvalue()
    expanded = (COHORT / ("train_" + MODE) / "expanded.bin").read_bytes()
    replay = final["saved_only_replay"]
    require(sha256(previous).hexdigest() == prior_replay["saved_output_sha256"] and
            sha256(expanded).hexdigest() == replay["saved_output_sha256"] and
            replay["status"] == "saved_two_sweep_exact_replay_pass" and replay["native_producer_calls"] == 0,
            "expanded replay identity differs")
    forecast_name = "benchmarks/results/native-dyadic-eleven-card-forecast-v1/forecast.json"
    forecast_path = WORK / "dyfirstreg-src1" / forecast_name
    require(digest(forecast_path) == hashes[forecast_name], "eleven-card forecast identity differs")
    model = "scripts/project_virtual_dyadic_eleven.py"
    require(digest(WORK / "dyfirstreg-src1" / model) == hashes[model],
            "eleven-card forecasting code differs")
    require((ROOT / model).read_bytes().replace(b"\r\n", b"\n") ==
            (WORK / "dyfirstreg-src1" / model).read_bytes().replace(b"\r\n", b"\n"),
            "executed model differs from the frozen source")
    eleven = read(forecast_path)["n11_prospective"]
    terms = forecast(11, 646, 14, 1, first_regret_bound=True)
    prior_eleven = prior["eleven_card_projection"]
    projected = {
        "scope": "rank-free eleven-card projection, zero training and hand-ranking calls",
        "quantizer_terms": terms, "quantizer_work": sum(terms), "quantizer_cap": 520_000_000,
        "quantizer_work_removed": prior_eleven["quantizer_work"]-sum(terms),
        "state_work": prior_eleven["state_work"], "state_cap": 300_000_000,
    }
    expected = bytearray(previous)
    at = -480
    require(int.from_bytes(previous[at:at+8], "little") == prior_replay["work_plan"]["quantizer"],
            "quantizer forecast offset differs")
    expected[at:at+8] = replay["work_plan"]["quantizer"].to_bytes(8, "little")
    require(expanded == expected and replay["work_actual"] == prior_replay["work_actual"] and
            replay["profile_and_br"] == prior_replay["profile_and_br"] and
            sum(terms) == 1_014_146_272 and eleven["shape"]["rows"] == 380_172,
            "saved numerical output or projection differs")
    counts = prior_paging
    require(final["paging"]["counts"] == counts, "pager counts differ")
    native = read(COHORT / ("train_" + MODE) / "process.json")
    files = {
        "operator/packager.py": Path(__file__), "operator/launcher.py": launcher,
        "controls/runner.py": WORK / "check-dyadic-first-regret-controls2.py",
        "earlier-control/stderr.log": WORK / "dyfirstreg-controls1/normal/stderr.log",
        "earlier-control/exit.json": WORK / "dyfirstreg-controls1/normal/exit.json",
    }
    for control in ("virtual-dyadic-state-controls", "dyadic-policy-controls"):
        build_number = 1 if control == "virtual-dyadic-state-controls" else 2
        relative = f"dyfirstreg-controls-build{build_number}/{control}"
        path = WORK / relative / "native-exact-build-manifest.json"
        require(digest(path) == controls["builds"][relative]["manifest_sha256"], "control build identity differs")
        files[f"controls/builds/{control}.json"] = path
    for prefix, folder in (("operator", OPERATOR), ("cohort", COHORT), ("controls", CONTROLS)):
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(folder)
            if prefix == "cohort" and (relative.parts[0] == "source" or
                    relative.parts[0] == "build" and path != build_path or
                    path.name in ("committed.bin", "staged.bin", "expanded.bin")):
                continue
            files[f"{prefix}/{relative.as_posix()}"] = path
    inventory = {name: {"bytes": path.stat().st_size, "sha256": digest(path)} for name, path in files.items()}
    RESULT.mkdir()
    archive_path = RESULT / "verification.zip"
    with ZipFile(archive_path, "x", ZIP_DEFLATED) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, name)
        archive.writestr("inventory.json", json.dumps(inventory, indent=2, sort_keys=True))
    with ZipFile(archive_path) as archive:
        require(archive.testzip() is None, "archive failed integrity check")
        for name, meta in inventory.items():
            with archive.open(name) as stream:
                require(archive.getinfo(name).file_size == meta["bytes"] and
                        file_digest(stream, "sha256").hexdigest() == meta["sha256"], "archive member differs")
    manifest = {
        "version": RESULT.name, "source_head": HEAD, "control_source_head": CONTROL_HEAD, "source_files": len(hashes),
        "prior_manifest_sha256": links["manifest.json"], "training_invocations": 1,
        "admission": final["admission"], "focused_controls_per_mode": controls["tests_per_mode"],
        "native_seconds": native["duration_seconds"], "quality_gate": final["quality_gate"],
        "paging_before": prior_paging, "paging_after": counts, "compact_sweep_capture": capture,
        "saved_only_replay": replay, "changed_footer_words": 1,
        "work_before": prior_replay["work_plan"], "work_after": replay["work_plan"],
        "actual_work_before": prior_replay["work_actual"], "actual_work_after": replay["work_actual"],
        "composed_work_before": prior["admission"]["factored_composed_work"],
        "composed_work_after": final["admission"]["factored_composed_work"],
        "eleven_card_projection": projected,
        "archive": {"path": archive_path.name, "bytes": archive_path.stat().st_size,
                    "sha256": digest(archive_path), "members": len(inventory)+1},
    }
    (RESULT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps(manifest["archive"], sort_keys=True))


if __name__ == "__main__":
    main()

