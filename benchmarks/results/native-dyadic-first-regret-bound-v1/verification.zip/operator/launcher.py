"""External stdlib trust anchor; observe one committed T2 cohort's outer exit."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading


def save(path,value):
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2);f.write('\n')


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def git(repo,*args):
    return subprocess.check_output(['git','-c','core.fsmonitor=false',*args],cwd=repo)


def snapshot(repo):
    if git(repo,'status','--porcelain=v1','--untracked-files=all'):
        raise RuntimeError('operator requires clean frozen source')
    names=[x.decode() for x in git(repo,'ls-files','-z').split(b'\0') if x]
    if not 1<=len(names)<=4096:raise RuntimeError('operator source path allowance')
    result={};total=0
    for name in names:
        path=repo/name
        if path.is_symlink():raise RuntimeError('operator linked source')
        size=path.stat().st_size;total+=size
        if size>64<<20 or total>1<<30:raise RuntimeError('operator source byte allowance')
        result[name]=sha(path)
    return result


def observe(command,repo,out):
    save(out/'command.json',command)
    process=subprocess.Popen(command,cwd=repo,stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
    failures=[]
    def stop():
        if process.poll() is None:process.kill()
    def drain(pipe,path):
        remaining=2<<20
        try:
            with path.open('xb') as f:
                while True:
                    block=pipe.read(65536)
                    if not block:break
                    saved=block[:remaining];f.write(saved);remaining-=len(saved)
                    if len(saved)!=len(block):failures.append('outer stream bound');stop();break
        except BaseException as error:
            failures.append(type(error).__name__);stop()
        finally:pipe.close()
    threads=[threading.Thread(target=drain,args=(process.stdout,out/'stdout.log')),
             threading.Thread(target=drain,args=(process.stderr,out/'stderr.log'))]
    for thread in threads:thread.start()
    try:code=process.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        failures.append('outer timeout');stop();code=process.wait()
    finally:
        stop()
        for thread in threads:thread.join()
    receipt={'actual_exit_observed':process.poll() is not None,'returncode':code,'failures':failures}
    save(out/'exit.json',receipt)
    if code or failures:raise RuntimeError('outer dyadic cohort failed; preserve first attempt')
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['repo','out','cohort']:parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--head',required=True)
    parser.add_argument('--train',action='store_true')
    parser.add_argument('--paired',action='store_true')
    parser.add_argument('--packed-averages',action='store_true')
    parser.add_argument('--compact-strategy',action='store_true')
    parser.add_argument('--scaled-averages',action='store_true')
    parser.add_argument('--sealed-menus',action='store_true')
    parser.add_argument('--paged-strategy',action='store_true')
    parser.add_argument('--compact-directory',action='store_true')
    parser.add_argument('--rank-sets',action='store_true')
    parser.add_argument('--split-checkpoint',action='store_true')
    parser.add_argument('--ten-card',action='store_true')
    parser.add_argument('--ten-buffered',action='store_true')
    parser.add_argument('--ten-virtual-zero',action='store_true')
    parser.add_argument('--ten-ordered-state',action='store_true')
    parser.add_argument('--ten-row-coverage',action='store_true')
    parser.add_argument('--ten-shared-policy',action='store_true')
    parser.add_argument('--ten-paged-directory',action='store_true')
    parser.add_argument('--ten-sweep-stream',action='store_true')
    parser.add_argument('--ten-sparse-chance',action='store_true')
    parser.add_argument('--ten-single-division',action='store_true')
    parser.add_argument('--ten-phase-payload',action='store_true')
    parser.add_argument('--ten-row-batched',action='store_true')
    parser.add_argument('--ten-indexed-cache',action='store_true')
    parser.add_argument('--ten-complement',action='store_true')
    parser.add_argument('--ten-compact-wire',action='store_true')
    parser.add_argument('--ten-factored',action='store_true')
    parser.add_argument('--ten-checked-history',action='store_true')
    parser.add_argument('--ten-history-visit',action='store_true')
    parser.add_argument('--ten-equal-quantizer',action='store_true')
    parser.add_argument('--ten-reuse-snapshot',action='store_true')
    parser.add_argument('--ten-zero-policy-bootstrap',action='store_true')
    parser.add_argument('--ten-first-regret-bound',action='store_true')
    parser.add_argument('--proof9-t3',action='store_true')
    parser.add_argument('--proof9-t4',action='store_true')
    parser.add_argument('--proof9-quality32',action='store_true')
    parser.add_argument('--proof9-linear32',action='store_true')
    args=parser.parse_args()
    modes=(args.paired,args.packed_averages,args.compact_strategy,args.scaled_averages,args.sealed_menus,args.paged_strategy,args.compact_directory,args.rank_sets,args.split_checkpoint,args.ten_card,args.ten_buffered,args.ten_virtual_zero,args.ten_ordered_state,args.ten_row_coverage,args.ten_shared_policy,args.ten_paged_directory,args.ten_sweep_stream,args.ten_sparse_chance,args.ten_single_division,args.ten_phase_payload,args.ten_row_batched,args.ten_indexed_cache,args.ten_complement,args.ten_compact_wire,args.ten_factored,args.ten_checked_history,args.ten_history_visit,args.ten_equal_quantizer,args.ten_reuse_snapshot,args.ten_zero_policy_bootstrap,args.ten_first_regret_bound,args.proof9_t3,args.proof9_t4,args.proof9_quality32,args.proof9_linear32)
    if sum(modes)>1:
        parser.error('choose one strategy profile')
    suffix=next((name for flag,name in zip(modes,('_paired','_packed','_compact','_scaled','_sealed','_paged','_directory','_rank_sets','_split','_ten','_ten_buffered','_ten_virtual_zero','_ten_ordered_state','_ten_row_coverage','_ten_shared_policy','_ten_paged_directory','_ten_sweep_stream','_ten_sparse_chance','_ten_single_division','_ten_phase_payload','_ten_row_batched','_ten_indexed_cache','_ten_complement','_ten_compact_wire','_ten_factored','_ten_checked_history','_ten_history_visit','_ten_equal_quantizer','_ten_reuse_snapshot','_ten_zero_policy_bootstrap','_ten_first_regret_bound','_proof9_t3','_proof9_t4','_proof9_q32','_proof9_linear32')) if flag),'')
    mode=('train' if args.train else 'admit')+suffix
    repo=args.repo.resolve(strict=True);out=args.out.resolve();cohort=args.cohort.resolve()
    if out.is_relative_to(repo) or cohort.is_relative_to(repo) or out==cohort:
        raise RuntimeError('operator and cohort evidence must be distinct and external')
    if git(repo,'rev-parse','HEAD').decode().strip()!=args.head:raise RuntimeError('operator HEAD differs')
    out.mkdir(exist_ok=False)
    before=snapshot(repo);save(out/'source-before.json',before)
    name='scripts/run_virtual_frozen_source_only.py';bootstrap=repo/name;raw=bootstrap.read_bytes()
    committed=git(repo,'show',args.head+':'+name)
    if raw!=committed and raw.replace(b'\r\n',b'\n')!=committed:raise RuntimeError('trusted bootstrap committed byte drift')
    stages=[ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign) and
            any(isinstance(t,ast.Name) and t.id=='FIRST_STAGE' for t in n.targets)]
    if len(stages)!=1 or type(stages[0]) is not str:raise RuntimeError('trusted first-stage literal')
    stage=stages[0];digest=hashlib.sha256(raw).hexdigest();receipt_path=out/'bootstrap.json'
    save(out/'operator-launch.json',{'head':args.head,'mode':mode,
        'operator_sha256':sha(Path(__file__)),'bootstrap_sha256':digest,'first_stage':stage,
        'first_stage_sha256':hashlib.sha256(stage.encode()).hexdigest()})
    command=[sys.executable,'-I','-S','-B','-c',stage,str(bootstrap),digest,
             '--module','scripts.run_virtual_dyadic_training_cohort','--receipt',str(receipt_path),'--',
             '--output',str(cohort),'--expected-head',args.head]
    if args.train:command.append('--train')
    if args.paired:command.append('--paired')
    if args.packed_averages:command.append('--packed-averages')
    if args.compact_strategy:command.append('--compact-strategy')
    if args.scaled_averages:command.append('--scaled-averages')
    if args.sealed_menus:command.append('--sealed-menus')
    if args.paged_strategy:command.append('--paged-strategy')
    if args.compact_directory:command.append('--compact-directory')
    if args.rank_sets:command.append('--rank-sets')
    if args.split_checkpoint:command.append('--split-checkpoint')
    if args.ten_card:command.append('--ten-card')
    if args.ten_buffered:command.append('--ten-buffered')
    if args.ten_virtual_zero:command.append('--ten-virtual-zero')
    if args.ten_ordered_state:command.append('--ten-ordered-state')
    if args.ten_row_coverage:command.append('--ten-row-coverage')
    if args.ten_shared_policy:command.append('--ten-shared-policy')
    if args.ten_paged_directory:command.append('--ten-paged-directory')
    if args.ten_sweep_stream:command.append('--ten-sweep-stream')
    if args.ten_sparse_chance:command.append('--ten-sparse-chance')
    if args.ten_single_division:command.append('--ten-single-division')
    if args.ten_phase_payload:command.append('--ten-phase-payload')
    if args.ten_row_batched:command.append('--ten-row-batched')
    if args.ten_indexed_cache:command.append('--ten-indexed-cache')
    if args.ten_complement:command.append('--ten-complement')
    if args.ten_compact_wire:command.append('--ten-compact-wire')
    if args.ten_factored:command.append('--ten-factored')
    if args.ten_checked_history:command.append('--ten-checked-history')
    if args.ten_history_visit:command.append('--ten-history-visit')
    if args.ten_equal_quantizer:command.append('--ten-equal-quantizer')
    if args.ten_reuse_snapshot:command.append('--ten-reuse-snapshot')
    if args.ten_zero_policy_bootstrap:command.append('--ten-zero-policy-bootstrap')
    if args.ten_first_regret_bound:command.append('--ten-first-regret-bound')
    if args.proof9_t3:command.append('--proof9-t3')
    if args.proof9_t4:command.append('--proof9-t4')
    if args.proof9_quality32:command.append('--proof9-quality32')
    if args.proof9_linear32:command.append('--proof9-linear32')
    receipt=observe(command,repo,out)
    if receipt_path.stat().st_size>1<<20:raise RuntimeError('outer bootstrap byte allowance')
    boot=json.loads(receipt_path.read_bytes())
    if (boot['entry_module']!='scripts.run_virtual_dyadic_training_cohort' or
            boot['trusted_first_stage']['bootstrap_sha256']!=digest or
            boot['trusted_first_stage']['command_sha256']!=hashlib.sha256(stage.encode()).hexdigest() or
            boot['initial_cache_scan']['project_bytecode_files'] or boot['final_cache_scan']['project_bytecode_files']):
        raise RuntimeError('outer final bootstrap identity differs')
    for filename,identity in boot['compiled'].items():
        if before.get(filename)!=identity:raise RuntimeError('outer compiled source bytes differ')
    after=snapshot(repo)
    if after!=before:raise RuntimeError('outer raw source changed')
    save(out/'source-after.json',after)
    result={'head':args.head,'mode':mode,**receipt,
            'compiled_project_sources':len(boot['compiled']),'raw_source_stable':True}
    save(out/'completion.json',result)
    print(json.dumps(result))


if __name__=='__main__':main()
