# Paged directory engineering review

Source freeze: 56a27a2262012d775d2cb524c8e93cf8a616534b.

Sol reviewed the native directory, fused descriptor reads, immutable snapshot
lifetime, tag/completion byte overlay, failure propagation and resource equations.
No blocking native issue remained. The frozen schedule is prelude R plus two
times (begin R + profile R + preorder policy R + postorder stage R) plus export R,
or 10R directory gets. Registration has a separate R last-append snapshot bound.

Terra independently reconstructed the physical-support traversal and cache trace.
Its N10 prediction is 1,191,960 gets, 1,184,304 hits, 7,656 misses, 979,168 rows
read and 31,333,376 read bytes. Buffered append writes 119,196 rows in 932 calls.
The independent wire verifier reconstructs all row keys, scales and consecutive
packed offsets, and checks a bijection between native and reference menu sources.
Its checks run before and after saved-only replay.

Luna implemented native parity and failure controls: exact two-sweep shared-policy
comparison, caller-owned policy snapshots, streamed export, a 129-row short final
page, page-read cap exhaustion, truncated directory read and invalid bounds before
directory creation. Root reviewed and ran the compiled controls successfully.

Sol's Python review found an unbounded receipt read before parsing. Root added
a private regular-file and 65,536-byte size check, plus a control proving an
oversized receipt is rejected before reading. Source tests pass normally and
optimized: 14 trainer/admission, 7 native State and 4 independent wire tests.

The directory work forecast replaces 11,442,816 with 24,916,800 modeled units.
Removing the obsolete registration lookup allowance saves 28,607,040 State units,
giving a net forecast reduction of 15,133,056. Composed entries fall by 471,984
to 360,303, including 192 extra snapshot frame entries. These are modeled units,
separate from measured process memory and runtime.

Scope remains the explicit ten-card two-sweep profile. Longer recurrence,
convergence quality and larger-game admission remain open. Current policy
receipts, image epochs and replay contain fixed-two-sweep assumptions; changing
the sweep constant alone is not an accepted generalization.
