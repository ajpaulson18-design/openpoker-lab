"""Separate Windows native-child working-set observations; no timing benchmark."""
import base64
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading

WORK = Path(__file__).resolve().parent
REPO = WORK / 'native-indexed-ci-repo'
STUDY = WORK / 'native-indexed-study-v2'
OUT = WORK / 'native-indexed-process-memory-v1'
FROZEN = '322cb53158969a89a1dfaee477c8118033aa7a47'
EXECUTABLE = WORK / 'native-indexed-engine-corrected-build-v2/native-exact-four-street-train.exe'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def need(value, message):
    if not value:
        raise ValueError(message)

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

class Counters(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD),
        ('PeakWorkingSetSize', ctypes.c_size_t), ('WorkingSetSize', ctypes.c_size_t),
        ('QuotaPeakPagedPoolUsage', ctypes.c_size_t), ('QuotaPagedPoolUsage', ctypes.c_size_t),
        ('QuotaPeakNonPagedPoolUsage', ctypes.c_size_t), ('QuotaNonPagedPoolUsage', ctypes.c_size_t),
        ('PagefileUsage', ctypes.c_size_t), ('PeakPagefileUsage', ctypes.c_size_t),
        ('PrivateUsage', ctypes.c_size_t)]

def main():
    need(os.name == 'nt', 'This probe requires Windows native process counters')
    OUT.mkdir(exist_ok=False)
    (OUT / 'probe-helper.py').write_bytes(Path(__file__).read_bytes())
    auth_path = WORK / 'exact-selected-independent-review.py'
    need(sha(auth_path.read_bytes()) == '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5', 'Source auth helper drift')
    namespace = {'__name__': 'memory_source_auth', '__file__': str(auth_path)}
    exec(compile(auth_path.read_bytes(), str(auth_path), 'exec'), namespace)
    namespace['FROZEN'] = FROZEN
    source = json.loads((STUDY / 'source-before.json').read_bytes())
    authenticated = namespace['source_identity'](REPO, source)
    write(OUT / 'source-authentication.json', authenticated)
    manifest_raw = (STUDY / 'manifest.json').read_bytes()
    need(sha(manifest_raw) == '9c695cf6b07e0b895bf04c58cc804ae0e2a0ced8bf86ad3ab27f9222481d1275', 'Study manifest drift')
    manifest = json.loads(manifest_raw)
    for name, expected in manifest['sha256'].items():
        need(sha((STUDY / name).read_bytes()) == expected, 'Study byte drift: ' + name)
    expected_exe = '89a52e596f39d328b1f39e46ddcd29236ee321ff9da25cae1c292beedc3efec8'
    need(sha(EXECUTABLE.read_bytes()) == expected_exe, 'Native executable drift')
    get_memory = ctypes.WinDLL('psapi', use_last_error=True).GetProcessMemoryInfo
    get_memory.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    get_memory.restype = wintypes.BOOL
    schedule = [(case, route) for case in ('original-22-t10', 'mixed-stabilizer')
        for route in ('full-history', 'indexed')]
    write(OUT / 'protocol.json', {'source_commit': FROZEN, 'schedule': schedule,
        'executable_sha256': expected_exe, 'study_manifest_sha256': sha(manifest_raw),
        'scope': 'Four separate fresh native processes. Poll Windows process working-set/commit counters during lifetime; process peak working set is OS-reported high-water through last successful query, sampled private commit is not a peak guarantee. Excludes Python/API and system total; not native heap/RSS equivalence or a timing benchmark. No inference of memory reduction.'})
    observations = []
    for case, route in schedule:
        label = case + '-' + route + '-0'
        saved = json.loads((STUDY / (label + '.stdout.bin')).read_bytes())
        stream = saved['native_streams'][0]
        request, expected_stdout = (base64.b64decode(stream[name], validate=True) for name in ('request', 'stdout'))
        completed = threading.Event()
        captured = {}
        process = subprocess.Popen([str(EXECUTABLE)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        def communicate():
            try:
                captured['stdout'], captured['stderr'] = process.communicate(request, timeout=30)
            except BaseException as error:
                captured['error'] = str(error)
                process.kill()
                captured['stdout'], captured['stderr'] = process.communicate()
            finally:
                completed.set()
        worker = threading.Thread(target=communicate)
        worker.start()
        samples = []
        failed_queries = []
        while True:
            counters = Counters()
            counters.cb = ctypes.sizeof(counters)
            if get_memory(wintypes.HANDLE(int(process._handle)), ctypes.byref(counters), counters.cb):
                samples.append({'peak_working_set_bytes': counters.PeakWorkingSetSize,
                    'working_set_bytes': counters.WorkingSetSize,
                    'sampled_private_commit_bytes': counters.PrivateUsage,
                    'peak_pagefile_bytes': counters.PeakPagefileUsage})
            else:
                failed_queries.append(ctypes.get_last_error())
            if completed.wait(.001):
                break
        worker.join()
        (OUT / (label + '.stdout')).write_bytes(captured.get('stdout', b''))
        (OUT / (label + '.stderr')).write_bytes(captured.get('stderr', b''))
        write(OUT / (label + '.queries.json'), {'successful': samples, 'failed_query_codes': failed_queries})
        need(process.returncode == 0 and not captured.get('error') and not captured.get('stderr') and
            captured['stdout'] == expected_stdout, 'Native memory probe output differs: ' + label)
        need(samples and max(s['peak_working_set_bytes'] for s in samples) > 0, 'No meaningful memory counter observed')
        observations.append({'sample': label, 'query_count': len(samples), 'failed_query_count': len(failed_queries),
            'max_os_reported_peak_working_set_bytes': max(s['peak_working_set_bytes'] for s in samples),
            'max_sampled_private_commit_bytes': max(s['sampled_private_commit_bytes'] for s in samples),
            'max_os_reported_peak_pagefile_bytes': max(s['peak_pagefile_bytes'] for s in samples),
            'stdout_sha256': sha(captured['stdout']), 'frozen_stdout_identical': True, 'returncode': process.returncode})
    namespace['source_identity'](REPO, source)
    need(sha(EXECUTABLE.read_bytes()) == expected_exe, 'Native executable changed after probe')
    write(OUT / 'receipt.json', {'status': 'passed', 'source_commit': FROZEN, 'native_calls': 4,
        'observations': observations, 'scope': 'Separate Windows native-child OS counters only; no total-solve/heap or memory-reduction claim. All stdout matches frozen corrected-source study.'})
    write(OUT / 'manifest.json', {'sha256': {p.name: sha(p.read_bytes()) for p in sorted(OUT.iterdir()) if p.is_file()}})
    print(json.dumps(observations), flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.is_dir():
            write(OUT / 'first-failure.json', {'type': type(error).__name__, 'message': str(error)})
        raise
