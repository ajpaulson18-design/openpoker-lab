from pathlib import Path
import hashlib,difflib,json
repo=Path('native');out=Path('../native-indexed-instrumentation-v1');out.mkdir(exist_ok=False)
pins={'exact_selected_cfr.hpp':'814af20d4b43aa78b768f47309955a2c4a9936cd7a2e1910e24ec8a19059006d','exact_public_graph.hpp':'7346474312aef7d1f3519cd05acb26bd581a97cb5c97e161f3847e0b583bbc33','exact_public_history_index.hpp':'ba7a73ea7e4b78fc74f1d5a6172b0415dd9d9dc27e2f7d6d705c8d07d30c3ed5','exact_indexed_routing.hpp':'75e3bd7c37df52e40c5d553d29e32042edc9cf750d121a9ce78c1eec062df6ee'}
names=[*pins,'exact_selected_kernel.hpp','exact_binary64.hpp'];before={}
for name in names:
 raw=(repo/name).read_bytes();h=hashlib.sha256(raw).hexdigest();before[name]=h
 if name in pins and h!=pins[name]:raise ValueError('source pin mismatch '+name)
 (out/name).write_bytes(raw)
def replace(name,needle,repl):
 p=out/name;s=p.read_text(encoding='utf8');n=s.count(needle)
 if n!=1:raise ValueError(f'anchor {name}: {n} {needle!r}')
 p.write_text(s.replace(needle,repl),encoding='utf8',newline='\n')
g='exact_public_graph.hpp';c='exact_selected_cfr.hpp'
replace(g,'namespace openpoker::exact_public_graph {','namespace openpoker::exact_public_graph {\ninline bool terra_learning=false; inline unsigned long long terra_calls[5]={};')
replace(g,'inline std::vector<Card> revealed_cards(std::span<const std::string> history) {','inline std::vector<Card> revealed_cards(std::span<const std::string> history) {\n    if(terra_learning) ++terra_calls[3];')
replace(g,'std::span<const std::string> history) const {\n        validate_query_history(history);\n        const auto prefix = detail::revealed_cards(history);','std::span<const std::string> history) const {\n        if(terra_learning) ++terra_calls[2];\n        validate_query_history(history);\n        const auto prefix = detail::revealed_cards(history);')
replace(g,'static History extend_history(const History& history, const Action& action) {','static History extend_history(const History& history, const Action& action) {\n        if(terra_learning) ++terra_calls[0];')
replace(g,'std::string_view label) {\n        History result = history;','std::string_view label) {\n        if(terra_learning) ++terra_calls[0];\n        History result = history;')
replace(g,'std::span<const Action> menu) const {\n        validate_query_history(history);','std::span<const Action> menu) const {\n        if(terra_learning) ++terra_calls[1];\n        validate_query_history(history);')
replace(g,'inline History Plan::transform_history(std::span<const std::string> history, const SuitMap& mapping) const {','inline History Plan::transform_history(std::span<const std::string> history, const SuitMap& mapping) const {\n    if(terra_learning) ++terra_calls[4];')
replace(c,'            for (unsigned iteration = 1; iteration <= plan_.iterations(); ++iteration) {','            for(auto& v : graph::terra_calls) v=0; graph::terra_learning=true;\n            for (unsigned iteration = 1; iteration <= plan_.iterations(); ++iteration) {')
replace(c,'            if (receipt_.member_checks != receipt_.expected_member_checks ||','            graph::terra_learning=false;\n            std::cout << "INDEPENDENT_LEARNING_CALLS"; for(auto v : graph::terra_calls) std::cout << " " << v; std::cout << "\\n";\n            if (receipt_.member_checks != receipt_.expected_member_checks ||')
# Only external test executable; include ostream before instrumented header.
harness=Path('../native-cfr-shadow-terra.cpp').read_text(encoding='utf8');harness='#include <iostream>\n'+harness;(out/'controls.cpp').write_text(harness,encoding='utf8',newline='\n')
for name in (g,c):
 a=(repo/name).read_text(encoding='utf8').splitlines(True);b=(out/name).read_text(encoding='utf8').splitlines(True);(out/(name+'.diff')).write_text(''.join(difflib.unified_diff(a,b,fromfile='original/'+name,tofile='instrumented/'+name)),encoding='utf8')
(out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n',encoding='utf8');print('source hashes authenticated and exact anchors transformed')
