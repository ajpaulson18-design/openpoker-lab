#include "exact_public_history_index.hpp"
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace openpoker::exact_public_graph;
namespace hi=openpoker::exact_public_history_index;
void need(bool v,const char* m){if(!v)throw std::runtime_error(m);}
int main(){try{
 constexpr std::uint64_t kBits=0x3ff0000000000000ULL;
 Action act{"check",0,0,false,"check"};Graph g;g.vertices.push_back(Vertex::decision(0,{act},{1}));g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{kBits,kBits}));
 Plan p(std::move(g),{{{48,49},kBits}},{{{44,45},kBits}},{{{0,4,8,12,16}}},10);
 hi::Limits l;l.query_schedule=hi::QuerySchedule{1,1,1,1};l.external={99,101};hi::HistoryIndex x(p,l);const auto& r=x.receipt();
 need(r.query_schedule_declared&&r.combined_modeled_work_upper==r.combined_base_modeled_work_upper+r.query_work_upper,"work partition");need(r.combined_peak_entries_upper==r.combined_base_peak_entries_upper+r.query_cumulative_entries_upper,"entry partition");need(r.external_work_upper==99&&r.external_entries_upper==101,"external reservation");
 auto a=x.root_cursor();auto b=x.advance_action(a,0);auto c=x.cursor_from_history(History{"check"});need(b.ordinal()==c.ordinal(),"routes mismatch");auto q=x.query_counts();need(q.history_routes==1&&q.history_route_tokens==1&&q.root_cursors==1&&q.edge_advances==1,"schedule counts");need(x.query_work_reserved()<=r.query_work_upper,"work forecast exceeded");need(x.inverse_query_entries_reserved()<=r.query_cumulative_entries_upper,"entries forecast exceeded");
 try{(void)x.root_cursor();throw std::runtime_error("overrun root accepted");}catch(const PlanError& e){need(e.code()==ErrorCode::work_limit,"wrong root overrun");}
 auto pv=p.prefix_support(std::span<const Card>{});const auto& legacy=p.prefix_board_indexes(History{});need(pv.board_index_key==&legacy,"borrowed board vector identity");
 for(int i=0;i<2;i++)need(p.mapped_hand_index(static_cast<std::uint8_t>(i),0,0)==0,"identity hand map");
 hi::Limits bad=l;bad.max_combined_modeled_work=r.combined_modeled_work_upper-1;try{hi::HistoryIndex y(p,bad);throw std::runtime_error("work preflight accepted");}catch(const PlanError& e){need(e.code()==ErrorCode::work_limit,"wrong work preflight");}
 hi::Limits bad2=l;bad2.max_combined_entries=r.combined_peak_entries_upper-1;try{hi::HistoryIndex y(p,bad2);throw std::runtime_error("entry preflight accepted");}catch(const PlanError& e){need(e.code()==ErrorCode::storage_limit,"wrong entry preflight");}
 std::cout<<"PASS schedule partition, actual counts, one-unit-short guards, borrowed prefix and identity map\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}

