import hashlib,json,struct
from pathlib import Path
w=Path(__file__).resolve().parent;pins=[('native-indexed-study-v1','0c2f57fa6d9c6928926e8d73bcd90535c38aa8e8ef8d852fdcfcc805ef7b4185'),('native-indexed-study-v2','9c695cf6b07e0b895bf04c58cc804ae0e2a0ced8bf86ad3ab27f9222481d1275')]
def need(c,m):
 if not c:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(name,pin):
 p=w/name;b={x.relative_to(p).as_posix():x.read_bytes() for x in p.rglob('*') if x.is_file()};need(sha(b['manifest.json'])==pin,'manifest pin');m=json.loads(b['manifest.json']);need(set(b)==set(m['sha256'])|{'manifest.json'} and all(sha(b[k])==v for k,v in m['sha256'].items()),'inventory/hashes');return b
before=[load(*x) for x in pins];metrics=('value_sb','value_bb','sb_best_response_value','bb_best_response_value','sb_gain','bb_gain','nash_conv','exploitability');bits=lambda v:struct.pack('>d',v).hex();r1=json.loads(before[0]['report.json']);r2=json.loads(before[1]['report.json']);labels=[x['artifact'].removesuffix('.stdout.bin') for x in r1['samples'] if not x['case'].endswith('qreject')];need(len(labels)==18,'sample count');out=[]
for label in labels:
 a,b=[json.loads(x[label+'.stdout.bin'])['payload'] for x in before]
 def rows(p):return {(r['player'],r['hand'],tuple(r['history'])):(tuple((x['name'],bits(x['amount']),bits(x['raise_to']),x['history_key'],bits(x['probability'])) for x in r['actions']),r['street'],tuple(r['revealed_board'])) for r in p['strategy']}
 ra,rb=rows(a),rows(b);need(len(ra)==len(a['strategy']) and len(rb)==len(b['strategy']) and ra==rb,'policy '+label);need(all(bits(a[k])==bits(b[k]) for k in metrics),'metrics '+label)
 x,y=[json.loads(v[label+'-verification.json'])['exact_compact_certificate']['exact_certificate'] for v in before];need(all(x[k]==y[k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256')),'exact '+label);out.append({'label':label,'rows':len(ra)})
need([load(*x) for x in pins]==before,'bytes drift');receipt={'status':'passed','samples':out,'metric_fields':list(metrics),'scope':'Cross-source saved complete policy/menu/metric bits and exact certificate identity only; no timing comparison or production execution.'};dest=w/'native-indexed-cross-source-receipt.json';need(not dest.exists(),'refuse overwrite');dest.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf8');print(json.dumps(receipt))
