"""Saved-only independent native exact whole-game review; never runs producer."""
import argparse,base64,hashlib,importlib.util,itertools,json,math,statistics,struct,sys,zipfile
from collections import deque
from pathlib import Path
from fractions import Fraction
from contextlib import ExitStack
from unittest.mock import patch
PIN='8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
COMMIT='322cb53158969a89a1dfaee477c8118033aa7a47'
MANIFEST=None
REPORT=None
AFTER=None
METRICS=('value_sb','value_bb','sb_best_response_value','bb_best_response_value','sb_gain','bb_gain','nash_conv','exploitability')
SCHEDULE=[('original-22-t10',mode,i,False) for i in range(3) for mode in (('full-history','indexed') if i%2==0 else ('indexed','full-history'))]+[('original-22-t10',m,'traced',True) for m in ('full-history','indexed')]+[(name,m,0,False) for name in ('payoff-varied-t100','blocker-18','asymmetric-weighted','mixed-stabilizer','original-22-qreject') for m in ('full-history','indexed')]+[('original-22-t10','shadow','shadow',False),('mixed-stabilizer','shadow','shadow',False)]
SUITS='cdhs'; DECK=tuple(r+s for r in '23456789TJQKA' for s in SUITS); ORDER={c:i for i,c in enumerate(DECK)}
def check(v,m):
 if not v: raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_helper(name):
 p=Path(__file__).with_name(name);spec=importlib.util.spec_from_file_location('review_helper_'+name.replace('-','_').replace('.','_'),p);obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
def hand(h,m):return tuple(sorted(c[0]+m[c[1]] for c in h))
def board(b,m):return tuple(sorted((c[0]+m[c[1]] for c in b[:3]),key=ORDER.__getitem__))+tuple(c[0]+m[c[1]] for c in b[3:])
def history(h,m):
 out=[]
 for t in h:
  if t.startswith('flop@'):out.append('flop@'+''.join(sorted((t[i]+m[t[i+1]] for i in (5,7,9)),key=ORDER.__getitem__)))
  elif t.startswith(('turn@','river@')):out.append(t[:-1]+m[t[-1]])
  else:out.append(t)
 return tuple(out)
def bits(v):return struct.pack('>d',v).hex()
def parse_wire(raw):
    check(type(raw) is bytes and len(raw)<=64*1024*1024 and raw.endswith(b"\n"),"invalid native input envelope")
    tokens=raw.decode("ascii").split();check(len(tokens)<=200000,"native input token cap")
    pos=0
    def take():
        nonlocal pos
        check(pos<len(tokens),"truncated native input")
        text=tokens[pos];pos+=1
        check(0<len(text)<=64 and all(32<ord(c)<127 for c in text),"invalid native token")
        return text
    def nat(ceiling):
        text=take();check(text.isdecimal() and len(text)<=12,"invalid natural field")
        value=int(text);check(value<=ceiling,"native natural exceeds independent cap");return value
    def fp():
        text=take();check(len(text)==16 and all(c in "0123456789abcdef" for c in text),"invalid exact FP bits")
        value=struct.unpack(">d",bytes.fromhex(text))[0];check(math.isfinite(value),"nonfinite native money/prior")
        return text
    check(take()=="OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1","wrong input magic")
    iterations=nat(10000);cache=nat(64);h0,h1=nat(4),nat(4);b=nat(8);n=nat(2048);e=nat(16384);root=nat(max(n-1,0));initial_n=nat(32)
    check(iterations>=10 and cache and h0 and h1 and b and n,"unsupported fixed input dimensions")
    caps=(65536,500000000,2000000,1<<30,500000000,2000000,16000000,500000000,25000000,1000000,2000000)
    limits=[nat(cap) for cap in caps];check(all(limits),"zero native limit")
    ranges=[]
    for h in (h0,h1):
        side=[]
        for _ in range(h):
            a,c=nat(51),nat(51);weight=fp();check(a!=c and struct.unpack(">d",bytes.fromhex(weight))[0]>0,"invalid positive holding")
            side.append({"hand":[DECK[a],DECK[c]],"weight_bits":weight})
        check(len({tuple(sorted(row["hand"])) for row in side})==h,"duplicate private holding")
        ranges.append(side)
    boards=[[DECK[nat(51)] for _ in range(5)] for _ in range(b)]
    check(all(len(set(outcome))==5 and outcome[:3]==sorted(outcome[:3],key=ORDER.__getitem__) for outcome in boards) and
         boards==sorted(boards,key=lambda outcome:tuple(ORDER[c] for c in outcome)) and len({tuple(v) for v in boards})==b,"noncanonical or duplicate native selected boards")
    initial=[take() for _ in range(initial_n)];vertices=[];edges=0
    for _ in range(n):
        tag=take()
        if tag=="D":
            actor=nat(1);count=nat(32);check(count>0,"empty action menu");actions=[];children=[]
            for _ in range(count):
                action={"name":take(),"amount_bits":fp(),"raise_to_bits":fp(),"full_raise":bool(nat(1)),"token":take()}
                actions.append(action);children.append(nat(n-1))
            check(len({a["token"] for a in actions})==count,"duplicate native action tokens")
            vertices.append({"kind":"D","actor":actor,"actions":actions,"children":children});edges+=count
        elif tag=="C":
            street=nat(3);index=nat(6);count=nat(8);check(street and count and index==street+3,"wrong native reveal index/street")
            branches=[(take(),nat(n-1)) for _ in range(count)];check(len({v[0] for v in branches})==count,"duplicate chance labels")
            vertices.append({"kind":"C","street":street,"card_index":index,"branches":branches});edges+=count
        elif tag in ("F","S"):
            winner=nat(1) if tag=="F" else None
            contributions=[fp(),fp()];check(all(struct.unpack(">d",bytes.fromhex(value))[0]>=0 for value in contributions),"negative terminal money")
            vertices.append({"kind":tag,"winner":winner,"contribution_bits":contributions})
        else:raise ValueError("unknown native wire field/vertex tag")
    check(pos==len(tokens) and edges==e,"unknown trailing native fields or edge mismatch")
    def children(v):return v["children"] if v["kind"]=="D" else [child for _,child in v["branches"]] if v["kind"]=="C" else []
    degrees=[0]*n
    for vertex in vertices:
        for child in children(vertex):degrees[child]+=1
    queue=deque(i for i,d in enumerate(degrees) if d==0);order=[]
    while queue:
        i=queue.popleft();order.append(i)
        for child in children(vertices[i]):
            degrees[child]-=1
            if degrees[child]==0:queue.append(child)
    check(len(order)==n,"native graph cycle")
    reached={root};depth={root:0}
    for i in order:
        check(i in reached,"native graph unreachable vertex")
        for child in children(vertices[i]):
            reached.add(child);depth[child]=max(depth.get(child,0),depth[i]+1)
            check(depth[child]<=32,"independent numeric graph depth cap")
    return {"iterations":iterations,"rank_cache_boards":cache,"ranges":ranges,"boards":boards,"vertices":vertices,
        "root":root,"initial_history":initial,"edges":edges,"limits":limits,"maximum_depth":max(depth.values())}

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--study',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--confirmed-terminal-handle',required=True);p.add_argument('--terminal-exit-code',type=int,required=True);p.add_argument('--manifest-sha256',required=True);p.add_argument('--report-sha256',required=True);p.add_argument('--source-after-sha256',required=True);a=p.parse_args();global MANIFEST,REPORT,AFTER;MANIFEST=a.manifest_sha256;REPORT=a.report_sha256;AFTER=a.source_after_sha256
 check((a.confirmed_terminal_handle,a.terminal_exit_code)==('99535',0),'unconfirmed producer status')
 repo=a.repo.resolve();study=a.study.resolve();out=a.output_dir.resolve();check(not out.exists() and repo not in out.parents and study not in out.parents,'new external output required');out.mkdir()
 ap=Path(__file__).with_name('exact-selected-independent-review.py');check(sha(ap.read_bytes())==PIN,'authentication helper pin');auth=load_helper(ap.name);auth.FROZEN=COMMIT;parse=auth.parse
 saved={p.relative_to(study).as_posix():p.read_bytes() for p in study.rglob('*') if p.is_file()};check(sha(saved['manifest.json'])==MANIFEST,'manifest pin');manifest=parse(saved['manifest.json']);check(manifest['source_commit']==COMMIT and set(saved)==set(manifest['sha256'])|{'manifest.json'},'inventory')
 for n,v in manifest['sha256'].items():check(Path(n).name==n and sha(saved[n])==v,'artifact '+n)
 check(sha(saved['report.json'])==REPORT and sha(saved['source-after.json'])==AFTER,'report/source pin')
 source=parse(saved['source-before.json']);check(parse(saved['source-after.json'])==source,'source drift recorded');identity=auth.source_identity(repo,source)
 protocol=parse(saved['protocol.json']);report=parse(saved['report.json']);check(protocol['source_commit']==report['source_commit']==COMMIT and protocol['version']=='native-exact-indexed-routing-fixed-study-v1' and protocol['schedule']==[list(i) for i in SCHEDULE],'protocol/schedule');check(report['calls_planned']==report['calls_completed']==20 and report['failure'] is None and len(report['samples'])==20,'producer status')
 build=protocol['build'];exe=Path(build['executable']);bp=exe.parent/'native-exact-build-manifest.json';br=bp.read_bytes();bm=parse(br)
 check(sha(br)==build['manifest_sha256'] and sha(exe.read_bytes())==build['executable_sha256']=='89a52e596f39d328b1f39e46ddcd29236ee321ff9da25cae1c292beedc3efec8','build bytes')
 names={'native/exact_four_street_train.cpp','native/exact_public_graph.hpp','native/exact_public_history_index.hpp','native/exact_indexed_routing.hpp','native/exact_selected_cfr.hpp','native/exact_selected_kernel.hpp','native/exact_binary64.hpp','scripts/build_native_exact_four_street.py','third_party/boost-multiprecision-1.92.0/manifest.json','third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt','third_party/boost-multiprecision-1.92.0/headers.zip'}
 check(set(build['source_sha256'])==names and bm['source_sha256']==build['source_sha256'] and bm['executable_sha256']==build['executable_sha256'] and all(sha((repo/n).read_bytes())==v for n,v in build['source_sha256'].items()),'build closure')
 dep=parse((repo/'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
 with zipfile.ZipFile(repo/'third_party/boost-multiprecision-1.92.0/headers.zip') as z:
  headers={i.filename:sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
 check(len(headers)==198 and headers==dep['headers_sha256'],'pinned header archive')
 include=exe.parent/'boost-include';check({x.relative_to(include).as_posix():sha(x.read_bytes()) for x in include.rglob('*') if x.is_file()}==headers,'built extracted headers')
 base=parse((repo/'benchmarks/four-street-integration-v1.json').read_bytes())['case']
 small=dict(base,config=dict(base['config'],starting_stack=[2,2]),runouts=['2c3c4h5s6h','2d3d4h5s6h'])
 expected={'original-22-t10':dict(base,id='original-22-exact-product-study'),
  'payoff-varied-t100':dict(small,id='payoff-varied-private-flush-v1',sb_range='AcQc,AdQd',bb_range='KcJc,KdJd',runouts=['2c3c7c9hTs','2d3d7d9hTs']),
  'blocker-18':dict(small,id='blocker-conditioned-18-worlds-v1',sb_range='AcAh,AdAh,2cAh,2dAh',bb_range='KcKh,KdKh,3cKh,3dKh'),
  'asymmetric-weighted':dict(small,id='weighted-asymmetric-suit-exchange-v1',sb_range='AcAh:0.7,AdAh:0.3',bb_range='KcKh:0.4,KdKh:0.6'),
  'mixed-stabilizer':dict(small,id='mixed-suit-stabilizer-v1',sb_range='AcAd',bb_range='KcKd')}
 expected['original-22-qreject']=expected['original-22-t10']
 check(protocol['cases']==expected,'fixed physical case declarations mismatch')
 sys.path.insert(0,str(repo));from scripts import four_street_validation as physical, exact_selected_compact_certificate as cert
 from scripts.preflop_validation import compare_result
 forbidden=['pokerlab.exact_selected_solver.solve_four_street_exact_selected','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.__init__','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.terminal_values_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.joint_marginals_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.pair_probability_exact','pokerlab.exact_selected_kernel.rank_hand','pokerlab.cards.rank_hand','pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.__init__','pokerlab.suit_quotient_plan.SuitQuotientPlan.__init__','pokerlab.suit_quotient_cfr.train_suit_quotient','pokerlab.equivariant_packed_cfr.train_equivariant_packed','pokerlab.packed_operator_cfr.train_packed','pokerlab.preflop_solver._enumerate_physical_worlds','pokerlab.selected_runout_operator.SelectedRunoutOperator._iter_worlds','pokerlab.native_selected_operator.train_native_selected','pokerlab.native_selected_dag.train_native_selected_dag','pokerlab.native_public_cfr.train_native_public','pokerlab.native_exact_four_street._invoke','pokerlab.native_exact_four_street.train','pokerlab.native_exact_four_street.wire','pokerlab.native_exact_four_street.admit','subprocess.Popen']
 payloads={};certs={};orbits=[];gaps=[];models={};raws={}
 with ExitStack() as guard:
  for target in forbidden:guard.enter_context(patch(target,side_effect=AssertionError('forbidden '+target)))
  for record,entry in zip(report['samples'],SCHEDULE):
   name,mode,sample,traced=entry;label=f'{name}-{mode}-{sample}';raw=parse(saved[label+'.stdout.bin']);raws[label]=raw
   check(record.get('artifact')==label+'.stdout.bin' and {k:v for k,v in record.items() if k!='artifact'}=={k:v for k,v in raw.items() if k not in ('payload','native_streams')},'report binding '+label)
   check((raw['case'],raw['routing'],raw['sample'],raw['traced'])==entry and raw['runtime']==protocol['runtime'],'sample '+label)
   check(math.isfinite(raw['seconds']) and raw['seconds']>0 and isinstance(raw['process_peak_bytes'],int) and raw['process_peak_bytes']>0,'timing')
   check((isinstance(raw['python_allocation_peak_bytes'],int) and raw['python_allocation_peak_bytes']>0) if traced else raw['python_allocation_peak_bytes'] is None,'trace')
   counts=raw['counts'];check(not any(counts[k] for k in ('pair','world','legacy')),'forbidden producer counters')
   if name.endswith('qreject'):
    check(raw['payload'] is None and raw['failure'] and raw['iterations']==1000 and not any(counts[k] for k in ('python_trainer','native_invoke','python_rank')) and not raw['native_streams'],'pretraining rejection');continue
   x=raw['payload'];T=100 if name.endswith('t100') else 10;check(x is not None and raw['failure'] is None and raw['iterations']==T,'missing policy');encoded=json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode();check((sha(encoded),len(encoded))==(raw['payload_sha256'],raw['payload_bytes']),'payload digest')
   case=protocol['cases'][name];models.setdefault(name,physical.build_model(case));model=models[name]
   expanded=dict(x,compatible_private_pairs=model.counts['compatible_pairs'],private_pair_probabilities=[{'sb_hand':r['sb_hand'],'bb_hand':r['bb_hand'],'probability':float(Fraction(r['fraction']))} for r in model.counts['pair_probabilities']]);replay=physical.replay_policy(expanded,case);compare_result(expanded,replay)
   v=replay['value_sb'];b0=replay['sb_best_response_value'];b1=replay['bb_best_response_value'];g0=max(0.,b0-v);g1=max(0.,b1+v);mm=dict(value_sb=v,value_bb=-v,sb_best_response_value=b0,bb_best_response_value=b1,sb_gain=g0,bb_gain=g1,nash_conv=g0+g1,exploitability=(g0+g1)/2)
   delta={k:abs(x[k]-mm[k]) for k in METRICS};check(all(math.isfinite(x[k]) and delta[k]<=1e-10 for k in METRICS),'physical metric mismatch '+label);gaps.append(delta)
   fresh=cert.evaluate_exact(case,x);old=parse(saved[label+'-verification.json'])['exact_compact_certificate'];f=fresh['exact_certificate'];z=old['exact_certificate'];check(all(f[k]==z[k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256')) and fresh['compact_input_canonical_sha256']==old['compact_input_canonical_sha256'],'exact certificate '+label)
   (out/(label+'-fresh-certificate.json')).write_text(json.dumps(fresh,sort_keys=True,indent=2,allow_nan=False),encoding='utf8');certs[label]=f;payloads[label]=x
   check(counts['native_invoke']==1 and counts['python_trainer']==0 and counts['rank_before_native']==0 and len(raw['native_streams'])==1,'native counters')
   stream=raw['native_streams'][0];rq,rs,err=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'));nc=x['operator_census']['native_exact'];check(stream['returncode']==0 and not err and (sha(rq),sha(rs),len(rq),len(rs))==(nc['request_sha256'],nc['result_sha256'],nc['request_bytes'],nc['result_bytes']),'native stream')
   lines=rs.decode('ascii').splitlines();check(lines[0]==('OPENPOKER_NATIVE_EXACT_FOUR_STREET_RESULT_V1' if mode=='full-history' else 'OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_RESULT_V2'),'native header');ranges=x['chance_input_snapshot']['ranges'];rows={(r['player'],r['hand'],tuple(r['history'])):r for r in x['strategy']};seen=set()
   done=[line.split('\t') for line in lines[1:] if line.startswith('DONE\t')];fields_order=('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots','member_checks','expected_member_checks','modeled_work_upper','kernel_work_upper','retained_entries_upper','maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls');check(len(done)==1 and len(done[0])==14 and [int(v) for v in done[0][1:]]==[nc[k] for k in fields_order],'DONE counters '+label)
   for line in lines[1:]:
    fields=line.split('\t')
    if fields[0]!='ROW':check(fields[0] in ('DONE','ROUTE'),'unexpected native record');continue
    player=int(fields[1]);index=int(fields[2]);n=int(fields[3]);hist=tuple(fields[4:4+n]);count=int(fields[4+n]);values=fields[5+n:];check(player in (0,1) and 0<=index<len(ranges[player]) and len(values)==count,'ROW dimensions');key=('sb' if player==0 else 'bb',ranges[player][index]['hand'],hist);check(key in rows and key not in seen,'ROW identity');seen.add(key);check(values==[bits(a['probability']) for a in rows[key]['actions']],'ROW probabilities '+label)
   check(len(seen)==len(rows)==x['info_sets'] and nc['member_checks']==2*T*len(rows) and nc['maximum_numeric_workspace_slots']==4*nc['quotient_action_slots'] and nc['final_numeric_workspace_slots']==0,'native row/counters')
   if mode=='full-history':v1rq=rq
   else:
    v1rq=rq.replace(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_V2\n'+mode.encode()+b'\n',b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1\n',1)
   wire=parse_wire(v1rq);stack=[wire['root']];visits=decisions=terminals=0
   while stack:
    v=wire['vertices'][stack.pop()];visits+=1;check(visits<=250000,'wire occurrence cap')
    if v['kind']=='D':decisions+=1;stack.extend(v['children'])
    elif v['kind']=='C':stack.extend(child for _,child in v['branches'])
    else:terminals+=1
   check(wire['iterations']==T,'wire iteration')
   routes=[line.split('\t') for line in lines if line.startswith('ROUTE\t')]
   if mode=='full-history':check(not routes and rq.startswith(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1\n'),'v1 route shape')
   else:
    check(len(routes)==1 and routes[0][1]==mode and rq.startswith(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_V2\n'+mode.encode()+b'\n'),'v2 route shape')
    fields=routes[0][2:];parsed={}
    for f in fields:
     k,sep,v=f.partition('=');check(sep and k not in parsed and v.isascii() and v.isdecimal() and len(v)<=20,'malformed ROUTE');parsed[k]=int(v)
    check(len(parsed)==41 and nc['indexed_routing']==dict(mode=mode,**parsed),'ROUTE receipt fields')
    check(parsed['r_lookup_entries']==0 and parsed['old_q_histories_retained']==1 and parsed['final_router_entries']==0 and parsed['cursor_fields']==196,'route representation')
    for k in ('router_work','index_work','index_entries','router_retained'):check(parsed[k]<=parsed[k+'_upper'],'route capacity')
    check(parsed['q_routes']==parsed['q_routes_upper']==parsed['q_rows']==nc['quotient_rows'] and parsed['q_tokens']==parsed['q_tokens_upper'],'Q route setup')
    check(parsed['combined_work']==nc['modeled_work_upper'] and parsed['combined_entries']==nc['retained_entries_upper'],'whole owner')
    expected_counts={'roots':3*T,'edges':3*T*(visits-1),'decisions':3*T*decisions,'prefixes':T*(2*terminals+decisions)}
    for k,v in expected_counts.items():check(parsed[k]==parsed[k+'_upper']==v,'wire-derived route census '+k)
    shadow=mode=='shadow';check(parsed['legacy_extensions']==(parsed['edges'] if shadow else 0) and parsed['legacy_rows']==(parsed['decisions'] if shadow else 0) and parsed['legacy_prefixes']==(parsed['prefixes'] if shadow else 0) and parsed['decision_comparisons']==(parsed['decisions'] if shadow else 0) and parsed['prefix_comparisons']==(parsed['prefixes'] if shadow else 0),'legacy/shadow counters')

   outcomes,rng=physical._case_inputs(case)[-2:];group=[]
   for perm in itertools.permutations(SUITS):
    m=dict(zip(SUITS,perm))
    if all({hand(h,m):Fraction.from_float(float(w)) for h,w in side.items()}=={h:Fraction.from_float(float(w)) for h,w in side.items()} for side in rng) and {board(b,m) for b in outcomes}==set(outcomes):group.append(m)
   keys=model.expected_infos;classes={}
   for k,node in keys.items():
    images={(k[0],''.join(hand((k[1][:2],k[1][2:]),m)),history(k[2],m)) for m in group};check(all(q in keys and tuple((a.name,a.amount,a.raise_to,a.token) for a in keys[q].actions)==tuple((a.name,a.amount,a.raise_to,a.token) for a in node.actions) for q in images),'group/menu closure');classes[min(images)]=(len(images),len(node.actions))
    ref=rows[('sb' if k[0]==0 else 'bb',k[1],k[2])];check(all([bits(a['probability']) for a in ref['actions']]==[bits(a['probability']) for a in rows[('sb' if q[0]==0 else 'bb',q[1],q[2])]['actions']] for q in images),'orbit bits')
   check((nc['group_size'],nc['quotient_rows'],nc['quotient_action_slots'])==(len(group),len(classes),sum(c for _,c in classes.values())),'physical quotient census '+label);orbits.append({'label':label,'group':len(group),'rows':len(keys),'q_rows':len(classes),'q_slots':sum(c for _,c in classes.values()),'orbit_sizes':sorted({n for n,_ in classes.values()})})
 for name,mode,sample,traced in SCHEDULE:
  if name.endswith('qreject') or mode=='indexed':continue
  p=f'{name}-full-history-{0 if mode=="shadow" else sample}';n=f'{name}-{mode if mode=="shadow" else "indexed"}-{sample}';check(payloads[p]['strategy']==payloads[n]['strategy'] and all(bits(payloads[p][k])==bits(payloads[n][k]) for k in METRICS),'paired bits '+p);check(certs[p]['metrics']==certs[n]['metrics'] and certs[p]['threshold_met']==certs[n]['threshold_met'],'paired exact '+p)
 for mode in ('full-history','indexed'):
  median=statistics.median(raws[f'original-22-t10-{mode}-{i}']['seconds'] for i in range(3));check(median==report['medians_seconds'][mode],'reported median '+mode)
 check(len(payloads)==18 and len(orbits)==18,'sample coverage');check(auth.source_identity(repo,source)['raw_sha256']==identity['raw_sha256'],'source drift');check({p.relative_to(study).as_posix():p.read_bytes() for p in study.rglob('*') if p.is_file()}==saved and bp.read_bytes()==br and sha(exe.read_bytes())==build['executable_sha256'],'artifact/build drift')
 receipt={'status':'passed','source_commit':COMMIT,'source_files':identity['files'],'manifest_sha256':MANIFEST,'report_sha256':REPORT,'executable_sha256':build['executable_sha256'],'complete_policies':len(payloads),'paired_comparisons':10,'pretraining_rejections':2,'quality_passes':sum(v['threshold_met'] for v in certs.values()),'quality_misses':sum(not v['threshold_met'] for v in certs.values()),'max_metric_gap':max(max(g.values()) for g in gaps),'orbits':orbits,'scope':'Saved policies and native ROW bits; no production trainer or candidate executable invoked; no independent full input graph equivalence claim.'}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True),encoding='utf8');print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
