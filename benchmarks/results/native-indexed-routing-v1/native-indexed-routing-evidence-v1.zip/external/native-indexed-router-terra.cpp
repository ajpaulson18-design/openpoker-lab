#include "exact_indexed_routing.hpp"
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace openpoker::exact_public_graph;
namespace ir=openpoker::exact_indexed_routing;
void need(bool v,const char* m){if(!v)throw std::runtime_error(m);}
int main(){try{
 constexpr std::uint64_t bits=0x3ff0000000000000ULL;
 Action a{"z",0,0,false,"z"},b{"a",0,0,false,"a"};Graph g;g.vertices.push_back(Vertex::decision(0,{a,b},{1,1}));g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{bits,bits}));
 Plan p(std::move(g),{{{48,49},bits},{{44,45},bits}},{{{40,41},bits}},{{{0,4,8,12,16}}},10);
 ir::IndexedRouting x(p);auto c=x.root_cursor();auto rows=x.locate_decision_rows(c,0,p.graph().vertices[0].actions);auto old=p.locate_decision_rows(0,History{},p.graph().vertices[0].actions);
 need(rows==old,"indexed rows differ from literal reference");need(&x.prefix_board_indexes(c)==&p.prefix_board_indexes(History{}),"borrowed vector identity");
 auto r=x.receipt();need(r.router_setup_scratch_entries_upper>=512+2*ir::kMaximumCursorLogicalEntries+24*(7+3),"setup arrays not fully charged");need(r.router_query_scratch_entries_upper>=512+4*2+24*(7+3),"query arrays not fully charged");
 ir::WholeLimits limited;limited.logical_entries=r.combined_logical_entries_upper-1;try{ir::IndexedRouting y(p,{},limited);throw std::runtime_error("one-short cap accepted");}catch(const PlanError& e){need(e.code()==ErrorCode::storage_limit,"wrong cap error");}
 Graph h;h.vertices.push_back(Vertex::decision(0,{a,b},{1,1}));h.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{bits,bits}));
 Plan hp(std::move(h),{{{48,49},bits},{{0,2},bits},{{44,45},bits}},{{{40,41},bits}},{{{0,4,8,12,16}}},10);
 ir::IndexedRouting hx(hp);auto hc=hx.root_cursor();auto hs=hx.locate_decision_rows(hc,0,hp.graph().vertices[0].actions);auto literal=hp.locate_decision_rows(0,History{},hp.graph().vertices[0].actions);
 need(hs==literal && hs.size()==3 && hs[0] && !hs[1] && hs[2],"interior supported-hand hole misrouted");
 try{(void)hx.locate_decision_rows(hc,1,hp.graph().vertices[0].actions);throw std::runtime_error("wrong actor accepted");}catch(const PlanError& e){need(e.code()==ErrorCode::invalid_query,"wrong actor error");}
 std::cout<<"PASS literal row parity, interior support hole, wrong actor, borrowed board identity, fixed 24 scratch and one-short cap\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
