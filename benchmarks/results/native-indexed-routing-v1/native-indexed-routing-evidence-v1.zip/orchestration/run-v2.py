"""Authenticate full committed closure, then execute the single fixed study."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
repo = work / 'native-indexed-ci-repo'
frozen = '322cb53158969a89a1dfaee477c8118033aa7a47'
helper = work / 'exact-selected-independent-review.py'
if hashlib.sha256(helper.read_bytes()).hexdigest() != '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5':
    raise ValueError('Source authentication helper drift')
namespace = {'__name__': 'indexed_study_source_auth', '__file__': str(helper)}
exec(compile(helper.read_bytes(), str(helper), 'exec'), namespace)
namespace['FROZEN'] = frozen
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
names = git('ls-files', '-z').decode().split('\0')[:-1]
source = {'commit': git('rev-parse', 'HEAD').decode().strip(),
    'status': git('status', '--porcelain', '--untracked-files=all').decode().strip(),
    'sha256': {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names}}
authenticated = namespace['source_identity'](repo, source)
(work / 'native-indexed-study-v2-source-auth.json').write_text(json.dumps(authenticated, indent=2, sort_keys=True) + '\n', encoding='utf-8')
sys.path.insert(0, str(repo))
from scripts.benchmark_native_indexed_routing import run
result = run(work / 'native-indexed-study-v2', work / 'native-indexed-engine-corrected-build-v2/native-exact-four-street-train.exe')
print(json.dumps(result), flush=True)
raise SystemExit(0 if result['outcome'] == 'complete' else 1)

