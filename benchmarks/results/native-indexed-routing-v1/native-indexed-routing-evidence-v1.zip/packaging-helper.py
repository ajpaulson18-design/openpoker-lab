"""Preserve both frozen routing studies, reviews, development gaps and OS probe."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
TARGET = WORK / 'native-indexed-routing-evidence-v1.zip'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def need(value, message):
    if not value: raise ValueError(message)
def read(path): return json.loads(path.read_bytes())

def main():
    need(not TARGET.exists(), 'Retain existing archive')
    entries = {}
    def add(name, path):
        need(name not in entries and path.is_file() and not path.is_symlink(), 'Invalid archive entry: ' + name)
        entries[name] = path.read_bytes()
    def folder(prefix, directory):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix not in ('.exe', '.obj', '.pyc') and '__pycache__' not in path.parts:
                add(prefix + '/' + path.relative_to(directory).as_posix(), path)
    helper = WORK / 'exact-selected-independent-review.py'
    need(sha(helper.read_bytes()) == '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5', 'Auth helper drift')
    auth = {'__name__': 'indexed_archive_auth', '__file__': str(helper)}
    exec(compile(helper.read_bytes(), str(helper), 'exec'), auth)
    authenticated = {}
    for version, commit, repo_name in (
        ('v1', 'c7ece29033ba91a9d363f2dcc250a6b2a451e190', 'native-indexed-routing-repo'),
        ('v2', '322cb53158969a89a1dfaee477c8118033aa7a47', 'native-indexed-ci-repo')):
        study = WORK / ('native-indexed-study-' + version)
        review = WORK / ('native-indexed-review-' + version)
        repo = WORK / repo_name
        source = read(study / 'source-before.json')
        need((study / 'source-before.json').read_bytes() == (study / 'source-after.json').read_bytes(), 'Source drift')
        auth['FROZEN'] = commit
        authenticated[version] = auth['source_identity'](repo, source)
        manifest = read(study / 'manifest.json')
        need(set(p.name for p in study.iterdir() if p.is_file()) == set(manifest['sha256']) | {'manifest.json'}, 'Study inventory drift')
        for name, expected in manifest['sha256'].items():
            need(sha((study / name).read_bytes()) == expected, 'Study artifact drift: ' + name)
        report, receipt = read(study / 'report.json'), read(review / 'receipt.json')
        need(report['failure'] is None and report['calls_completed'] == report['calls_planned'] == 20 and
            len(report['paired_identities']) == 10 and receipt['status'] == 'passed' and
            receipt['complete_policies'] == 18 and receipt['quality_misses'] == 16 and receipt['quality_passes'] == 2,
            'Incomplete fixed study/replay')
        folder('study-' + version, study)
        folder('saved-review-' + version, review)
        add('orchestration/run-' + version + '.py', WORK / ('run-native-indexed-study-' + version + '.py'))
        add('orchestration/run-' + version + '.log', WORK / ('native-indexed-study-' + version + '-run.log'))
        add('orchestration/source-auth-' + version + '.json', WORK / ('native-indexed-study-' + version + '-source-auth.json'))
        # Complete native/preparation/reference/replay source closure, plus
        # original fixture declarations and every introduced source/document.
        introduced = subprocess.check_output(['git', 'diff', '--name-only', '4142f326433404daef432dc1ea4c0325a123c5c2', commit], cwd=repo).decode().splitlines()
        names = set(introduced)
        names.update(path.relative_to(repo).as_posix() for root, suffix in
            (('pokerlab', '*.py'), ('scripts', '*.py'), ('native', '*.hpp'), ('native', '*.cpp'), ('benchmarks/cases', '*.json'))
            for path in (repo / root).rglob(suffix))
        names.update('third_party/boost-multiprecision-1.92.0/' + name for name in ('headers.zip', 'manifest.json', 'LICENSE_1_0.txt'))
        for name in sorted(names): add('source-' + version + '/' + name, repo / name)
    legacy = Path(r'C:\Users\pauls\Documents\Codex\work')
    development = legacy / 'native-indexed-development-evidence-v1.zip'
    need(sha(development.read_bytes()) == '603c9a3a68277ecd0dbf8ebd19a4603c6ff251746fd29631eeb80db29efee273', 'Development archive drift')
    with zipfile.ZipFile(development) as archive:
        need(archive.testzip() is None and len(archive.namelist()) == 229, 'Development archive integrity')
    add('development/evidence.zip', development)
    add('development/inventory.json', legacy / 'native-indexed-development-inventory.json')
    for path in sorted(WORK.glob('native-indexed*')):
        if path.is_file() and path.suffix in ('.json', '.log', '.py', '.cpp', '.cmd'):
            add('external/' + path.name, path)
    for name in ('native-indexed-c7-engine-failure-artifact', 'native-indexed-c7-index-failure-artifact',
                 'native-indexed-engine-corrected-build-v1', 'native-indexed-engine-corrected-build-v2'):
        directory = WORK / name
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.log'):
                add('build-and-ci/' + name + '/' + path.relative_to(directory).as_posix(), path)
    folder('native-process-memory', WORK / 'native-indexed-process-memory-v1')
    add('packaging-helper.py', Path(__file__))
    manifest = {'contract': 'native-indexed-routing-evidence-v1',
        'source_authentication': authenticated,
        'scope': 'Two distinct committed-source 20-child studies and 18-policy saved replays each. No source-version timing comparison. Includes preserved development/build/reviewer failures and explicit capture gaps. Separate native-process OS probe is not native heap, full API memory or a memory-reduction proof. Historical archived source is evidence only, never executed by saved-only review.',
        'sha256': {name: sha(raw) for name, raw in sorted(entries.items())}}
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(TARGET, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(entries.items()): archive.writestr(name, raw)
        archive.writestr('evidence-manifest.json', manifest_raw)
    with zipfile.ZipFile(TARGET) as archive:
        need(archive.testzip() is None and len(archive.namelist()) == len(entries) + 1, 'Final archive integrity')
        for name, raw in entries.items(): need(archive.read(name) == raw, 'Archive byte drift: ' + name)
    receipt = {'archive': TARGET.name, 'archive_bytes': TARGET.stat().st_size,
        'archive_sha256': sha(TARGET.read_bytes()), 'archive_entries': len(entries) + 1,
        'evidence_manifest_sha256': sha(manifest_raw),
        'source_commits': [authenticated[v]['commit'] for v in ('v1', 'v2')],
        'scope': manifest['scope']}
    (WORK / 'native-indexed-routing-evidence-v1-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__': main()
