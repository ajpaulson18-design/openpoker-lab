from pathlib import Path
import sys,json,traceback,time
repo=Path.cwd();sys.path.insert(0,str(repo));out=repo.parent/'virtual-frozen-real-source-auth-v1';out.mkdir(exist_ok=False)
from tests.virtual_frozen_source_guard import capture_source,verify_source
start=time.perf_counter();status={'status':'started','native_calls':0}
try:
    snapshot=capture_source(repo)
    (out/'source-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
    after=verify_source(repo,snapshot)
    (out/'source-recheck.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
    status.update(status='complete',head=snapshot['head'],files=len(snapshot['files']),bytes=snapshot['bytes'],raw_recheck=after['raw_bytes_identical'])
except BaseException:
    status.update(status='failed',first_error=traceback.format_exc())
finally:
    status['duration_seconds']=time.perf_counter()-start
    (out/'completion.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
print(json.dumps(status));sys.exit(0 if status['status']=='complete' else 1)
