"""Package frozen packed-policy shortcuts and independently checked receipts."""
from hashlib import file_digest, sha256
import io
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / "dyadic-phase-payload-repo"
HEAD = "1acbdfcf2d3736dc4ac1d708c2be1f493e6565b2"
COHORT = WORK / "dypacked-cohort1"
OPERATOR = WORK / "dypacked-launch1"
CONTROLS = WORK / "dypacked-controls3"
CONTROL_HEAD = "4a1db24f0d6fcb93f59ba8f9028e3b9bb1f642ac"
RESULT = ROOT / "benchmarks/results/native-dyadic-packed-policy-v1"
BASELINE = "benchmarks/results/native-dyadic-bounded-policy-division-v1"
MODE = "ten_packed_policy"

sys.path.insert(0, str(ROOT))
from scripts.virtual_dyadic_compact_wire import expand_compact


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    final = read(COHORT / "result.json")
    source = read(COHORT / "source.json")
    hashes = {name: item["raw_sha256"] for name, item in source["files"].items()}
    outer = read(OPERATOR / "completion.json")
    controls = read(CONTROLS / "completion.json")
    require(final["head"] == source["head"] == outer["head"] == HEAD and controls["head"] == CONTROL_HEAD and
            final["training_invocations"] == 1 and read(COHORT / "terminal.json")["status"] == "complete" and
            outer["actual_exit_observed"] and outer["returncode"] == 0 and not outer["failures"] and
            outer["raw_source_stable"] and controls["raw_source_stable"] and
            controls["tests_per_mode"] == 85 and controls["skips"] == 0 and
            all(read(OPERATOR / ("source-" + phase + ".json")) == hashes for phase in ("before", "after")) and
            read(CONTROLS / "source-before.json") == read(CONTROLS / "source-after.json"),
            "frozen execution, control or source identity differs")
    launcher = WORK / "trusted-virtual-dyadic-training-launch-v41.py"
    require(read(OPERATOR / "operator-launch.json")["operator_sha256"] == digest(launcher),
            "outer launcher identity differs")
    for boot_path in (OPERATOR / "bootstrap.json", COHORT / "saved-review-bootstrap.json"):
        boot = read(boot_path)
        require(boot["initial_cache_scan"]["project_bytecode_files"] ==
                boot["final_cache_scan"]["project_bytecode_files"] == 0 and
                all(hashes[name] == value for name, value in boot["compiled"].items()),
                "source-only closure identity differs")
    for child in ("admit_" + MODE, "train_" + MODE, "saved-review"):
        process = read(COHORT / child / "process.json")
        require(process["actual_exit_observed"] and process["returncode"] == 0 and
                not process["failures"] and process["automatic_retries"] == 0,
                "child exit or retry count differs")
    build_path = COHORT / "build/native-exact-build-manifest.json"
    build = read(build_path)
    require(digest(Path(build["executable"])) == build["executable_sha256"] and
            all(hashes[name] == value for name, value in build["source_sha256"].items()),
            "native build differs")
    links = {}
    for name in ("manifest.json", "verification.zip"):
        path = ROOT / BASELINE / name
        links[name] = digest(path)
        require(links[name] == hashes[BASELINE + "/" + name], "snapshot baseline identity differs")
    prior = read(ROOT / BASELINE / "manifest.json")
    require(prior["archive"]["sha256"] == links["verification.zip"], "snapshot archive hash differs")
    with ZipFile(ROOT / BASELINE / "verification.zip") as archive:
        prior_replay = json.loads(archive.read("cohort/saved-review/stdout.bin"))
        prior_result = json.loads(archive.read("cohort/result.json"))
        prior_compact = archive.read("cohort/train_ten_bounded_division/stdout.bin")
        prior_paging = json.loads(archive.read("cohort/page-images/paging.json"))
    capture = final["compact_sweep_capture"]
    require(capture["frames"] == prior["compact_sweep_capture"]["frames"] and
            sha256(prior_compact).hexdigest() == prior["compact_sweep_capture"]["retained_sha256"] and
            final["row_directory"] == prior_result["row_directory"] and
            final["policy_spill"] == prior_result["policy_spill"] and
            final["factored_execution"] == prior_result["factored_execution"], "exact checkpoint or I/O identity differs")
    with io.BytesIO() as writer:
        expand_compact(io.BytesIO(prior_compact), writer, source_size=len(prior_compact))
        previous = writer.getvalue()
    expanded = (COHORT / ("train_" + MODE) / "expanded.bin").read_bytes()
    replay = final["saved_only_replay"]
    require(sha256(previous).hexdigest() == prior_replay["saved_output_sha256"] and
            sha256(expanded).hexdigest() == replay["saved_output_sha256"] and
            replay["status"] == "saved_two_sweep_exact_replay_pass" and replay["native_producer_calls"] == 0,
            "expanded replay identity differs")
    projected = prior["eleven_card_projection"]
    scan=final["packed_policy"]["scan_work"]
    require(scan==17_913_688 and final["packed_policy"]==replay["packed_policy"],
            "packed policy scan realization differs")
    expected=bytearray(previous)
    expected_compact=bytearray(prior_compact)
    for offset,key in ((480,"work_plan"),(432,"work_actual")):
        old_word=prior_replay[key]["quantizer"]
        new_word=replay[key]["quantizer"]
        require(new_word==old_word+scan and
                int.from_bytes(previous[-offset:-offset+8],"little")==old_word,
                "packed quantizer footer delta differs")
        expected[-offset:-offset+8]=new_word.to_bytes(8,"little")
        expected_compact[-offset:-offset+8]=new_word.to_bytes(8,"little")
        expected_work=dict(prior_replay[key],quantizer=new_word)
        require(replay[key]==expected_work,"non-quantizer work changed")
    require(expanded==expected and
            (COHORT / ("train_"+MODE) / "stdout.bin").read_bytes()==expected_compact and
            capture["contract"]==prior["compact_sweep_capture"]["contract"] and
            replay["profile_and_br"]==prior_replay["profile_and_br"] and
            replay["unequal_two_positive_rows"]==prior_replay["unequal_two_positive_rows"],
            "packed policy changed bytes beyond its two declared work words")
    counts = prior_paging
    require(final["paging"]["counts"] == counts, "pager counts differ")
    native = read(COHORT / ("train_" + MODE) / "process.json")
    files = {
        "operator/packager.py": Path(__file__), "operator/launcher.py": launcher,
        "controls/runner.py": WORK / "check-dyadic-packed-controls3.py",
    }
    build_paths = {"virtual-dyadic-state-controls": "dypacked-controls-build2/virtual-dyadic-state-controls",
                   "dyadic-policy-controls": "dypacked-controls-build1/dyadic-policy-controls",
                   "packed-signed-update-controls": "dypacked-controls-build1/packed-signed-update-controls",
                   "dyadic-policy-division-controls": "dypacked-controls-build1/dyadic-policy-division-controls"}
    for control, relative in build_paths.items():
        path = WORK / relative / "native-exact-build-manifest.json"
        require(digest(path) == controls["builds"][relative]["manifest_sha256"], "control build identity differs")
        files[f"controls/builds/{control}.json"] = path
    for prefix, folder in (("operator", OPERATOR), ("cohort", COHORT), ("controls", CONTROLS)):
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(folder)
            if prefix == "cohort" and (relative.parts[0] == "source" or
                    relative.parts[0] == "build" and path != build_path or
                    path.name in ("committed.bin", "staged.bin", "expanded.bin")):
                continue
            files[f"{prefix}/{relative.as_posix()}"] = path
    timing = WORK / "dypacked-timing1"
    timing_result = read(timing / "result.json")
    require(read(timing / "terminal.json")["status"] == "complete" and timing_result["source_head"] == HEAD and
            timing_result["pairs"] == 4 and timing_result["training_invocations"] == 8 and
            timing_result["raw_source_stable"] and timing_result["all_complete_streams_and_checkpoint_images_exact"] and
            read(timing / "source-before.json") == read(timing / "source-after.json") == hashes,
            "timing provenance or terminal status differs")
    files["timing/runner.py"] = WORK / "compare-dyadic-packed-timing.py"
    for name in ("configuration.json", "result.json", "terminal.json", "source-before.json", "source-after.json"):
        files["timing/" + name] = timing / name
    for run in sorted(timing.glob("pair-*")):
        for child in ("verified.json", "process/process.json", "page-images/paging.json"):
            files["timing/" + run.name + "/" + child] = run / child
    training_sources=set(build["source_sha256"])
    for path in (OPERATOR / "bootstrap.json", COHORT / "saved-review-bootstrap.json"):
        training_sources.update(read(path)["compiled"])
    training_sources.update(timing_result["imported_source_closure"])
    control_hashes=read(CONTROLS / "source-before.json")
    control_sources=set()
    for relative in build_paths.values():
        control_sources.update(read(WORK / relative / "native-exact-build-manifest.json")["source_sha256"])
    for mode in ("normal","optimized"):
        control_sources.update(read(CONTROLS / mode / "bootstrap.json")["compiled"])
    changed={name for name in hashes if hashes[name]!=control_hashes.get(name)}
    require(changed=={"tests/native/virtual_dyadic_state_controls.cpp",
                      "tests/test_native_virtual_dyadic_state.py"} and
            set(hashes)==set(control_hashes),"training/control source difference exceeds test repairs")
    archived_sources={}
    for label,names,folder,expected_hashes in (
            ("training",training_sources,WORK/"dypacked-src1",hashes),
            ("controls",control_sources,WORK/"dypacked-controls-src3",control_hashes)):
        archived_sources[label]={}
        for name in sorted(names):
            path=folder/name
            require(name in expected_hashes and digest(path)==expected_hashes[name],
                    "archived source bytes differ")
            files["source/"+label+"/"+name]=path
            archived_sources[label][name]=expected_hashes[name]
    files["controls/first-attempt/runner.py"]=WORK/"check-dyadic-packed-controls2.py"
    files["controls/first-attempt/operator.log"]=WORK/"dypacked-controls-operator2.log"
    for path in sorted((WORK/"dypacked-controls2").rglob("*")):
        if path.is_file():
            files["controls/first-attempt/"+path.relative_to(WORK/"dypacked-controls2").as_posix()]=path
    first_hashes=read(WORK/"dypacked-controls2/source-before.json")
    for name in ("tests/test_native_virtual_dyadic_state.py",
                 "tests/native/virtual_dyadic_state_controls.cpp"):
        path=WORK/"dypacked-controls-src2"/name
        require(digest(path)==first_hashes[name],"first failure source differs")
        files["controls/first-attempt/source/"+name]=path
    inventory = {name: {"bytes": path.stat().st_size, "sha256": digest(path)} for name, path in files.items()}
    RESULT.mkdir()
    archive_path = RESULT / "verification.zip"
    with ZipFile(archive_path, "x", ZIP_DEFLATED) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, name)
        archive.writestr("inventory.json", json.dumps(inventory, indent=2, sort_keys=True))
    with ZipFile(archive_path) as archive:
        require(archive.testzip() is None, "archive failed integrity check")
        for name, meta in inventory.items():
            with archive.open(name) as stream:
                require(archive.getinfo(name).file_size == meta["bytes"] and
                        file_digest(stream, "sha256").hexdigest() == meta["sha256"], "archive member differs")
    manifest = {
        "version": RESULT.name, "source_head": HEAD, "control_source_head": CONTROL_HEAD, "source_files": len(hashes),
        "prior_manifest_sha256": links["manifest.json"], "training_invocations": 1,
        "admission": final["admission"], "focused_controls_per_mode": controls["tests_per_mode"],
        "native_seconds": native["duration_seconds"], "quality_gate": final["quality_gate"],
        "timing": timing_result,
        "accounting_model": "weighted-divmod-invocations-plus-fixed-stride-word-scan",
        "primitive_operation_bound": "not established by this study",
        "packed_policy": final["packed_policy"],
        "saved_integer_imports": 2*final["admission"]["slots"]-final["packed_policy"]["imported_slots"],
        "native_packed_control_vectors": 560,
        "archived_source_closure": archived_sources,
        "timing_host": "same Windows host, four alternating pairs, no broader suite active; other load uncontrolled",
        "first_control_attempt": "85 tests, one parser failure; preserved, corrected before accepted normal/optimized controls",
        "paging_before": prior_paging, "paging_after": counts, "compact_sweep_capture": capture,
        "saved_only_replay": replay, "changed_footer_words": 2,
        "work_before": prior_replay["work_plan"], "work_after": replay["work_plan"],
        "actual_work_before": prior_replay["work_actual"], "actual_work_after": replay["work_actual"],
        "composed_work_before": prior["admission"]["factored_composed_work"],
        "composed_work_after": final["admission"]["factored_composed_work"],
        "eleven_card_projection": projected,
        "eleven_card_projection_scope": "unchanged baseline; packed-policy training is ten-card only",
        "archive": {"path": archive_path.name, "bytes": archive_path.stat().st_size,
                    "sha256": digest(archive_path), "members": len(inventory)+1},
    }
    (RESULT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps(manifest["archive"], sort_keys=True))


if __name__ == "__main__":
    main()

