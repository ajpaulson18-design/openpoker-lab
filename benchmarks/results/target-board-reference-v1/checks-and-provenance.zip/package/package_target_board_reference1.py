"""Package the frozen target-board reference and its exact replay evidence.

This preparer creates four small ZIPs and a hash manifest only when explicitly
run. It never runs the generator, reference math, reader, or tests.
"""
from __future__ import annotations

import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path, PurePosixPath


WORK = Path(__file__).resolve().parent
REPO = WORK / 'dyprofile-repo'
ARTIFACT = WORK / 'target-board-reference-artifact1'
OUT = WORK / 'target-board-reference-package1'
EXECUTION_RECEIPT = WORK / 'target-board-artifact1-execution-receipt.json'
REFUSAL_LOG = WORK / 'target-board-reference-artifact1.log'
CAPTURE_HEAD = '3564e4cd06f45dbd8c4863fbc01fe2837bd6994b'
FIRST_READER_HEAD = '961e7d834db5a186be951adf6a166f7d69f45931'
READER_HEAD = 'efffb416349ea80ad703d7eef291457bb6b22f63'
MAX_MEMBER = 8 * 1024 * 1024
MAX_ARTIFACT = 32 * 1024 * 1024
MAX_EXPANDED = 80 * 1024 * 1024
MAX_ARCHIVE = 8 * 1024 * 1024
PROFILE_NAMES = ('uniform', 'zero-skew')
SOURCES = (
    'pokerlab/__init__.py', 'pokerlab/cards.py',
    'scripts/matrix_free_certificate_budget.py', 'scripts/matrix_free_four_street_rules.py',
    'scripts/preflop_validation.py', 'tests/full_deck_public_chance_reference.py',
    'tests/test_native_dyadic_policy.py', 'tests/test_native_exact_reach.py',
    'tests/virtual_betting_template_reference.py', 'tests/virtual_dyadic_training_reference.py',
    'tests/virtual_frozen_run_control.py', 'tests/virtual_frozen_update_reference.py',
    'tests/virtual_frozen_value_reference.py',
    'scripts/replay_native_frozen_policy_state.py',
    'tests/virtual_frozen_sample_reference.py', 'tests/virtual_grid_update_reference.py',
    'tests/virtual_target_board_reference.py', 'tests/test_target_board_reference.py',
    'tests/virtual_frozen_policy_input_reference.py',
    'scripts/freeze_target_board_reference.py',
)
FAILURE_LOGS = tuple(f'target-board-reference{i}-normal.log' for i in (1, 2, 3))
SUCCESS_LOGS = ('target-board-reference4-normal.log', 'target-board-reference4-optimized.log')
LEGACY_REPLAY_LOGS = ('target-board-replay1-normal.log', 'target-board-replay2-optimized.log')
REPLAY_LOGS = ('target-board-replay3-normal.log', 'target-board-replay4-optimized.log')


def fail(message: str) -> None:
    raise RuntimeError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str, input_bytes: bytes | None = None) -> bytes:
    result = subprocess.run(['git', *args], cwd=REPO, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, input=input_bytes, check=False)
    if result.returncode != 0:
        fail(f'git {args[0]} failed: {result.stderr.decode("utf-8", "replace")[:1000]}')
    return result.stdout


def git_text(*args: str) -> str:
    return git(*args).decode('ascii').strip()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode('utf-8')


def read_json(path: Path, limit: int = 1 << 20) -> dict:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > limit:
        fail(f'missing or oversized JSON evidence: {path.name}')
    return json.loads(path.read_text(encoding='utf-8'))


def bounded(path: Path, limit: int = MAX_MEMBER) -> bytes:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > limit:
        fail(f'missing, linked, or oversized evidence member: {path}')
    data = path.read_bytes()
    if len(data) != path.stat().st_size or len(data) > limit:
        fail(f'bounded read mismatch: {path}')
    return data


def safe_path(name: str) -> str:
    if '\\' in name or name.startswith('/'):
        fail(f'unsafe archive path: {name!r}')
    path = PurePosixPath(name)
    if not name or any(part in ('', '.', '..') for part in path.parts):
        fail(f'unsafe archive path: {name!r}')
    return path.as_posix()


def put(files: dict[str, bytes], name: str, data: bytes) -> None:
    name = safe_path(name)
    if name in files:
        fail(f'duplicate archive member: {name}')
    if len(data) > MAX_MEMBER:
        fail(f'archive member exceeds 8 MiB: {name} ({len(data)} bytes)')
    files[name] = data


def verify_artifact() -> tuple[dict, dict, dict[str, bytes], int]:
    result_raw = bounded(ARTIFACT / 'result.json', 1 << 20)
    proof_raw = bounded(ARTIFACT / 'input-proof.json', 1 << 20)
    result = json.loads(result_raw)
    proof = json.loads(proof_raw)
    if result.get('format') != 'frozen-target-board-expectation-v1':
        fail('unexpected immutable result format')
    if result.get('source_head') != CAPTURE_HEAD or proof.get('source_head') != CAPTURE_HEAD:
        fail('artifact captured source HEAD differs from pinned source')
    if proof.get('format') != 'target-board-reference-input-v1':
        fail('unexpected input proof format')
    if proof.get('native_calls') != 0 or proof.get('rng_calls') != 0 or proof.get('requested_board_calls') != 120:
        fail('input proof claims an unexpected execution scope')
    if len(SOURCES) != 20 or set(result.get('source_files', {})) != set(SOURCES):
        fail('artifact source closure is not exactly twenty files')
    if proof.get('source_files') != result['source_files']:
        fail('input proof and result source inventories differ')
    source_tree = {}
    for line in git('ls-tree', '-r', CAPTURE_HEAD).decode('utf-8').splitlines():
        metadata, name = line.split('\t', 1)
        source_tree[name] = metadata.split()[2]
    files: dict[str, bytes] = {}
    seen_paths = set()
    source_total = 0
    for path in sorted(ARTIFACT.rglob('*')):
        if path.is_symlink():
            fail(f'symlink refused in frozen artifact: {path}')
        if path.is_file():
            relative = path.relative_to(ARTIFACT).as_posix()
            if '\\' in relative or '..' in PurePosixPath(relative).parts:
                fail(f'unsafe frozen artifact path: {relative}')
            seen_paths.add(relative)
            data = bounded(path)
            files[relative] = data
            if relative.startswith('source/'):
                source_total += len(data)
                if len(data) > 2 * 1024 * 1024 or source_total > 64 * 1024 * 1024:
                    fail('frozen source closure size limit')
                name = relative[len('source/'):]
                row = result['source_files'].get(name)
                if row is None or sha(data) != row.get('raw_sha256') or len(data) != row.get('bytes'):
                    fail(f'frozen raw source hash mismatch: {name}')
                if source_tree.get(name) != row.get('git_blob'):
                    fail(f'frozen committed blob mismatch: {name}')
                canonical = git('show', f'{CAPTURE_HEAD}:{name}')
                git_blob = git('hash-object', '--stdin', input_bytes=canonical).decode('ascii').strip()
                if git_blob != row['git_blob'] or not (
                    data == canonical or (b'\r' not in canonical and data == canonical.replace(b'\n', b'\r\n'))
                ):
                    fail(f'frozen raw copy does not match committed bytes: {name}')

    expected = ({'result.json', 'input-proof.json', 'input-uniform.bin', 'input-zero-skew.bin',
                 'expected-uniform.bin', 'expected-zero-skew.bin'} |
                {'source/' + name for name in SOURCES})
    if seen_paths != expected or len(files) != 26:
        fail('frozen artifact member inventory is not the exact 26-file set')
    artifact_total = sum(map(len, files.values()))
    if artifact_total != 23_513_442 or artifact_total > MAX_ARTIFACT:
        fail('frozen artifact total byte count differs from execution receipt or 32 MiB cap')
    if len(result_raw) != 26_708 or sha(result_raw) != '33cce03e68634acce98f888806631615f545c721fcc64aacbfd7622028062faf':
        fail('immutable result bytes/hash differ from recorded first successful run')
    if result.get('members') != {
        name: {'bytes': len(data), 'sha256': sha(data)}
        for name, data in sorted(files.items()) if name != 'result.json'
    }:
        fail('result manifest hashes do not cover the frozen artifact members')
    if proof.get('output_cap_bytes') != MAX_ARTIFACT or proof.get('output_forecast_bytes', 0) > MAX_ARTIFACT:
        fail('artifact output reservation differs from the fixed cap')
    if source_total != result.get('source_total_bytes'):
        fail('saved source total differs from immutable result manifest')
    profiles = result.get('profiles')
    if not isinstance(profiles, list) or tuple(row.get('profile') for row in profiles) != PROFILE_NAMES:
        fail('artifact profile list/order differs')
    for profile in profiles:
        name = profile['profile']
        if profile.get('rows') != 24_420 or profile.get('slots') != 58_164 or profile.get('positive_board_calls') != 60:
            fail(f'incomplete saved expectation profile: {name}')
        if profile.get('literal_expectation_match') is not True or profile.get('coordinate_second_moment_bound_proved') is not True:
            fail(f'profile lacks literal equality or exact moment certificate: {name}')
        for label, path in (('input_policy', f'input-{name}.bin'), ('expected_table', f'expected-{name}.bin')):
            row = profile.get(label, {})
            if row != {'bytes': len(files[path]), 'sha256': sha(files[path])}:
                fail(f'profile {label} receipt mismatch: {name}')
    if result.get('calls') != {'target_board_operator_calls': 120, 'native_calls': 0,
                               'rng_calls': 0, 'training_iterations': 0}:
        fail('artifact execution scope changed')
    return result, proof, files, artifact_total


def verify_replay_logs(result: dict) -> tuple[dict[str, bytes], dict, dict[str, bytes], dict]:
    reports = {}
    artifact_profiles = {row['profile']: row for row in result.get('profiles', [])}
    for name in REPLAY_LOGS:
        raw = bounded(WORK / name, MAX_MEMBER)
        report = json.loads(raw)
        if report.get('status') != 'all-target-board-expectations-exact':
            fail(f'pending or failed exact replayer log: {name}')
        if report.get('artifact_source_head') != CAPTURE_HEAD or report.get('authenticated_sources') != 20:
            fail(f'replay report source identity mismatch: {name}')
        if report.get('artifact_members') != 25 or report.get('native_calls') != 0 or report.get('rng_calls') != 0:
            fail(f'replay report scope mismatch: {name}')
        if report.get('active_replay_head') != READER_HEAD:
            fail(f'replay did not run the pinned reader commit: {name}')
        if report.get('artifact_total_bytes') != 23_513_442:
            fail(f'replay report artifact byte total mismatch: {name}')
        profiles = report.get('profiles', [])
        if tuple(p.get('profile') for p in profiles) != PROFILE_NAMES or any(
                p.get('rows') != 24_420 or p.get('slots') != 58_164 or p.get('board_calls') != 60
                for p in profiles):
            fail(f'replay result census mismatch: {name}')
        for profile in profiles:
            saved = artifact_profiles.get(profile['profile'])
            if saved is None or profile.get('input_sha256') != saved['input_policy']['sha256'] or \
                    profile.get('table_sha256') != saved['expected_table']['sha256']:
                fail(f'replay report does not bind exact saved profile bytes: {name}/{profile.get("profile")}')
        reports[name] = report
    if reports[REPLAY_LOGS[0]] != reports[REPLAY_LOGS[1]]:
        fail('normal and optimized source-only replay reports differ')
    legacy_reports = {}
    for name in LEGACY_REPLAY_LOGS:
        raw = bounded(WORK / name, MAX_MEMBER)
        report = json.loads(raw)
        if report.get('status') != 'all-target-board-expectations-exact' or \
                report.get('active_replay_head') != FIRST_READER_HEAD:
            fail(f'legacy reader report identity mismatch: {name}')
        legacy_reports[name] = report
    if legacy_reports[LEGACY_REPLAY_LOGS[0]] != legacy_reports[LEGACY_REPLAY_LOGS[1]]:
        fail('legacy normal and optimized reports differ')
    return ({name: bounded(WORK / name, MAX_MEMBER) for name in REPLAY_LOGS},
            reports[REPLAY_LOGS[0]],
            {name: bounded(WORK / name, MAX_MEMBER) for name in LEGACY_REPLAY_LOGS},
            legacy_reports[LEGACY_REPLAY_LOGS[0]])


def verify_reader_and_delta(result: dict) -> tuple[bytes, bytes, bytes, bytes, bytes, dict]:
    if git_text('rev-parse', '--verify', f'{READER_HEAD}^{{commit}}') != READER_HEAD:
        fail('pinned reader commit is unavailable')
    reader_path = 'scripts/replay_target_board_reference.py'
    if git_text('rev-parse', '--verify', f'{FIRST_READER_HEAD}^{{commit}}') != FIRST_READER_HEAD:
        fail('first reader commit is unavailable')
    first_reader = git('show', f'{FIRST_READER_HEAD}:{reader_path}')
    tree_reader = git_text('rev-parse', f'{READER_HEAD}:{reader_path}')
    reader = git('show', f'{READER_HEAD}:{reader_path}')
    current = bounded(REPO / reader_path, MAX_MEMBER)
    current_head = git_text('rev-parse', 'HEAD')
    active_tree = {}
    for line in git('ls-tree', '-r', current_head).decode('utf-8').splitlines():
        metadata, name = line.split('\t', 1)
        active_tree[name] = metadata.split()[2]
    if not (current == reader or (b'\r' not in reader and current == reader.replace(b'\n', b'\r\n'))) or \
            active_tree.get(reader_path) != tree_reader:
        fail('current reader bytes differ from the frozen reader commit')
    captured_tree = {}
    reader_tree = {}
    first_tree = {}
    for commit, target in ((CAPTURE_HEAD, captured_tree), (FIRST_READER_HEAD, first_tree),
                           (READER_HEAD, reader_tree)):
        for line in git('ls-tree', '-r', commit).decode('utf-8').splitlines():
            metadata, name = line.split('\t', 1)
            target[name] = metadata.split()[2]
    changed_math = [name for name in SOURCES if captured_tree.get(name) != reader_tree.get(name)]
    changed_first_math = [name for name in SOURCES if captured_tree.get(name) != first_tree.get(name)]
    if changed_math or changed_first_math:
        fail('the independent math/source closure changed after the frozen artifact: ' +
             ', '.join(sorted(set(changed_math + changed_first_math))))
    initial_patch = git('diff', '--binary', CAPTURE_HEAD, FIRST_READER_HEAD, '--', reader_path)
    portability_patch = git('diff', '--binary', FIRST_READER_HEAD, READER_HEAD, '--', reader_path)
    patch = git('diff', '--binary', CAPTURE_HEAD, READER_HEAD, '--', reader_path)
    if any(not value or b'diff --git a/scripts/replay_target_board_reference.py' not in value
           for value in (initial_patch, portability_patch, patch)):
        fail('frozen reader source difference is unavailable')
    receipt = {
        'captured_math_source_head': CAPTURE_HEAD,
        'first_reader_source_commit': FIRST_READER_HEAD,
        'reader_source_commit': READER_HEAD,
        'reader_git_blob': tree_reader,
        'reader_bytes': len(reader), 'reader_sha256': sha(reader),
        'first_reader_bytes': len(first_reader), 'first_reader_sha256': sha(first_reader),
        'changed_captured_math_sources': changed_math,
        'source_difference': 'the captured twenty-file math closure is unchanged; the reader was added at the first reader commit and then received the exact Git LF/CRLF portability correction',
        'reader_patch_bytes': len(patch), 'reader_patch_sha256': sha(patch),
        'first_reader_patch_bytes': len(initial_patch), 'first_reader_patch_sha256': sha(initial_patch),
        'portability_patch_bytes': len(portability_patch), 'portability_patch_sha256': sha(portability_patch),
        'current_checkout_head': current_head,
    }
    return reader, first_reader, initial_patch, portability_patch, patch, receipt


def zip_bytes(files: dict[str, bytes]) -> tuple[bytes, dict]:
    if 'members.json' in files:
        fail('reserved inner inventory name collision')
    expanded = sum(len(data) for data in files.values())
    if expanded > MAX_EXPANDED:
        fail(f'expanded archive exceeds 80 MiB: {expanded}')
    inventory = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())}
    members = json_bytes(inventory)
    if len(members) > MAX_MEMBER:
        fail('inner members.json exceeds the member size ceiling')
    complete = dict(inventory)
    complete['members.json'] = {'bytes': len(members), 'sha256': sha(members)}
    expanded += len(members)
    if expanded > MAX_EXPANDED:
        fail(f'expanded archive including members.json exceeds 80 MiB: {expanded}')
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 23, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
        info = zipfile.ZipInfo('members.json', (2026, 11, 23, 0, 0, 0))
        info.compress_type = zipfile.ZIP_STORED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, members)
    payload = buffer.getvalue()
    if len(payload) > MAX_ARCHIVE:
        fail(f'archive exceeds 8 MiB: {len(payload)}')
    return payload, {'expanded_bytes': expanded, 'member_count': len(complete),
                     'inventory': complete, 'sha256': sha(payload), 'bytes': len(payload)}


def build_package() -> dict:
    if OUT.exists():
        fail(f'refusing to overwrite existing package directory: {OUT}')
    result, proof, artifact_files, artifact_total = verify_artifact()
    receipt_raw = bounded(EXECUTION_RECEIPT, MAX_MEMBER)
    execution = json.loads(receipt_raw)
    if execution.get('source_head') != CAPTURE_HEAD or execution.get('result_sha256') != sha(artifact_files['result.json']):
        fail('artifact first-execution receipt does not match the preserved data')
    if execution.get('observed_python_exit') is not None:
        fail('unexpected top-level first invocation field')
    first = execution.get('first_invocation', {})
    second = execution.get('second_invocation', {})
    provenance = execution.get('console_provenance', {})
    if (first.get('tool_session') != 99512 or first.get('observed_python_exit') != 0 or
            second.get('observed_python_exit') != 1 or second.get('mathematical_calls_entered') != 0 or
            'fresh directory' not in second.get('refusal', '') or
            provenance.get('first_console_log_overwritten_by_second_refusal') is not True or
            provenance.get('original_console_log_available') is not False):
        fail('historical artifact execution receipt does not preserve both outcomes accurately')
    refusal = bounded(REFUSAL_LOG, MAX_MEMBER)
    if b'destination must be a fresh directory' not in refusal:
        fail('available artifact console log is not the retained second-invocation refusal')

    replay_logs, replay_report, legacy_replay_logs, legacy_replay_report = verify_replay_logs(result)
    reader, first_reader, initial_patch, portability_patch, patch, reader_receipt = verify_reader_and_delta(result)
    current_head = git_text('rev-parse', 'HEAD')

    checks = {}
    for filename in (*FAILURE_LOGS, *SUCCESS_LOGS):
        raw = bounded(WORK / filename, MAX_MEMBER)
        checks[filename] = raw
    for filename in SUCCESS_LOGS:
        raw = checks[filename].decode('utf-8', 'replace')
        if 'Ran 5 tests' not in raw or 'OK' not in raw:
            fail(f'reference test log does not show five passing checks: {filename}')
    for filename in FAILURE_LOGS:
        if not checks[filename]:
            fail(f'historical failed phase log is empty: {filename}')

    source_archive: dict[str, bytes] = {}
    for name in SOURCES:
        put(source_archive, 'artifact/source/' + name, artifact_files['source/' + name])
    put(source_archive, 'reader/scripts/replay_target_board_reference.py', reader)
    put(source_archive, 'reader/development/replay_target_board_reference-961e7d8.py', first_reader)
    put(source_archive, 'source-differences/reader-added.patch', initial_patch)
    put(source_archive, 'source-differences/reader-line-ending-portability-fix.patch', portability_patch)
    put(source_archive, 'source-differences/reader-captured-to-final.patch', patch)
    put(source_archive, 'artifact/input-proof.json', artifact_files['input-proof.json'])
    put(source_archive, 'artifact/input-uniform.bin', artifact_files['input-uniform.bin'])
    put(source_archive, 'artifact/input-zero-skew.bin', artifact_files['input-zero-skew.bin'])

    checks_archive: dict[str, bytes] = {}
    put(checks_archive, 'artifact/result.json', artifact_files['result.json'])
    put(checks_archive, 'execution/first-and-refused-invocations.json', receipt_raw)
    put(checks_archive, 'execution/available-console-is-second-refusal.log', refusal)
    for filename, raw in checks.items():
        classification = 'historical-failure' if filename in FAILURE_LOGS else 'successful-reference-tests'
        put(checks_archive, f'checks/{classification}/{filename}', raw)
    for filename, raw in legacy_replay_logs.items():
        mode = 'normal' if 'normal' in filename else 'optimized'
        put(checks_archive, f'checks/development-reader-961e7d8/{mode}.json', raw)
    for filename, raw in replay_logs.items():
        mode = 'normal' if 'normal' in filename else 'optimized'
        put(checks_archive, f'checks/independent-replay/{mode}.json', raw)
    put(checks_archive, 'reader/normal-optimized-report-summary.json', json_bytes({
        'status': replay_report['status'], 'active_replay_head': replay_report['active_replay_head'],
        'profiles': replay_report['profiles'], 'archived_source_executed': replay_report['archived_source_executed'],
        'native_calls': replay_report['native_calls'], 'rng_calls': replay_report['rng_calls'],
        'training_iterations': replay_report['training_iterations'], 'quality_gate': replay_report['quality_gate'],
        'scope': replay_report['scope'],
    }))

    package_script = Path(__file__).read_bytes()
    put(checks_archive, 'package/package_target_board_reference1.py', package_script)

    archives: dict[str, dict[str, bytes]] = {
        'source-and-policies.zip': source_archive,
        'expected-uniform.zip': {
            'artifact/expected-uniform.bin': artifact_files['expected-uniform.bin'],
            'metadata/profile-uniform.json': json_bytes(result['profiles'][0]),
        },
        'expected-zero-skew.zip': {
            'artifact/expected-zero-skew.bin': artifact_files['expected-zero-skew.bin'],
            'metadata/profile-zero-skew.json': json_bytes(result['profiles'][1]),
        },
        'checks-and-provenance.zip': checks_archive,
    }
    packed = {}
    inventories = {}
    for archive_name, files in archives.items():
        payload, info = zip_bytes(files)
        packed[archive_name] = payload
        inventories[archive_name] = info

    artifact_inventory = {
        name: {'bytes': len(data), 'sha256': sha(data)}
        for name, data in sorted(artifact_files.items())
    }
    manifest = {
        'schema': 'target-board-reference-evidence-package-v1',
        'artifact_source_head': CAPTURE_HEAD,
        'reader_source_commit': READER_HEAD,
        'packaging_checkout_head': current_head,
        'scope': 'Exact fixed-policy PROOF9 target-board expectation reference and its independent saved replay; no training, convergence, quality, N11 or full-range claim.',
        'artifact': {
            'members_including_result': len(artifact_files), 'total_bytes': artifact_total,
            'result_sha256': sha(artifact_files['result.json']),
            'source_file_count': len(SOURCES), 'source_total_bytes': result['source_total_bytes'],
            'inventory': artifact_inventory,
        },
        'artifact_execution_receipt': {
            'first_invocation_exit': first['observed_python_exit'],
            'first_tool_session': first['tool_session'],
            'second_invocation_exit': second['observed_python_exit'],
            'second_invocation_refused_before_math': second['mathematical_calls_entered'] == 0,
            'original_first_console_log_available': False,
            'available_console_file_classification': 'second invocation fresh-destination refusal; never evidence of first invocation stdout',
        },
        'reader_source': reader_receipt,
        'reader_modes': {
            'normal': 'successful exact independent replay with final cross-platform source authentication; full JSON report is packaged',
            'optimized': 'successful exact independent replay with final cross-platform source authentication; full JSON report is packaged',
            'matching_reports': True,
            'earlier_reader_reports': 'preserved as development evidence; these used reader commit 961e7d8 before the exact LF/CRLF fix',
            'earlier_reports_status': legacy_replay_report['status'],
        },
        'checks': {
            **{name: {'classification': 'historical-failure-preserved', 'bytes': len(checks[name]),
                      'sha256': sha(checks[name])} for name in FAILURE_LOGS},
            **{name: {'classification': 'successful-five-test-run', 'bytes': len(checks[name]),
                      'sha256': sha(checks[name])} for name in SUCCESS_LOGS},
            'target-board-reference-artifact1.log': {
                'classification': 'second invocation refusal; original first console unavailable',
                'bytes': len(refusal), 'sha256': sha(refusal),
            },
        },
        'limits': {'max_member_bytes': MAX_MEMBER, 'max_archive_bytes': MAX_ARCHIVE,
                   'max_expanded_archive_bytes': MAX_EXPANDED, 'max_artifact_bytes': MAX_ARTIFACT,
                   'zip_compression': 'stored to guarantee bounded archive size'},
        'package_script': {'path': '../package_target_board_reference1.py',
                           'bytes': len(package_script), 'sha256': sha(package_script)},
        'archives': inventories,
    }
    OUT.mkdir(parents=True, exist_ok=False)
    for name, payload in packed.items():
        (OUT / name).write_bytes(payload)
    manifest_raw = json_bytes(manifest)
    (OUT / 'manifest.json').write_bytes(manifest_raw)
    return {'output': str(OUT), 'archives': {
        name: {'bytes': info['bytes'], 'sha256': info['sha256'],
               'member_count': info['member_count'], 'expanded_bytes': info['expanded_bytes']}
        for name, info in sorted(inventories.items())},
        'manifest_bytes': len(manifest_raw), 'manifest_sha256': sha(manifest_raw),
        'artifact_source_head': CAPTURE_HEAD, 'reader_source_commit': READER_HEAD,
        'current_checkout_head': current_head, 'artifact_members': len(artifact_files),
        'artifact_bytes': artifact_total, 'normal_optimized_replay_reports_identical': True}


if __name__ == '__main__':
    print(json.dumps(build_package(), sort_keys=True))
