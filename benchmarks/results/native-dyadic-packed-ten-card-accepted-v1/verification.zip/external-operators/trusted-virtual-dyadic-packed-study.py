"""Observe one committed packed-checkpoint conversion and saved-only replay."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import runpy
import sys
import time
import zlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'baseline', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    source = args.repo.resolve(strict=True)
    baseline = args.baseline.resolve(strict=True)
    output = args.output.resolve()
    require(not output.is_relative_to(source) and not output.is_relative_to(baseline), 'study needs external fresh output')
    helper = Path(__file__).with_name('trusted-virtual-dyadic-training-launch-v12.py')
    operator = runpy.run_path(str(helper))
    git, snapshot, sha, observe, save = (operator[name] for name in ('git', 'snapshot', 'sha', 'observe', 'save'))
    require(git(source, 'rev-parse', 'HEAD').decode().strip() == args.head, 'study source HEAD differs')
    before = snapshot(source)
    accepted_path = 'benchmarks/results/native-dyadic-buffered-ten-card-accepted-v1/manifest.json'
    accepted_raw = git(source, 'show', '69dc7b4c7b4cd3221fc85eef565b894db71ea0e9:' + accepted_path)
    accepted = json.loads(accepted_raw)
    require(accepted['status'] == 'accepted_buffered_ten_card_training_and_replay'
            and (source / accepted_path).read_bytes().replace(b'\r\n', b'\n') == accepted_raw, 'baseline receipt drift')
    inputs = accepted['checkpoint_inputs']
    old_replay = accepted['saved_only_replay']
    scaffold = baseline / 'train_ten_buffered/stdout.bin'
    images = baseline / 'page-images'
    raw_hashes = [item['sha256'] for item in inputs['sweep_images']]
    require(sha(scaffold) == inputs['stream']['sha256']
            and all(sha(images / item['name']) == item['sha256'] for item in inputs['sweep_images']),
            'saved baseline bytes differ')
    bootstrap_path = 'scripts/run_virtual_frozen_source_only.py'
    bootstrap = source / bootstrap_path
    raw = bootstrap.read_bytes()
    require(raw.replace(b'\r\n', b'\n') == git(source, 'show', args.head + ':' + bootstrap_path), 'bootstrap source drift')
    stages = [ast.literal_eval(node.value) for node in ast.parse(raw).body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'FIRST_STAGE' for target in node.targets)]
    require(len(stages) == 1 and isinstance(stages[0], str), 'bootstrap first stage differs')
    digest = hashlib.sha256(raw).hexdigest()
    output.mkdir()
    save(output / 'source-before.json', before)
    operator_hashes = {path.name: sha(path) for path in (Path(__file__), helper)}
    save(output / 'operator-identity.json', operator_hashes)
    observations = {}

    def run(label, module, arguments):
        evidence = output / label
        evidence.mkdir()
        receipt = evidence / 'bootstrap.json'
        command = [sys.executable, '-I', '-S', '-B', '-c', stages[0], str(bootstrap), digest,
                   '--module', module, '--receipt', str(receipt), '--', *map(str, arguments)]
        start = time.perf_counter()
        result = observe(command, source, evidence)
        observations[label] = {**result, 'elapsed_seconds': time.perf_counter() - start}
        require((evidence / 'stderr.log').stat().st_size == 0, 'unexpected study child stderr')
        boot = json.loads(receipt.read_bytes())
        require(boot['entry_module'] == module and boot['trusted_first_stage']['bootstrap_sha256'] == digest
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files']
                and all(before.get(name) == value for name, value in boot['compiled'].items()),
                'study bootstrap source identity differs')
        observations[label]['compiled_sources'] = len(boot['compiled'])
        return json.loads((evidence / 'stdout.log').read_bytes())

    packed = output / 'packed'
    packet = run('pack', 'scripts.pack_virtual_dyadic_checkpoints',
                 ['--page-images', images, '--output', packed, '--ten-card', '--sweep-image-sha256', *raw_hashes])
    require(packet == json.loads((packed / 'packet.json').read_bytes())
            and [row['raw'] for row in packet['images']] == inputs['sweep_images'], 'packed packet binding differs')
    encoded = [row['packed'] for row in packet['images']]
    replay = run('replay', 'scripts.verify_virtual_dyadic_training',
                 ['--saved', scaffold, '--sha256', inputs['stream']['sha256'], '--ten-card', '--paired', '--rank-sets',
                  '--packed-page-images', packed, '--sweep-image-sha256', *raw_hashes,
                  '--packed-sweep-image-sha256', *(row['sha256'] for row in encoded)])
    expected = dict(old_replay)
    expected['duration_seconds'] = replay['duration_seconds']
    expected['packed_checkpoint_images'] = encoded
    require(replay == expected and replay['native_producer_calls'] == 0, 'packed replay differs from accepted raw replay')
    for row in encoded:
        path = packed / row['name']
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'packed bytes changed')
    require(sha(scaffold) == inputs['stream']['sha256']
            and all(sha(images / item['name']) == item['sha256'] for item in inputs['sweep_images']),
            'saved baseline changed during study')
    after = snapshot(source)
    require(before == after and git(source, 'rev-parse', 'HEAD').decode().strip() == args.head,
            'frozen study source changed')
    save(output / 'source-after.json', after)
    result = {'status': 'saved_packed_ten_card_exact_replay_pass', 'head': args.head,
              'baseline_publication': '69dc7b4c7b4cd3221fc85eef565b894db71ea0e9',
              'baseline_manifest_sha256': hashlib.sha256(accepted_raw).hexdigest(),
              'checkpoint_inputs': inputs, 'packet': packet, 'observations': observations,
              'saved_only_replay': replay, 'raw_source_stable': True,
              'native_producer_calls': 0, 'zlib_runtime': zlib.ZLIB_RUNTIME_VERSION,
              'raw_image_bytes': sum(row['bytes'] for row in inputs['sweep_images']),
              'packed_image_bytes': sum(row['bytes'] for row in encoded),
              'packed_packet_bytes': inputs['stream']['bytes'] + sum(row['bytes'] for row in encoded)}
    save(output / 'completion.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'head', 'raw_image_bytes', 'packed_image_bytes',
                                                   'packed_packet_bytes', 'native_producer_calls', 'observations')}))


if __name__ == '__main__':
    main()
