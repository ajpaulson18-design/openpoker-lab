"""Publish packed sweep images and the observed saved-only study."""
import hashlib
import json
from pathlib import Path
import shutil
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
STUDY = WORK / 'dyt2-pgi-study1'
DEST = WORK / 'dyadic-training-repo/benchmarks/results/native-dyadic-packed-ten-card-accepted-v1'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    result = read(STUDY / 'completion.json')
    require(result['status'] == 'saved_packed_ten_card_exact_replay_pass'
            and result['native_producer_calls'] == 0 and result['raw_source_stable']
            and result['head'] == '0cde4ed9daa1742685f9e4835118f1ee757a6024'
            and result['packed_packet_bytes'] < result['raw_image_bytes'], 'packed study acceptance differs')
    require(read(STUDY / 'packed/packet.json') == result['packet'], 'packed receipt drift')
    source_hashes = read(STUDY / 'source-before.json')
    require(source_hashes == read(STUDY / 'source-after.json'), 'source manifest drift')
    for label in ('pack', 'replay'):
        observed = read(STUDY / label / 'exit.json')
        require(observed == {key: result['observations'][label][key] for key in observed}
                and observed == {'actual_exit_observed': True, 'returncode': 0, 'failures': []},
                'observed exit receipt differs')
        compiled = read(STUDY / label / 'bootstrap.json')['compiled']
        require('scripts/dyadic_checkpoint_transport.py' in compiled
                and all(source_hashes.get(name) == digest for name, digest in compiled.items()),
                'compiled source closure differs')
    images = [item['packed'] for item in result['packet']['images']]
    require(images == result['saved_only_replay']['packed_checkpoint_images'], 'packed checkpoint binding differs')
    DEST.mkdir(exist_ok=False)
    for item in images:
        source = STUDY / 'packed' / item['name']
        copied = DEST / item['name']
        require(source.stat().st_size == item['bytes'] and sha(source) == item['sha256'], 'source image drift')
        shutil.copyfile(source, copied)
        require(sha(copied) == item['sha256'], 'published image drift')
    logs = DEST / 'verification.zip'
    with ZipFile(logs, 'x', ZIP_DEFLATED) as archive:
        for file in sorted(STUDY.rglob('*')):
            if file.is_file() and file.suffix != '.pgi':
                archive.write(file, file.relative_to(STUDY).as_posix())
        for file in (Path(__file__), WORK / 'trusted-virtual-dyadic-packed-study.py',
                     WORK / 'trusted-virtual-dyadic-training-launch-v12.py'):
            archive.write(file, 'external-operators/' + file.name)
    with ZipFile(logs) as archive:
        require(archive.testzip() is None, 'verification archive differs')
    result['verification_archive'] = {'name': logs.name, 'bytes': logs.stat().st_size, 'sha256': sha(logs)}
    (DEST / 'manifest.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'path': str(DEST), 'packed_image_bytes': result['packed_image_bytes'],
                      'packed_packet_bytes': result['packed_packet_bytes'], 'images': images,
                      'verification': result['verification_archive']}, sort_keys=True))


if __name__ == '__main__':
    main()
