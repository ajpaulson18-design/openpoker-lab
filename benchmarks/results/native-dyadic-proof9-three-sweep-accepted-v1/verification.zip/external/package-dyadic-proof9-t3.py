"""Bind the PROOF9 T3 saved stream and independently rebuild the transient wire."""
import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-training-repo'
BASE = REPO/'benchmarks/results/native-dyadic-split-checkpoint-accepted-v1'
DEST = BASE.parent/'native-dyadic-proof9-three-sweep-accepted-v1'
EARLY = ('cohort/page-images/staged.bin', 'cohort/page-images/committed.bin')


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def reconstruct(numerical, frames, baseline_path, pages):
    digest = sha256()
    with numerical.open('rb') as stream, ZipFile(baseline_path) as baseline:
        digest.update(stream.read(8+16*8+11*8+1105*96+24420*24))
        for sweep, frame in enumerate(frames, 1):
            digest.update(stream.read(58164*8+4*12*8))
            body = baseline.read(EARLY[0]) if sweep==1 else (
                pages/('committed.bin' if sweep==2 else 'staged.bin')).read_bytes()
            require(frame=={'sweep':sweep,'slot':sweep%2,'bytes':len(body),
                            'sha256':sha256(body).hexdigest()}, 'image epoch differs')
            if sweep==2:
                require(baseline.read(EARLY[1])==body, 'second archived image differs')
            digest.update(struct.pack('<8sQQQ',b'OPLCPG01',sweep,sweep%2,len(body)))
            digest.update(body)
        digest.update(stream.read())
    return digest.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--head', required=True)
    p.add_argument('--cohort', type=Path, required=True)
    p.add_argument('--operator', type=Path, required=True)
    p.add_argument('--control-log', type=Path, action='append', required=True)
    args = p.parse_args()
    cohort, operator = args.cohort, args.operator
    run, outer = read(cohort/'result.json'), read(operator/'completion.json')
    require(run['head']==outer['head']==args.head and outer['mode']=='train_proof9_t3'
            and outer['raw_source_stable'] and run['training_invocations']==1
            and read(cohort/'terminal.json')['status']=='complete', 'source-frozen cohort incomplete')
    hashes = {name: item['raw_sha256'] for name,item in read(cohort/'source.json')['files'].items()}
    require(read(operator/'source-before.json')==read(operator/'source-after.json')==hashes,
            'source inventories differ')
    for path in (operator/'bootstrap.json',cohort/'saved-review-bootstrap.json'):
        boot = read(path)
        require(all(hashes.get(name)==digest for name,digest in boot['compiled'].items())
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    build_path = cohort/'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(identity(Path(build['executable']))['sha256']==build['executable_sha256']
            and all(hashes[name]==digest for name,digest in build['source_sha256'].items()), 'native build differs')
    build_hash = identity(build_path)['sha256']
    for label in ('admit_proof9_t3','train_proof9_t3'):
        binary = read(cohort/label/'binary-identity.json')
        require(binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                and binary['build_manifest_sha256']==build_hash, 'observed native binary differs')
    require(outer['actual_exit_observed'] and outer['returncode']==0 and not outer['failures'],
            'outer process exit differs')
    for label in ('admit_proof9_t3','train_proof9_t3','saved-review'):
        receipt = read(cohort/label/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures']
                and receipt['automatic_retries']==0, 'process exit differs')

    trained = cohort/'train_proof9_t3'
    capture, inputs, replay = (run[key] for key in ('sweep_capture','checkpoint_inputs','saved_only_replay'))
    numerical = trained/'stdout.bin'
    frames = capture['frames']
    require(identity(trained/'process.json')['sha256']==run['sweep_capture_process_sha256']
            and read(trained/'process.json')['sweep_capture']==capture and identity(numerical)==inputs['stream']
            and capture['retained_sha256']==inputs['stream']['sha256']==replay['saved_output_sha256']
            and replay['status']=='saved_three_sweep_exact_replay_pass'
            and replay['checkpoint_verification']=='independent_compact_digest'
            and frames==inputs['sweep_epochs']==replay['checkpoint_epochs'] and len(frames)==3
            and inputs['sweep_images']==replay['checkpoint_images']
            and replay['native_producer_calls']==0, 'digest replay binding differs')
    baseline_path = BASE/'evidence.zip'
    for item in (BASE/'manifest.json',baseline_path):
        require(identity(item)['sha256']==hashes[item.relative_to(REPO).as_posix()], 'baseline source differs')
    baseline = read(BASE/'manifest.json')
    require(baseline['status']=='accepted_split_checkpoint_training_and_replay'
            and identity(baseline_path)['sha256']==baseline['archive']['sha256'], 'baseline archive differs')
    pages = cohort/'page-images'
    require(reconstruct(numerical,frames,baseline_path,pages)==capture['wire_sha256']
            and numerical.stat().st_size+sum(32+f['bytes'] for f in frames)==capture['contract']['wire_bytes'],
            'complete wire reconstruction differs')
    files = {}
    for label,directory in (('cohort',cohort),('operator',operator)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(),'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label=='cohort' and (rel.parts[0]=='source' or
                    (rel.parts[0]=='build' and path.name!='native-exact-build-manifest.json') or
                    (rel.parts[0]=='page-images' and path.name=='committed.bin')):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__),WORK/'trusted-virtual-dyadic-training-launch-v19.py',
                 WORK/'project-dyadic-proof9-t3.py',WORK/'dyadic-proof9-t3-feasibility.json',
                 WORK/'project-dyadic-proof9-t3-chance.py',*args.control_log):
        files[f'external/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes']
                        and file_digest(stream,'sha256').hexdigest()==expected['sha256'],'archive member differs')
    manifest = {'status':'accepted_proof9_three_sweep_checkpoint_digest_replay','source_head':args.head,
                'baseline_source_head':baseline['source_head'],'operator':outer,
                'first_two_numerical_sweeps_match':True,'independent_wire_reconstruction':True,
                'earlier_checkpoint_archive':{'path':baseline_path.relative_to(REPO).as_posix(),
                    **identity(baseline_path),'members_by_sweep':dict(zip(('1','2'),EARLY))},
                **{key:run[key] for key in ('admission','sweep_capture','sweep_capture_process_sha256',
                    'checkpoint_inputs','paging','row_directory','policy_spill','proof9_t3_comparison',
                    'saved_only_replay','training_invocations','quality_gate')},
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observation':run['proof9_t3_comparison']['native_observation'],
                      'wire':capture['wire_sha256']},sort_keys=True))


if __name__=='__main__':
    main()
