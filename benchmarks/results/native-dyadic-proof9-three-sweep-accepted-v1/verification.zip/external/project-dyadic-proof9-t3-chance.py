from collections import Counter
from itertools import combinations, permutations
from functools import lru_cache
import json
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parent/'dyadic-training-repo'
sys.path.insert(0,str(REPO))
from tests.full_deck_public_chance_reference import PROOF9
from tests.virtual_dyadic_training_reference import build_reference_template, _template_case, scaled_proof9_ranges

ranges = tuple(tuple(set(hand) for hand,_ in side) for side in scaled_proof9_ranges())
legal = [(a,b) for a in ranges[0] for b in ranges[1] if a.isdisjoint(b)]
prefixes = {k:set() for k in (0,3,4,5)}
for a,b in legal:
    left = set(PROOF9)-a-b
    for flop in combinations(sorted(left),3):
        for reveal in permutations(left-set(flop),2):
            board = flop+reveal
            for k in prefixes:
                prefixes[k].add(board[:k])
pops = {k:Counter(tuple(sum(h.isdisjoint(board) for h in side) for side in ranges) for board in boards)
        for k,boards in prefixes.items()}
assert [len(p) for p in prefixes.values()]==[1,25,56,60]
words=lambda bits:max(1,(bits+63)//64)
add=lambda bits:2+3*words(bits)
copy=lambda bits:1+2*words(bits)
mul=lambda a,b:2+2*(words(a)+words(b))+words(a)*words(b)
plan = json.loads((REPO/'benchmarks/results/native-dyadic-split-checkpoint-accepted-v1/manifest.json').read_bytes())['admission']
rank_planes = len({frozenset(board) for board in prefixes[5]})
assert rank_planes==plan['rank_cache_planes']
lookup = 2*rank_planes

@lru_cache(None)
def cost(show,k,seat,exp):
    reach=exp+1
    acc=0
    for n,count in pops[k].items():
        own,opp=n[seat],n[1-seat]
        bucket=8+reach+max(0,opp-1).bit_length()
        unit=22+k+2*(4+2*words(reach))
        dynamic=(12+opp*mul(4,reach)+53*(2+own if show else 1)
                 +(9 if show else 3)*opp*add(bucket)
                 +own*((12 if show else 3)*add(bucket)+mul(4,bucket)+copy(bucket+4)+2*words(bucket))+128)
        acc+=count*(unit+dynamic+(lookup if show else 0))
    return acc

template=build_reference_template(_template_case())
def walk(i,depth,first):
    n=template.nodes[i]
    if n.phase=='decision':
        p=n.state.player
        depth=tuple(x+int(seat==p) for seat,x in enumerate(depth))
        exp=1 if len(n.edges)==2 else 2 if len(n.edges)==4 else 52
        first=tuple(x+(exp if seat==p else 0) for seat,x in enumerate(first))
    elif n.phase=='reveal':
        base=sum(cost(False,n.state.board_length,seat,0) for seat in (0,1))
        yield base,base
    else:
        show=n.phase=='showdown'
        size=5 if show else n.street
        yield tuple(sum(cost(show,size,seat,exp[1-seat]) for seat in (0,1))
                    for exp in (first,tuple(52*d for d in depth)))
    for edge in n.edges:
        yield from walk(edge.child,depth,first)

base=sum(cost(False,0,seat,0) for seat in (0,1))
a,b=(sum(x)+base for x in zip(*walk(template.root,(0,0),(0,0))))
fixed=65536+4096*plan['expected_rank_calls']+rank_planes*(512+64+4*rank_planes)
print(dict(first=a,grid=b,fixed=fixed,two=fixed+a+b,old=plan['component_work']['chance'],three=fixed+a+2*b))
assert fixed+a+b==plan['component_work']['chance']