"""Rank-free PROOF9 T3 owner and transport feasibility projection."""
from functools import lru_cache
import json
from pathlib import Path
import sys


WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-training-repo'
sys.path.insert(0, str(REPO))

from tests.virtual_betting_template_reference import build_reference_template
from tests.virtual_dyadic_stage_schedule import stage_schedule
from tests.virtual_frozen_update_reference import _template_case


def words(bits):
    return (bits+63)//64


def quantizer_work(actions, effective_bits, value_bits):
    sum_bits = effective_bits + (actions-1).bit_length() + 1
    scaled_bits = effective_bits + 52
    bits = max(53, sum_bits, scaled_bits)
    return (64+16*actions+4*actions*(words(value_bits)+1)+256+16*actions*(words(bits)+1)
            +8*actions*(2*words(scaled_bits)*words(sum_bits)+4*words(bits)+8)
            +4*actions*actions*(words(sum_bits)+1))


def project():
    path = REPO/'benchmarks/results/native-dyadic-split-checkpoint-accepted-v1/manifest.json'
    baseline = json.loads(path.read_bytes())
    plan = baseline['admission']
    rows, slots, bits = plan['rows'], plan['slots'], plan['value_bits']
    template = build_reference_template(_template_case())
    support = dict(zip((0,3,4,5), plan['prefix_supported_rows'], strict=True))

    @lru_cache(None)
    def suffix(node_id):
        node = template.nodes[node_id]
        return int(node.phase=='decision')+max((suffix(edge.child) for edge in node.edges), default=0)

    count = [0,0,0]

    def visit(node_id, past):
        node = template.nodes[node_id]
        if node.phase=='decision':
            actor = node.state.player
            holdings = support[node.street][actor]
            actions = len(node.edges)
            shift = 52*(12-past[1-actor]-suffix(node_id))
            if not 0<=shift<bits:
                raise ValueError('regret scale differs')
            count[0] += holdings
            count[1] += holdings*actions
            count[2] += holdings*quantizer_work(actions,bits-shift,bits)
            past = tuple(value+int(seat==actor) for seat,value in enumerate(past))
        for edge in node.edges:
            visit(edge.child,past)

    visit(template.root,(0,0))
    if count[:2]!=[rows,slots]:
        raise ValueError('independent PROOF9 row census differs')
    schedule = stage_schedule(virtual_zero=True)
    if (schedule['rows'],schedule['slots'],schedule['image_words'])!=(rows,slots,606730):
        raise ValueError('independent PROOF9 image census differs')
    widths = {str(sweeps):{'regret_bound_bits':(sweeps*16*(580<<625)).bit_length(),
                           'average_bound_bits':(sweeps*(580<<625)).bit_length()}
              for sweeps in (2,3,4,8)}
    if any(max(bound.values())>bits for bound in widths.values()):
        raise ValueError('retained width envelope differs')
    old = plan['component_work']
    fixed_chance = 65536+4096*plan['expected_rank_calls']+plan['rank_cache_planes']*(512+64+4*plan['rank_cache_planes'])
    per_sweep_chance,remainder = divmod(old['chance']-fixed_chance,2)
    if remainder:
        raise ValueError('chance work sweep decomposition differs')
    history_walk = 40*plan['actions']+72*plan['reveals']+48*plan['visits']+40*rows
    lookup_removed = (16*rows.bit_length()-32)*rows
    state_sweep = 88*rows+132*slots+(16*slots+8*rows)*words(bits+58)
    additional_read_epochs = [epoch for epoch in schedule['read_epochs'] if epoch['name'].startswith('sweep_2')]
    if len(additional_read_epochs)!=2:
        raise ValueError('independent pager epochs differ')
    reads = schedule['logical_read_calls']+sum(epoch['logical_reads'] for epoch in additional_read_epochs)
    physical = schedule['physical_read_words']+sum(epoch['physical_words'] for epoch in additional_read_epochs)
    stages = 3*schedule['per_sweep_stage_calls']
    retained = plan['output_bytes']+8*slots+4*12*8
    return {
        'scope':'Rank-free PROOF9 T3 projection for ordered paged State and the streamed replay transport',
        'baseline_source':baseline['source_head'], 'rows':rows, 'slots':slots,
        'native_producer_calls':0,'hand_rank_calls':0,'admitted':False,
        'retained_width_bits':bits,'path_independent_width_bounds':widths,
        'width_proof':'Prior mass and each sequence reach are at most one. Each action counterfactual value has magnitude at most 8D. A clipped regret adds at most 16D per sweep and a raw average adds at most D.',
        'projected_owner_work':{'template':old['template'],'chance':old['chance']+per_sweep_chance,
                                'history':old['history']+history_walk+32*rows,
                                'state':old['state']-lookup_removed+state_sweep,
                                'quantizer':old['quantizer']+count[2]},
        'general_third_sweep_quantizer_work':count[2],
        'quantizer_export_basis':'Existing base-width plus two bits covers the sum of three average increments',
        'legacy_driver_owner_caps':{'chance':110000000,'history':42000000,'state':75000000,'quantizer':106000000},
        'pager':{'image_words':schedule['image_words'],'write_words':3*schedule['image_words'],
                 'write_calls':3*schedule['per_sweep_dirty_runs'],'read_words':physical,
                 'logical_read_calls':reads,'stage_calls':stages,'logical_requests':reads+stages,
                 'legacy_write_word_cap':1820190,'legacy_logical_request_cap':1000000},
        'transport':{'numerical_bytes':retained,'wire_bytes':retained+3*(32+8*schedule['image_words'])},
        'remaining_admission':['New named driver owner caps and complete parent/transport work ledger',
                               'Three-sweep directory trace and composed storage',
                               'Versioned three-sweep binary, receipts and independent whole-game replay'],
    }


if __name__=='__main__':
    result=project()
    output=WORK/'dyadic-proof9-t3-feasibility.json'
    with output.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print(json.dumps(result,sort_keys=True))
