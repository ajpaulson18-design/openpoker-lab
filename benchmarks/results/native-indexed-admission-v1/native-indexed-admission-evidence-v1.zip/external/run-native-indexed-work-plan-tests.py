"""External configured compiler environment for focused regression controls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE / "native-indexed-work-plan-repo"
OUTPUT = BASE / ("native-indexed-work-plan-tests-" + sys.argv[1])
OUTPUT.mkdir(exist_ok=False)
build = BASE / "native-indexed-work-plan-engine-build-v3"
manifest = json.loads((build / "native-exact-build-manifest.json").read_bytes())
vcvars = Path(manifest["compiler"]).parents[6] / "Auxiliary/Build/vcvars64.bat"
setup_file = OUTPUT / "setup.cmd"
setup_file.write_text('@call "' + str(vcvars) + '" >nul\n@if errorlevel 1 exit /b 1\n@set\n', encoding="utf-8")
setup = subprocess.run(["cmd.exe", "/d", "/c", str(setup_file)], capture_output=True)
(OUTPUT / "setup-stderr.log").write_bytes(setup.stderr)
if setup.returncode:
    raise RuntimeError("compiler environment setup failed")
environment = os.environ.copy()
for line in setup.stdout.decode("utf-8", "replace").splitlines():
    key, sep, value = line.partition("=")
    if sep and key.upper() in ("PATH", "INCLUDE", "LIB", "LIBPATH"):
        environment[key.upper()] = value
for key in ("CL", "_CL_", "LINK", "_LINK_"):
    environment.pop(key, None)
environment["OPENPOKER_NATIVE_EXACT_FOUR_STREET_EXE"] = str(build / "native-exact-four-street-train.exe")
suites = sys.argv[2:] or ["tests.test_native_exact_four_street", "tests.test_native_indexed_admission",
    "tests.test_benchmark_native_exact_four_street", "tests.test_benchmark_native_indexed_routing"]
command = [sys.executable, "-m", "unittest", *suites, "-v"]
def source_identity():
    names = set(subprocess.check_output(["git", "ls-files", "-z"], cwd=REPO).decode().split("\0"))
    names.update(subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=REPO).decode().split("\0"))
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in sorted(names - {""})}
sources = source_identity()
(OUTPUT / "input.json").write_text(json.dumps({"command": command, "sources": sources}, indent=2) + "\n")
with (OUTPUT / "stdout.log").open("wb") as stdout, (OUTPUT / "stderr.log").open("wb") as stderr:
    result = subprocess.run(command, cwd=REPO, env=environment, stdout=stdout, stderr=stderr)
stable = sources == source_identity()
receipt = {"returncode": result.returncode, "source_stable": stable, "command": command}
(OUTPUT / "status.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
raise SystemExit(result.returncode if stable else 3)
