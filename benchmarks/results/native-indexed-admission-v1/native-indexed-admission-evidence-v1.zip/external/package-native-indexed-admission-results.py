"""Package frozen attempts, corrections and reviews; execute no candidate."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
TARGET = WORK / "native-indexed-admission-evidence-v1.zip"
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def need(value, message):
    if not value:
        raise ValueError(message)
def read(path):
    return json.loads(path.read_bytes())
def main():
    need(not TARGET.exists(), "preserve previous archive")
    entries = {}
    def add(name, path):
        need(name not in entries and path.is_file() and not path.is_symlink(), "invalid archive entry: " + name)
        entries[name] = path.read_bytes()
    def folder(prefix, path):
        for file in sorted(path.rglob("*")):
            if file.is_file() and file.suffix not in (".exe", ".obj", ".pyc", ".pdb", ".ilk") and not any(
                    part in ("__pycache__", "boost-include", ".git") for part in file.relative_to(path).parts):
                add(prefix + "/" + file.relative_to(path).as_posix(), file)
    helper = WORK / "exact-selected-independent-review.py"
    need(sha(helper.read_bytes()) == "8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5", "source auth helper changed")
    spec = importlib.util.spec_from_file_location("archive_source_auth", helper)
    auth = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auth)
    identities = {}
    for version, commit, repository, snapshot in (
        ("frozen", "52295e8f7b4ebb8003b738dc7a8828b4636c8cb5", "native-indexed-work-plan-repo", "native-indexed-admission-study-continuation-v2/source-before.json"),
        ("corrected", "33334e631ed0cd05202a42aaeca9104b8981ccd4", "native-indexed-admission-fix-repo", "native-indexed-admission-corrected-saved-compatibility-v1/source-before.json")):
        repo = WORK / repository
        source = read(WORK / snapshot)
        auth.FROZEN = commit
        identities[version] = auth.source_identity(repo, source)
        names = set(subprocess.check_output(["git", "diff", "--name-only", "4344e0bd1e2e78a79d5684dca8526f2458324eb8", commit], cwd=repo).decode().splitlines())
        for directory, suffixes in (("pokerlab", ("*.py",)), ("scripts", ("*.py",)),
                ("native", ("*.hpp", "*.cpp")), ("benchmarks/cases", ("*.json",))):
            for suffix in suffixes:
                names.update(p.relative_to(repo).as_posix() for p in (repo / directory).rglob(suffix))
        names.update("third_party/boost-multiprecision-1.92.0/" + n for n in ("headers.zip", "manifest.json", "LICENSE_1_0.txt"))
        for name in sorted(names):
            add("source-" + version + "/" + name, repo / name)
    study_names = ("native-indexed-admission-study-v1", "native-indexed-admission-study-continuation-v1", "native-indexed-admission-study-continuation-v2")
    for name in study_names:
        study = WORK / name
        manifest = read(study / "manifest.json")
        need(set(p.name for p in study.iterdir() if p.is_file()) == set(manifest["sha256"]) | {"manifest.json"}, "study inventory changed")
        need(all(sha((study / n).read_bytes()) == digest for n,digest in manifest["sha256"].items()), "study artifact drift")
        folder("attempts/" + name, study)
    complete = read(WORK / study_names[-1] / "report.json")
    need(complete["outcome"] == "complete" and complete["calls_attempted"] == complete["calls_captured"] == 28, "fixed schedule incomplete")
    review = WORK / "native-indexed-admission-independent-review-v7/receipt.json"
    need(sha(review.read_bytes()) == "5012eb7b1dd3e7eeb1932cb2a8a30868bda38284d07d13cf109a97009b92ed3e" and read(review)["status"] == "passed", "independent review pin")
    compatibility = WORK / "native-indexed-admission-corrected-saved-compatibility-v1/receipt.json"
    need(sha(compatibility.read_bytes()) == "0eafe99f8a2a882898e6fbdd243a238c5dda99dfb7f9ec5d082dbc4d7d33684d" and read(compatibility)["status"] == "passed", "corrected compatibility pin")
    supplement = WORK / "native-indexed-admission-saved-budget-binding-v1.json"
    need(read(supplement)["status"] == "passed" and len(read(supplement)["records"]) == 15, "saved budget supplement incomplete")
    for pattern in ("native-indexed-admission-independent-review-v*", "native-indexed-admission-corrected-saved-compatibility-v*",
                    "native-indexed-admission-runner-development-v*", "native-indexed-work-plan-development-v*",
                    "native-indexed-work-plan-ledger-development-v*", "native-indexed-work-plan-tests-*",
                    "native-indexed-work-plan-build-*", "native-indexed-work-plan-engine-build-v*"):
        for directory in sorted(WORK.glob(pattern)):
            if directory.is_dir():
                folder("development/" + directory.name, directory)
    patterns = ("native-indexed-admission*", "native-indexed-work-plan*", "native-indexed-zero-decision*",
                "verify-native-indexed-admission*", "resume-native-indexed-admission*",
                "check-corrected-indexed-admission*", "check-indexed-admission*", "run-native-indexed-work-plan*",
                "build-native-indexed-work-plan*")
    selected = {p for pattern in patterns for p in WORK.glob(pattern) if p.is_file() and p.suffix in (".py", ".json", ".log", ".cpp", ".cmd")}
    selected.add(helper)
    for file in sorted(selected):
        add("external/" + file.name, file)
    add("external/package-native-indexed-admission-results.py", Path(__file__))
    for version, repository in (("frozen", "native-indexed-work-plan-repo"), ("corrected", "native-indexed-admission-fix-repo")):
        auth.FROZEN = identities[version]["commit"]
        source = {"commit":auth.FROZEN,"status":"","sha256":identities[version]["raw_sha256"]}
        need(auth.source_identity(WORK / repository, source)["raw_sha256"] == source["sha256"], "source changed while packaging")
    manifest = {"contract":"native-indexed-admission-evidence-v1","source_authentication":identities,
        "scope":"28 distinct frozen producer attempts at 52295e8 across preserved parent continuations; 15 numeric replays, 12 exact misses, 3 exact verifier-cap unknowns, 13 native budget rejections. Five completed pairs match; T20/T40 legacy rejects. Parent stops 14/22 differ from raw reclassifications 14/17/22; omitted index17 in continuation summary is explicitly retained. Corrected 33334e6 parser acceptance/budget compatibility is separate from frozen production. All earlier failures remain. Logical accounting, no CPU/RSS/general speed/full-deck claim. Archived source is evidence only, not executed.",
        "sha256":{name:sha(raw) for name,raw in sorted(entries.items())}}
    raw_manifest = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    with zipfile.ZipFile(TARGET, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name,raw in sorted(entries.items()):
            archive.writestr(name, raw)
        archive.writestr("evidence-manifest.json", raw_manifest)
    with zipfile.ZipFile(TARGET) as archive:
        need(archive.testzip() is None and len(archive.namelist()) == len(entries)+1, "archive integrity")
        need(all(archive.read(name) == raw for name,raw in entries.items()), "archive byte drift")
    receipt = {"archive":TARGET.name,"archive_bytes":TARGET.stat().st_size,"archive_sha256":sha(TARGET.read_bytes()),
        "archive_entries":len(entries)+1,"evidence_manifest_sha256":sha(raw_manifest),
        "source_commits":[identities[v]["commit"] for v in ("frozen","corrected")],"scope":manifest["scope"]}
    (WORK / "native-indexed-admission-evidence-v1-receipt.json").write_bytes((json.dumps(receipt, sort_keys=True, indent=2)+"\n").encode())
    print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
