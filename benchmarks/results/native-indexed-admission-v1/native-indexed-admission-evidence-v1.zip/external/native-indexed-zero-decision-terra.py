import sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.benchmark_suit_quotient_solver import case_for,request_for
from pokerlab import exact_selected_solver as s
from pokerlab import native_exact_four_street as n
case=case_for('original-22-t10');case['config']={**case['config'],'starting_stack':[0.5,1.0]};q=request_for(case,10)
p=s._prepare_exact_selected(q,rank_cache_boards=64,pair_diagnostics='compact',exact_arithmetic='dyadic',training_reduction='suit-equivariant',strategy_storage='suit-quotient',quotient_lookup='per-decision',execution_profile='native-indexed-v1')
print('decision prefixes',list(p.unique_prefixes),'occurrences',p.topology.census.expanded_logical_visits)
r=n.admit(p);wire=n.wire(p,10,rank_cache_boards=64,native_work=r['native_work_limit'],native_entries=r['native_entries_limit'],routing='indexed');path=r'C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\native-indexed-work-plan-engine-build-v3\native-exact-four-street-train.exe';print('identity',n.executable_identity(path)['executable_sha256']);raw=n._invoke(path,wire);print('native admission line',raw.decode().splitlines()[-1]);
try:n.parse_policy(raw,p,routing='indexed');print('unexpected acceptance')
except Exception as e:print('parser rejection',type(e).__name__,str(e))
