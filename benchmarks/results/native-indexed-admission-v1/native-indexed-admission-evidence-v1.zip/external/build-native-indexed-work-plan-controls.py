"""External strict compile/run with first failures and input bytes preserved."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
W=Path(__file__).resolve().parent
R=W/'native-indexed-work-plan-repo'
B=W/('native-indexed-work-plan-build-'+sys.argv[1])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):(B/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def main():
 if B.exists():raise ValueError('preserve previous build')
 B.mkdir()
 accepted=json.loads((W/'native-indexed-schedule-build-v2/native-exact-build-manifest.json').read_bytes())
 compiler=accepted['compiler'];flags=accepted['flags'];environment=os.environ.copy()
 script=B/'environment.cmd';vcvars=Path(compiler).parents[6]/'Auxiliary/Build/vcvars64.bat'
 script.write_text('@call "'+str(vcvars)+'" >nul\n@if errorlevel 1 exit /b 1\n@set\n',encoding='utf-8')
 setup=subprocess.run(['cmd.exe','/d','/c',str(script)],capture_output=True)
 (B/'environment-stderr.log').write_bytes(setup.stderr)
 if setup.returncode:raise ValueError('environment failed')
 for line in setup.stdout.decode('utf-8','replace').splitlines():
  key,sep,value=line.partition('=')
  if sep and key.upper() in ('PATH','LIB','INCLUDE','LIBPATH'):environment[key.upper()]=value
 for key in ('CL','_CL_','LINK','_LINK_'):environment.pop(key,None)
 names=['native/exact_selected_cfr.hpp','native/exact_indexed_routing.hpp','native/exact_public_history_index.hpp','native/exact_public_graph.hpp','native/exact_selected_kernel.hpp','native/exact_binary64.hpp','tests/native/exact_selected_cfr_controls.cpp']
 before={n:sha(R/n) for n in names};put('input-identity.json',before)
 for name in names:
  target=B/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/name).read_bytes())
 command=[compiler,*flags,'/I'+str(R/'native'),str(R/names[-1]),'/Fo'+str(B/'controls.obj'),'/Fe'+str(B/'controls.exe')]
 compiled=subprocess.run(command,cwd=B,env=environment,capture_output=True,timeout=180)
 (B/'compiler-stdout.log').write_bytes(compiled.stdout);(B/'compiler-stderr.log').write_bytes(compiled.stderr)
 put('status.json',{'compile_returncode':compiled.returncode,'command':command})
 if compiled.returncode:return compiled.returncode
 result=subprocess.run([str(B/'controls.exe')],cwd=B,capture_output=True,timeout=180)
 (B/'run-stdout.log').write_bytes(result.stdout);(B/'run-stderr.log').write_bytes(result.stderr)
 put('status.json',{'compile_returncode':compiled.returncode,'run_returncode':result.returncode,'command':command,'exe_sha256':sha(B/'controls.exe'),'source_stable':before=={n:sha(R/n) for n in names}})
 print(result.stdout.decode('utf-8','replace'));print(result.stderr.decode('utf-8','replace'),file=sys.stderr)
 return result.returncode
if __name__=='__main__':raise SystemExit(main())
