"""Authenticate corrected source and parse saved native output without training."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

WORK = Path(__file__).resolve().parent
REPO = WORK / "native-indexed-admission-fix-repo"
STUDY = WORK / "native-indexed-admission-study-continuation-v2"
OUTPUT = WORK / "native-indexed-admission-corrected-saved-compatibility-v1"
COMMIT = "33334e631ed0cd05202a42aaeca9104b8981ccd4"
def need(value, message):
    if not value:
        raise ValueError(message)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def write(path, value):
    path.write_bytes(json.dumps(value, indent=2, sort_keys=True) .encode() + b"\n")
def snapshot():
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=REPO).decode().split("\0")[:-1]
    return {"commit":subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip(),
        "status":subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=REPO).decode().strip(),
        "sha256":{name:sha((REPO / name).read_bytes()) for name in names}}
def main():
    need(not OUTPUT.exists(), "preserve previous review")
    OUTPUT.mkdir()
    stage = "authentication"
    try:
        helper = WORK / "exact-selected-independent-review.py"
        need(sha(helper.read_bytes()) == "8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5", "auth helper drift")
        spec = importlib.util.spec_from_file_location("saved_compatibility_auth", helper)
        auth = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(auth)
        auth.FROZEN = COMMIT
        before = snapshot()
        authenticated = auth.source_identity(REPO, before)
        write(OUTPUT / "source-before.json", before)
        manifest_raw = (STUDY / "manifest.json").read_bytes()
        need(sha(manifest_raw) == "fc59d72086d557d5f4646e2195ea58817a30be85aa56bb4eda4b48a015d3ca3d", "study manifest drift")
        manifest = auth.parse(manifest_raw)
        saved = {p.name:p.read_bytes() for p in STUDY.iterdir() if p.is_file()}
        need(set(saved) == set(manifest["sha256"]) | {"manifest.json"} and
            all(sha(saved[k]) == v for k,v in manifest["sha256"].items()), "study closure drift")
        report = auth.parse(saved["report.json"])
        protocol = auth.parse(saved["protocol.json"])
        need(report["outcome"] == "complete" and report["calls_captured"] == 28, "incomplete study")
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(REPO))
        from pokerlab import exact_selected_solver as solver, native_exact_four_street as native
        from scripts.benchmark_suit_quotient_solver import request_for
        identity = native.executable_identity(protocol["build"]["executable"])
        need(identity == protocol["build"], "native implementation differs across source correction")
        targets = ("pokerlab.exact_selected_kernel.rank_hand", "pokerlab.cards.rank_hand",
            "pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.pair_probability_exact",
            "pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.terminal_values_exact",
            "pokerlab.suit_quotient_plan.SuitQuotientPlan.__init__",
            "pokerlab.suit_quotient_cfr.train_suit_quotient", "pokerlab.equivariant_packed_cfr.train_equivariant_packed",
            "pokerlab.exact_selected_solver.train_packed", "pokerlab.preflop_solver._enumerate_physical_worlds",
            "pokerlab.selected_runout_operator.SelectedRunoutOperator._iter_worlds",
            "pokerlab.native_exact_four_street._invoke", "subprocess.Popen")
        completed = []
        with ExitStack() as guards:
            for target in targets:
                guards.enter_context(patch(target, side_effect=AssertionError("forbidden compatibility call: " + target)))
            for record in report["samples"]:
                if record["status"] != "complete":
                    continue
                label = record["label"]
                stage = label
                raw = auth.parse(saved[label + ".stdout.bin"])
                name, iterations, admission = record["entry"]
                request = request_for(protocol["cases"][name], iterations)
                profile = "native-indexed-v1" if admission == "indexed-v1" else "legacy"
                prepared = solver._prepare_exact_selected(request, execution_profile=profile, **protocol["options"])
                reserved = native.admit(prepared)
                import base64
                native_raw = base64.b64decode(raw["native_streams"][0]["stdout"], validate=True)
                parsed, receipt = native.parse_policy(native_raw, prepared, routing="indexed")
                need(receipt["modeled_work_upper"] <= reserved["native_work_limit"] and
                    receipt["retained_entries_upper"] <= reserved["native_entries_limit"], "saved result exceeds corrected remaining budget")
                payload = raw["payload"]
                need(len(parsed) == payload["info_sets"] and receipt["quotient_rows"] == payload["operator_census"]["native_exact"]["quotient_rows"], "saved policy geometry changed")
                completed.append({"label":label,"policy_rows":len(parsed),"native_result_sha256":sha(native_raw),
                    "native_work":receipt["modeled_work_upper"],"corrected_native_work_limit":reserved["native_work_limit"],
                    "native_entries":receipt["retained_entries_upper"],"corrected_native_entries_limit":reserved["native_entries_limit"]})
                print(label, len(parsed), flush=True)
        need(len(completed) == 15, "wrong completed-policy count")
        stage = "after authentication"
        after = snapshot()
        need(after == before and auth.source_identity(REPO, before)["raw_sha256"] == authenticated["raw_sha256"], "corrected source drift")
        need({p.name:p.read_bytes() for p in STUDY.iterdir() if p.is_file()} == saved and
            native.executable_identity(protocol["build"]["executable"]) == identity, "saved evidence/build drift")
        write(OUTPUT / "source-after.json", after)
        receipt = {"status":"passed","corrected_source_commit":COMMIT,"frozen_producer_commit":manifest["source_commit"],
            "authenticated_source_files":authenticated["files"],"completed_policy_parses":completed,"candidate_training_calls":0,
            "scope":"Corrected host proof/remaining-budget compatibility for existing frozen native policy bytes. Rank-free preparation executes; no native/train/rank/pair/world calls. This is separate from independent physical quality replay."}
        write(OUTPUT / "receipt.json", receipt)
        print(json.dumps({"status":"passed","policies":len(completed)}))
    except BaseException as exc:
        write(OUTPUT / "first-failure.json", {"stage":stage,"type":type(exc).__name__,"message":str(exc)})
        raise

if __name__ == "__main__":
    main()
