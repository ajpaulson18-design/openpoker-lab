"""Saved-only request-limit binding supplement, with no project imports."""
import base64
import hashlib
import importlib.util
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
REPO = WORK / "native-indexed-admission-fix-repo"
STUDY = WORK / "native-indexed-admission-study-continuation-v2"
COMPAT = WORK / "native-indexed-admission-corrected-saved-compatibility-v1"
OUT = WORK / "native-indexed-admission-saved-budget-binding-v1.json"
def need(value, message):
    if not value:
        raise ValueError(message)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
need(not OUT.exists(), "preserve prior supplement")
helper = WORK / "exact-selected-independent-review.py"
need(sha(helper.read_bytes()) == "8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5", "auth helper drift")
spec = importlib.util.spec_from_file_location("budget_supplement_auth", helper)
auth = importlib.util.module_from_spec(spec)
spec.loader.exec_module(auth)
auth.FROZEN = "33334e631ed0cd05202a42aaeca9104b8981ccd4"
source = auth.parse((COMPAT / "source-before.json").read_bytes())
before = auth.source_identity(REPO, source)
receipt_raw = (COMPAT / "receipt.json").read_bytes()
need(sha(receipt_raw) == "0eafe99f8a2a882898e6fbdd243a238c5dda99dfb7f9ec5d082dbc4d7d33684d", "compatibility receipt drift")
compatibility = auth.parse(receipt_raw)
manifest_raw = (STUDY / "manifest.json").read_bytes()
need(sha(manifest_raw) == "fc59d72086d557d5f4646e2195ea58817a30be85aa56bb4eda4b48a015d3ca3d", "study manifest drift")
manifest = auth.parse(manifest_raw)
records = []
for item in compatibility["completed_policy_parses"]:
    label = item["label"]
    raw = (STUDY / (label + ".stdout.bin")).read_bytes()
    need(sha(raw) == manifest["sha256"][label + ".stdout.bin"], "saved producer raw drift")
    data = auth.parse(raw)
    stream = data["native_streams"][0]
    request = base64.b64decode(stream["request"], validate=True)
    lines = request.decode("ascii").splitlines()
    header = lines[0]
    if header == "OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_V3":
        limit_line = 2
    else:
        need(header == "OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_V2" and lines[1] == "indexed", "unknown fixed wire mode")
        limit_line = 3
    values = lines[limit_line].split()
    need(len(values) == 11 and all(x.isascii() and x.isdecimal() for x in values), "malformed saved limits")
    limits = list(map(int, values))
    need([limits[i] for i in (1,4,7)] == [item["corrected_native_work_limit"]] * 3,
         "saved kernel/Plan/trainer work differs from corrected remainder")
    need([limits[i] for i in (2,5,8)] == [item["corrected_native_entries_limit"]] * 3,
         "saved kernel/Plan/trainer entries differ from corrected remainder")
    need(item["native_work"] <= min(limits[i] for i in (1,4,7)) <= 500_000_000 and
         item["native_entries"] <= min(limits[i] for i in (2,5,8)) <= 2_000_000, "saved result exceeds request limits")
    records.append({"label":label,"request_sha256":sha(request),"shared_native_work":limits[4],"shared_native_entries":limits[5]})
need(len(records) == 15 and auth.source_identity(REPO, source)["raw_sha256"] == before["raw_sha256"], "incomplete supplement or source drift")
result = {"status":"passed","corrected_source_commit":auth.FROZEN,"candidate_calls":0,
    "compatibility_receipt_sha256":sha(receipt_raw),"study_manifest_sha256":sha(manifest_raw),"records":records,
    "scope":"Independent saved request-limit decoding and binding to prior corrected-source remainder checks. No project mathematical imports, native invocation, training or policy replay."}
OUT.write_bytes(json.dumps(result, sort_keys=True, indent=2).encode() + b"\n")
print(json.dumps({"status":"passed","requests":len(records),"receipt_sha256":sha(OUT.read_bytes())}))
