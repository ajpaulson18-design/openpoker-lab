"""Continue unattempted fixed requests; preserve first raw classifier failure."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import sys
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
REPO = BASE / "native-indexed-work-plan-repo"
FIRST = BASE / "native-indexed-admission-study-v1"
OUTPUT = BASE / "native-indexed-admission-study-continuation-v1"
COMMIT = "52295e8f7b4ebb8003b738dc7a8828b4636c8cb5"
EXPECTED = "indexed router whole-work limit is below its bounded schedule scan floor"
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO))
# This module imports standard-library code only; authenticate before dependencies.
from scripts import benchmark_native_indexed_admission as study

def main():
    study.need(not OUTPUT.exists(), "preserve all earlier attempts")
    source = study._authenticate_source()
    study.need(source["commit"] == COMMIT, "source freeze changed")
    before = {p.name: p.read_bytes() for p in FIRST.iterdir() if p.is_file()}
    manifest = study.decode(before["manifest.json"])
    study.need(manifest["source_commit"] == COMMIT and set(before) == set(manifest["sha256"]) | {"manifest.json"}, "first closure incomplete")
    study.need(all(study.sha(before[name]) == digest for name, digest in manifest["sha256"].items()), "first artifact drift")
    previous = study.decode(before["report.json"])
    study.need(previous["calls_attempted"] == 15 and previous["calls_captured"] == 14 and
        previous["failure"]["stage"] == "child:original-weighted-2x2-t100-indexed-v1", "unexpected first attempt shape")
    study.need(study.decode(before["source-before.json"]) == study.decode(before["source-after.json"]) == source, "source authentication differs")
    deps = study._dependencies()
    protocol = study.decode(before["protocol.json"])
    executable = Path(protocol["build"]["executable"])
    build = deps.native.executable_identity(executable)
    study.need(build == protocol["build"], "build changed")
    cases = study.validate_cases(deps)
    study.need(cases == protocol["cases"], "fixed fixtures changed")
    OUTPUT.mkdir()
    for name, raw in before.items():
        target = "original-attempt-" + name if name in ("manifest.json", "report.json", "first-failure.json") else name
        (OUTPUT / target).write_bytes(raw)
    study.write(OUTPUT / "continuation-protocol.json", {
        "source_commit": COMMIT, "first_terminal_handle": 23875, "first_terminal_exit_code": 1,
        "first_attempt_manifest_sha256": study.sha(before["manifest.json"]),
        "first_attempt_report_sha256": study.sha(before["report.json"]),
        "preserved_producer_attempts": 15, "new_producer_indices": list(range(15, 28)),
        "reclassification": {"schedule_index": 14, "raw_status": "failed", "derived_status": "native-resource-rejected", "exact_stderr_fragment": EXPECTED},
        "scope": "No producer retry. Only known budget-floor classification changes in the external parent; raw bytes and mathematical source stay frozen."})
    original_classifier = study._bounded_resource
    def classified(message):
        return original_classifier(message) or EXPECTED in message
    samples, payloads, checks, origins, raw_pins = [], {}, {}, [], {}
    attempts = 15
    failure = None
    stage = "initialization"
    def raw_unchanged():
        study.need(all(study.sha((OUTPUT / name).read_bytes()) == digest for name, digest in raw_pins.items()), "captured raw drift")
        study.need({p.name:p.read_bytes() for p in FIRST.iterdir() if p.is_file()} == before, "immutable first attempt drift")
    try:
        with patch.object(study, "_bounded_resource", new=classified):
            for index, entry in enumerate(study.SCHEDULE):
                identifier = study.label(entry)
                stage = "child:" + identifier
                study.need(study._identity() == source and deps.native.executable_identity(executable) == build, "source/build drift before child")
                if index >= 15:
                    attempts += 1
                    process = study._run_child([sys.executable, "-B", "-m", "scripts.benchmark_native_indexed_admission", "--child", str(index), "--native-executable", str(executable)])
                    (OUTPUT / (identifier + ".stdout.bin")).write_bytes(process.stdout)
                    (OUTPUT / (identifier + ".stderr.bin")).write_bytes(process.stderr)
                    study.write(OUTPUT / (identifier + "-status.json"), {"returncode":process.returncode})
                for suffix in (".stdout.bin", ".stderr.bin", "-status.json"):
                    name = identifier + suffix
                    raw_pins[name] = study.sha((OUTPUT / name).read_bytes())
                status = study.decode((OUTPUT / (identifier + "-status.json")).read_bytes())
                study.need(status["returncode"] == 0, "child process failed")
                raw = study.decode((OUTPUT / (identifier + ".stdout.bin")).read_bytes())
                view = copy.deepcopy(raw)
                outcome = study._resource_outcome(view)
                if outcome:
                    view["status"] = outcome
                study.validate(view, entry, deps, cases)
                origins.append({"schedule_index":index, "label":identifier,
                    "producer_source_commit":COMMIT, "producer_origin":"original-attempt" if index < 15 else "continuation",
                    "raw_status":raw["status"], "derived_status":view["status"], "raw_stdout_sha256":raw_pins[identifier+".stdout.bin"]})
                samples.append({"label":identifier,"entry":entry,**{k:v for k,v in view.items() if k not in ("payload","native_streams")}})
                if raw["payload"] is not None:
                    stage = "protected-verification:" + identifier
                    raw_unchanged()
                    if index < 15:
                        checked = study.decode((OUTPUT / (identifier + "-verification.json")).read_bytes())
                    else:
                        pin = study.sha(study.canonical(raw["payload"]))
                        checked = study._verify(cases[entry[0]], raw["payload"], deps)
                        study.need(study.sha(study.canonical(raw["payload"])) == pin, "replay changed policy")
                        study.write(OUTPUT / (identifier + "-verification.json"), checked)
                    raw_unchanged()
                    payloads[identifier], checks[identifier] = raw["payload"], checked
                study.write(OUTPUT / "progress.json", {"completed_rows":len(samples),"producer_attempts_total":attempts,"last_label":identifier})
                print(index, identifier, view["status"], "preserved" if index < 15 else "new", flush=True)
            pairs = {}
            for name,t,mode in study.SCHEDULE:
                if mode != "legacy":
                    continue
                left,right = study.label((name,t,"legacy")),study.label((name,t,"indexed-v1"))
                pairs[left+"__vs__"+right] = (study._pair(payloads[left],payloads[right],[checks[left],checks[right]],deps)
                    if left in payloads and right in payloads else {"status":"not-both-complete","quality_gate":None})
    except Exception as exc:
        failure = {"stage":stage,"type":type(exc).__name__,"message":str(exc),"calls_captured":len(samples)}
        study.write(OUTPUT / "first-failure.json", failure)
        pairs = {}
    try:
        raw_unchanged()
        after = study._authenticate_source()
        study.need(after == source and deps.native.executable_identity(executable) == build, "final source/build drift")
        study.write(OUTPUT / "source-after.json", after)
        study.write(OUTPUT / "build-after.json", build)
    except Exception as exc:
        failure = {"stage":"final-authentication","type":type(exc).__name__,"message":str(exc),"previous":failure}
        study.write(OUTPUT / "final-authentication-failure.json", failure)
    report = {"outcome":"complete" if failure is None and len(samples)==28 else "failed",
        "failure":failure,"calls_planned":28,"calls_attempted":attempts,"calls_captured":len(samples),
        "samples":samples,"paired_identities":pairs,"producer_provenance":origins,"captured_raw_artifact_sha256":raw_pins,
        "verification_status":{k:{"numeric":v["numeric"]["status"],"exact":v["exact"]["status"],"quality_gate":v["quality_gate"]} for k,v in checks.items()},
        "scope":"Fixed frozen-source 28-attempt aggregate; original failed classifier attempt preserved, only unattempted producers executed. No speed/full-deck claim."}
    study.write(OUTPUT / "report.json", report)
    study.write(OUTPUT / "manifest.json", {"source_commit":COMMIT,"sha256":{p.name:study.sha(p.read_bytes()) for p in OUTPUT.iterdir() if p.is_file()}})
    print(json.dumps({"outcome":report["outcome"],"failure":failure,"attempts":attempts,"captured":len(samples)}))
    return 0 if report["outcome"] == "complete" else 1

if __name__ == "__main__":
    raise SystemExit(main())
