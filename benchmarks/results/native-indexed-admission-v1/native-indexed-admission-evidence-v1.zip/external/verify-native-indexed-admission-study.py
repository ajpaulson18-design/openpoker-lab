"""Independent saved-only 28-call indexed admission review; never executes candidate."""
import argparse,base64,hashlib,importlib.util,json,math,re,struct,sys,zipfile
from collections import deque
from contextlib import ExitStack
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from unittest.mock import patch
COMMIT="52295e8f7b4ebb8003b738dc7a8828b4636c8cb5"
AUTH="8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5"
DECK=tuple(r+s for r in "23456789TJQKA" for s in "cdhs")
ORDER={c:i for i,c in enumerate(DECK)}
METRICS=("value_sb","value_bb","sb_best_response_value","bb_best_response_value","sb_gain","bb_gain","nash_conv","exploitability")
BASE=("original-22-t10","payoff-varied-t10","blocker-18","asymmetric-weighted","mixed-stabilizer")
MATRIX=("original-weighted-2x2","balanced-4x4-unit","balanced-8x8-unit","balanced-16x16-unit","asymmetric-2x16-unit")
SCHEDULE=[(n,10,m) for n in BASE for m in ("legacy","indexed-v1")]+[("original-22-t10",t,m) for t in (20,40) for m in ("legacy","indexed-v1")]+[(n,t,"indexed-v1") for n in MATRIX for t in (10,100,1000) if (n,t)!=(MATRIX[0],10)]
def check(x,m):
 if not x:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def bits(x):return struct.pack(">d",x).hex()

def parse_wire(raw):
    check(type(raw) is bytes and len(raw)<=64*1024*1024 and raw.endswith(b"\n"),"invalid native input envelope")
    tokens=raw.decode("ascii").split();check(len(tokens)<=10000000,"native input token cap")
    pos=0
    def take():
        nonlocal pos
        check(pos<len(tokens),"truncated native input")
        text=tokens[pos];pos+=1
        check(0<len(text)<=64 and all(32<ord(c)<127 for c in text),"invalid native token")
        return text
    def nat(ceiling):
        text=take();check(text.isdecimal() and len(text)<=12,"invalid natural field")
        value=int(text);check(value<=ceiling,"native natural exceeds independent cap");return value
    def fp():
        text=take();check(len(text)==16 and all(c in "0123456789abcdef" for c in text),"invalid exact FP bits")
        value=struct.unpack(">d",bytes.fromhex(text))[0];check(math.isfinite(value),"nonfinite native money/prior")
        return text
    check(take()=="OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1","wrong input magic")
    iterations=nat(10000);cache=nat(64);h0,h1=nat(1326),nat(1326);b=nat(64);n=nat(250000);e=nat(1000000);root=nat(max(n-1,0));initial_n=nat(32)
    check(iterations>=10 and cache and h0 and h1 and b and n,"unsupported fixed input dimensions")
    caps=(65536,500000000,2000000,1<<30,500000000,2000000,16000000,500000000,25000000,1000000,2000000)
    limits=[nat(cap) for cap in caps];check(all(limits),"zero native limit")
    ranges=[]
    for h in (h0,h1):
        side=[]
        for _ in range(h):
            a,c=nat(51),nat(51);weight=fp();check(a!=c and struct.unpack(">d",bytes.fromhex(weight))[0]>0,"invalid positive holding")
            side.append({"hand":[DECK[a],DECK[c]],"weight_bits":weight})
        check(len({tuple(sorted(row["hand"])) for row in side})==h,"duplicate private holding")
        ranges.append(side)
    boards=[[DECK[nat(51)] for _ in range(5)] for _ in range(b)]
    check(all(len(set(outcome))==5 and outcome[:3]==sorted(outcome[:3],key=ORDER.__getitem__) for outcome in boards) and
         boards==sorted(boards,key=lambda outcome:tuple(ORDER[c] for c in outcome)) and len({tuple(v) for v in boards})==b,"noncanonical or duplicate native selected boards")
    initial=[take() for _ in range(initial_n)];vertices=[];edges=0
    for _ in range(n):
        tag=take()
        if tag=="D":
            actor=nat(1);count=nat(32);check(count>0,"empty action menu");actions=[];children=[]
            for _ in range(count):
                action={"name":take(),"amount_bits":fp(),"raise_to_bits":fp(),"full_raise":bool(nat(1)),"token":take()}
                actions.append(action);children.append(nat(n-1))
            check(len({a["token"] for a in actions})==count,"duplicate native action tokens")
            vertices.append({"kind":"D","actor":actor,"actions":actions,"children":children});edges+=count
        elif tag=="C":
            street=nat(3);index=nat(6);count=nat(64);check(street and count and index==street+3,"wrong native reveal index/street")
            branches=[(take(),nat(n-1)) for _ in range(count)];check(len({v[0] for v in branches})==count,"duplicate chance labels")
            vertices.append({"kind":"C","street":street,"card_index":index,"branches":branches});edges+=count
        elif tag in ("F","S"):
            winner=nat(1) if tag=="F" else None
            contributions=[fp(),fp()];check(all(struct.unpack(">d",bytes.fromhex(value))[0]>=0 for value in contributions),"negative terminal money")
            vertices.append({"kind":tag,"winner":winner,"contribution_bits":contributions})
        else:raise ValueError("unknown native wire field/vertex tag")
    check(pos==len(tokens) and edges==e,"unknown trailing native fields or edge mismatch")
    def children(v):return v["children"] if v["kind"]=="D" else [child for _,child in v["branches"]] if v["kind"]=="C" else []
    degrees=[0]*n
    for vertex in vertices:
        for child in children(vertex):degrees[child]+=1
    queue=deque(i for i,d in enumerate(degrees) if d==0);order=[]
    while queue:
        i=queue.popleft();order.append(i)
        for child in children(vertices[i]):
            degrees[child]-=1
            if degrees[child]==0:queue.append(child)
    check(len(order)==n,"native graph cycle")
    reached={root};depth={root:0}
    for i in order:
        check(i in reached,"native graph unreachable vertex")
        for child in children(vertices[i]):
            reached.add(child);depth[child]=max(depth.get(child,0),depth[i]+1)
            check(depth[child]<=256,"independent numeric graph depth cap")
    return {"iterations":iterations,"rank_cache_boards":cache,"ranges":ranges,"boards":boards,"vertices":vertices,
        "root":root,"initial_history":initial,"edges":edges,"limits":limits,"maximum_depth":max(depth.values())}

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--study',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--manifest-sha256',required=True);p.add_argument('--report-sha256',required=True);p.add_argument('--source-after-sha256',required=True);p.add_argument('--terminal-handle',required=True);p.add_argument('--terminal-exit-code',type=int,required=True);a=p.parse_args();check((a.terminal_handle,a.terminal_exit_code)==('23875',0),'producer completion not confirmed')
 repo,study,out=a.repo.resolve(),a.study.resolve(),a.output_dir.resolve();check(not out.exists() and repo not in out.parents and study not in out.parents,'new external output required');out.mkdir();stage='authentication'
 try:
  ap=Path(__file__).with_name('exact-selected-independent-review.py');check(sha(ap.read_bytes())==AUTH,'authentication helper pin');spec=importlib.util.spec_from_file_location('external_auth',ap);auth=importlib.util.module_from_spec(spec);spec.loader.exec_module(auth);auth.FROZEN=COMMIT;parse=auth.parse
  saved={x.relative_to(study).as_posix():x.read_bytes() for x in study.rglob('*') if x.is_file()};check(sha(saved['manifest.json'])==a.manifest_sha256 and sha(saved['report.json'])==a.report_sha256 and sha(saved['source-after.json'])==a.source_after_sha256,'artifact pins');manifest=parse(saved['manifest.json']);check(manifest['source_commit']==COMMIT and set(saved)==set(manifest['sha256'])|{'manifest.json'} and all(Path(k).name==k and sha(saved[k])==v for k,v in manifest['sha256'].items()),'artifact closure')
  source=parse(saved['source-before.json']);check(parse(saved['source-after.json'])==source,'source snapshot drift');identity=auth.source_identity(repo,source);protocol=parse(saved['protocol.json']);report=parse(saved['report.json']);check(protocol['source']['commit']==COMMIT and protocol['schedule']==[list(x) for x in SCHEDULE] and report['outcome']=='complete' and report['calls_planned']==report['calls_attempted']==report['calls_captured']==28 and not report['failure'],'study completion/schedule')
  build=protocol['build'];exe=Path(build['executable']);bp=exe.parent/'native-exact-build-manifest.json';br=bp.read_bytes();bm=parse(br);check(sha(br)==build['manifest_sha256'] and sha(exe.read_bytes())==build['executable_sha256'],'build pins');names={'native/exact_four_street_train.cpp','native/exact_public_graph.hpp','native/exact_public_history_index.hpp','native/exact_indexed_routing.hpp','native/exact_selected_cfr.hpp','native/exact_selected_kernel.hpp','native/exact_binary64.hpp','scripts/build_native_exact_four_street.py','third_party/boost-multiprecision-1.92.0/manifest.json','third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt','third_party/boost-multiprecision-1.92.0/headers.zip'};check(set(build['source_sha256'])==names and bm['source_sha256']==build['source_sha256'] and bm['executable_sha256']==build['executable_sha256'] and all(sha((repo/k).read_bytes())==v for k,v in build['source_sha256'].items()),'build source closure')
  dep=parse((repo/'third_party/boost-multiprecision-1.92.0/manifest.json').read_bytes())
  with zipfile.ZipFile(repo/'third_party/boost-multiprecision-1.92.0/headers.zip') as z:headers={i.filename:sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
  check(len(headers)==198 and headers==dep['headers_sha256'] and {x.relative_to(exe.parent/'boost-include').as_posix():sha(x.read_bytes()) for x in (exe.parent/'boost-include').rglob('*') if x.is_file()}==headers,'dependency closure')
  sys.dont_write_bytecode=True;sys.path.insert(0,str(repo));from pokerlab.cards import expand_range
  from scripts import four_street_validation as physical, exact_selected_compact_certificate as cert
  from scripts.preflop_validation import compare_result
  for name in MATRIX[1:]:
   case=protocol['cases'][name];h=(2,16) if name==MATRIX[-1] else (int(name.split('-')[1].split('x')[0]),)*2
   for key,n in zip(('sb_range','bb_range'),h):
    ranges=expand_range(case[key]);check(len(ranges)==n and all(float(v)==1 for v in ranges.values()),'synthetic physical hand count/weight')
  forbidden=['pokerlab.exact_selected_solver.solve_four_street_exact_selected','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.__init__','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.terminal_values_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.joint_marginals_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.pair_probability_exact','pokerlab.exact_selected_kernel.rank_hand','pokerlab.cards.rank_hand','pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.__init__','pokerlab.suit_quotient_plan.SuitQuotientPlan.__init__','pokerlab.suit_quotient_cfr.train_suit_quotient','pokerlab.equivariant_packed_cfr.train_equivariant_packed','pokerlab.packed_operator_cfr.train_packed','pokerlab.preflop_solver._enumerate_physical_worlds','pokerlab.selected_runout_operator.SelectedRunoutOperator._iter_worlds','pokerlab.native_selected_operator.train_native_selected','pokerlab.native_selected_dag.train_native_selected_dag','pokerlab.native_public_cfr.train_native_public','pokerlab.native_exact_four_street._invoke','pokerlab.native_exact_four_street.train','subprocess.Popen']
  results=[];payloads={};certs={};counts={'complete':0,'host-admission-rejected':0,'native-resource-rejected':0};maxgap=0.
  with ExitStack() as guard:
   for target in forbidden:guard.enter_context(patch(target,side_effect=AssertionError('forbidden replay '+target)))
   for record,entry in zip(report['samples'],SCHEDULE):
    name,T,mode=entry;label=f'{name}-t{T}-{mode}';stage='sample '+label;raw=parse(saved[label+'.stdout.bin']);check(tuple(record['entry'])==entry and record['label']==label and (raw['case'],raw['iterations'],raw['native_admission'])==entry and raw['request_case']==protocol['cases'][name],'sample identity');status=raw['status'];check(status in counts,'unexpected status');counts[status]+=1;calls=raw['counts'];check(not any(calls[k] for k in ('python_trainer','pair','world','legacy')),'forbidden producer calls')
    if status!='complete':
     check(raw['payload'] is None and raw['failure'] and calls['python_rank']==0,'invalid rejection');message=raw['failure'].get('message','');check(isinstance(message,str) and re.search(r'limit|cap|exceed|capacity|budget|envelope',message,re.I),'unbounded rejection')
     if status=='host-admission-rejected':check(calls['native_invoke']==0 and raw['failure']['type']=='ValueError' and not raw['native_streams'] and raw['native_observations']=={'learning_completed':False,'rank_calls':0},'host rejection observations')
     else:
      check(calls['native_invoke']==1 and len(raw['native_streams'])==1 and raw['native_observations']=={'learning_completed':None,'rank_calls':None},'native rejection observations');stream=raw['native_streams'][0];req,stdout,stderr=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'));check(req.startswith(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_V3\n') and stream['returncode']==2 and not stdout and b'native exact four-street rejected:' in stderr and re.search(rb'limit|cap|exceed|capacity|budget|envelope',stderr,re.I),'raw native bounded rejection')
     results.append({'label':label,'status':status,'quality':None});continue
    x=raw['payload'];check(raw['failure'] is None and calls['native_invoke']==1 and calls['rank_before_native']==0 and len(raw['native_streams'])==1,'completion calls');encoded=json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode();check((sha(encoded),len(encoded))==(raw['payload_sha256'],raw['payload_bytes']),'payload hash');stream=raw['native_streams'][0];rq,rs,err=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'));nc=x['operator_census']['native_exact'];check(stream['returncode']==0 and not err and (sha(rq),sha(rs),len(rq),len(rs))==(nc['request_sha256'],nc['result_sha256'],nc['request_bytes'],nc['result_bytes']),'wire binding')
    prefix=(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_V3\n' if mode=='indexed-v1' else b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_V2\nindexed\n');check(rq.startswith(prefix),'input protocol') ;wire=parse_wire(b'OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1\n'+rq[len(prefix):]);initial=tuple(wire['initial_history']);stack=[(wire['root'],initial)];visits=decisions=terminals=0;history_tokens=len(initial);decision_hands=action_count=history_entries=row_bytes=depth=0;marginal_keys=set();all_prefixes=set()
    while stack:
     index,hist=stack.pop();v=wire['vertices'][index];visits+=1;check(visits<=250000,'wire visit bound');history_tokens+=len(hist);depth=max(depth,len(hist)-len(initial))
     if v['kind']=='D':
      decisions+=1;h=len(wire['ranges'][v['actor']]);n=len(v['actions']);decision_hands+=h;action_count+=n;history_entries+=len(hist)+n;row_bytes+=sum(len(q.encode('utf8')) for q in hist)+64*n;board=[]
      for token in hist:
       if token.startswith('flop@'):board.extend((token[5:7],token[7:9],token[9:11]))
       elif token.startswith('turn@'):board.append(token[5:])
       elif token.startswith('river@'):board.append(token[6:])
      marginal_keys.add(tuple(j for j,board_full in enumerate(wire['boards']) if board_full[:len(board)]==board));stack.extend((child,hist+(act['token'],)) for child,act in zip(v['children'],v['actions']))
     elif v['kind']=='C':
      tag=('flop@','turn@','river@')[v['street']-1];stack.extend((child,hist+(tag+text,)) for text,child in v['branches'])
     else:terminals+=1
    check(wire['iterations']==T,'wire iteration')
    lines=rs.decode('ascii').splitlines();check(lines[0]==('OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_RESULT_V3' if mode=='indexed-v1' else 'OPENPOKER_NATIVE_EXACT_FOUR_STREET_ROUTED_RESULT_V2'),'result protocol');rows={(r['player'],r['hand'],tuple(r['history'])):r for r in x['strategy']};seen=set();done=None;route=None;admission=None
    for line in lines[1:]:
     fields=line.split('\t')
     if fields[0]=='ROW':
      player=int(fields[1]);handidx=int(fields[2]);n=int(fields[3]);history=tuple(fields[4:4+n]);count=int(fields[4+n]);key=('sb' if player==0 else 'bb',x['chance_input_snapshot']['ranges'][player][handidx]['hand'],history);check(key in rows and key not in seen and fields[5+n:]==[bits(v['probability']) for v in rows[key]['actions']] and len(fields[5+n:])==count,'raw ROW');seen.add(key)
     elif fields[0]=='DONE':check(done is None and len(fields)==14,'DONE shape');done=[int(x) for x in fields[1:]]
     elif fields[0] in ('ROUTE','ADMISSION'):
      values={};check(len(fields)>2 and fields[1] in ('indexed','indexed-v1'),'proof mode')
      for field in fields[2:]:
       k,sep,v=field.partition('=');check(sep and k not in values and v.isdecimal() and len(v)<=20,'proof field');values[k]=int(v)
      if fields[0]=='ROUTE':check(route is None and len(values)==41,'ROUTE shape');route=values
      else:check(admission is None,'duplicate ADMISSION');admission=values
     else:raise ValueError('unknown raw result record')
    check(len(seen)==len(rows)==x['info_sets'] and done is not None and route is not None,'row completeness');fields=('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots','member_checks','expected_member_checks','modeled_work_upper','kernel_work_upper','retained_entries_upper','maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls');check(done==[nc[k] for k in fields],'DONE counters');check(route=={k:v for k,v in nc['indexed_routing'].items() if k!='mode'},'ROUTE receipt');expected={'roots':3*T,'edges':3*T*(visits-1),'decisions':3*T*decisions,'prefixes':T*(2*terminals+decisions)}
    for k,v in expected.items():check(route[k]==route[k+'_upper']==v,'wire-derived '+k)
    check(not any(route[k] for k in ('legacy_extensions','legacy_rows','legacy_prefixes')),'indexed legacy calls')
    if mode=='indexed-v1':
     check(admission is not None and len(admission)==12 and admission=={k:v for k,v in nc['indexed_admission'].items() if k!='mode'},'ADMISSION receipt');group=nc['group_size'];lookup=group*(128*history_tokens+256*decision_hands);one=group*(16*history_entries+4*row_bytes+8*(depth+1)*decision_hands+16*(depth+1)*visits);check(admission['plan_legacy_lookup_removed']==3*T*lookup and admission['plan_legacy_action_removed']==6*T*32*action_count and admission['trainer_legacy_history_removed']==3*T*one and admission['trainer_history_retained']==4*one and admission['marginal_calls_actual']==len(marginal_keys) and admission['marginal_calls_upper']==len(all_prefixes) and admission['marginal_reuse']==1,'independent removed-work/marginal proof');check(admission['combined_work']==admission['plan_setup_work']+admission['index_setup_work']+admission['router_setup_work']+route['router_work_upper']+route['index_work_upper']+route['caller_work']==nc['modeled_work_upper'],'native component ledger');owner=x['operator_census']['whole_request_admission'];res=owner['native_additional_admission'];check(admission['combined_work']<=res['native_work_limit'] and admission['combined_entries']<=res['native_entries_limit'] and owner['combined_modeled_work_upper']<=owner['whole_request_limit']<=500000000,'host/native remaining ledger');check(wire['limits'][4]==wire['limits'][7]==res['native_work_limit'] and wire['limits'][5]==wire['limits'][8]==res['native_entries_limit'],'wire remaining limits')
    else:check(admission is None,'legacy admission marker')
    case=protocol['cases'][name];savedcheck=parse(saved[label+'-verification.json']);fresh={'numeric':'resource-unverified','exact':'resource-unverified'}
    try:
     model=physical.build_model(case);expanded=dict(x,compatible_private_pairs=model.counts['compatible_pairs'],private_pair_probabilities=[{'sb_hand':r['sb_hand'],'bb_hand':r['bb_hand'],'probability':float(Fraction(r['fraction']))} for r in model.counts['pair_probabilities']]);replay=physical.replay_policy(expanded,case);compare_result(expanded,replay);v=replay['value_sb'];b0=replay['sb_best_response_value'];b1=replay['bb_best_response_value'];g0=max(0.,b0-v);g1=max(0.,b1+v);mm=dict(value_sb=v,value_bb=-v,sb_best_response_value=b0,bb_best_response_value=b1,sb_gain=g0,bb_gain=g1,nash_conv=g0+g1,exploitability=(g0+g1)/2);gaps=[abs(x[k]-mm[k]) for k in METRICS];check(max(gaps)<=1e-10,'numeric replay');maxgap=max(maxgap,max(gaps));fresh['numeric']='complete'
    except ValueError as e:
     check(savedcheck['numeric']['status']=='resource-unverified' and re.search(r'limit|cap|exceed|capacity|budget',str(e),re.I),'unexpected numeric failure '+str(e));fresh['numeric_error']=str(e)
    try:
     exact=cert.evaluate_exact(case,x);actual=exact['exact_certificate'];old=savedcheck['exact'];check(old['status']=='complete' and all(actual[k]==old['result']['exact_certificate'][k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256')),'exact certificate');fresh['exact']='complete';fresh['quality']=actual['threshold_met'];certs[label]=actual;(out/(label+'-fresh-certificate.json')).write_text(json.dumps(exact,sort_keys=True,indent=2),encoding='utf8')
    except ValueError as e:
     check(savedcheck['exact']['status']=='resource-unverified' and re.search(r'limit|cap|exceed|capacity|budget',str(e),re.I),'unexpected exact failure '+str(e));fresh['exact_error']=str(e)
    check(fresh['numeric']==savedcheck['numeric']['status'] and fresh['exact']==savedcheck['exact']['status'],'verification status mismatch');payloads[label]=x;results.append({'label':label,'status':status,**fresh})
  pairs={}
  for name,T,mode in SCHEDULE:
   if mode!='legacy':continue
   l=f'{name}-t{T}-legacy';r=f'{name}-t{T}-indexed-v1'
   if l in payloads and r in payloads:
    a1,b1=payloads[l],payloads[r];check(a1['strategy']==b1['strategy'] and all(bits(a1[k])==bits(b1[k]) for k in METRICS),'pair mismatch');check([bits(v['probability']) for row in a1['strategy'] for v in row['actions']]==[bits(v['probability']) for row in b1['strategy'] for v in row['actions']],'pair bits');pairs[l+'__'+r]='matched'
   else:pairs[l+'__'+r]='not-both-complete'
  stage='after-authentication';check(auth.source_identity(repo,source)['raw_sha256']==identity['raw_sha256'] and {x.relative_to(study).as_posix():x.read_bytes() for x in study.rglob('*') if x.is_file()}==saved and bp.read_bytes()==br and sha(exe.read_bytes())==build['executable_sha256'] and {x.relative_to(exe.parent/'boost-include').as_posix():sha(x.read_bytes()) for x in (exe.parent/'boost-include').rglob('*') if x.is_file()}==headers,'after drift')
  receipt={'status':'passed','source_commit':COMMIT,'source_files':identity['files'],'manifest_sha256':a.manifest_sha256,'report_sha256':a.report_sha256,'candidate_calls':0,'counts':counts,'pairs':pairs,'max_numeric_gap':maxgap,'results':results,'scope':'Saved policy and raw wire census; no new full input-graph equivalence, CPU, or universal quality claim. Resource-unverified verifier results are not passes.'};(out/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n',encoding='utf8');print(json.dumps(receipt,sort_keys=True))
 except BaseException as e:
  (out/'first-failure.json').write_text(json.dumps({'stage':stage,'type':type(e).__name__,'message':str(e)},sort_keys=True,indent=2)+'\n',encoding='utf8');raise
if __name__=='__main__':main()
