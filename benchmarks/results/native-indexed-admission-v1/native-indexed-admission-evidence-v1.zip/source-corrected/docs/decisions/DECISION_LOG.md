# Decision register

Stable IDs identify decisions, not implementation milestones. Sources and statuses
are explicit. Historical alternatives without evidence remain unknown.

| ID | Decision | Authority / status | Source |
| --- | --- | --- | --- |
| D001 | GitHub is transferable institutional memory across AI providers | Confirmed owner decision, current | [Mission](../context/OWNER_MISSION_2026-10-08.md), §§1, 7–10 |
| D002 | Teach situation, difficulty and reasoning beyond optimal moves | Confirmed owner decision, current | Mission §4; [vision](../product/VISION.md) |
| D003 | Separate solver, evidence, explanations and presentation; coach does not calculate strategy | Owner direction plus implemented contract boundaries | Mission §4; [human-aware architecture](../human-aware-strategy.md), [coach evidence](../coach-analysis-v1.md) |
| D004 | External conversational AI is optional; structured explanations are central | Confirmed owner decision, current; optional provider implemented separately | Mission §4; [setup](../ai-coach-setup.md), [current turns](../current-coach-conversation-v1.md) |
| D005 | Entertainment poker game is outside scope; no assumed integration | Confirmed owner decision, current | Mission §3 |
| D006 | Commercial value and legitimate reuse matter; license obligations remain | Confirmed owner decision, current | Mission §6; [licensing](../research/LICENSING.md) |
| D007 | Recursive exact CFR remains default/reference; optional DCFR/planned/public-batched are measured candidates | Recorded engineering decision, implemented at baseline | [solver progress](../solver-progress.md), [public-batched](../public-batched-cfr.md), PR #63 |
| D008 | Selected runouts condition the joint game; no unrestricted NLHE claims | Implemented mathematical boundary, current | [postflop validation](../postflop-validation.md), AGENTS.md |
| D009 | Preserve approved espresso front face; minor visual changes thereafter | Repository-recorded owner decision; original chat unavailable | [visual interface](../visual-interface.md), commit `8e36324`, PR #61 |
| D010 | Lead owns architectural/product judgment; bounded Luna workers extract/draft/validate | Confirmed owner decision, current | Mission §2; [task protocol](../agents/TASK_PROTOCOL.md) |
| D011 | Knowledge mission is additive and protects active development | Confirmed owner decision, current | Mission §11 |
| D012 | Use the “generative imagine prototyping phase” while preserving system integrity and approved visual targets | Owner direction recovered from supplied dated excerpt and saved-memory summary | [Recovered context](../context/RECOVERED_CHAT_KNOWLEDGE.md), C008; [vision](../product/VISION.md) |
| D013 | Personal preference for OpenPoker Lab over other apps/videos is the coaching quality benchmark | Saved owner-memory summary, also explicit current mission; aspirational acceptance direction | Recovered context C004; mission §4 |

## Superseded and unresolved context

Older root/Copilot agent instructions appointed Copilot specialists as the support
layer. The current supplied mission establishes Sol/Luna delegation for this work;
provided owner context also reports a later preference for Luna over Copilot.
Legacy `.github/agents/` and compiled workflows still exist. Their existence does
not prove current subscription availability or successful execution. Preserve them
as implementation/history and audit separately; this mission does not authorize
workflow deletion, budget changes or billing changes.

[Coach architecture](../ai-coach-architecture.md) is explicitly a dated architecture
record, with an early baseline and future slices. Subsequent slice specifications,
code and commits establish what shipped. Do not rewrite that historical baseline
as if it described today's complete solver or coach.

## Adding a decision

### D073: Charge the executed indexed path within unchanged ceilings (October 29, 2026)

Sol accepts the explicit [native indexed admission profile](../native-indexed-admission.md)
after the preserved census identifies legacy Python/Q training forecasts as the
first gate for several larger requests. Keep defaults and prior evidence intact.
Charge real host preparation/diagnostics, native Q construction, numeric learning,
callbacks and Index/Router schedules in one shared work allowance. Remove only
named unexecuted training terms, retain setup/output/history/storage envelopes,
reject foreign modes before training arrays and require independent policy replay.
Development parity is not a frozen capacity or quality result; final study and CI
remain separate gates. No cap increase, numerical trajectory or poker-law change.

### D072: Integrate numeric routing without changing the numerical trajectory (October 29, 2026)

The [indexed training candidate](../native-indexed-routing.md) uses typed visible
prefixes and ordinal Q keys in actual learning, with full-history and shadow
references retained. Preserve old q/order/menu/offset/member bits and physical
support holes, original arithmetic edge order and strict callbacks. Declare all
index/router/caller work and cumulative query entries before allocation; charge
fixed 24-slot arrays regardless of G and retain conservative old history/kernel
overlap forecasts. Use an explicit V2 request/proof and reject instead of fallback.
Independent physical replay and source-frozen measurements precede performance or
broader admission claims. This is additional integration, not full-deck capability.

### D071: Prove exact public-path indexing before changing Q lookup (October 29, 2026)

Sol chooses staged [public-history indexing](../native-public-history-index.md):
first immutable canonical continuation counts/lexical offsets and incremental
suit transitions; later Q and training integration only after complete key,
member-mask, phase/policy and independent replay checks. A shared vertex is never
a full-history identity. Keep exact token ordering separate from numerical
traversal order, owner-bound cursors and the Plan lifetime precondition. Charge
all index arrays, token characters, comparison/query work and simultaneous Plan
storage. Stage A changes no trainer/API/wire/admission result. Measure actual
phases before choosing later optimization; modeled work shares are not CPU shares,
and eliminating an inherited marginal forecast alone cannot admit T1000.

### D070: Join native exact vectors and Q learning in one whole-game process (October 28, 2026)

Sol selects an explicit [native exact four-street backend](../native-exact-whole-game.md)
from the converter/kernel prerequisites. Python legal preparation/API and
independent diagnostics remain measured costs; native independently computes
Z/support/ranks/vectors and the full Q learning trajectory. No Python pair/world,
rank/vector, normalizer or Q witness enters the new protocol. Preserve old guards
and numerical order, member checks, saved misses and separate quality gates.
Reject incomplete positive chance branches and contradictory graph metadata;
charge complete native callbacks, full histories and transport additionally.
Use four Q arrays and release training state before streaming expanded output.
Luna implements the public/Q plan, Terra challenges the draft, Sol corrects the
trainer and root integrates actual API/wire and independent complete-policy tests.
Development bit parity and [two frozen saved-only acceptances](../native-exact-whole-game-result.md)
are achieved. Corrected-source native/sanitizer CI passes; final publication CI
is separate. Preserve exact physical terminal-tail equivalence separately from
the failed strict graph-isomorphism claim, all quality misses and unmeasured
native heap. This is not unrestricted/full-deck scalability or general speed/RAM.

### D069: Compute native exact vectors from physical inputs (October 28, 2026)

Sol accepts the [bounded selected-kernel implementation direction](../native-exact-selected-vectors.md):
one native owner decodes original role priors, computes exact global normalization
and blocker-aware support, ranks physical hands on demand, and completes signed
payoff vectors before strict conversion. No trusted Python Z/ranks/vectors or
pair/world table is an input. Luna implements the header; Sol owns the bounded
conformance protocol, physical tests and integration; Terra challenges arithmetic
and admission independently. Add a separate aggregate logical integer-payload cap
and preserve all older whole-solve limits. Query checks do not establish full
native training, policies, quality, scalability or performance. Frozen provenance
and final native/sanitizer CI govern acceptance before whole-game integration.

### D068: Admit native exact arithmetic before whole-game migration (October 28, 2026)

Sol selects a separate [native exact-product boundary](../native-exact-four-street.md)
to move exact callback computation and Q learning into one process while keeping
Python rules/preparation and independent replay where justified. Legacy rounded
native protocols are not relabeled as exact-product. Reuse pinned standalone
Boost integer arithmetic with retained license and complete source/build closure;
own the game's arithmetic, strict rounding and pre-allocation resource policy.
Luna implements integer-only nearest-ties-even binary64 conversion, Terra
independently challenges it with exact rational boundaries, and Sol owns
dependency packaging, builder, integration and acceptance. Conversion accepts
exact zero as positive zero and nonzero results only if rounded finite normal.
Keep the 65,536-bit input cap and explicit additional 53-bit conversion scratch
cap separate. Neither converter correctness nor successful compilation proves
a poker kernel, native training, speed, memory savings or broader solver quality.
Full-game integration, frozen evidence and final CI remain required.

### D067: Share authenticated public-history work within one decision (October 28, 2026)

Sol uses the frozen Q profile to implement an explicit
[per-decision lookup](../batched-suit-row-lookup.md), retaining per-row lookup
as reference. Authenticate the route/menu once and transform/parse histories
once per group element, then regenerate distinct member identities per hand
without a retained history/member cache. Preserve all numeric operations, phase
checks and the original conservative per-row admission. Complete small-game
policy/certificate parity and member/hole controls pass. The
[frozen study](../batched-suit-row-lookup-result.md) preserves twelve saved policies
and six identical pairs; physical reconstruction confirms reduced route counts.
Original median time improves while traced allocation rises. Final review remains
a gate. This is not native exact computation or
a general runtime/memory claim. Worker usage limits leave Sol/root implementing
this candidate; independent physical oracle code remains unchanged.

### D066: Procedural suit-orbit rows with staged member verification (October 28, 2026)

Under the foundation goal, Sol selects a conservative exact suit group preserving
role-specific exact priors, ordered selected outcomes and the complete public
graph. A [procedural Q-row plan](../suit-quotient-storage.md) retains no expanded
member map and handles stabilizers through distinct-image ordinals/masks. Each
responder/average phase must verify all member bits before committing one
unchanged increment per orbit under D065. Original expanded admission remains;
Q savings cannot reopen a rejected request. Luna implements the trainer, Terra
independently challenges numerical/physical and allocation contracts, and Sol
owns integration and acceptance. Plan/graph controls pass after preserved
adversarial failures. The integrated candidate now passes complete policy,
eight-metric and exact-certificate comparisons plus nine independent phase,
mapping and buffer-lifetime adversarial controls. The 71-test combined suite
passes optimized. The [frozen 23-call result](../suit-quotient-storage-result.md)
preserves eleven identical complete storage-policy pairs and 22 independent
certificates. Eighteen misses, four T100 passes and the T1000 rejection remain.
Symmetric numeric payload falls, but identity groups do not compress and complete
calls/traced allocation regress. Final publication CI remains; this is not a
general memory/performance or commercial-quality claim.

### D065: Establish an equivariant arithmetic reference before strategy sharing (October 28, 2026)

Sol selects an explicit unquotiented binary64 training contract using sorted
finite chance components and fixed action/reach/average operations, preserving
the default trainer and exact completed-query adapter. Luna implements the
whole-game reference; Terra independently challenges lifetime, numerical and
mapping behavior. Canonical positive zero and finite validation apply before
sorting/comparison; local subnormal intermediates remain valid. Reserve added
history-scan work and nested scratch before information allocation. This
[implemented prerequisite](../equivariant-selected-training.md) is not Q storage
or proof of full-game scalability. Actual sharing must verify whole-game suit
closure and distinct-member bits/coverage before each phase commit, avoid an
expanded row map, and retain independent policy/BR replay plus measured costs.
The [frozen reference study](../equivariant-selected-result.md) now independently
replays fourteen complete policies/exact certificates after source authentication;
preserve twelve T10 misses, two one-world passes and the T1000 rejection. Larger
single-call runtime and traced allocation regress, and original 22-world policies
differ by 0.5 in at least one row despite tiny aggregate metric differences.
The reference merged in PR #262 at `728cdd7ca0679f3b05442e295e47647b2d27c5af`
after final checks passed, with exact tree/ancestry verified. Actual quotient
implementation and evidence are scoped separately under D066.

### D064: Measure supported information/history growth before quotienting (October 28, 2026)

Sol accepts shared rank-free preparation for the actual exact-product solve and
its storage census, preserving original complete-request admission. Count supported
full actor/hand/visible-history rows, actions, history tokens/bytes and overlapping
storage phases separately from compact public topology. Enumerate only global
suit maps preserving both exact role-ordered priors and the whole selected ordered
board set. Orbit counts are conservative structural opportunities, never approved
strategy merging or independent BR equivalence. Preserve first cap rejections and
unknown downstream counts; perform no solving/ranking/pair queries. The
[contract and independent controls](../exact-storage-frontier.md) establish bounded
census fidelity; a frozen growth frontier and actual quotient proof remain gates.
The [frozen result](../exact-storage-frontier-result.md) now independently counts
sixteen conditional graph witnesses and retains one work rejection. It shows
linear row/history growth despite a fixed DAG, and identity-only symmetry on
the 16-hand range case. Both reviewer schema repairs remain preserved. Actual
strategy/regret quotienting and reach/average proofs remain separate. PR #261
final checks passed and merged at `1a015ee6adda3f5eb15be8e0ae2865bf57a742a6`;
the reviewed and fetched main trees match exactly.

### D063: Integer query arithmetic under the exact-product law (October 27, 2026)

Sol architecture, Terra independent criticism/execution and Luna implementation
accept an explicit dyadic integer bucket/sweep core inside the current unified
direct-DAG packed solver, retaining Fraction default/reference and completed
rational-to-binary64 conversion. All global normalization, blockers, ranks,
monetary signs and visible-history rows remain. Reject unsupported non-dyadic
query inputs without fallback; preserve old admission even if runtime improves.
Admit integer bit widths/payload separately and distinguish counted query-core
limb models from full arithmetic/CPU. The [contract and current checks](../exact-dyadic-arithmetic.md)
record bounded parity and adversarial controls. The [frozen result](../exact-dyadic-result.md)
now authenticates source before twelve numeric/six exact saved replays. All
paired policies/metrics/certificates match; accuracy misses and old admission
rejection remain. T10 median improves but T100 single call and traced allocation
do not; retain those misses and the separately scoped profiles. Final publication
remains a gate; no native/full-deck or strategy compression claim follows.

### D062: Compact exact-product chance diagnostics (October 27, 2026)

Engineering decision under the foundation goal: make pair-table-free output an
explicit option on the new exact-product four-street solver, preserving expanded
default admission/behavior. Snapshot canonical parsed hand/weight inputs linearly;
charge snapshot work and overlapping storage separately, and perform no production
pair queries in compact mode. Preserve all complete policies/diagnostics when
both modes admit; disclose cases compact admits because individual pair-float
serialization is absent. Keep strict completed-vector conversions and all old
oracle limits. Independent compact verification reconstructs its own bounded
physical support and remains materialized/capped. The [frozen result](../compact-exact-policy-result.md)
retains identical policies/metrics/exact misses, a slower small-game median and
slightly higher modeled peak. The full-range forced-all-in control has no choices
or exact certificate. Terra/Luna quota limits required a separate Sol reviewer;
root performed independent saved replays. No general memory/speed, scalable
strategy/history or full-deck claim follows. Final PR #259 CI remains a gate.

### D061: Explicit exact-product chance and ranked blocker sweeps (October 27, 2026)

Engineering decision after the independently documented non-rank-one legacy
rounded pair matrix: snapshot parsed binary64 weights exactly and define one
new global exact-product selected-game prior. Use exact card buckets and merged
rank sweeps to remove pair scans from batched marginal/terminal queries. Do not
relabel this as bitwise legacy equivalence or alter existing defaults, guards,
native protocols or immutable evidence. Integrate one coherent four-street root
through once-rounded completed vectors and original terminal payoff snapshots,
then independently certify complete serialized policies with the unchanged
exact-product physical oracle. Separately admit whole requested work, bits,
strategy/history/phase-overlap slots and pair-probability serialization. Preserve
admission failures, numerical conversion rejections and quality misses. Terra
found early sign/rank/input/resource defects; Luna corrected implementation;
a separate Sol reviewer completed independent integration scrutiny after their
usage limits. Formal measured and publication gates remain distinct. See the
[contract and current evidence](../exact-selected-kernel-contract.md).
The [frozen result](../exact-selected-kernel-result.md) now validates complete
saved policies under independent exact-product physical replay. It retains
original 22-world T10/T100 target misses and T1000 work rejection, plus a scoped
one-world T1000 exact target pass. Unpaired measured costs establish no general
speed or memory gain. The exact-product input/trajectory distinction remains.


### D060: Native traversal over direct shared vertices (October 27, 2026)

Engineering decision under the foundation goal: add a distinct, explicitly
source-built selected-DAG protocol, retaining the old native selected-tree
source and helper unchanged. Derive compatible-deal prefix support and
vertex/prefix contexts natively; retain separate occurrence row/slot bases for
perfect recall. Remove expanded native node/hand maps while counting contexts,
logical visits, rows and prefix ordinals separately. Preserve original probability,
monetary, reduction and alternating CFR+ contracts and all existing limits.
Require malformed-wire controls, physical numeric/exact saved replay, compiled
Python-version/sanitizer conformance and source-frozen full-call measurements.
No general memory, speed, full-deck or strategy compression claim follows.
Terra/Luna supplied initial review/adapter; both hit an account limit during
validation. Root completed integration/controls; a separate Sol reviewer is the
explicit Terra substitute for remaining independent scrutiny. See the
[protocol and acceptance scope](../native-selected-dag-protocol.md).
The [frozen result](../native-selected-dag-result.md) now preserves all paired
policies and T1000 exact targets, with a scoped native speed result and slightly
higher traced Python allocation. Separate saved reviews authenticate all source
and raw artifacts before numerical/exact replay. The 96-world exact-cap and
T1000-admission misses remain. Final evidence-head CI/publication remain separate.


### D059: Construct shared topology without a literal postflop source tree (October 27, 2026)

Engineering decision after the shared compiler bridge's measured full-call memory
and runtime regressions: build immutable selected-game vertices directly from
the original small preflop skeleton and exact local betting-state recurrence.
Reuse original action helpers, clean only at original fresh-street/translation
boundaries, retain ordered public reveals and full history-policy identities.
Preserve all old logical limits; separately charge canonical contexts/support,
memo/scratch/transition work and every unfolded cached occurrence before growth.
Require literal full-path/action/terminal parity, independent policy/BR replay,
source-frozen complete-call measurements and retained misses. Native DAG traversal
and strategy-history compression remain separate work. See the
[construction contract](../direct-shared-topology.md).

### D058: Share topology while preserving complete information histories (October 26, 2026)

Engineering decision under the owner's foundation goal: intern exact immutable
public transition structure and reconstruct logical histories during traversal,
without merging strategy rows for different histories or public boards. Preserve
action/reveal order, exact numeric bits, global seats and shifted utility. Extend
the existing packed CFR+ kernel explicitly rather than redefine probability or
regret arithmetic. Keep old builders/defaults and all prior admission limits;
charge shared structure, expanded logical work, histories, rows and transient
compiler/cursor state separately. The first bridge consumes a literal tree and
does not remove construction peak; native support and direct shared building are
later integrations. See [contract and evidence gates](../shared-public-topology.md).

### D057: Native selected probability/payoff computation (October 26, 2026)

Engineering decision under the owner's foundation-first goal: integrate native
whole-game CFR+ with the non-materialized selected operator, rather than restore
complete-world/prefix-edge preparation to use the old native wire format. Keep
the old backend unchanged as a reference, retain all existing game/scan/storage
limits and add independent native request/storage admission. Send bounded
per-hand board ranks, verify the global raw binary64 normalizer with an exact
positive accumulator, preserve hidden-information keys, reach and FP reduction
contracts, and require compiled/sanitized controls plus independent complete
saved-policy replay and full-call measurements. No unrestricted/full-deck or
commercial performance claim follows. See [contracts and gates](../native-selected-operator.md).

### D056: Contiguous operator strategy storage (October 26, 2026)

Engineering decision under the scalable-foundation goal: establish bounded
flat numeric storage for the same four-street selected game before choosing
larger abstractions/decomposition. Preserve exact semantic information-set
identity, all actions, separated reaches and the alternating CFR+ reduction
schedule. Keep row storage as the default/reference and old caps unchanged;
admit dense holes, flat arrays and complete requested layout work separately.
Require complete-policy parity, independent policy/BR replay and full-call
memory/cost measurements. This does not establish sublinear strategy storage
or full-deck support. See [scope and acceptance](../packed-operator-strategy.md).

### D055: Bounded selected-board rank reuse (October 26, 2026)

Engineering decision under the owner's foundation goal: profile the integrated
non-materialized path before optimizing. Add explicit solve-local rank-vector
LRU capacity, preserving the default one-board path, selected-board identity,
chance/reach reductions and old scan/rank admission. Bound retained and active
construction references separately before ranking; keep caches out of policy
identity and never cache failed builds. Accept only after complete policy and
independent BR replay plus source-frozen complete-call measurements. This does
not resolve explicit tree/strategy storage or full-deck solving. See
[scope and protocol](../selected-board-rank-cache.md).

### D054: Non-materialized selected-game training foundation (October 26, 2026)

Authority: owner's supplied scalable-solver goal. Sol leads architecture; Terra
provides independent criticism; Luna implements the operator. Introduce a
separate opt-in selected-runout chance/payoff provider into the shared betting
and CFR architecture, preserving global conditioning and original numerical
rules. Retain the materialized solver as the small-game reference. Do not
substitute full-deck prefix probabilities for selected-board conditioning.
Require independent physical reach/payoff and serialized-policy/BR replay,
source-pinned paired measurement and quantitative tree/strategy census. This
bounded milestone leaves overall foundation work active. D052 remains reserved
for the separate paused expansion. See [contracts and protocol](../selected-operator-four-street.md).

D014 (2026-10-16): engineering decision under the owner's authorized compiled
backend development scope: implement bounded native preflop count preparation as
a separate explicit source-built API. Preserve the default Python reference,
progress callbacks, immutable table, all admission limits and solver payloads.
This isolates compiler/protocol failures and permits complete-call comparison
without implicit tool installation. Third-party evaluator reuse and a default
backend switch were not selected. Implementation and evidence status are tracked
in [native preparation](../native-preflop-equity.md); no toolchain distribution
clearance or broader game coverage is implied. No earlier decision is superseded.

D015 (2026-10-16): engineering decision under the owner's ongoing preflop/flop
solver scope: extend the reusable full-board preflop table through a separate
finite preflop betting adapter with forced hidden future checkdown. Reuse the
existing betting builder and scalar CFR/CFR+ kernels, with an independent
configuration-derived pre-build admission envelope and numeric replay oracle.
This adds limps and finite raises without changing selected-outcome APIs or
later-street work. Full-deck postflop betting is deferred; the existing pair
caps remain. See [scope and evidence](../preflop-full-checkdown.md) for actual
validation/publication status. This decision adds a model, not a claim of
unrestricted NLHE or an exact finite-iteration equilibrium. No prior decision
is superseded.

D016 (2026-10-16): engineering decision under the owner's efficiency scope:
provide explicit per-private-pair signed-mean world indexing for full-board
preflop forced-checkdown. The hidden category is never available to a decision,
and terminal payoff is linear in sign; retain hidden opponent-hand distinctions
and full pair mass. Preserve the categorical default and independently validate
floating-point and finite-iteration effects. Admit the complete requested P-world
work with unchanged structural/source caps and retained category setup. See
[proof, boundaries and measured status](../preflop-pair-mean.md). No default switch,
third-party implementation or broader game model is authorized by this choice;
no prior decision is superseded.

D017 (2026-10-17): engineering decision under the owner's authorized compiled
backend scope: provide separate explicit source-built fixed-public-tree native
training for the prepared preflop and forced-checkdown flop models. The
[measured prepared-call profile](../fixed-street-profile.md) identifies training
as the dominant cost. Preserve Python rules/diagnostics/default payloads, all
historical admission and a separate complete native work/storage envelope.
A static C scalar traversal is the first experiment. Its fixed-flop DCFR policy
gate miss is retained in the initial report. The followup uses compiled
public-hand-vector reduction for flop, while preserving preflop scalar math,
original acceptance gates and the failed evidence. A Python default switch,
third-party solver implementation, public-chance support and compiled diagnostics
were not selected. See [scope and evidence](../native-fixed-street.md) for actual
validation/publication status. No earlier decision is superseded.

D018 (2026-10-18): engineering decision under the owner's continuing independent
solver-validation scope: establish an exact weighted preflop forced-checkdown
equilibrium anchor before expanding private-pair or future-betting coverage.
Reuse the project-owned bounded rational simplex without changing its limits;
independently reconstruct physical-count payoffs, legal histories, primal/dual
witnesses and own-information responses. A separate pure-response check guards
hidden-information mistakes. This adds a research certificate and validation
target, not production behavior or broader equilibrium coverage. See
[scope and publication status](../preflop-weighted-sequence.md). No earlier
decision is superseded.

D019 (2026-10-18): engineering decision under the owner's ongoing accuracy and
efficiency scope: compare prepared Python/native preflop strategies to the
separately certified weighted exact game value. Keep exact reference proof,
finite-strategy legal best responses, quality targets, cross-backend agreement,
complete-call timing and Python allocation traces distinct. A policy-distance
gate to one LP equilibrium would penalize legitimate alternate or unreachable
policies, so legal exploitability and exact value containment govern accuracy.
No production algorithm or default changes are selected. See
[protocol and measurement status](../preflop-exact-anchor-comparison.md).
No earlier decision is superseded.

D020 (2026-10-18): engineering decision under the owner's ongoing broader-range
solver scope: pool already covered full-board count sources through joint suit
bijections into a separately bounded prepared table and explicit solving entry.
This removes the enumeration cap from the prepared-data representation without
changing enumeration itself, and reuses the existing betting/training body.
All full-request solve limits remain; missing or conflicting source coverage
rejects. Raising global preparation limits or merging private information sets
was not selected. See [scope and evidence](../preflop-covered-counts.md).
No prior decision is superseded.

D021 (2026-10-18): engineering decision under the owner's independent validation
and compiled-computation scope: add an isolated project-owned exhaustive best-five
reference to establish new physical preflop source rows without reusing the
production direct-seven-card evaluator. Require complete five-card tuple parity,
known category totals, fixed full-board counters, the existing independently
enumerated anchor and independent production count agreement. The tool has only
fixed finite modes and no solver/backend/default integration. See
[method, work units and publication status](../preflop-five-card-reference.md).
No prior decision is superseded.

D022 (2026-10-18): engineering decision under the owner's independent validation
and broader-range scope: extend the project-owned best-five reference with a
strictly bounded explicit private-pair argv mode. Require current-build exhaustive
conformance before each source query, retain all original production query caps,
and physically verify missing QQ/KK suit classes for later mixed-range work.
Source/evaluator/solver defaults remain separate; generic unbounded enumeration
and imported evaluators were not selected. See
[method, caps and publication status](../preflop-generic-five-reference.md).
No prior decision is superseded.

Record ID, date, authority, source, rationale, considered alternatives where known,
status, affected interfaces and superseded IDs. A new ADR is useful for a major
tradeoff; minor entries belong here. Never invent rationale to fill a template.
Materially conflicting owner intent stays open in [knowledge gaps](../context/KNOWLEDGE_GAPS.md).

D023 (2026-10-21): under the owner's autonomous flop/preflop detour, add an
isolated fixed-game class CFR+ research adapter after the full no-training proof.
Retain the 140-sweep physical reference envelope, unchanged shared recurrence,
raw average rows, explicit exact-grid output normalization and unrestricted
physical own-hand responses. Require a frozen first pilot and separate evidence
for any later budget or performance claim. No prior decision is superseded. See
[scope and admission](../flop-class-cfrplus.md).

D024 (2026-10-21): under the ongoing autonomous flop/preflop detour, add a
separate opt-in compact-work fixed-flop research entry after the 140-sweep
physically verified quality miss. Charge named compact recurrence/setup/output
loops under pinned shared sources and a separately versioned 76-million cap,
with at most 560 requested sweeps and unchanged fixed physical preparation/BR
checks. Preserve the legacy adapter and its source-pinned result literally.
This is a new explicit resource policy, not a silent relaxation of defaults or
a convergence/performance claim. See [scope](../flop-class-compact-cfrplus.md).
No prior decision is superseded.

D025 (2026-10-21): after the independently replayed fixed-flop 560-sweep
quality pass, prioritize complete-call runtime and allocation evidence before
choosing another performance architecture. Freeze three paired timed rounds
and one separate allocation call per entry, retaining every payload, miss,
failure and source identity. Both entries already use the same representation;
comparison across 140/560 sweeps describes different quality/work budgets, not
a same-work speedup. See [measurement scope](../flop-class-call-cost.md).
No prior decision is superseded.

The D025 eight-call study completed on 2026-10-22 with all policies and source
identities retained, zero recorded errors and saved verification passing. Its
[observations](../flop-class-call-cost.md) qualify runtime variation and Python
allocation scope; phase profiling is the next diagnostic, not a speed claim.

D026 (2026-10-22): after the completed fixed-flop eight-call study, add one
separate instrumented 560-sweep compact call to locate time allocation before
selecting another performance architecture. Require full-request admission,
clean source snapshots, pilot-semantic equality, lossless report retention, and
reversible nested wrappers around existing boundaries. Inclusive phase times
overlap and include instrumentation overhead; they do not replace primary
medians or establish a speed, memory, or bottleneck claim. No solver/proof/
recurrence source or default changes are selected. See [profile scope and status](../flop-class-phase-profile.md). No earlier decision is superseded.

The D026 single-call profile completed on 2026-10-22 with 21 retained events
and the unchanged passing pilot policy. The observed largest root interval is
publication verification; no prepared-reuse or production architecture has
been implemented by this measurement.


D027 (2026-10-22): after the merged runtime/phase studies, prioritize a new
family of fixed-support range-prior games rather than optimizing certification
cost alone. First require a separate no-training proof for baseline, uniform
and skewed positive rational weights, including global blocker conditioning,
fresh weighted physical reconstruction and exact legal response equivalence.
Keep old-prior anchors/sources unchanged, all request/resource guards explicit,
and all failed/partial work retained. Training under new priors remains a later
milestone. See [scope and evidence](../flop-class-reweight.md). No previous
decision is superseded.


The D027 single frozen proof batch completed on 2026-10-22 with all three
positive-prior cases, twelve exact-response controls, fifteen retained artifacts,
zero errors/training and stable committed sources. Saved authentication is
separate from fresh physical replay. New-prior training remains the next bounded
milestone; these controls make no convergence claim.


D028 (2026-10-22): after the completed D027 no-training proof, implement a
separate three-prior CFR+ research adapter with the unchanged shared recurrence,
positive joint masses, its own explicit setup charge and fresh unrestricted
physical responses. Freeze one 560-sweep call per prior; require exact historical
baseline calibration and retain every quality miss/failure without tuning or
retry. Actual training waits for the proof merge and clean reviewed source.
See [scope and pending evidence](../flop-class-reweight-cfrplus.md). No prior
decision is superseded.


The D028 single pilot and all three fresh saved-policy replays completed on
2026-10-22 at frozen e1. Baseline calibration passed; normalized-policy exact
NashConv was 0.002892400528, 0.000012958529 and 0.000993121225 for baseline,
uniform and skew, each below 0.005. All raw policies, normalization records and
exact response metrics are retained, with no lost positive probabilities, errors
or retries. Training count was three; subsequent physical replay count was three
with zero training. These finite-game results do not select a performance or
broader-card-support claim.


D029 (2026-10-22): after the three-prior quality pilot and independent physical
replays, locate baseline call time and Python allocation scope before choosing
another efficiency architecture. Freeze one phase call and one separate traced
call at 560 sweeps, requiring full published report byte equality, complete
admission, reversible instrumentation and no retries. Inclusive events and one
Python peak are diagnostics, not comparative speed/RSS or general bottleneck
claims. See [scope and pending status](../flop-class-reweight-baseline-diagnostic.md).
No earlier decision is superseded.

D029 observation: the one admitted batch completed without errors/retries and
both full reports match the previously replayed baseline exactly. Thirteen phase
events include four repeated full model validations. The separate trace records
401,901,644 new Python allocation bytes and a large retained wall/CPU gap; no
comparative or general performance claim follows. Investigate call-owned model
integrity before considering validation reuse; a mutable flag/cache alone is
insufficient. The existing checks remain required. See the completed evidence
and its qualifications in the linked diagnostic document.

D030 (2026-10-22): before a validation-reuse performance experiment, test complete
call-owned model integrity coverage separately, retaining unchanged independent
validation before and after six bounded graph fingerprints. Require exact stable
and restored digests/censuses, action and rooted-index alias mutation detection,
39 clean source hashes, zero guarded authorities and first-error retention.
A digest is not model validity, immutability or permission to bypass validators.
No real fit, performance or memory claim exists yet. See
[the no-training investigation](../flop-owned-fingerprint.md).

D030 observation: the one admitted fresh baseline model fits the declared graph
caps. All six fingerprints complete, both mutations change the digest, and both
restorations/repeat return exactly to the original digest and census. Stable
tracked objects/edges are 318,280/1,608,777; 39 sources are clean/stable and all
41 authority counters remain zero, with two unchanged full validations and no
training/errors/retries. This does not authorize reuse or select a performance
architecture. Broader flop-board support remains a separate independently proved
slice with freshly measured partitions and tree dimensions.

D031 (2026-10-22): broaden flop correctness evidence to the fixed `7c8d9h`
board before choosing a validation-reuse performance architecture. First freeze
one admitted no-training physical-reference build and candidate partition, with
fresh complete world/tree views and hashes. Keep exact global blocker priors,
bounded and counted reference ranking, full source/error receipts and unchanged
candidate-only flags. New class dimensions are measured, not inherited from
`2c3d4h`. This preparation does not establish full class/tree or best-response
equivalence; that separate proof must precede training. See
[the reference protocol and pending status](../flop-second-board-reference.md).
No earlier decision is superseded.

D031 observation: the one frozen reference batch completed without errors or
retries, with one physical build/candidate partition, 4,134 preparation and
4,134 same-ranker recheck calls, all 5,940 world signs compared, clean stable
44-source identities and all 41 guarded authorities at zero. Fresh candidates
have 13 turn classes, 17 river signatures and 170 class worlds. Complete
physical world/tree views and hashes are retained. These measured dimensions
establish a new reference; they do not prove public-chance equivalence or
authorize training. Across-class variation is a valid future control; physical
card-specific variation within a class must reject projection.

D032 (2026-10-23 UTC): independently prove the fixed second-board quotient
before training. Freeze one complete no-training batch with fresh physical
anchors, full joint support/masses/signs and both numeric reveal subtrees.
Require exact compact/unrestricted own-hand responses and separate numeric
replay for four positive class-constant controls, preserving all rows/actions.
Across-class variation is valid; within-class card variation and near-normalized
floats must reject. Admit every proof/response/output family before any ranking,
retain source/error/policy receipts and change no shared or published source.
See [the full protocol and pending execution status](../flop-second-board-equivalence.md).
No earlier decision is superseded.

D032 observation: the one frozen batch passed all joint-mass and complete
two-reveal numeric subtree checks, all four positive exact/numeric response
controls and both intended projection rejections. It derives 170 compact worlds,
1,270 numeric states and 608 own-hand rows, retaining all six complete policies.
Ten model proofs, eight exact metric calls, four numeric replays, six projections,
one fresh physical build and 4,134 rank calls completed without errors/retries.
Clean 49-source identities and all 41 zero authority counters are preserved.
The controls are not trained strategies and establish no quality target,
convergence, speed, memory or unrestricted NLHE result. Publication authentication
and CI must finish before a separate new-board trainer is admitted.

D033 (2026-10-23 UTC): stage a separate fixed second-board CFR+ pilot after
D032 publication validation. Keep a distinct versioned 110M named logical-work
envelope and the unchanged shared recurrence; the old 76M cap is preserved.
Freeze fresh T140/T560 calls and exact physical NashConv<=0.005 checks, retaining
all target misses. Validate the complete model before/after, all positive joint
masses, own-hand information rows, both response domains and separate numeric
replay. Keep raw averages, normalized full policies, errors and source identities.
No training or quality result is claimed by this staging decision. See
[the pilot and its limits](../flop-second-board-cfrplus.md). No earlier decision
is superseded.

D033 observation: the one frozen v1 batch stopped after T140 on an adapter
schema check that wrongly excluded replay audit metadata. T560 never ran;
the original quality gate is null. Retain the complete failed report, raw and
normalized policies, identical compact/physical exact metrics, original error,
all zero guard counters and clean source identities. Final model validation
passed, but the numeric replay return was not saved and the case is not a
completed verified policy. Preserve frozen v1 sources and require a distinct
reviewed correction/protocol before further measurement. See the
[retained failure](../flop-second-board-cfrplus.md).

D034 (2026-10-23 UTC): stage a distinct
[replay-boundary v2](../flop-second-board-cfrplus-replay-v2.md) rather than alter
the frozen D033 failure. Authenticate the stopped-v1 saved evidence, wrap one
unchanged independent replay call, retain/validate its full thirteen-field
return, and expose the eight numeric metrics to the preserved adapter. Require
restoration on every exit, exact-once counting, stable 58/54 source identities
and the unchanged exact/numeric/model guards. Keep the same fresh T140/T560
quality protocol and separate named resource envelopes; no v2 actual training
or quality result is claimed by this staging decision. No earlier decision is
superseded.

D034 observation: the single frozen replay-v2 batch completed T140/T560
without execution errors, retries or fallbacks. Exact compact and unrestricted
physical metric maps agree, numeric gaps remain below 7e-16, both full replay
receipts are retained and source/model/authority checks passed. Keep T140's
0.014166984012911272 NashConv miss and T560's 0.0016464625267553663 pass as
separate finite-game observations. Two models/training calls, six proof passes,
four exact calls, two replays/projections and 8,268 ranks are recorded. The v1
failure stays unchanged; saved-data authentication/CI still gate publication.
See [the complete outcomes and limits](../flop-second-board-cfrplus-replay-v2.md).

D035 (2026-10-24): **confirmed owner instruction in the integration chat**:
temporarily pause independent preflop/flop and turn/river development and make one
coherent game model spanning all four streets the primary solver objective. Audit
existing engines/state/ranges/actions/transitions/validation first; maximize reuse
of verified implementations; preserve accuracy benchmarks; demonstrate a complete
small four-street game before gradual realistic heads-up NLHE expansion. Connecting
independent street policies does not establish a complete-game equilibrium. Sol
leads audit, architecture, milestones and task scoping; Luna handles routine
implementation/tests, Terra difficult implementation/debugging, and Sol architectural
decisions. Pause for review before major refactors. Unrelated features and isolated
benchmark optimization are out of this phase unless necessary for integration.

The [pinned integration audit and proposed design](../unified-solver-integration.md)
records an existing selected-outcome combined-root four-street path and separates
that verified implementation from new contracts, evidence gates and future work.
The owner has approved the priority and workflow, **not yet the proposed technical
architecture or implementation launch**. This instruction takes precedence over
earlier isolated-street development priorities while retaining their mathematical
constraints and immutable evidence.

D036 (2026-10-24): **confirmed subsequent owner instruction in the same chat**:
the owner revoked the pause for their review, requested continuous work as an
active goal, and delegated review responsibility to the agent until instructed
otherwise. This supersedes D035's owner-review/implementation-launch gate and
the initial audit's waiting status. The integration objective, Sol architectural
lead, Luna bounded implementation/tests, Terra difficult implementation/debugging,
independent mathematical validation and preservation of existing evidence remain.
The agent performs architecture/implementation reviews, advances scoped milestones,
resolves ordinary defects, and publishes completed changes through GitHub without
waiting for the owner. A failed quality gate remains a miss; a capacity rejection
remains unknown. These are inputs to autonomous review and a separately justified
next step, not reasons to silently change the old experiment or stop for approval.

D037 (2026-10-24): Sol architectural review under D036 approves the additive
[four-street request/result boundary](../four-street-solver.md): reuse the current
all-streets `solve_preflop` engine through one exact delegation, frozen input
contracts and a complete immutable JSON result snapshot. Keep existing graph,
numerical, admission, strategy-row and history semantics. Ordinary calls explicitly
report unknown source revision; authenticated source and exact-normalized quality
certificates belong to the later frozen integration runner. Exclude advanced
sampling/grouping/compaction/delay/stopping options from this initial facade.
Existing analysis/Coach contracts and simulator state remain separate. The lead
reviewed the implementation and executed the combined 50-test boundary/legacy
suite; the new contract-only suite also passes with optimized Python. This is an
interface milestone, not the final whole-game quality gate or full-deck coverage.

D038 (2026-10-24): autonomous Sol-led review accepts the bounded independent
[four-street numeric model and staged corpus](../four-street-integration-protocol.md).
Reuse old numeric-state/ranking/replay utilities read-only; independently rebuild
physical support, betting, reveals and complete information rows without production
tree/rank/payoff/evaluation/BR authorities. Preserve binary64 parenthesization,
local quantization, fixed preflop ledger origin, refunds and global SB/BB identity.
Require bounded snapshotted inputs, joint selected-world conditioning and all
off-path row checks. Fifteen focused tests pass normally and under optimized
Python; the combined numeric/interface/legacy suite passes 44 tests. A complete
T10 development policy passes all 1,200 row checks with maximum scalar replay gap
2.498001805406602e-16. No exact generic certificate or frozen quality run is claimed.
Proceed to a fresh call-owned rational evaluator with full named-work forecast,
100,000 work/65,536 Fraction-bit caps and grouped legal own-hand best responses;
then review its controls before freezing the one-call accuracy experiment.

D039 (2026-10-24): the first exact evaluator's full structural forecast rejects
the unchanged 22-world fixture at 118,261 modeled work against the 100,000 cap.
Preserve this development source/census and its unknown whole-fixture quality;
eight small/control tests passing does not satisfy U4 or authorize training.
Sol approves a distinct evaluator v2 correction that computes the current-profile
value inside the SB grouped legal-response traversal, sharing weighted terminal
sums while retaining all legal SB actions. Opponent reach alone weights groups;
SB policy mixtures supply SB reach exactly once. Keep separate BB response,
complete normalization/output ledgers and existing caps/fixture/threshold. Add
common named actual/forecast events and per-family dominance checks, preserving
the v1 capacity miss. Require fresh census and exact mixed/zero/tiny-probability,
hidden-future and literal coupling controls before the frozen runner is eligible.

D040 (2026-10-25): root review accepts the v2 prescribed-policy controls for
bounded frozen-runner implementation. Sol's fused profile/response proof and
storage correction retain the same game/caps; the full forecast is 98,298,
including two root result slots. All ten exact-control tests pass normally and
under optimized Python; the combined 54-test suite passes. The literal check/call
value is 1/34, the prescribed one-row river change yields 5/34, and the same legal
response bounds remain. Complete normalization ledgers, slow exact profile
comparison and familywise runtime/forecast checks pass. Case snapshot copying
now has a 1,024-node bound before expansion. Preserve D039's rejected source and
census. The runner may be implemented with inert tests; final architectural
accounting/preparation disclosure, clean source authentication, both official
admissions and runner/authenticator review must pass before any production
quality call. No trained-policy quality outcome is claimed by these controls.

D041 (2026-10-25): Sol's final read-only review accepts the U4 fused profile/legal
response mathematics, hidden-information boundaries, normalization and familywise
98,298-work envelope, qualified by separate bounded graph-preparation reporting.
Record conservative world-scan, copied-reference and information-index bounds
for the forecast's two and evaluation/identity's three owned-graph walks. Keep
all existing named node/edge/mass charges and hard caps unchanged; neither receipt
is a Python-operation, byte or RSS guarantee. A narrow guarded text formatter
uses exact integer Decimal construction separately for Fraction numerator and
denominator, avoiding Python's lower default string digit limit without Decimal
division or global-setting changes. Independent large-component round trips
pass. The combined 57-test suite and thirteen focused optimized tests pass.
This closes U4's qualified mathematical/control review. The unexecuted production
quality call remains gated by runner/authenticator validation, clean source
authentication and both official admission receipts.

D042 (2026-10-25): Sol/root review accepts the single-attempt runner and saved-only
publication verifier for clean-source freezing. Seventeen lifecycle/integration
controls pass normally (163.405 seconds) and with optimized Python (193.238 seconds).
They use the full real source closure and actual no-training preparations, with
synthetic complete policies; production solve/trainer tripwires remain untouched.
Fresh independent support, numeric replay and full exact certificates/ledgers
authenticate retained misses. Altered raw/numeric/source/ledger artifacts reject;
a partial pre-training claim remains a failure, and a forged exact capacity
failure rejects when fresh replay succeeds. Numeric exploitability comparison
derives NashConv/2 from the preserved oracle. The scripts directory remains a
namespace package. Pin the 16 MiB raw-artifact bound before execution; it is
separate from all unchanged mathematical and production admission caps. This
accepts implementation controls, not a frozen production quality result. The
single T1000 call still requires clean committed source, fresh official admissions
and publication verification. No additional owner review gate is introduced.

D043 (2026-10-25): the sole fixed U5 production attempt completed and passed its
exact normalized whole-game NashConv target of 1/1000 BB. Frozen source is
bf1c21b17e84162dea3a3a68104e785b19269b40, with all 24 pre-run CI checks green.
Both official admissions preceded the claim and the one production call. The
complete 1,200-row policy has exact NashConv approximately 0.000399738815144135 BB;
all seven subsequent source checks match the original 314-file snapshot. Fresh
saved-only replay authenticated the pinned report and entire numeric/exact ledger
with zero solver/trainer calls. Accept this named finite conditioned game to its
declared tolerance; no unrestricted/full-deck quality or performance claim follows.
Publish the byte-identical twelve-artifact corpus and verification receipt, keep
the frozen protocol/fixture unchanged as historical execution inputs, and preserve
all earlier failures and misses. See the [complete result](../four-street-integration-result.md).
The next integration expansion may be scoped only with a fresh joint law and
full requested forecasts under unchanged caps, before any new training.

D044 (2026-10-25): after v1 passed saved-only authentication and its code/evidence
merged in PRs #237/#240, Sol accepts the next M5 ticket as preflight only. Append
`5c6d7s8cKc` to the six existing outcomes and change only the case ID; all public
request fields except runouts remain literal v1. Reuse both preparations and the
generic complete-game forecast, preserving the full false forecast and support
comparison before any rejection. One real test verifies 26-world support, four
analytic pair masses, the added winner reversal and zero solver/trainer access.
Keep all old sources, corpus bytes, thresholds and caps unchanged. The fresh
source-frozen receipt is still required; no expanded-game solve is authorized by
this implementation acceptance. See the [preflight specification](../four-street-expansion-preflight.md).

D045 (2026-10-25): the official M5 preflight on clean committed source
644eae2b3036dff71d81a1e445d675476beb155a preserves a complete admission rejection.
Both 315-file snapshots match; production admits 26 worlds and 188,281,040 modeled
vector work under 500 million. Independent support and all signs/masses match,
but the exact all-positive forecast is 113,078 against 100,000, a 13,078 deficit.
No production solve or training ran and quality remains unknown. Publish the
unaltered full receipt before a separate certificate correction. Sol's analytical
proposal combines first-mass signed terminal accumulation with one maximum
normalization-adjustment absolute value per row, retaining every ledger entry;
the proposed 99,119 forecast is not executable admission evidence. Keep all v1
sources/corpora, game/threshold and hard caps unchanged. A fresh direct-graph
census, same-policy exact parity and normal/optimized controls must precede any
corrected preflight, and training remains gated by observed complete admission.

D046 (2026-10-26 UTC): Sol/root review accepts the narrow private trusted
operator seam rather than duplicate hundreds of lines of verified response and
ledger orchestration. Extract the literal terminal-group loop, retain fixed
public signatures and fresh owned-model boundaries, and preserve default-v2
arithmetic, counters and complete receipts. All 15 certificate controls pass
normally and with assertions disabled; a byte-authenticated regression compares
the entire published certificate. Historical source/corpora stay immutable in
Git. Implement the distinct v3 signed-first-mass and row-extremum operators next,
with fresh bounded census and complete mathematical/output parity controls
before corrected preflight. No cap increase or training result is established.
See [operator scope and acceptance](../four-street-exact-operators-v3.md).

D047 (2026-10-26 UTC): Sol/root accepts the distinct v3 first-mass signed
terminal and maximum-individual-adjustment operators after static review and all
31 certificate/preflight controls pass normally (59.246 seconds) and with
assertions disabled (58.735 seconds). Preserve complete default-v2 certificate
and original113078 rejection parity, all signed ledger entries, exact configured
binary64 payoffs and all caps. Fresh all-positive census piggybacks on the shared
response forecast with explicit fixed/per-group logical setup/output/reference
charges and aggregate graph/census preparation admission. Positive and pruned
policies fit every forecast family; independent coupling anchors are -1/20 and
+1/20 BB. The fixed corrected preflight reuses source capture/exclusive writing,
uses distinct validator identities and exposes no caller-selected callback.
Freeze clean source and measure the actual corrected no-training admission next;
no expanded-game quality outcome follows from prescribed-policy controls. See
[the implementation and scope](../four-street-exact-operators-v3.md).

D048 (2026-10-26 UTC): the corrected source-frozen preflight on clean committed
98c3a779b079ee838c92727ed852af6d447e2f39 completed with exit code 0 and admits
99,119/100,000 exact work units. Production admits188,281,040/500million; all26
worlds and four pair/sign/mass support match. Both317-file source snapshots match.
The15,901-entry fresh census plus448,760 graph-preparation envelope totals464,661
under8million. Preserve the original113,078 rejection and the new full raw receipt;
zero production calls and qualitynull distinguish admission from trained quality.
All61 wider solver/interface/lifecycle tests pass (271.068 seconds), together with
the31 normal/optimized focused controls and documentation validation. Proceed
with a separately identified frozen26world/T1000 quality-runner and saved-only
verifier through private fixed-experiment reuse seams; retain originalv1 behavior
and source-authentication-before-mathematics. No cap, iteration or game-rule
change follows. See [corrected admission and scope](../four-street-exact-operators-v3.md).

D050 (2026-10-25, America/New_York): the owner explicitly requests language
optimization and implementation without preserving Python for convenience. Sol
selects a C++ public-chance CFR+ computational backend with Python preparation,
API and independent numeric/exact validation. Profiling the existing coupled
fixture identifies repeated training as the first migration boundary. Terra
implements the bounded chance-aware engine/transport/build; Luna owns compiled
controls, reproducible complete-call comparison and CI. Native selection is
explicit, retains all original admission and zero-delay alternating semantics,
and rejects unsupported configurations without fallback. Existing frozen
engines, evidence and defaults are preserved. Rust remains a credible alternative;
there is no equal-work Rust comparison or universal language-optimality claim.
Acceptance requires compiled controls, independent whole-game replay, same-work
timing and source/build provenance. See the [architecture and language assessment](../native-four-street-architecture.md).

D051 (2026-10-26, America/New_York): Sol accepts the scoped C++ public-chance
CFR+ migration after Terra implementation, independent Sol resource/recurrence
review and Luna compiled/lifecycle validation. The clean published source freeze
0985645 completed all six T1000 complete-call comparisons: Python median
54.243413 seconds, native median 0.814282 seconds, ratio 66.6150, and zero policy
probability difference across each of the three pairs. Every independent numeric
replay passed; a separately authenticated saved native policy passed the unchanged
exact normalized 1/1000 BB gate at approximately 0.000399738815144135 BB, with
92,534/100,000 exact work. Retain full raw policies, timing samples, source/build
identities and exact normalization ledger. Twenty-four focused controls pass
normally/optimized; 53 legacy controls pass, together with docs. Linux native
Python 3.11-3.13 and sanitizer checks passed at the code freeze; final PR-head
checks still govern merge. Python preparation/API and independent oracles remain
justified by the measured boundary. No memory/RSS, Rust comparison, wider support
or algorithm/convergence-mode migration follows. See [retained evidence](../native-four-street-result.md).

D053 (2026-10-26, America/New_York): the owner prioritizes a foundation-first
audit against a commercial four-street educational solver and authorizes
evidence-backed action, preserving functioning and frozen work. Sol/root finds
and contains an accepted-input underflow defect: materialized joint masses could
erase a roughly 9% posterior or change a 2:1 distribution into 1:1. Reject
zero/subnormal/nonfinite raw and normalized masses in four existing producers;
preserve literal admitted arithmetic. Sol independently accepts the bounded
full-deck prefix-mass experiment implemented by Luna, with global root
normalization, exact binary64-image fractions and no pair/future-world storage.
This is research probability work, not a new trainer or selected-game parity
claim. Preserve current native/finite-game achievements and unresolved broader
quality misses. Resolve game-law, representation/storage, scalable verification
and per-action educational evidence before further product expansion. Terra was
unavailable; root handled difficult numerical work. D052 is reserved for the
paused expanded-runner workstream. See [assessment and gates](../foundation-first-audit.md)
and [executed record](../foundation-first-execution.md).

The same audit also exposed assertion-dependent legacy evidence acceptance.
Harden all 84 original predicates in four named validators to explicit checks;
independently normalize legacy preflop replay's parsed-input chance weights
exactly before one float conversion and reject nonfinite comparison data.
Configured binary64 action/payoff rules remain fixed. The final combined 175
tests pass normally and optimized, including compiled controls and adversarial
subprocesses; mechanical conversion of three validators preserves complete AST
predicates/messages. Local full-suite execution was interrupted after source-drift
guards fired during ongoing edits; final clean-head CI remains a separate gate.
