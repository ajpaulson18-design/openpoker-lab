#pragma once
// Sparse fixed-Q52 vanilla strategy rows for two sequential uniform epochs.
// This is a component contract, not a trainer or admission for other games.
#include "dyadic_policy.hpp"
#include "virtual_dyadic_history.hpp"
#include "virtual_strategy_catalog.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace openpoker::virtual_sparse_strategy_epoch {
namespace policy = dyadic_policy;
namespace history = virtual_dyadic_history;
namespace catalog = virtual_strategy_catalog;
using Integer = policy::Integer;
using RowId = catalog::RowId;
using History = history::History;
using Catalog = catalog::Catalog;
using Cursor = History::Cursor;
inline constexpr std::uint64_t grid = policy::grid_units;
inline constexpr std::size_t action_limit = 4;
inline constexpr std::size_t epoch_limit = 2;
inline const Integer regret_denominator = Integer(580) << 625;
inline const Integer average_denominator = Integer(580) << 364;
inline constexpr std::uint64_t work_cap = 75'000'000;
inline constexpr std::size_t entries_cap = 2'000'000;
inline constexpr std::size_t payload_bits_cap = std::size_t{1} << 30;

enum class ErrorKind { invalid_limits, owner_mismatch, failed_owner, active_lease,
                       lease_generation, incomplete_walk, row_or_menu, duplicate_stage,
                       epoch_limit, arithmetic, resource_limit, quantizer };
enum class ProposalLaw { uniform_public, weighted_river };
class Error final : public std::runtime_error {
    ErrorKind kind_;
public:
    Error(ErrorKind kind, const char* message) : std::runtime_error(message), kind_(kind) {}
    [[nodiscard]] ErrorKind kind() const noexcept { return kind_; }
};

struct Limits {
    std::size_t max_rows_touched = 1'060;       // cumulative across two transitions
    std::size_t max_slots_touched = 2'564;
    std::size_t max_stage_rows = 530;           // per transition
    std::size_t max_stage_slots = 1'282;
    std::uint64_t max_reads = 2'136;            // two policy reads per row plus controls
    std::size_t catalog_max_public_blocks = 24'420;
    std::uint64_t max_work = work_cap;
    std::size_t max_entries = entries_cap;
    std::size_t max_payload_bits = payload_bits_cap;
    std::size_t max_epochs = epoch_limit;
};

struct Forecast {
    std::uint64_t constructor_work = 0;
    std::uint64_t lease_work = 0;
    std::uint64_t read_work = 0;
    std::uint64_t stage_work = 0;
    std::uint64_t commit_work = 0;
    std::uint64_t quantizer_work = 0;
    std::uint64_t catalog_read_work = 0; // billed by Catalog
    std::uint64_t history_read_work = 0; // billed by History
    std::uint64_t own_work = 0;
    std::uint64_t component_work = 0; // Store + Quantizer; do not double-count borrowed owners
    std::uint64_t work = 0;
    std::size_t entries = 0;
    std::size_t payload_bits = 0;
    std::uint64_t max_quantized_rows = 0;
};

struct Receipt {
    std::uint64_t work = 0;
    std::uint64_t reads = 0;
    std::uint64_t staged_rows = 0;
    std::uint64_t staged_slots = 0;
    std::uint64_t commits = 0;
    std::uint64_t quantizer_work = 0;
    std::uint64_t quantized_rows = 0;
    std::size_t current_rows = 0;
    std::size_t pending_rows = 0;
    std::size_t current_slots = 0;
    std::size_t pending_slots = 0;
    std::size_t peak_payload_bits = 0;
};

inline std::size_t magnitude_bits(const Integer& value) {
    const auto& backend = value.backend();
    const auto count = backend.size();
    using Limb = std::remove_cvref_t<decltype(backend.limbs()[0])>;
    constexpr auto limb_bits = std::numeric_limits<Limb>::digits;
    return count ? limb_bits * (count - 1) + std::bit_width(backend.limbs()[count - 1]) : 0;
}
inline constexpr std::uint64_t words(std::size_t bits) { return (bits + 63) / 64; }
inline constexpr std::uint64_t copy_cost(std::size_t bits) { return 1 + 2 * words(bits); }
inline constexpr std::uint64_t add_cost(std::size_t bits) { return 2 + 3 * words(bits); }
inline constexpr std::uint64_t multiply_cost(std::size_t a, std::size_t b) {
    return 2 + 2 * (words(a) + words(b)) + words(a) * words(b);
}

inline std::vector<std::uint64_t> uniform_units(std::size_t count) {
    if (!count || count > action_limit) throw Error(ErrorKind::row_or_menu, "sparse row action count");
    std::vector<std::uint64_t> result(count);
    const auto base = grid / count;
    const auto remainder = grid % count;
    for (std::size_t i = 0; i < count; ++i) result[i] = base + (i < remainder ? 1 : 0);
    return result;
}

inline Forecast forecast(const Limits& limits) {
    if (limits.max_epochs != epoch_limit || !limits.max_rows_touched ||
        limits.max_rows_touched > 1'060 || !limits.max_slots_touched || limits.max_slots_touched > 2'564 ||
        !limits.max_stage_rows || limits.max_stage_rows > 530 ||
        !limits.max_stage_slots || limits.max_stage_slots > 1'282 ||
        2 * limits.max_stage_rows > limits.max_rows_touched ||
        2 * limits.max_stage_slots > limits.max_slots_touched ||
        limits.max_reads < 2 * limits.max_rows_touched || limits.max_reads > 2'136 ||
        !limits.catalog_max_public_blocks || limits.catalog_max_public_blocks > 24'420 ||
        !limits.max_work || limits.max_work > work_cap || !limits.max_entries || limits.max_entries > entries_cap ||
        !limits.max_payload_bits || limits.max_payload_bits > payload_bits_cap)
        throw Error(ErrorKind::invalid_limits, "invalid sparse strategy epoch limits");
    Forecast f;
    f.constructor_work = 2'048;
    f.lease_work = limits.max_epochs * 128;
    f.read_work = limits.max_reads * (160 + 32 * action_limit);
    constexpr std::uint64_t per_stage_slot = 48 + copy_cost(649) + add_cost(649) +
        multiply_cost(383, 317) + add_cost(382) + 64;
    f.stage_work = limits.max_epochs * (1'024 + limits.max_stage_rows *
        (512 + action_limit * per_stage_slot));
    f.commit_work = limits.max_epochs * (2'048 + limits.max_stage_rows * (256 + 32 * action_limit));
    f.max_quantized_rows = limits.max_epochs * limits.max_stage_rows;
    // Legacy/separate worst case at 649-bit R, 701-bit scaled weights,
    // four positives: 11,200 wide-kernel units plus 320 setup/LSB scans.
    f.quantizer_work = f.max_quantized_rows * 12'000;
    if (f.constructor_work > std::numeric_limits<std::uint64_t>::max() - f.lease_work ||
        f.constructor_work + f.lease_work > std::numeric_limits<std::uint64_t>::max() - f.read_work ||
        f.constructor_work + f.lease_work + f.read_work > std::numeric_limits<std::uint64_t>::max() - f.stage_work ||
        f.constructor_work + f.lease_work + f.read_work + f.stage_work > std::numeric_limits<std::uint64_t>::max() - f.commit_work ||
        f.constructor_work + f.lease_work + f.read_work + f.stage_work + f.commit_work >
            std::numeric_limits<std::uint64_t>::max() - f.quantizer_work)
        throw Error(ErrorKind::invalid_limits, "sparse strategy forecast overflow");
    f.own_work = f.constructor_work + f.lease_work + f.read_work + f.stage_work + f.commit_work;
    const auto catalog_map_steps = std::bit_width(limits.catalog_max_public_blocks + 1);
    const auto catalog_access = 512 + 256 * catalog::maximum_actions + 32 * catalog_map_steps + 8;
    f.catalog_read_work = (limits.max_reads * 2 + limits.max_epochs * limits.max_stage_rows) * catalog_access;
    // resolve + view per policy read, and one validating view per staged row.
    // History decision key/actions, Catalog's full history identity, and the
    // first-block menu revalidation path, for every supported policy read.
    f.history_read_work = limits.max_reads *
        (32 + 24 + 16 * action_limit + 48 + 32 + 24 + 16 * action_limit);
    f.component_work = f.own_work + f.quantizer_work;
    f.work = f.own_work + f.quantizer_work + f.catalog_read_work + f.history_read_work;
    f.entries = 256 + 24 * limits.max_rows_touched + 8 * limits.max_slots_touched + 2'048;
    f.payload_bits = 2 * limits.max_slots_touched * (649 + 382 + 64) +
        2 * limits.max_rows_touched * 2'048 + 64 * 64'000;
    if (f.work > limits.max_work || f.entries > limits.max_entries || f.payload_bits > limits.max_payload_bits)
        throw Error(ErrorKind::invalid_limits, "sparse strategy forecast exceeds its admitted component caps");
    return f;
}

struct FrozenRow {
    std::uint64_t actor = 0;
    std::uint64_t holding_index = 0;
    std::uint64_t history_ordinal = 0;
    std::uint64_t offset = 0; // sentinel only; sparse identity is RowId/full ordinal
    std::span<const std::string> actions;
};
struct FrozenPolicyView {
    RowId id;
    FrozenRow row;
    std::span<const std::uint64_t> units;
};

class Store final {
public:
    class EpochLease;
private:
    struct Entry {
        std::vector<Integer> regrets;
        std::vector<Integer> averages;
        std::vector<std::uint64_t> units;
        void swap(Entry& other) noexcept {
            regrets.swap(other.regrets); averages.swap(other.averages); units.swap(other.units);
        }
    };
    struct Seen {
        std::size_t actions = 0;
        std::uint8_t reads = 0;
    };
    Limits limits_;
    Forecast forecast_;
    History* history_;
    Catalog* catalog_;
    std::array<std::size_t, 2> hand_counts_;
    policy::Quantizer quantizer_;
    std::map<RowId, Entry> current_;
    std::map<RowId, Entry> pending_;
    std::map<RowId, Seen> staged_ids_;
    Receipt receipt_{};
    std::uint64_t generation_ = 0;
    std::size_t committed_epochs_ = 0;
    std::size_t epoch_stage_rows_ = 0;
    std::size_t epoch_stage_slots_ = 0;
    bool active_ = false;
    bool pending_ready_ = false;
    bool poisoned_ = false;

    static policy::Limits quantizer_limits(const Limits& limits) {
        const auto f = forecast(limits);
        if (f.work > limits.max_work) throw Error(ErrorKind::invalid_limits, "no work remains for quantizer owner");
        policy::Limits q;
        q.work = limits.max_work - (f.work - f.quantizer_work);
        q.integer_bits = 704;
        q.entries = limits.max_entries;
        q.integer_payload_bits = limits.max_payload_bits;
        q.profile = policy::Profile::legacy;
        q.division_kernel = policy::DivisionKernel::separate;
        q.mixed_cache = false;
        return q;
    }
    [[noreturn]] void reject(ErrorKind kind, const char* message) {
        poisoned_ = true;
        throw Error(kind, message);
    }
    void healthy() const {
        if (poisoned_) throw Error(ErrorKind::failed_owner, "sparse strategy store failed closed");
        if (catalog_->failed()) throw Error(ErrorKind::failed_owner, "sparse strategy catalog failed");
    }
    void charge(std::uint64_t amount) {
        if (amount > forecast_.own_work - receipt_.work)
            reject(ErrorKind::resource_limit, "sparse strategy component work exceeded");
        receipt_.work += amount;
    }
    void check_epoch(const EpochLease& lease);
    void release(std::uint64_t generation, bool complete) noexcept {
        if (active_ && generation_ == generation) {
            active_ = false;
            if (!complete) poisoned_ = true;
        }
    }
    std::size_t payload_bits(const std::map<RowId, Entry>& rows) const {
        std::size_t bits = 0;
        for (const auto& [id, entry] : rows) {
            (void)id;
            bits += 2'048 + 64 * entry.units.size();
            for (const auto& x : entry.regrets) bits += magnitude_bits(x);
            for (const auto& x : entry.averages) bits += magnitude_bits(x);
        }
        return bits;
    }
    void refresh_receipt() {
        receipt_.current_rows = current_.size();
        receipt_.pending_rows = pending_.size();
        receipt_.current_slots = 0; receipt_.pending_slots = 0;
        auto account = [&](const auto& rows, std::size_t& slots) {
            for (const auto& [id, entry] : rows) {
                (void)id;
                slots += entry.units.size();
            }
        };
        account(current_, receipt_.current_slots);
        account(pending_, receipt_.pending_slots);
        receipt_.peak_payload_bits = std::max(receipt_.peak_payload_bits,
                                               payload_bits(current_) + payload_bits(pending_));
    }
    static void validate_entry(const Entry& entry, std::size_t actions) {
        if (entry.regrets.size() != actions || entry.averages.size() != actions ||
            entry.units.size() != actions || !actions || actions > action_limit)
            throw Error(ErrorKind::row_or_menu, "sparse strategy entry/menu width");
        Integer positive_sum = 0;
        std::uint64_t unit_sum = 0;
        for (std::size_t i = 0; i < actions; ++i) {
            if (magnitude_bits(entry.regrets[i]) > 649 || entry.averages[i] < 0 ||
                magnitude_bits(entry.averages[i]) > 382)
                throw Error(ErrorKind::arithmetic, "sparse strategy cumulative integer bound");
            if (entry.regrets[i] > 0) positive_sum += entry.regrets[i];
            if (entry.units[i] > grid - unit_sum)
                throw Error(ErrorKind::arithmetic, "sparse strategy policy partition overflow");
            unit_sum += entry.units[i];
        }
        if (magnitude_bits(positive_sum) > 651 || unit_sum != grid)
            throw Error(ErrorKind::arithmetic, "sparse strategy positive sum or policy partition");
    }
    Entry default_entry(std::size_t actions) const {
        Entry result;
        result.regrets.resize(actions);
        result.averages.resize(actions);
        result.units = uniform_units(actions);
        return result;
    }
    void stage_impl(EpochLease& lease, RowId id, std::span<const Integer> raw_regrets,
                    std::span<const Integer> raw_averages, const Integer& raw_average_denominator,
                    const Integer& raw_regret_denominator);
    void commit_impl();

public:
public:
    class EpochLease final {
        friend class Store;
        Store* owner_ = nullptr;
        std::uint64_t generation_ = 0;
        std::map<RowId, std::vector<std::uint64_t>> defaults_;
        std::map<RowId, Seen> observed_;
        std::size_t slots_ = 0;
        std::uint64_t reads_ = 0;
        bool raw_complete_ = false;
        bool live_ = false;
        EpochLease(Store& owner, std::uint64_t generation) : owner_(&owner), generation_(generation), live_(true) {}
        void check() const {
            if (!owner_) throw Error(ErrorKind::lease_generation, "moved-from sparse epoch lease");
            owner_->check_epoch(*this);
        }
    public:
        EpochLease() = default;
        EpochLease(const EpochLease&) = delete;
        EpochLease& operator=(const EpochLease&) = delete;
        EpochLease(EpochLease&& other) noexcept
            : owner_(std::exchange(other.owner_, nullptr)), generation_(other.generation_),
              defaults_(std::move(other.defaults_)), observed_(std::move(other.observed_)),
              slots_(other.slots_), reads_(other.reads_), raw_complete_(other.raw_complete_),
              live_(std::exchange(other.live_, false)) {}
        EpochLease& operator=(EpochLease&& other) noexcept {
            if (this != &other) {
                if (live_ && owner_) owner_->release(generation_, raw_complete_ && owner_->pending_ready_);
                owner_ = std::exchange(other.owner_, nullptr); generation_ = other.generation_;
                defaults_ = std::move(other.defaults_); observed_ = std::move(other.observed_);
                slots_ = other.slots_; reads_ = other.reads_; raw_complete_ = other.raw_complete_;
                live_ = std::exchange(other.live_, false);
            }
            return *this;
        }
        ~EpochLease() { if (live_ && owner_) owner_->release(generation_, raw_complete_ && owner_->pending_ready_); }

        [[nodiscard]] bool raw_policy_ready() const noexcept {
            return owner_ && live_ && owner_->active_ && owner_->generation_ == generation_ &&
                   !owner_->poisoned_ && !owner_->catalog_->failed() && !raw_complete_;
        }
        [[nodiscard]] FrozenPolicyView frozen_policy(Cursor cursor, std::size_t actor, std::size_t holding) {
            check();
            try {
                if (raw_complete_ || actor > 1 || holding >= owner_->hand_counts_[actor])
                    owner_->reject(ErrorKind::row_or_menu, "sparse frozen policy read outside active walk");
                owner_->charge(160 + 32 * action_limit);
                if (++reads_ > owner_->limits_.max_reads || ++owner_->receipt_.reads > owner_->limits_.max_reads)
                    owner_->reject(ErrorKind::resource_limit, "sparse policy read limit exceeded");
                const auto info = owner_->history_->decision_key(cursor);
                if (info.actor != actor || !info.actions || info.actions > action_limit)
                    owner_->reject(ErrorKind::row_or_menu, "sparse policy history actor/menu mismatch");
                std::array<std::string_view, action_limit> tokens{};
                owner_->history_->decision_actions(cursor, std::span(tokens).first(info.actions));
                const auto id = owner_->catalog_->resolve(*owner_->history_, cursor, actor, holding,
                    owner_->hand_counts_[actor], info.source, std::span(tokens).first(info.actions));
                const auto catalog_row = owner_->catalog_->view(id);
                if (catalog_row.actor != actor || catalog_row.holding_index != holding ||
                    catalog_row.source_menu_ref != info.source || catalog_row.actions.size() != info.actions)
                    owner_->reject(ErrorKind::row_or_menu, "sparse catalog row/menu mismatch");
                const auto current = owner_->current_.find(id);
                const bool needs_default = current == owner_->current_.end() && !defaults_.contains(id);
                const bool needs_observation = !observed_.contains(id);
                const auto next_entries = owner_->current_.size() + owner_->pending_.size() +
                    owner_->staged_ids_.size() + observed_.size() + defaults_.size() +
                    static_cast<std::size_t>(needs_default) + static_cast<std::size_t>(needs_observation);
                const auto next_payload = owner_->payload_bits(owner_->current_) + owner_->payload_bits(owner_->pending_) +
                    2'048 * (owner_->staged_ids_.size() + observed_.size() + static_cast<std::size_t>(needs_observation)) +
                    256 * (defaults_.size() + static_cast<std::size_t>(needs_default));
                if (next_entries > owner_->forecast_.entries || next_entries > owner_->limits_.max_entries ||
                    next_payload > owner_->limits_.max_payload_bits)
                    owner_->reject(ErrorKind::resource_limit, "sparse lease directory exceeds its reservation");
                auto [seen, inserted] = observed_.try_emplace(id, Seen{info.actions, 0});
                if (inserted) {
                    slots_ += info.actions;
                    if (observed_.size() > owner_->limits_.max_stage_rows ||
                        slots_ > owner_->limits_.max_stage_slots)
                        owner_->reject(ErrorKind::resource_limit, "sparse epoch walk row/slot limit exceeded");
                } else if (seen->second.actions != info.actions) {
                    owner_->reject(ErrorKind::row_or_menu, "sparse observed menu changed");
                }
                if (++seen->second.reads > 2) owner_->reject(ErrorKind::incomplete_walk, "sparse row read too many times");
                std::span<const std::uint64_t> units;
                if (current != owner_->current_.end()) units = current->second.units;
                else {
                    auto [it, made] = defaults_.try_emplace(id);
                    if (made) it->second = uniform_units(info.actions);
                    units = it->second;
                }
                const auto descriptor_bits = owner_->payload_bits(owner_->current_) + owner_->payload_bits(owner_->pending_) +
                    2'048 * (observed_.size() + owner_->staged_ids_.size()) + 256 * defaults_.size();
                owner_->receipt_.peak_payload_bits = std::max(owner_->receipt_.peak_payload_bits, descriptor_bits);
                if (descriptor_bits > owner_->limits_.max_payload_bits ||
                    owner_->current_.size() + owner_->pending_.size() + observed_.size() + defaults_.size() >
                        owner_->forecast_.entries)
                    owner_->reject(ErrorKind::resource_limit, "sparse lease directory reservation exceeded");
                if (units.size() != info.actions) owner_->reject(ErrorKind::row_or_menu, "sparse policy row width");
                return {id, {static_cast<std::uint64_t>(actor), static_cast<std::uint64_t>(holding),
                         catalog_row.public_ordinal, 0, catalog_row.actions}, units};
            } catch (...) { owner_->poisoned_ = true; throw; }
        }

        // Call only after the raw front door has accepted complete row/slot/visit coverage.
        void seal_raw_walk(std::size_t rows, std::size_t slots, std::uint64_t reads) {
            check();
            try {
                if (raw_complete_ || rows != observed_.size() || slots != slots_ || reads != reads_ ||
                    reads != 2 * rows || std::any_of(observed_.begin(), observed_.end(),
                        [](const auto& item) { return item.second.reads != 2; }))
                    owner_->reject(ErrorKind::incomplete_walk, "sparse raw walk is not a complete two-seat pass");
                raw_complete_ = true;
            } catch (...) { owner_->poisoned_ = true; throw; }
        }
        template<class Callback>
        void for_each_observed_row(Callback&& callback) const {
            check();
            if (!raw_complete_) throw Error(ErrorKind::incomplete_walk, "sparse rows are unavailable before walk seal");
            for (const auto& [id, seen] : observed_)
                callback(id, seen.actions, seen.reads);
        }
        void stage(RowId id, std::span<const Integer> raw_regrets,
                   std::span<const Integer> raw_averages, const Integer& raw_average_denominator,
                   const Integer& raw_regret_denominator = Integer(regret_denominator)) {
            if (!owner_) throw Error(ErrorKind::lease_generation, "moved-from sparse epoch lease");
            owner_->stage_impl(*this, id, raw_regrets, raw_averages,
                               raw_average_denominator, raw_regret_denominator);
        }
    };

    Store(Catalog& catalog_owner, History& history_owner, std::array<std::size_t, 2> declared_hand_counts,
          Limits limits = {})
        : limits_(limits), forecast_(forecast(limits)), history_(&history_owner), catalog_(&catalog_owner),
          hand_counts_(declared_hand_counts), quantizer_(quantizer_limits(limits)) {
        const auto& catalog_limits = catalog_owner.admitted_limits();
        const auto& catalog_receipt = catalog_owner.receipt();
        const auto required_catalog_lookups = limits.max_reads * 2 + limits.max_epochs * limits.max_stage_rows;
        if (declared_hand_counts != std::array<std::size_t, 2>{2, 2} || catalog_owner.failed() ||
            !catalog_owner.owns_identity(history_owner, declared_hand_counts) ||
            catalog_limits.max_holding_count > 2 ||
            catalog_limits.max_public_blocks > limits.catalog_max_public_blocks ||
            catalog_receipt.lookups > catalog_limits.max_lookups ||
            required_catalog_lookups > catalog_limits.max_lookups - catalog_receipt.lookups ||
            catalog_receipt.work > catalog_limits.max_work ||
            forecast_.catalog_read_work > catalog_limits.max_work - catalog_receipt.work)
            throw Error(ErrorKind::invalid_limits, "sparse strategy epoch requires the fixed two-hand catalog");
        charge(forecast_.constructor_work);
    }
    Store(const Store&) = delete;
    Store& operator=(const Store&) = delete;
    [[nodiscard]] const Receipt& receipt() const noexcept { return receipt_; }
    [[nodiscard]] const Forecast& admitted_forecast() const noexcept { return forecast_; }
    [[nodiscard]] std::size_t committed_epochs() const noexcept { return committed_epochs_; }
    [[nodiscard]] bool failed() const noexcept { return poisoned_ || catalog_->failed() || quantizer_.failed(); }
    [[nodiscard]] bool raw_policy_ready() const noexcept { return active_ && !failed(); }
    [[nodiscard]] EpochLease begin_epoch(ProposalLaw law) {
        healthy();
        if (law != ProposalLaw::uniform_public)
            reject(ErrorKind::invalid_limits, "sparse epoch accepts the uniform proposal only");
        if (active_) reject(ErrorKind::active_lease, "one sparse epoch policy lease is already active");
        if (committed_epochs_ >= epoch_limit || pending_ready_)
            reject(ErrorKind::epoch_limit, "sparse strategy epoch transition unavailable");
        charge(128);
        if (++generation_ == 0) reject(ErrorKind::lease_generation, "sparse epoch generation exhausted");
        active_ = true;
        epoch_stage_rows_ = epoch_stage_slots_ = 0;
        staged_ids_.clear(); pending_.clear();
        return EpochLease(*this, generation_);
    }
    void commit() { healthy(); if (active_) reject(ErrorKind::active_lease, "cannot commit while sparse epoch lease is active"); commit_impl(); }
private:
    friend class EpochLease;
    void check_epoch(const EpochLease& lease) {
        healthy();
        if (!lease.live_ || lease.owner_ != this || !active_ || lease.generation_ != generation_)
            reject(ErrorKind::lease_generation, "stale or foreign sparse epoch lease");
    }
};

inline void Store::stage_impl(EpochLease& lease, RowId id, std::span<const Integer> raw_regrets,
                              std::span<const Integer> raw_averages, const Integer& raw_average_denominator,
                              const Integer& raw_regret_denominator) {
    check_epoch(lease);
    try {
        if (!lease.raw_complete_ || committed_epochs_ >= epoch_limit || raw_regrets.empty() ||
            raw_regrets.size() != raw_averages.size() || raw_regrets.size() > action_limit)
            reject(ErrorKind::incomplete_walk, "sparse stage requires a complete walk and bounded row");
        const auto seen = lease.observed_.find(id);
        if (seen == lease.observed_.end() || seen->second.reads != 2 || seen->second.actions != raw_regrets.size())
            reject(ErrorKind::row_or_menu, "sparse stage row was not read in both target passes");
        if (staged_ids_.contains(id)) reject(ErrorKind::duplicate_stage, "duplicate sparse row stage");
        const auto row = catalog_->view(id);
        if (row.actor > 1 || row.holding_index >= hand_counts_[row.actor] ||
            row.actions.size() != raw_regrets.size())
            reject(ErrorKind::row_or_menu, "sparse stage catalog identity/menu mismatch");
        if (magnitude_bits(raw_regret_denominator) > 638 || raw_regret_denominator <= 0 ||
            raw_regret_denominator != regret_denominator ||
            magnitude_bits(raw_average_denominator) > 381 || raw_average_denominator <= 0 ||
            Integer(average_denominator) % raw_average_denominator != 0)
            reject(ErrorKind::arithmetic, "sparse raw denominator outside exact fixed contract");
        const Integer average_factor = Integer(average_denominator) / raw_average_denominator;
        if (magnitude_bits(average_factor) > 317)
            reject(ErrorKind::arithmetic, "sparse average scale bound");
        const auto actions = raw_regrets.size();
        if (epoch_stage_rows_ + 1 > limits_.max_stage_rows ||
            epoch_stage_slots_ + actions > limits_.max_stage_slots ||
            receipt_.staged_rows + 1 > limits_.max_rows_touched ||
            receipt_.staged_slots + actions > limits_.max_slots_touched)
            reject(ErrorKind::resource_limit, "sparse stage row/slot limit exceeded before allocation");
        const auto predicted_entries = current_.size() + pending_.size() + staged_ids_.size() +
            lease.observed_.size() + lease.defaults_.size() + 2;
        const auto predicted_payload = payload_bits(current_) + payload_bits(pending_) +
            2'048 + actions * (649 + 382 + 64) + 2'048 * (lease.observed_.size() + staged_ids_.size() + 1) +
            256 * lease.defaults_.size() + 40'000;
        if (predicted_entries > forecast_.entries || predicted_entries > limits_.max_entries ||
            predicted_payload > limits_.max_payload_bits)
            reject(ErrorKind::resource_limit, "sparse stage temporary allocation exceeds its reservation");
        charge(512 + 160 * raw_regrets.size());
        const auto old = current_.find(id);
        Entry next = old == current_.end() ? default_entry(raw_regrets.size()) : old->second;
        const bool regret_changed = std::any_of(raw_regrets.begin(), raw_regrets.end(),
                                                [](const Integer& x) { return x != 0; });
        for (std::size_t i = 0; i < raw_regrets.size(); ++i) {
            if (magnitude_bits(raw_regrets[i]) > 648 || raw_averages[i] < 0 ||
                magnitude_bits(raw_averages[i]) > 383)
                reject(ErrorKind::arithmetic, "sparse raw integer exceeds source bound");
            next.regrets[i] += raw_regrets[i];
            const Integer average_delta = raw_averages[i] * average_factor;
            if (magnitude_bits(average_delta) > 382)
                reject(ErrorKind::arithmetic, "sparse converted average bound");
            next.averages[i] += average_delta;
        }
        Integer positive_sum = 0;
        for (std::size_t i = 0; i < next.regrets.size(); ++i) {
            if (magnitude_bits(next.regrets[i]) > 649 || next.averages[i] < 0 ||
                magnitude_bits(next.averages[i]) > 382)
                reject(ErrorKind::arithmetic, "sparse cumulative integer bound before quantization");
            if (next.regrets[i] > 0) positive_sum += next.regrets[i];
        }
        if (magnitude_bits(positive_sum) > 651)
            reject(ErrorKind::arithmetic, "sparse positive regret sum bound");
        if (regret_changed) {
            const auto before = quantizer_.receipt();
            receipt_.peak_payload_bits = std::max(receipt_.peak_payload_bits,
                payload_bits(current_) + payload_bits(pending_) +
                2'048 + actions * (649 + 382 + 64) +
                2'048 * (lease.observed_.size() + staged_ids_.size() + 1) +
                256 * lease.defaults_.size() + 40'000);
            const auto policy_image = quantizer_.regret_policy(std::span<const Integer>(next.regrets));
            next.units.assign(policy_image.units().begin(), policy_image.units().end());
            receipt_.quantizer_work = quantizer_.receipt().work;
            receipt_.quantized_rows = quantizer_.receipt().rows;
            if (receipt_.quantizer_work > forecast_.quantizer_work ||
                receipt_.quantized_rows > forecast_.max_quantized_rows ||
                quantizer_.receipt().work - before.work > limits_.max_work - forecast_.work + forecast_.quantizer_work)
                reject(ErrorKind::resource_limit, "sparse quantizer budget exceeded");
        }
        validate_entry(next, raw_regrets.size());
        if (std::any_of(next.regrets.begin(), next.regrets.end(), [](const auto& x) { return x != 0; }) ||
            std::any_of(next.averages.begin(), next.averages.end(), [](const auto& x) { return x != 0; }))
            pending_.emplace(id, std::move(next));
        staged_ids_.emplace(id, Seen{raw_regrets.size(), 2});
        ++epoch_stage_rows_; epoch_stage_slots_ += raw_regrets.size();
        ++receipt_.staged_rows; receipt_.staged_slots += raw_regrets.size();
        pending_ready_ = true;
        refresh_receipt();
        const auto active_entries = current_.size() + pending_.size() + staged_ids_.size();
        if (active_entries > forecast_.entries || active_entries > limits_.max_entries ||
            receipt_.peak_payload_bits > limits_.max_payload_bits)
            reject(ErrorKind::resource_limit, "sparse active storage reservation exceeded");
    } catch (...) { poisoned_ = true; throw; }
}

inline void Store::commit_impl() {
    try {
        if (!pending_ready_ || committed_epochs_ >= epoch_limit || staged_ids_.empty())
            reject(ErrorKind::epoch_limit, "sparse commit requires a staged complete epoch");
        charge(2'048 + 256 * pending_.size());
        // Validate every replacement and the complete next image before the
        // first live numeric map entry changes. Publication itself only swaps
        // vectors and transfers already allocated map nodes.
        std::size_t projected_rows = current_.size();
        std::size_t projected_slots = receipt_.current_slots;
        for (const auto& [id, entry] : pending_) {
            validate_entry(entry, entry.units.size());
            const auto found = current_.find(id);
            if (found == current_.end()) {
                ++projected_rows;
                projected_slots += entry.units.size();
            } else {
                projected_slots -= found->second.units.size();
                projected_slots += entry.units.size();
            }
        }
        const auto projected_payload = payload_bits(current_) + 2 * payload_bits(pending_) +
            2'048 * staged_ids_.size();
        if (projected_rows > limits_.max_rows_touched || projected_slots > limits_.max_slots_touched ||
            projected_rows + pending_.size() + staged_ids_.size() > forecast_.entries ||
            projected_payload > limits_.max_payload_bits ||
            receipt_.work + receipt_.quantizer_work > limits_.max_work ||
            receipt_.work + receipt_.quantizer_work > forecast_.work)
            reject(ErrorKind::resource_limit, "sparse next image exceeds its admission before publication");
        static_assert(noexcept(std::declval<RowId>() < std::declval<RowId>()));
        for (auto it = pending_.begin(); it != pending_.end(); ++it) {
            const auto found = current_.find(it->first);
            if (found != current_.end()) {
                found->second.swap(it->second);
            }
        }
        current_.merge(pending_); // existing collisions retain old entries in pending_
        ++committed_epochs_; ++receipt_.commits;
        pending_.clear(); staged_ids_.clear(); pending_ready_ = false;
        refresh_receipt();
    } catch (...) { poisoned_ = true; throw; }
}

} // namespace openpoker::virtual_sparse_strategy_epoch
