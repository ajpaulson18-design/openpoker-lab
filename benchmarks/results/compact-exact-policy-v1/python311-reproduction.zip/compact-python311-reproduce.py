"""Capture current-source Python 3.11 policy drift; no archived source executes."""
import hashlib,json,sys
from pathlib import Path
from zipfile import ZipFile
repo=Path(__file__).with_name('compact-exact-policy-repo')
sys.path.insert(0,str(repo))
from pokerlab.exact_selected_solver import solve_four_street_exact_selected
from tests.test_exact_selected_solver import request_from_case
from scripts import four_street_validation as physical
from scripts.preflop_validation import compare_result
case=json.loads((repo/'benchmarks/four-street-integration-v1.json').read_text())['case']
actual=solve_four_street_exact_selected(request_from_case(case),rank_cache_boards=64)
with ZipFile(repo/'benchmarks/results/exact-product-selected-v1/exact-selected-study-v1.zip') as z:
 prior=json.loads(z.read('original-t10-0.json'))['payload']
drifts=[]
for row,old in zip(actual['strategy'],prior['strategy']):
 delta=max(abs(a['probability']-b['probability']) for a,b in zip(row['actions'],old['actions']))
 if delta>1e-12:drifts.append({'identity':{k:v for k,v in row.items() if k!='actions'},'actual':row['actions'],'prior':old['actions'],'maximum_drift':delta})
replay=physical.replay_policy(actual,case)
gaps=compare_result(actual,replay)
out=Path(__file__).with_name('compact-python311-reproduction.json')
out.write_text(json.dumps({'runtime':sys.version,'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'payload':actual,'drifts_above_1e12':drifts,'numeric_gaps':gaps},indent=2,sort_keys=True)+'\n')
print(json.dumps({'runtime':sys.version,'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'large_drift_rows':len(drifts),'maximum_drift':max((d['maximum_drift'] for d in drifts),default=0),'numeric_gaps':gaps}))
print(json.dumps(drifts[:5],indent=2))
