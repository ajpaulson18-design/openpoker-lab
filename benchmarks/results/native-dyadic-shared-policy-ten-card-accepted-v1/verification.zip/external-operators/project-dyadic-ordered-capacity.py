"""Rank-free resident and limb census for the ordered State follow-up."""
from functools import lru_cache
import json
from pathlib import Path
import sys


repo = Path(sys.argv[1]).resolve(strict=True)
sys.path.insert(0, str(repo))
from scripts import census_virtual_dyadic_storage as geometry
from tests.virtual_frozen_update_reference import scaled_proof9_ranges

geometry.DECK_SIZES = (9, 10, 11)
template = geometry.build_reference_template(geometry._template_case())
ranges = scaled_proof9_ranges()


@lru_cache(None)
def suffix(node_id):
    node = template.nodes[node_id]
    return int(node.phase == 'decision') + max((suffix(edge.child) for edge in node.edges), default=0)


def forecast(cards, bits):
    deck = geometry.nested_deck(cards)
    support = {(street, actor): sum(geometry.supported_prefixes(deck, actor, hand, street, ranges)
               for hand, _ in ranges[actor]) for street in geometry.STREETS for actor in (0, 1)}
    rows = slots = average = regret = 0

    def visit(node_id, past):
        nonlocal rows, slots, average, regret
        node = template.nodes[node_id]
        next_past = past
        if node.phase == 'decision':
            actor = node.state.player
            count = support[node.street, actor]
            actions = count * len(node.edges)
            avg_shift = 1 + 52 * (11 - past[actor])
            regret_shift = 52 * (12 - past[1-actor] - suffix(node_id))
            if not 0 <= min(avg_shift, regret_shift) <= max(avg_shift, regret_shift) < bits:
                raise ValueError('invalid projected row shifts')
            average += actions * ((bits-avg_shift+63)//64)
            regret += actions * ((bits-regret_shift+63)//64)
            rows += count
            slots += actions
            next_past = tuple(depth + (seat == actor) for seat, depth in enumerate(past))
        for edge in node.edges:
            visit(edge.child, next_past)

    visit(template.root, (0, 0))
    catalog = 1056 + 3*410 + 2*388
    common = catalog + 4*rows
    index_slots = 1 << (4*rows - 1).bit_length()
    image_words = average + regret
    return {'cards':cards, 'deck_ids':deck, 'value_bits':bits, 'rows':rows, 'slots':slots,
            'average_words':average, 'regret_words':regret, 'image_words':image_words,
            'image_bytes':8*image_words, 'staging_bitmap_bytes':(image_words+7)//8,
            'old_build_entries':common+index_slots, 'old_frozen_entries_excluding_pager':common+2*(rows+slots),
            'ordered_build_entries':common+5, 'ordered_frozen_entries_excluding_pager':common+5+rows+slots}


reports = [forecast(cards, bits) for cards,bits in ((9,642),(10,644),(11,646))]
expected = [(258694,348036),(1295812,1666910),(4188150,5536052)]
if [(row['average_words'],row['regret_words']) for row in reports] != expected:
    raise ValueError('independent limb census differs')
print(json.dumps({'scope':'rank-free layout projection only','native_producer_calls':0,'fixtures':reports},indent=2))
