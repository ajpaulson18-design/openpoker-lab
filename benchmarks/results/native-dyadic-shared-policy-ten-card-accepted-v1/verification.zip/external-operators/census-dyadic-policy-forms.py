"""Classify the exact grid rows in an authenticated ten-card split scaffold."""
import hashlib
import json
from pathlib import Path
import struct
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def census(path, identity):
    raw = path.read_bytes()
    require(len(raw) == identity['bytes'] == 9_833_076
            and hashlib.sha256(raw).hexdigest() == identity['sha256'], 'saved stream identity differs')
    header = struct.unpack_from('<16Q',raw,8)
    rows,slots,nodes = header[3:6]
    require(raw[:8] == b'OPLDTP01' and (rows,slots,nodes) == (119196,281066,1105)
            and header[1:3] == (52,11) and header[6] == 2, 'ten-card header differs')
    position = 8 + 16*8 + 11*8 + 96*nodes
    menus = []
    slots_seen = 0
    for _ in range(rows):
        _,flags,start = struct.unpack_from('<3Q',raw,position)
        count = (flags>>16)&255
        require(flags>>24 == 0 and 2 <= count <= 4 and start == slots_seen, 'policy row framing differs')
        menus.append(count)
        slots_seen += count
        position += 24
    require(slots_seen == slots, 'policy slot count differs')
    reports = []
    Q = 1 << 52
    for label in ('sweep_1','sweep_2','average_export'):
        counts = dict(name=label,uniform=0,pure=0,mixed=0,mixed_slots=0,mixed_nonzero_slots=0)
        for count in menus:
            units = struct.unpack_from(f'<{count}Q',raw,position)
            require(sum(units) == Q, 'policy row does not sum to the exact grid')
            floor,remainder = divmod(Q,count)
            if all(unit == floor+(action < remainder) for action,unit in enumerate(units)):
                counts['uniform'] += 1
            elif Q in units:
                counts['pure'] += 1
            else:
                counts['mixed'] += 1
                counts['mixed_slots'] += count
                counts['mixed_nonzero_slots'] += sum(bool(unit) for unit in units)
            position += 8*count
        reports.append(counts)
        if label != 'average_export':
            position += 4*(1+11)*8
    flags = raw[position:position+rows]
    require(all(flag in (0,1) for flag in flags) and raw[position+rows:position+rows+8] == b'OPLDTP02'
            and position+rows+520 == len(raw), 'saved flags or footer differs')
    require([(row['uniform'],row['pure'],row['mixed'],row['mixed_slots']) for row in reports] ==
            [(119196,0,0,0),(32,98846,20318,68436),(114350,0,4846,12560)], 'independent policy-form count differs')
    return {'scope':'saved two-sweep ten-card stream only','native_producer_calls':0,'stream':identity,
            'forms':reports,'average_fallback_rows':sum(flags),'dense_policy_bytes':8*slots,
            'maximum_observed_mixed_pool_bytes':8*max(row['mixed_slots'] for row in reports)}


if __name__ == '__main__':
    cohort = Path(sys.argv[1]).resolve(strict=True)
    identity = json.loads((cohort/'checkpoint-inputs.json').read_bytes())['stream']
    print(json.dumps(census(cohort/'train_ten_ordered_state/stdout.bin',identity),indent=2))
