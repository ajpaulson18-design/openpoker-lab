"""Package the frozen compact-wire training, replay, and timing receipts."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

WORK=Path(__file__).resolve().parent
ROOT=WORK/"dyadic-phase-payload-repo"
HEAD="cf5d480ceb96ee66d18359e86e7eccc542ecc801"
COHORT=WORK/"dywire-cohort3"
OPERATOR=WORK/"dywire-launch3"
RESULT=ROOT/"benchmarks/results/native-dyadic-compact-wire-v1"


def require(value,message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def main():
    final=read(COHORT/"result.json")
    source=read(COHORT/"source.json")
    hashes={name:item["raw_sha256"] for name,item in source["files"].items()}
    outer=read(OPERATOR/"completion.json")
    require(final["head"]==source["head"]==outer["head"]==HEAD and
            final["training_invocations"]==1 and read(COHORT/"terminal.json")["status"]=="complete" and
            outer["actual_exit_observed"] and outer["returncode"]==0 and not outer["failures"] and
            outer["raw_source_stable"] and
            read(OPERATOR/"source-before.json")==read(OPERATOR/"source-after.json")==hashes,
            "compact study source or terminal status differs")
    launcher=WORK/"trusted-virtual-dyadic-training-launch-v29.py"
    require(read(OPERATOR/"operator-launch.json")["operator_sha256"]==sha(launcher),
            "compact launcher differs")
    for name in (OPERATOR/"bootstrap.json",COHORT/"saved-review-bootstrap.json"):
        boot=read(name)
        require(boot["initial_cache_scan"]["project_bytecode_files"]==
                boot["final_cache_scan"]["project_bytecode_files"]==0 and
                all(hashes[name]==digest for name,digest in boot["compiled"].items()),
                "compact source-only closure differs")
    build_path=COHORT/"build/native-exact-build-manifest.json"
    build=read(build_path)
    require(sha(Path(build["executable"]))==build["executable_sha256"] and
            all(hashes[name]==digest for name,digest in build["source_sha256"].items()),
            "compact native source or executable differs")
    for child in ("admit_ten_compact_wire","train_ten_compact_wire","saved-review"):
        process=read(COHORT/child/"process.json")
        require(process["actual_exit_observed"] and process["returncode"]==0 and
                not process["failures"] and process["automatic_retries"]==0,
                "compact process observation differs")
    native=read(COHORT/"train_ten_compact_wire/process.json")
    compact=COHORT/"train_ten_compact_wire/stdout.bin"
    expanded=COHORT/"train_ten_compact_wire/expanded.bin"
    capture=final["compact_sweep_capture"]
    require(native["sweep_capture"]==capture and compact.stat().st_size==3_103_848 and
            sha(compact)==capture["retained_sha256"]==native["streams"][0]["sha256"] and
            expanded.stat().st_size==9_833_076 and
            sha(expanded)==final["saved_only_replay"]["saved_output_sha256"]==
                final["sweep_capture"]["retained_sha256"],
            "compact or expanded output identity differs")
    baseline="benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1"
    prior=read(ROOT/baseline/"manifest.json")
    require(sha(ROOT/baseline/"manifest.json")==hashes[baseline+"/manifest.json"] and
            sha(ROOT/baseline/"verification.zip")==hashes[baseline+"/verification.zip"]==prior["archive"]["sha256"] and
            capture["frames"]==prior["sweep_capture"]["frames"] and
            final["sweep_capture"]==prior["sweep_capture"] and
            final["saved_only_replay"]["work_actual"]==prior["saved_only_replay"]["work_actual"],
            "compact indexed baseline or numerical comparison differs")
    files={"operator/package-dyadic-wire.py":Path(__file__),
           "operator/trusted-virtual-dyadic-training-launch-v29.py":launcher}
    for prefix,folder in (("operator",OPERATOR),("cohort",COHORT)):
        for path in sorted(folder.rglob("*")):
            require(not path.is_symlink(),"linked compact evidence")
            if not path.is_file():
                continue
            rel=path.relative_to(folder)
            if prefix=="cohort" and (rel.parts[0]=="source" or
                    (rel.parts[0]=="build" and path!=build_path) or
                    rel.as_posix() in ("page-images/committed.bin","page-images/staged.bin",
                                      "train_ten_compact_wire/expanded.bin")):
                continue
            files[f"{prefix}/{rel.as_posix()}"]=path
    for kind in ("normal","opt"):
        log=WORK/f"dywire-controls3-{kind}.log"
        raw=log.read_text(encoding="utf-8-sig")
        require("Ran 38 tests" in raw and raw.rstrip().endswith("OK") and "skipped" not in raw,
                "compact control run incomplete")
        files[f"controls/{kind}.log"]=log
    timing_dir=WORK/"dywire-timing-pairs1"
    timing=read(timing_dir/"result.json")
    require(timing["source_head"]==HEAD and timing["training_invocations"]==8 and
            timing["raw_source_stable"] and timing["all_complete_streams_and_checkpoint_images_exact"] and
            read(timing_dir/"terminal.json")=={"status":"complete","training_invocations":8} and
            read(timing_dir/"source-before.json")==read(timing_dir/"source-after.json")==hashes and
            read(timing_dir/"configuration.json")["executable_sha256"]==build["executable_sha256"],
            "compact timing evidence differs")
    files["timing/compare-dyadic-wire-timing.py"]=WORK/"compare-dyadic-wire-timing.py"
    for name in ("configuration.json","result.json","terminal.json","source-before.json","source-after.json"):
        files[f"timing/{name}"]=timing_dir/name
    for item in timing["observations"]:
        label=f"pair-{item['pair']}-{item['mode']}"
        for name in ("verified.json","process/process.json","page-images/quantizer.json"):
            files[f"timing/{label}/{name}"]=timing_dir/label/name

    forecast="benchmarks/results/native-dyadic-eleven-card-forecast-v1/forecast.json"
    frozen_forecast=WORK/"dywire-src3"/forecast
    require(sha(frozen_forecast)==hashes[forecast],"N11 source forecast differs")
    files["projection/source-forecast.json"]=frozen_forecast
    old=read(frozen_forecast)["n11_prospective"]
    rows,slots,words=old["shape"]["rows"],old["shape"]["slots"],9_724_202
    require((rows,slots)==(380_172,892_910),"N11 source geometry differs")
    compact_bytes=8+128+88+1105*96+6*rows+768+14*(slots-rows)+(rows+7)//8+520
    projection={"status":"rank_free_output_projection_only","native_training_calls":0,
                "source_forecast_sha256":hashes[forecast],"rows":rows,"slots":slots,
                "compact_retained_bytes":compact_bytes,
                "compact_wire_bytes":compact_bytes+2*(32+8*words),
                "legacy_retained_bytes":old["retained_numerical_bytes"],
                "native_retained_ceiling":9_833_076,"headroom_bytes":9_833_076-compact_bytes,
                 "prior_composed_work_projection":old["composed_work_with_transport"],
                "compact_encoding_work":208*rows+64*slots+16*((rows+7)//8),
                "composed_work_with_compact_encoding":old["composed_work_with_transport"]+208*rows+64*slots+16*((rows+7)//8),
                "composed_entries_with_encoder_scratch":old["composed_entries"]+32,
                "composed_payload_bits_with_encoder_scratch":old["composed_payload_bits"]+2048,
                "composed_work_ceiling_unchanged":2_150_000_000}
    require(compact_bytes==9_614_478 and projection["compact_wire_bytes"]==165_201_774,
            "N11 exact output projection differs")
    earlier=WORK/"dywire-cohort1/result.json"
    prior_trial=read(earlier)
    require(prior_trial["head"]=="3a10f8ec47d4f7b6731efadb5944a070f72781ec" and
            prior_trial["training_invocations"]==1 and
            read(WORK/"dywire-launch1/completion.json")["returncode"]==0 and
            prior_trial["compact_sweep_capture"]==capture,
            "earlier format-only trial differs")
    for name,path in (
        ("earlier-format-only/result.json",earlier),
        ("earlier-format-only/completion.json",WORK/"dywire-launch1/completion.json"),
        ("earlier-format-only/source.json",WORK/"dywire-cohort1/source.json")):
        files[name]=path
    reviewed_trial=WORK/"dywire-cohort2/result.json"
    reviewed=read(reviewed_trial)
    require(reviewed["head"]=="581956d6676825e318800f3d6ae3e78bd29c92dc" and
            reviewed["compact_encoding_receipt"]==final["compact_encoding_receipt"] and
            reviewed["compact_sweep_capture"]==capture and
            read(WORK/"dywire-launch2/completion.json")["returncode"]==0,
            "reviewed intermediate trial differs")
    files["earlier-metered-trial/result.json"]=reviewed_trial
    files["earlier-metered-trial/completion.json"]=WORK/"dywire-launch2/completion.json"
    RESULT.mkdir(exist_ok=False)
    archive=RESULT/"verification.zip"
    inventory={name:{"bytes":path.stat().st_size,"sha256":sha(path)} for name,path in files.items()}
    with ZipFile(archive,"x",ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr("inventory.json",json.dumps(inventory,indent=2,sort_keys=True)+"\n")
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,"compact archive CRC differs")
        for name,record in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==record["bytes"] and
                        hashlib.file_digest(stream,"sha256").hexdigest()==record["sha256"],
                        "compact archive member differs")
    manifest={"version":"native-dyadic-compact-wire-v1","source_head":HEAD,"source_files":len(hashes),
               "training_invocations":1,
              "earlier_format_only_trial":{"source_head":prior_trial["head"],"training_invocations":1,
                  "limitation":"Precedes separate compact encoding resource accounting."},
              "earlier_metered_trial":{"source_head":reviewed["head"],"training_invocations":1,
                  "scope":"Metered semantic and wire replay before legacy-only emission adjustment."},
              "compact_sweep_capture":capture,"expansion":final["expansion"],
              "host_retained_bytes":final["host_retained_bytes"],
              "native_seconds":native["duration_seconds"],"native_memory":native.get("memory"),
               "quality_gate":final["quality_gate"],"comparison":final["comparison"],
              "compact_encoding_receipt":final["compact_encoding_receipt"],
              "compact_composed_work":final["admission"]["compact_composed_work"],
              "compact_composed_entries":final["admission"]["compact_composed_entries"],
              "compact_composed_payload_bits":final["admission"]["compact_composed_payload_bits"],
              "wire_reconstruction":final["wire_reconstruction"],
              "work_plan":final["saved_only_replay"]["work_plan"],
              "timing":timing,"n11_output_projection":projection,
              "archive":{"path":"verification.zip","bytes":archive.stat().st_size,
                         "sha256":sha(archive),"members":len(inventory)+1}}
    with (RESULT/"manifest.json").open("x",encoding="utf-8") as stream:
        json.dump(manifest,stream,indent=2,sort_keys=True)
        stream.write("\n")
    print(json.dumps({"source_head":HEAD,"archive":manifest["archive"],
                      "n11_output_projection":projection}))


if __name__=="__main__":
    main()
