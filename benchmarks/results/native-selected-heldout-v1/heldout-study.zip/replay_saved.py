import hashlib,json,sys
from pathlib import Path
from scripts.benchmark_selected_operator import ROOT,_identity
from pokerlab.native_selected_operator import executable_identity
from scripts.preflop_validation import replay_policy,compare_result
from scripts.four_street_certificate_v3 import evaluate_exact
OUT=Path(sys.argv[1]); exe=Path(sys.argv[2]).resolve(strict=True)
case=json.loads((OUT/'case.json').read_text(encoding='utf-8'))
payloads={};numeric={};certs={};cert_failures={}
for backend in ('python','native'):
 raw=(OUT/f't100-{backend}.json').read_bytes(); decoded=json.loads(raw); payload=decoded['payload'];payloads[backend]=payload
 oracle=replay_policy(payload,case['sb_range'],case['bb_range'],config=case['config'],runouts=case['runouts'],flop_config=case['flop_config'],turn_config=case['turn_config'],river_config=case['river_config'])
 gaps=compare_result(payload,oracle)
 numeric[backend]={'independent_metrics':{k:oracle[k] for k in ('value_sb','value_bb','sb_best_response_value','bb_best_response_value','nash_conv')},'gaps':gaps,'worlds':oracle['worlds'],'passed':max(gaps.values())<=1e-10}
 (OUT/f'numeric-replay-{backend}.json').write_text(json.dumps(numeric[backend],indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
 try:
  certificate=evaluate_exact(case,payload);certs[backend]=certificate
  (OUT/f'certificate-{backend}.json').write_text(json.dumps(certificate,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
 except Exception as exc:
  cert_failures[backend]={'error_type':type(exc).__name__,'error':str(exc),'strategy_rows':len(payload.get('strategy',[]))}
strategy_equal=payloads['python'].get('strategy')==payloads['native'].get('strategy')
fields=('value_sb','value_bb','sb_best_response_value','bb_best_response_value','nash_conv')
diagnostics={f:{'python':payloads['python'].get(f),'native':payloads['native'].get(f),'equal':payloads['python'].get(f)==payloads['native'].get(f)} for f in fields}
source_before=json.loads((OUT/'source-before.json').read_text());source_after=json.loads((OUT/'source-after.json').read_text())
bin_before=json.loads((OUT/'native-identity-before.json').read_text());bin_after=json.loads((OUT/'native-identity-after.json').read_text())
metrics_equal=(len(certs)==2 and certs['python'].get('metrics')==certs['native'].get('metrics'))
report={'outcome':'exact-audit-rejected-bounded-result-shape' if cert_failures else 'audited','source_commit':source_before['commit'],'source_unchanged':source_before==source_after and source_after==_identity() and not source_after['status'],'binary_unchanged':bin_before==bin_after and bin_after==executable_identity(exe),'raw_child_sha256':{b:hashlib.sha256((OUT/f't100-{b}.json').read_bytes()).hexdigest() for b in payloads},'strategy_rows':{b:len(payloads[b].get('strategy',[])) for b in payloads},'complete_strategy_rows_identical':strategy_equal,'independent_numeric_replay':numeric,'diagnostic_field_comparison':diagnostics,'private_pair_probabilities_identical':payloads['python'].get('private_pair_probabilities')==payloads['native'].get('private_pair_probabilities'),'exact_certificate_metrics_identical':metrics_equal,'certificate_failures':cert_failures,'t1000_preflight_rejection':json.loads((OUT/'native-heldout-admission.json').read_text())['rows'][2],'training_calls':2,'native_calls':1,'limitations':'One untraced T100 call per backend. Exact certificate rejected both complete 2,224-row payloads because its fixed input cap is 2,048 rows. No source caps changed and no T1000 training attempted.'}
(OUT/'partial-report.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('outcome','source_unchanged','binary_unchanged','complete_strategy_rows_identical','strategy_rows','diagnostic_field_comparison','private_pair_probabilities_identical','exact_certificate_metrics_identical','certificate_failures','t1000_preflight_rejection')},indent=2))
