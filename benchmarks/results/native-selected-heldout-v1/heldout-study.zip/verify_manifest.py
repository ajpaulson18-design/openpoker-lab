import hashlib,json,sys
from pathlib import Path
d=Path(sys.argv[1]);m=json.loads((d/'manifest.json').read_text());bad=[n for n,h in m['sha256'].items() if hashlib.sha256((d/n).read_bytes()).hexdigest()!=h]
print(json.dumps({'manifest_sha256':hashlib.sha256((d/'manifest.json').read_bytes()).hexdigest(),'sidecar':(d/'manifest.sha256').read_text().split()[0],'artifact_mismatches':bad,'source_status':json.loads((d/'source-after.json').read_text())['status'],'source_commit':json.loads((d/'source-after.json').read_text())['commit'],'outcome':json.loads((d/'study-receipt.json').read_text())['outcome']},indent=2))
