"""Single-call external held-out T100 paired study; no retries."""
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path
from pokerlab.native_selected_operator import executable_identity
from pokerlab.selected_operator_solver import solve_four_street_operator
from scripts.benchmark_selected_operator import ROOT, _identity, _request, _write
from scripts.preflop_validation import replay_policy, compare_result
from scripts.four_street_certificate_v3 import evaluate_exact

CACHE=64
STORAGE="packed"
EXPECTED="745e4dd48614673dbc6372025d30cdb6bb35f3af"
FIELDS=("value_sb","value_bb","sb_best_response_value","bb_best_response_value","nash_conv")

def child(case_path, backend, executable):
    case=json.loads(Path(case_path).read_text(encoding="utf-8"))
    request=_request(case,100)
    kwargs={"strategy_storage":STORAGE,"rank_cache_boards":CACHE}
    if backend=="native":
        if not executable: raise ValueError("Native backend requires explicit executable path")
        kwargs["native_executable"]=str(Path(executable).resolve(strict=True))
    elif backend!="python": raise ValueError("Unsupported backend")
    started=time.perf_counter()
    payload=solve_four_street_operator(request,**kwargs)
    elapsed=time.perf_counter()-started
    import ctypes
    from scripts.benchmark_selected_operator import _rss
    print(json.dumps({"backend":backend,"iterations":100,"strategy_storage":STORAGE,
      "rank_cache_boards":CACHE,"seconds":elapsed,
      "python_process_lifetime_peak_working_set_bytes":_rss(),
      "native_process_lifetime_peak_working_set_bytes":payload.get("native_training",{}).get("native_process_lifetime_peak_working_set_bytes") if backend=="native" else None,
      "payload":payload},allow_nan=False,separators=(",",":")))

def replay(payload, case):
    numeric=replay_policy(payload,case["sb_range"],case["bb_range"],config=case["config"],
      runouts=case["runouts"],flop_config=case["flop_config"],
      turn_config=case["turn_config"],river_config=case["river_config"])
    gaps=compare_result(payload,numeric)
    certificate=evaluate_exact(case,payload)
    return {"numeric_differences":gaps,"numeric_fields":list(FIELDS),
      "numeric_replay_worlds":numeric["worlds"],
      "certificate_metrics":certificate["metrics"],
      "certificate_target_met":certificate["threshold_met"],
      "certificate":certificate}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--child",choices=("python","native"));ap.add_argument("--case");ap.add_argument("--native-executable");ap.add_argument("--output",type=Path);a=ap.parse_args()
    if a.child:
      if not a.case: ap.error("--case required with --child")
      child(a.case,a.child,a.native_executable);return 0
    out=a.output.resolve(strict=True); exe=Path(a.native_executable).resolve(strict=True)
    if out==ROOT or ROOT in out.parents: raise ValueError("Output must remain outside checkout")
    case_path=out/"case.json"; admission_path=out/"native-heldout-admission.json"
    case_doc=json.loads((ROOT.parent/"native-next-census"/"native-heldout-admission.json").read_text(encoding="utf-8"))
    if case_doc["source"]["commit"]!=EXPECTED or case_doc["source"]["status"]!="": raise ValueError("Admission receipt source identity mismatch")
    if case_doc["case"]["id"]!="native-selected-heldout-96-worlds-v1": raise ValueError("Unexpected held-out case")
    if not (case_doc["rows"][1]["admitted"] and case_doc["rows"][1]["census"]["native_operator_admission"]["modeled_work_entries"]==63688728): raise ValueError("T100 admission does not match pinned receipt")
    _write(case_path,case_doc["case"]); _write(admission_path,case_doc)
    source_before=_identity()
    if source_before["commit"]!=EXPECTED or source_before["status"]: raise ValueError("Requires clean pinned source")
    binary_before=executable_identity(exe)
    _write(out/"source-before.json",source_before);_write(out/"native-identity-before.json",binary_before)
    protocol={"version":"native-heldout-selected-operator-t100-v1","case_id":case_doc["case"]["id"],
      "source_commit":EXPECTED,"iterations":100,"calls_per_backend":1,"retry_policy":"none; preserve first result or failure",
      "execution_order":["python","native"],"strategy_storage":STORAGE,"rank_cache_boards":CACHE,
      "native_executable":str(exe),"training":True,"native_calls_expected":1,
      "scope":"One selected 96-world held-out finite game; not a general performance or convergence claim."}
    _write(out/"protocol.json",protocol)
    rows=[];payloads={};errors=[]
    for backend in ("python","native"):
      name=f"t100-{backend}.json"
      command=[sys.executable,"-B",str(Path(__file__).resolve()),"--child",backend,"--case",str(case_path)]
      if backend=="native": command.extend(["--native-executable",str(exe)])
      env=os.environ.copy();env["PYTHONPATH"]=str(ROOT)+(os.pathsep+env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
      started=time.time_ns();wall=time.perf_counter()
      try:
        proc=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,check=False)
        raw=proc.stdout
        (out/name).write_bytes(raw) # retain exact child bytes before parsing
        (out/(name[:-5]+".stderr.txt")).write_bytes(proc.stderr)
        if proc.returncode!=0:
          raise RuntimeError(f"child exit {proc.returncode}")
        decoded=json.loads(raw)
        if decoded["backend"]!=backend or decoded["iterations"]!=100: raise ValueError("Child identity mismatch")
        payload=decoded["payload"];payloads[backend]=payload
        rows.append({k:v for k,v in decoded.items() if k!="payload"}|{"artifact":name,"raw_sha256":hashlib.sha256(raw).hexdigest(),"started_at_unix_ns":started,"parent_elapsed_wall_seconds":time.perf_counter()-wall,"complete_strategy_rows":len(payload.get("strategy",[])),"operator_statistics":payload.get("operator_statistics"),"rank_cache":payload.get("rank_cache"),"native_training":payload.get("native_training")})
      except Exception as e:
        errors.append({"backend":backend,"artifact":name,"error_type":type(e).__name__,"error":str(e),"child_returncode":locals().get("proc",None).returncode if "proc" in locals() else None})
        break
    source_after=_identity();binary_after=executable_identity(exe)
    _write(out/"source-after.json",source_after);_write(out/"native-identity-after.json",binary_after)
    if source_after!=source_before: errors.append({"stage":"source-identity","error":"Source changed during calls"})
    if binary_after!=binary_before: errors.append({"stage":"binary-identity","error":"Native identity changed during calls"})
    if errors:
      _write(out/"partial-report.json",{"outcome":"training-or-identity-failure","protocol":protocol,"samples":rows,"errors":errors,"source_before":source_before,"source_after":source_after,"native_identity_before":binary_before,"native_identity_after":binary_after})
      print(json.dumps({"outcome":"training-or-identity-failure","errors":errors}));return 1
    audits={}
    for backend in ("python","native"):
      audit=replay(payloads[backend],case_doc["case"])
      _write(out/f"certificate-{backend}.json",audit["certificate"])
      audit.pop("certificate")
      audits[backend]=audit
    p,n=payloads["python"],payloads["native"]
    expected_rows=case_doc["rows"][1]["census"]["information_sets"]
    strategy_equal=p.get("strategy")==n.get("strategy")
    diagnostics_equal=all(p.get(k)==n.get(k) for k in FIELDS)
    rows_complete=len(p.get("strategy",[]))==len(n.get("strategy",[]))==expected_rows
    pair_prob_equal=p.get("private_pair_probabilities")==n.get("private_pair_probabilities")
    exact_metrics_equal=audits["python"]["certificate_metrics"]==audits["native"]["certificate_metrics"]
    replay_pass=all(all(v<=1e-10 for v in a["numeric_differences"].values()) for a in audits.values())
    report={"outcome":"complete" if rows_complete and strategy_equal and diagnostics_equal and pair_prob_equal and exact_metrics_equal and replay_pass else "quality-miss",
      "protocol":protocol,"source_before":source_before,"source_after":source_after,"native_identity_before":binary_before,"native_identity_after":binary_after,
      "samples":rows,"comparisons":{"complete_rows_equal_expected_census":rows_complete,"strategy_rows_identical":strategy_equal,"diagnostics_identical":diagnostics_equal,"private_pair_probabilities_identical":pair_prob_equal,"exact_certificate_metrics_identical":exact_metrics_equal,"independent_numeric_replay_passed":replay_pass},"audits":audits,
      "t1000_admission_rejection":case_doc["rows"][2],"training_calls":2,"native_calls":1,
      "limitations":"Single untraced T100 training call per backend. T1000 was retained as preflight rejection only. No retries, broad performance claim, or convergence claim."}
    _write(out/"report.json",report)
    print(json.dumps({"outcome":report["outcome"],"report":str(out/"report.json"),"comparisons":report["comparisons"]},indent=2))
    return 0 if report["outcome"]=="complete" else 1
if __name__=="__main__":
    if "--child" in sys.argv: main()
    else: raise SystemExit(main())
