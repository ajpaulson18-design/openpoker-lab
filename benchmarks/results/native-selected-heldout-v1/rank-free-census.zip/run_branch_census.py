import json,sys,hashlib,subprocess
from pathlib import Path
from pokerlab.cards import DECK
from pokerlab.selected_operator_solver import census_four_street_operator
from pokerlab.solver_contracts import FourStreetSolveRequest,PostflopActions
from pokerlab.preflop_tree import PreflopConfig
OUT=Path(sys.argv[1]); old=json.loads((OUT/'census.json').read_text()); rows=[]
pool0=DECK[:12];pool1=DECK[12:24];rem=list(DECK[24:]);boards=[''.join(rem[:3]+[a,b]) for a,b in __import__('itertools').islice(__import__('itertools').permutations(rem[3:],2),6)]
def rt(pool,n): return ','.join(''.join(h) for h in __import__('itertools').islice(__import__('itertools').combinations(pool,2),n))
for stack,premax,postmax,sizes in [(8,1,1,(.5,)),(32,2,1,(.5,)),(32,2,2,(.5,)),(100,2,1,(.5,1.0)),(100,2,2,(.5,1.0)),(100,3,2,(.5,1.0))]:
  pre=PreflopConfig(small_blind=.5,big_blind=1,starting_stack=(stack,stack),raise_sizes=sizes,max_raises=premax,include_all_in=False)
  acts=PostflopActions(bet_sizes=sizes,raise_sizes=sizes if postmax else (),max_raises=postmax,include_all_in=False)
  req=FourStreetSolveRequest(rt(pool0,4),rt(pool1,4),tuple(boards),preflop_config=pre,flop_actions=acts,turn_actions=acts,river_actions=acts,iterations=10,algorithm='cfrplus',traversal='public-batched',diagnostics='public-batched',resource_model='public-vector')
  d={'label':'branching_extended','stack':stack,'preflop_max_raises':premax,'postflop_max_raises':postmax,'action_sizes':list(sizes)}
  try:
    c=census_four_street_operator(req);d.update({'admitted':True,'census':c})
  except Exception as e:d.update({'admitted':False,'error_type':type(e).__name__,'reason':str(e)})
  rows.append(d)
old['branching_extended']=rows
(OUT/'census.json').write_text(json.dumps(old,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps([{'stack':x['stack'],'premax':x['preflop_max_raises'],'postmax':x['postflop_max_raises'],'sizes':x['action_sizes'],'admitted':x['admitted'],'reason':x.get('reason'),'states':x.get('census',{}).get('public_states'),'decisions':x.get('census',{}).get('decisions'),'actions':x.get('census',{}).get('action_slots'),'max_actions':x.get('census',{}).get('maximum_actions'),'prep':x.get('census',{}).get('preparation_scan_upper_bound'),'scan':x.get('census',{}).get('pair_runout_scan_upper_bound')} for x in rows],indent=2))
