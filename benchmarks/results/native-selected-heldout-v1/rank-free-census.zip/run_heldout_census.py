import json,sys,itertools
from pathlib import Path
from pokerlab.cards import DECK
from pokerlab.selected_operator_solver import census_four_street_operator
from pokerlab.solver_contracts import FourStreetSolveRequest,PostflopActions
from pokerlab.preflop_tree import PreflopConfig
OUT=Path(sys.argv[1]); payload=json.loads((OUT/'census.json').read_text()); pool0=DECK[:12];pool1=DECK[12:24];safe=list(DECK[24:]);
# Two distinct flops, three ordered turn-river outcomes each.
flops=[safe[:3],safe[3:6]]; rest=safe[6:]
boards=[]
for flop in flops:
  pairs=list(itertools.permutations([c for c in rest if c not in flop],2))
  boards.extend(tuple(flop)+(a,b) for a,b in pairs[:3])
def rt(pool,n):return ','.join(''.join(h) for h in itertools.islice(itertools.combinations(pool,2),n))
acts=PostflopActions(bet_sizes=(.5,),raise_sizes=(),max_raises=0,include_all_in=False)
req=FourStreetSolveRequest(rt(pool0,4),rt(pool1,4),tuple(''.join(x) for x in boards),preflop_config=PreflopConfig(small_blind=.5,big_blind=1,starting_stack=(8,8),raise_sizes=(.5,),max_raises=1,include_all_in=False),flop_actions=acts,turn_actions=acts,river_actions=acts,iterations=10,algorithm='cfrplus',traversal='public-batched',diagnostics='public-batched',resource_model='public-vector')
try:
  c=census_four_street_operator(req);payload['held_out_candidate']={'description':'Two-flop, six-runout, 4x4 disjoint private-range census (96 supported physical worlds); rank-free only.','admitted':True,'census':c}
except Exception as e: payload['held_out_candidate']={'description':'Two-flop, six-runout, 4x4 disjoint private-range census (96 supported physical worlds); rank-free only.','admitted':False,'error_type':type(e).__name__,'reason':str(e)}
(OUT/'census.json').write_text(json.dumps(payload,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(payload['held_out_candidate'],indent=2))
