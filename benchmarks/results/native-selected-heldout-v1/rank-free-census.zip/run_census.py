import hashlib, json, sys, itertools, traceback
from pathlib import Path
from pokerlab.cards import DECK
from pokerlab.selected_operator_solver import census_four_street_operator
from pokerlab.solver_contracts import FourStreetSolveRequest, PostflopActions
from pokerlab.preflop_tree import PreflopConfig
ROOT=Path.cwd()
OUT=Path(sys.argv[1])
case=json.loads((ROOT/'benchmarks/four-street-integration-v1.json').read_text())['case']
def sha(p): return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
manifest={'source_commit':__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_status':__import__('subprocess').check_output(['git','status','--porcelain'],text=True).strip(),'source_sha256':{p:sha(p) for p in ['pokerlab/selected_operator_solver.py','pokerlab/selected_runout_operator.py','pokerlab/solver_contracts.py','pokerlab/preflop_tree.py','benchmarks/four-street-integration-v1.json']},'census_only':True,'training':False,'ranking':False,'native_binary':False,'iterations':10}
# Two disjoint 12-card pools give 66 hand combinations each. Remaining 28 cards
# provide a shared flop and at least 64 ordered turn-river outcomes.
remaining=list(DECK[24:]); pool0=list(DECK[:12]); pool1=list(DECK[12:24]); flop=remaining[:3]; later=remaining[3:]
boards=[tuple(flop)+(a,b) for a,b in itertools.permutations(later,2)][:64]
def range_text(pool,n): return ','.join(''.join(x) for x in itertools.islice(itertools.combinations(pool,2),n))
def request(nhands,nboards,raises=0):
  acts=PostflopActions(bet_sizes=(.5,),raise_sizes=((.5,) if raises else ()),max_raises=raises,include_all_in=False)
  return FourStreetSolveRequest(range_text(pool0,nhands),range_text(pool1,nhands),tuple(''.join(b) for b in boards[:nboards]),preflop_config=PreflopConfig(small_blind=.5,big_blind=1,starting_stack=(8,8),raise_sizes=(.5,),max_raises=1,include_all_in=False),flop_actions=acts,turn_actions=acts,river_actions=acts,iterations=10,algorithm='cfrplus',traversal='public-batched',diagnostics='public-batched',resource_model='public-vector')
rows=[]
def run(label,nh,nr,raises=0):
  item={'label':label,'hands_per_seat':nh,'boards':nr,'postflop_max_raises':raises}
  try:
    c=census_four_street_operator(request(nh,nr,raises))
    item.update({'admitted':True,'census':c})
  except Exception as e:
    item.update({'admitted':False,'error_type':type(e).__name__,'reason':str(e)})
  rows.append(item)
# Hand-size scale, fixed six boards and fixed menu.
for n in (1,2,4,8,16,32,48,64): run('private_range_scale',n,6)
# Board scale, fixed four hands per seat and fixed menu.
for n in (1,2,4,6,12,24,48,64): run('selected_board_scale',4,n)
# Tree branching scale, fixed four hands and six boards.
for r in (0,1,2,3): run('betting_history_scale',4,6,r)
manifest['rows']=rows
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'census.json').write_text(json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'receipt':str(OUT/'census.json'),'rows':[{'label':x['label'],'hands':x['hands_per_seat'],'boards':x['boards'],'raises':x['postflop_max_raises'],'admitted':x['admitted'],'reason':x.get('reason'),'states':x.get('census',{}).get('public_states'),'infos':x.get('census',{}).get('information_sets'),'actions':x.get('census',{}).get('action_slots'),'worlds':x.get('census',{}).get('physical_worlds_represented'),'prep':x.get('census',{}).get('preparation_scan_upper_bound'),'scan':x.get('census',{}).get('pair_runout_scan_upper_bound')} for x in rows]},indent=2))
