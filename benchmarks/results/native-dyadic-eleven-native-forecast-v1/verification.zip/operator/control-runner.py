"""Run source-bound N11 forecast and admission controls without training."""
import ast
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

WORK=Path(__file__).resolve().parent
REPO=WORK/"dy11forecast-src3"
HEAD="affeca296c9f3cd95694f89ba3bfce0198cf27ab"
OUT=WORK/"dy11forecast-controls3"
BUILD=WORK/"dy11forecast-build2/native-exact-build-manifest.json"
helpers=runpy.run_path(str(WORK/"trusted-virtual-dyadic-training-launch-v39.py"))
git,snapshot,save,sha,observe=(helpers[n] for n in ("git","snapshot","save","sha","observe"))

def committed(name,digest):
    path=REPO/name
    raw=path.read_bytes()
    tracked=git(REPO,"show",HEAD+":"+name)
    if sha(path)!=digest or raw!=tracked and raw.replace(b"\r\n",b"\n")!=tracked:
        raise ValueError("source identity differs "+name)

def main():
    if git(REPO,"rev-parse","HEAD").decode().strip()!=HEAD:
        raise ValueError("source HEAD differs")
    OUT.mkdir(exist_ok=False)
    before=snapshot(REPO)
    save(OUT/"source-before.json",before)
    build=json.loads(BUILD.read_bytes())
    if build["target"]!="virtual-dyadic-training" or sha(Path(build["executable"]))!=build["executable_sha256"]:
        raise ValueError("native build differs")
    for name,digest in build["source_sha256"].items():
        if before.get(name)!=digest: raise ValueError("build source differs "+name)
        committed(name,digest)
    bootstrap=REPO/"scripts/run_virtual_frozen_source_only.py"
    raw=bootstrap.read_bytes()
    stages=[ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Name) and t.id=="FIRST_STAGE" for t in n.targets)]
    if len(stages)!=1: raise ValueError("source-only entry differs")
    os.environ["OPENPOKER_NATIVE_VIRTUAL_DYADIC_TRAINING_EXE"]=build["executable"]
    exits={}
    for mode in ("normal","optimized"):
        target=OUT/mode
        target.mkdir()
        os.environ["OPENPOKER_NATIVE_VIRTUAL_DYADIC_TRAINING_CONTROL_DIR"]=str(target/"training")
        receipt=target/"bootstrap.json"
        command=[sys.executable,"-I","-S","-B",*(["-O"] if mode=="optimized" else []),
                 "-c",stages[0],str(bootstrap),sha(bootstrap),"--module","unittest","--receipt",str(receipt),"--",
                 "tests.test_native_virtual_dyadic_training.NativeDyadicAdmissionControls",
                 "tests.test_virtual_dyadic_directory","-v"]
        exits[mode]=observe(command,REPO,target)
        if not exits[mode]["actual_exit_observed"] or exits[mode]["returncode"] or exits[mode]["failures"]:
            raise ValueError("control execution failed")
        boot=json.loads(receipt.read_bytes())
        if boot["initial_cache_scan"]["project_bytecode_files"] or boot["final_cache_scan"]["project_bytecode_files"]:
            raise ValueError("project bytecode appeared")
        for name,digest in boot["compiled"].items():
            if before.get(name)!=digest: raise ValueError("compiled source differs")
            committed(name,digest)
        log=(target/"stderr.log").read_text()
        if "Ran 37 tests" not in log or "\nOK\n" not in log or "skipped" in log:
            raise ValueError("focused controls incomplete")
    after=snapshot(REPO)
    if after!=before: raise ValueError("source drift")
    save(OUT/"source-after.json",after)
    result={"source_head":HEAD,"tests_per_mode":37,"skips":0,"training_invocations":0,
            "exits":exits,"raw_source_stable":True,"source_files":len(before),
            "build_manifest_sha256":sha(BUILD),"executable_sha256":build["executable_sha256"]}
    save(OUT/"completion.json",result)
    print(json.dumps(result))

if __name__=="__main__":
    main()

