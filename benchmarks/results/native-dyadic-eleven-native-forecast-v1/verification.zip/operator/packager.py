"""Package the compiled eleven-card forecast and source-only controls."""
import hashlib
import json
from pathlib import Path
import runpy
from zipfile import ZipFile,ZIP_DEFLATED

WORK=Path(__file__).resolve().parent
ROOT=WORK/"dyadic-phase-payload-repo"
SOURCE=WORK/"dy11forecast-src3"
HEAD="affeca296c9f3cd95694f89ba3bfce0198cf27ab"
CONTROLS=WORK/"dy11forecast-controls3"
BUILD=WORK/"dy11forecast-build2/native-exact-build-manifest.json"
RESULT=ROOT/"benchmarks/results/native-dyadic-eleven-native-forecast-v1"
helpers=runpy.run_path(str(WORK/"trusted-virtual-dyadic-training-launch-v39.py"))
git=helpers["git"]

def require(value,message):
    if not value:raise ValueError(message)

def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def main():
    completed=read(CONTROLS/"completion.json")
    before=read(CONTROLS/"source-before.json")
    after=read(CONTROLS/"source-after.json")
    build=read(BUILD)
    require(completed["source_head"]==HEAD and completed["tests_per_mode"]==37 and completed["skips"]==0 and
            completed["training_invocations"]==0 and completed["raw_source_stable"] and before==after and
            git(SOURCE,"rev-parse","HEAD").decode().strip()==HEAD and
            completed["build_manifest_sha256"]==sha(BUILD) and
            completed["executable_sha256"]==sha(Path(build["executable"]))==build["executable_sha256"],
            "frozen controls or build identity differs")
    forecasts=[]
    closure=set(build["source_sha256"])
    for mode in ("normal","optimized"):
        folder=CONTROLS/mode
        boot=read(folder/"bootstrap.json")
        require(boot["initial_cache_scan"]["project_bytecode_files"]==
                boot["final_cache_scan"]["project_bytecode_files"]==0 and
                boot["interpreter"]["optimize"]==int(mode=="optimized"),
                "source-only mode differs")
        closure.update(boot["compiled"])
        require(all(before[name]==digest for name,digest in boot["compiled"].items()),
                "compiled closure differs")
        require(completed["exits"][mode]["actual_exit_observed"] and
                completed["exits"][mode]["returncode"]==0 and not completed["exits"][mode]["failures"],
                "control exit differs")
        folder=folder/"training/forecast_eleven"
        process=read(folder/"process.json")
        require(process["actual_exit_observed"] and process["returncode"]==0 and
                not process["failures"] and process["automatic_retries"]==0 and
                (folder/"request.bin").read_bytes()==b"DYADIC_T2_V1 FORECAST_ELEVEN\n" and
                not (folder/"stderr.bin").read_bytes(),
                "native forecast observation differs")
        raw=(folder/"stdout.bin").read_bytes()
        require(hashlib.sha256(raw).hexdigest()==process["streams"][0]["sha256"],"forecast digest differs")
        forecasts.append(raw)
    require(forecasts[0]==forecasts[1],"normal and optimized forecasts differ")
    forecast=json.loads(forecasts[0])
    require(forecast["status"]=="FORECAST_ONLY" and forecast["training_admitted"] is False and
            forecast["quality_gate"] is None and forecast["training_invocations"]==forecast["rank_calls"]==0,
            "forecast scope differs")
    require(forecast["work"]=={"template":42556544,"chance":448157615,"history":98688160,
                "state":662607040,"quantizer":1014146272,"parent":2308449784,
                "numerical":4574605415,"composed":5954402351} and
            forecast["work"]["composed"]>2**32 and forecast["wire_bytes"]==165201774 and
            forecast["compact_retained_bytes"]==9614478,
            "independently checked ledger differs")
    source_files={}
    for name in sorted(closure):
        path=SOURCE/name
        require(sha(path)==before[name],"source raw bytes differ")
        raw=path.read_bytes()
        tracked=git(SOURCE,"show",HEAD+":"+name)
        require(raw==tracked or raw.replace(b"\r\n",b"\n")==tracked,"source committed identity differs")
        source_files["source/"+name]=path
    files={"operator/packager.py":Path(__file__),"operator/control-runner.py":WORK/"check-eleven-forecast-controls3.py",
           "operator/launcher-helpers.py":WORK/"trusted-virtual-dyadic-training-launch-v39.py",
           "build/native-exact-build-manifest.json":BUILD,
           "build/build.log":BUILD.parent/"build.log",
           "earlier/admission-optimized.log":WORK/"dy11forecast-admission-optimized.log",
           "earlier/frozen-controls-stderr.log":WORK/"dy11forecast-controls2/normal/stderr.log",
           "earlier/frozen-controls-exit.json":WORK/"dy11forecast-controls2/normal/exit.json",
           **source_files}
    for path in sorted(CONTROLS.rglob("*")):
        require(not path.is_symlink(),"linked evidence")
        if path.is_file():files["controls/"+path.relative_to(CONTROLS).as_posix()]=path
    inventory={name:{"bytes":path.stat().st_size,"sha256":sha(path)} for name,path in files.items()}
    RESULT.mkdir()
    archive=RESULT/"verification.zip"
    with ZipFile(archive,"x",ZIP_DEFLATED) as zipped:
        for name,path in sorted(files.items()):zipped.write(path,name)
        zipped.writestr("inventory.json",json.dumps(inventory,sort_keys=True,indent=2))
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,"archive integrity failure")
        for name,meta in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==meta["bytes"] and
                        hashlib.file_digest(stream,"sha256").hexdigest()==meta["sha256"],
                        "archive member identity differs")
    manifest={"version":RESULT.name,"source_head":HEAD,"scope":"compiled forecast only",
              "training_invocations":0,"hand_rank_calls":0,"training_admitted":False,"quality_gate":None,
              "forecast":forecast,"tests_per_mode":37,"skips":0,"source_files":len(before),
              "source_closure_files":len(closure),"normal_optimized_forecast_identical":True,
              "storage_status":"projected envelope extended from N10; eleven-card owners remain unadmitted",
              "work_status":"prior independent Chance ledger plus independently reconstructed tree, row, History and integer work schedules",
              "native_train_request_rejected":True,"scratch_request_rejected":True,
              "failed_comparison_caps":[k for k,cap in forecast["comparison_caps"].items()
                                        if forecast["work"][k]>cap],
              "archive":{"path":archive.name,"bytes":archive.stat().st_size,"sha256":sha(archive),"members":len(inventory)+1}}
    (RESULT/"manifest.json").write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(manifest["archive"]))

if __name__=="__main__":main()

