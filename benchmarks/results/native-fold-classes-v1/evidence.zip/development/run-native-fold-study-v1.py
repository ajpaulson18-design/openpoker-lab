"""Durable one-attempt wrapper for the committed fixed fold-class study."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
repo = work / "native-fold-mask-repo"
engine = work / "native-fold-v5-engine-build-v2/native-exact-four-street-train.exe"
output = work / "native-fold-classes-study-v1"
logs = work / "native-fold-classes-study-process-v1"
expected_commit = sys.argv[1]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).decode().strip()
status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=repo)
if head != expected_commit or status or output.exists() or logs.exists():
    raise SystemExit("Require the exact clean frozen commit and fresh output/log directories")
logs.mkdir()
command = [sys.executable, "-B", "-m", "scripts.benchmark_native_fold_classes",
           "--output", str(output), "--native-executable", str(engine)]
protocol = {"source_commit": head, "command": command,
            "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "engine_sha256": hashlib.sha256(engine.read_bytes()).hexdigest(),
            "build_manifest_sha256": hashlib.sha256((engine.parent / "native-exact-build-manifest.json").read_bytes()).hexdigest(),
            "producer_attempts_authorized": 1, "retry": False}
(logs / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
with (logs / "stdout.log").open("xb") as stdout, (logs / "stderr.log").open("xb") as stderr:
    process = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
completion = {**protocol, "returncode": process.returncode,
              "stdout_sha256": hashlib.sha256((logs / "stdout.log").read_bytes()).hexdigest(),
              "stderr_sha256": hashlib.sha256((logs / "stderr.log").read_bytes()).hexdigest()}
(logs / "completion.json").write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"returncode": process.returncode, "logs": str(logs), "output": str(output)}), flush=True)
raise SystemExit(process.returncode)
