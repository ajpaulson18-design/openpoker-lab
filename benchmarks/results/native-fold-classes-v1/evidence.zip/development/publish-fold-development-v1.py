"""Retain scoped native development evidence; public acceptance is separate."""
import hashlib
import json
from pathlib import Path
import zipfile

work = Path(__file__).resolve().parent
repo = work / "native-fold-mask-repo"
out = repo / "benchmarks/results/native-fold-class-development-v1"
out.mkdir(exist_ok=False)
def sha(raw): return hashlib.sha256(raw).hexdigest()
inputs = {
    "exact-algebra-proof.py": work / "probe-fold-mask-classes-v1.py",
    "exact-algebra-receipt.json": work / "fold-mask-class-proof-v1/receipt.json",
    "native-controls-build.json": work / "native-fold-class-build-v3/native-exact-build-manifest.json",
    "native-controls.log": work / "native-fold-class-controls-v3.stdout.log",
    "native-controls-stderr.log": work / "native-fold-class-controls-v3.stderr.log",
    "default-regressions.log": work / "native-active-development-tests-fold-default-regression-v1/stderr.log",
    "default-regressions-status.json": work / "native-active-development-tests-fold-default-regression-v1/status.json",
}
for name, path in inputs.items(): (out / name).write_bytes(path.read_bytes())
build = json.loads((out / "native-controls-build.json").read_bytes())
with zipfile.ZipFile(out / "source-closure.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, digest in build["source_sha256"].items():
        raw = (repo / name).read_bytes()
        if sha(raw) != digest: raise ValueError("compiled source drift: " + name)
        archive.writestr(name, raw)
    archive.writestr("native-exact-build-manifest.json", (out / "native-controls-build.json").read_bytes())
(out / "README.md").write_text("""# Native fold-class development evidence

Development candidate; public integration, frozen timing and quality acceptance remain pending.
The research helper records 282 exact vector matches across 48 seeded fixtures and
one zero-support rejection. Its direct pair/board oracle is verification-only.
Native controls preserve 192 fold callback pairs and coupled G1/G6 policy bits,
including partial board blockers and conversion/resource guards. The expanded
G1 fixture has Q=213; G6 has Q=48. The default path passes 82 optimized controls.
The source archive contains the eleven authenticated compiled-helper inputs,
pinned dependency/license and build manifest. Archived source is evidence only.
No new admission credit, speed, full-deck or quality claim follows. Workers were
usage-limited; root performed this development work.

See the [candidate contract](../../../docs/native-fold-classes.md).
""", encoding="utf-8")
manifest = {"contract": "native-fold-class-development-v1",
    "scope": "Development controls only; public API, timing and quality acceptance pending.",
    "files": {p.name: sha(p.read_bytes()) for p in sorted(out.iterdir())}}
(out / "manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"files": len(manifest["files"]), "sha256": sha((out / "manifest.json").read_bytes())}), flush=True)
