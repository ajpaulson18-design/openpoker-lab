from pathlib import Path
import sys,subprocess,json,hashlib,time,traceback
repo=Path.cwd();sys.path.insert(0,str(repo));out=repo.parent/'virtual-frozen-committed-controls-v1';out.mkdir(exist_ok=False)
from tests.virtual_frozen_source_guard import capture_source,verify_source
modules=['tests.test_virtual_frozen_controller','tests.test_virtual_frozen_execution_closure','tests.test_virtual_frozen_source_guard','tests.test_virtual_frozen_run_control','tests.test_virtual_frozen_shared_preparation','tests.test_virtual_frozen_value_reference','tests.test_virtual_frozen_sample_reference','tests.test_virtual_frozen_update_reference','tests.test_virtual_frozen_study_admission','tests.test_virtual_frozen_update_comparison','tests.test_virtual_frozen_expectation','tests.test_virtual_frozen_reference_artifact','tests.test_virtual_frozen_whole_study']
status={'scope':'complete committed cohort controls, not the 5040-update producer','runs':[],'failure':None};started=time.perf_counter()
try:
    source=capture_source(repo)
    (out/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
    for label,flags in [('normal',[]),('optimized',['-O'])]:
        result=subprocess.run([sys.executable,'-B',*flags,'-m','unittest',*modules,'-v'],capture_output=True,check=False,cwd=repo)
        (out/(label+'.stdout.log')).write_bytes(result.stdout);(out/(label+'.stderr.log')).write_bytes(result.stderr)
        status['runs'].append({'mode':label,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
        if result.returncode:raise RuntimeError('committed cohort control failure in '+label)
    after=verify_source(repo,source);(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    status.update(head=source['head'],files=len(source['files']),raw_source_stable=True)
except BaseException:status['failure']=traceback.format_exc()
status['duration_seconds']=time.perf_counter()-started
(out/'completion.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status));sys.exit(0 if status['failure'] is None else 1)
