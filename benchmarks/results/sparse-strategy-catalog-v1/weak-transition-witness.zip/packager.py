"""Package terminal catalog/regression observations; never execute a candidate."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

WORK=Path(__file__).resolve().parent;ROOT=WORK/'dyprofile-repo'
DEST=ROOT/'benchmarks/results/sparse-strategy-catalog-v1';DEST.mkdir(exist_ok=False)
SELF=Path(__file__).read_bytes()


def files(directory,prefix,exclude=()):
    return {prefix+p.relative_to(directory).as_posix():p for p in sorted(directory.rglob('*'))
        if p.is_file() and p.relative_to(directory).as_posix() not in exclude and '__pycache__' not in p.parts}


def write(name,items):
    data={n:(p if isinstance(p,bytes) else p.read_bytes()) for n,p in items.items()}
    data['packager.py']=SELF
    if any(len(b)>8<<20 for b in data.values()):raise ValueError('member byte ceiling')
    index={n:{'bytes':len(b),'sha256':sha256(b).hexdigest()} for n,b in sorted(data.items())}
    data['members.json']=(json.dumps(index,indent=2)+'\n').encode()
    expanded=sum(map(len,data.values()))
    if expanded>80<<20:raise ValueError('expanded archive ceiling')
    path=DEST/(name+'.zip')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for n,b in sorted(data.items()):
            info=zipfile.ZipInfo(n,(2026,11,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            out.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    raw=path.read_bytes()
    if len(raw)>8<<20:raise ValueError('compressed archive ceiling')
    with zipfile.ZipFile(path) as check:
        if check.testzip() is not None or set(check.namelist())!=set(data):raise ValueError('archive integrity')
        for n,b in data.items():
            if check.read(n)!=b:raise ValueError('archive member drift')
    return {'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'members':len(data),'expanded_bytes':expanded}


catalog={}
for mode in ('normal','optimized'):
    catalog.update(files(WORK/('sparse-catalog3-'+mode),'formal/'+mode+'/'))
    catalog['logs/catalog-'+mode+'.log']=WORK/('sparse-catalog3-'+mode+'.log')
    catalog['logs/catalog-'+mode+'-saved-replay.json']=WORK/('sparse-catalog3-'+mode+'-replay.log')
catalog.update(files(WORK/'sparse-catalog1-build','build/catalog/'))
catalog['logs/catalog-build.log']=WORK/'sparse-catalog1-build.log'
catalog['maintained-source/replay_strategy_catalog.py']=ROOT/'scripts/replay_strategy_catalog.py'
catalog_pin=write('catalog',catalog)

# Preserve the complete numerical/training receipt and compact owner files.
# The two identical large checkpoint images reference their old canonical
# archive instead of silently duplicating them or raising the member ceiling.
excluded=('observed/page-images/committed.bin','observed/page-images/staged.bin')
regression=files(WORK/'sparse-identity-training1-complete-default','default/',excluded)
regression.update(files(WORK/'sparse-identity-training1-build','build/default/'))
regression.update(files(WORK/'sparse-identity-state1-build','build/state/'))
for mode in ('normal','optimized'):
    regression.update(files(WORK/('sparse-identity-state1-'+mode),'state/'+mode+'/'))
    regression['logs/state-'+mode+'.log']=WORK/('sparse-identity-state1-'+mode+'.log')
    regression['logs/reference-'+mode+'.log']=WORK/('sparse-epoch-reference3-'+mode+'.log')
regression['logs/default.log']=WORK/'sparse-identity-training1-complete-default.log'
regression['logs/state-build.log']=WORK/'sparse-identity-state1-build.log'
regression['logs/default-build.log']=WORK/'sparse-identity-training1-build.log'
regression['logs/build-metadata-controls.log']=WORK/'sparse-identity-build-metadata1.log'
regression['canonical-checkpoints.json']=(json.dumps({
    'archive':'benchmarks/results/native-dyadic-buffered-ten-card-accepted-v1/evidence.zip',
    'bytes':10270677,'sha256':'e82d5f8b40340893213ad9f73ac8ee71483119598551ce4db90ee8ff95a4674b',
    'members':{'cohort/page-images/committed.bin':'b9b1f88d1ed333908e3b49aec481ebe394e02a5f01281370eba4eafe6295f14a',
               'cohort/page-images/staged.bin':'fba2b68d8bfb1a4d624d626794e1917c2527a79fc2ee413029205796eb85923e'},
    'member_bytes':23701776,'scope':'existing identical complete numerical checkpoint references'},indent=2)+'\n').encode()
regression_pin=write('legacy-regression',regression)

# The generic policy-provider extraction has a distinct captured source and
# nineteen complete outputs equal to the existing immutable session matrix.
provider=files(WORK/'sparse-provider-parity1-normal','provider/')
provider.update(files(WORK/'sparse-provider-parity1-build','build/provider/'))
provider['logs/provider.log']=WORK/'sparse-provider-parity1-normal.log'
provider['logs/provider-build.log']=WORK/'sparse-provider-parity1-build.log'
canonical=ROOT/'benchmarks/results/native-frozen-policy-session-v1/normal.zip'
if sha256(canonical.read_bytes()).hexdigest()!='31488c428c628b90d0055050774551a1cb92b98fbd7a004319229b803ab65d14':
    raise ValueError('canonical provider parity archive drift')
observed=WORK/'sparse-provider-parity1-normal'
with zipfile.ZipFile(canonical) as archive:
    parity={}
    for path in sorted(observed.glob('*/stdout.bin')):
        relative=path.relative_to(observed).as_posix();body=path.read_bytes()
        if archive.read('matrix/'+relative)!=body:raise ValueError('generic provider numerical parity')
        parity[relative]=sha256(body).hexdigest()
provider['canonical-parity.json']=(json.dumps({'archive_sha256':sha256(canonical.read_bytes()).hexdigest(),
    'all_nineteen_complete_outputs_identical':len(parity)==19,'streams':parity,
    'scope':'generic raw-provider extraction parity only; not sparse learning or timing acceptance'},indent=2)+'\n').encode()
provider_pin=write('provider-parity',provider)

development={
    'logs/weak-pair-normal.log':WORK/'sparse-epoch-reference2-normal.log',
    'logs/weak-pair-optimized.log':WORK/'sparse-epoch-reference2-optimized.log',
    'source/reconstructed-committed-test.py':subprocess.check_output(['git','show','c2ad165:tests/test_sparse_epoch_reference.py'],cwd=ROOT),
    'scope.txt':b'Failed stronger transition witness: same five cards, swapped turn/river; second raw state changes without quantized policy change. Source is reconstructed from committed c2ad165; raw checkout line endings were not separately attested for this development run. Original logs are retained; accepted witness selects distinct private pairs.\n',
}
development_pin=write('weak-transition-witness',development)

manifest={'version':'sparse-strategy-catalog-v1',
    'native_source_head':'847afaff09aa40c2c0b1f52e374cc424f50d31d9',
    'introduced_source_head':json.loads((WORK/'sparse-catalog3-normal/source-identity.json').read_text())['head'],
    'maintained_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'archives':{'catalog':catalog_pin,'legacy-regression':regression_pin,'provider-parity':provider_pin,
                'weak-transition-witness':development_pin},
    'local_controls_per_mode':{'catalog':4,'legacy_state':11,'uniform_epoch_reference':5},
    'full_legacy_wire_bytes':50507464,
    'full_legacy_wire_sha256':'7fde396c4c2e645087d9fd8abdc373a97a485265bf157e537e3cfd181c538945',
    'scope':'catalog identity and legacy/provider parity only; no native epoch update, learning quality, realistic-range physical support, RSS or wider admission',
    'archived_source_executed':False,'system_inputs':'SDK/runtime/standard headers are not exhaustively byte-attested'}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
