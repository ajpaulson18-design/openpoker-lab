"""One complete existing ten-card regression; not sampled/raw-update training."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys

WORK=Path(__file__).resolve().parent;ROOT=WORK/'dyprofile-repo'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
# Closure-specific cleanliness is checked after names are known.
sys.path.insert(0,str(ROOT)) # trusted current checkout only; never archived code
from scripts.check_native_training_studies import verify_observation,SIDECARS
from tests.test_native_exact_reach import authenticate
from tests.virtual_frozen_run_control import run_bounded_dyadic_probe

exe=WORK/'sparse-identity-training1-build/native-virtual-dyadic-training-probe.exe'
identity=authenticate(exe,ROOT,'virtual-dyadic-training')
names=set(identity[1]['source_sha256'])|{'scripts/check_native_training_studies.py','tests/test_native_exact_reach.py',
    'tests/virtual_frozen_run_control.py','tests/virtual_dyadic_sweep_capture.py'}
if subprocess.check_output(['git','status','--porcelain','--',*sorted(names)],cwd=ROOT):raise ValueError('executed source closure must be clean')
source={name:(ROOT/name).read_bytes() for name in sorted(names)}
protocol_path=ROOT/'benchmarks/results/native-dyadic-staged-pages-v1/protocol.json'
protocol=protocol_path.read_bytes();expected=json.loads(protocol)['stable_sidecars']
if set(expected)!=SIDECARS:raise ValueError('sidecar inventory drift')
out=WORK/'sparse-identity-training1-complete-default';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'native-build-manifest.json').write_bytes(identity[0])
(out/'protocol.json').write_bytes(protocol)
for name,raw in source.items():
    p=out/'source'/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(raw)
(out/'source-identity.json').write_text(json.dumps({'head':head,'raw_sha256':{n:sha256(raw).hexdigest() for n,raw in source.items()},
    'controller_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'python_version':sys.version,
    'python_executable_sha256':sha256(Path(sys.executable).read_bytes()).hexdigest()},indent=2)+'\n')
case=out/'observed'
command=[str(exe),str(case/'page-images')]
(out/'command.json').write_text(json.dumps(command)+'\n')
record=run_bounded_dyadic_probe(command,'TRAIN_TEN_BOUNDED_DIVISION',case)
result=verify_observation(record,'virtual-dyadic-training')
for name,digest in expected.items():
    if sha256((case/name).read_bytes()).hexdigest()!=digest:raise ValueError('preserved sidecar drift '+name)
if authenticate(exe,ROOT,'virtual-dyadic-training')!=identity:raise ValueError('native/source identity changed')
if any((ROOT/name).read_bytes()!=raw for name,raw in source.items()):raise ValueError('executed source drift')
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()!=head:raise ValueError('source HEAD changed')
result.update({'historical_owner_sidecars_equal':True,'source_head':head,
    'scope':'one complete preserved ten-card regression after shared information-key extraction; no timing, sampler, raw-update or wider-capacity claim'})
(out/'verified.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
