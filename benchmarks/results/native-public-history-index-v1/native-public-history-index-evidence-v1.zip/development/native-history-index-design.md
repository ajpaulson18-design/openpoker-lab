# Bounded native public-history index: design for review

Status: proposed staged integration, not implemented or admitted capacity. This review reads the corrected native source and immutable study evidence; it does not alter a guard, execute a solve, or rerun either source-frozen study. Existing protocols/defaults and their preserved rejections remain authoritative.

## Why the original T1000 request is rejected

The first failure is `Exact selected whole-request kernel work admission exceeded before information/training allocation`, before ranking, training, or native launch. The original finite game has 99 unique DAG vertices, 173 edges, 1,462 unfolded public occurrences, 628 decisions, depth 14, 13 visible board prefixes, 1,200 supported physical rows and 2,402 supported action slots. Dense upper bounds include 1,256 rows and 2,514 slots. Its stabilizer is identity: Q=R, so further suit compression cannot help this fixture.

The kernel forecast is affine in T. Using the retained T10/T100 receipts and the unchanged source formulas gives the following T1000 decomposition, without training:

| Inherited Python kernel term | T1000 logical work |
| --- | ---: |
| Constructor/rank-free support plus future legal support | 2,826,058 |
| Marginals | 335,446,384 |
| Terminals | 2,276,489,040 |
| Total | 2,614,761,482 |

This is 5.23 times the 500-million cap. The forecast counts 635,542 marginal calls and 1,414,230 terminal calls. The native trainer already prepares its decision-prefix marginal map once, so iteration-times-decision marginal reservation does not describe its execution. However, deleting the entire marginal term would still leave 2,279,315,098 units: that alone cannot admit T1000.

There are also later native barriers. Algebraically substituting T=1000 into the existing native formulas on the same saved graph gives:

| Existing native term | Counterfactual T1000 upper |
| --- | ---: |
| Kernel callbacks/setup | 1,827,678,248 |
| Graph/Q-plan account | 7,380,293,108 |
| Trainer account | 3,362,625,856 |
| Of trainer account: full-history key/routing reservation | 2,981,361,856 |
| Whole native account including fixed terms | 12,570,661,340 |

These are calculations of the current formulas, not an executed or admitted T1000 request, measured operations, CPU time, or proof that all reservations are tight. The retained DONE field `kernel_work_upper` is an upper bound, not an actual kernel work counter. Native T10 is 148,600,700 units; the complete Python-plus-native reservation is 286,452,437. Python-mode T10 records 30,318,022 actual kernel modeled units versus its 39,636,842 kernel envelope; native-mode Python diagnostics alone record 6,265,382. Those scopes are different and must not be added or extrapolated as actual native work.

Replacing obsolete forecasts is necessary model maintenance, but the meaningful structural next step is to remove repeated full-history construction, root routing, suit-history transformation and string comparison from training. Even successful removal will not by itself prove T1000 admission: the remaining exact callback term still exceeds 500 million. A later callback-plan improvement or separately justified tighter model remains necessary.

## Representation: a full public path, not a shared vertex

Assign every *unfolded public node occurrence* an exact lexicographic path ordinal. Let `C(v) = 1 + sum(C(child))` in reverse DAG topological order, counting every edge, including repeated edges to the same child. Reject cycles, invalid labels, depth/visit excess and count overflow before constructing dependent tables. Require `C(root)` equal the independently checked unfolded logical census and remain within the existing visit cap.

Each outgoing edge appends exactly one complete history token. Independently sort a vertex's edges by exact token byte order and define `offset(e) = 1 + sum(C(previous lexical sibling child))`. The root occurrence starts at ordinal zero. A child occurrence has `parent_ordinal + offset(e)`.

This is preorder over the lexical unfolding: a path is before all of its extensions; sibling subtrees are in exact token order. Therefore ordinal ordering is exactly the ordering of complete token-history tuples. It does not reorder action arithmetic, chance arithmetic, physical traversal, output iteration or the published numerical contract. The offsets are metadata beside the existing ordered menu/branches.

DAG reconvergence is safe. Two histories reaching one vertex carry different parent ordinals and thus different occurrence ordinals. A shared vertex ID must never replace an occurrence ordinal. No table of all occurrence histories, R rows, or R-to-Q locations is constructed.

Duplicate labels within a decision or chance menu must reject. The input graph must also prohibit decision tokens impersonating reveal tokens, as the current graph validator does. With deterministic labeled transitions from one root and unique outgoing labels, identical full token sequences cannot name different paths. If a future protocol permits multi-token edges, this one-token construction is no longer sufficient; reject it or introduce an explicitly proved intermediate token trie. A flop label such as `flop@2c3d4h` is one token containing three cards, not three edge transitions.

An initial history is a fixed common prefix for all represented paths. Validate it once and require each requested suit permutation to fix it exactly. Relative ordinal ordering still equals complete-history ordering because the prefix is common. Preserve the existing initial-history and depth ceilings; do not accept foreign initial histories through a numeric handle.

## Incremental suit routing

At a physical traversal frame, carry its actual vertex/canonical continuation ID, actual path ordinal, visible-prefix ID, and at most G transformed continuation/ordinal states. Advancing an action follows the same ordered action token. Advancing chance transforms the revealed card or canonical flop token, then follows that exact labeled edge from the transformed parent. Update each transformed ordinal with that transformed edge's lexical offset.

A source-vertex-to-target-vertex table alone is insufficient when duplicate bottom-up signatures exist. Use the existing exact identity interner's canonical continuation IDs, with an explicit induction proof: equal terminal/menu/chance signatures have equal subtree counts and equal token-to-child-signature mappings, hence equal lexical offsets. Map transformed signatures by exact lookup, never hash-only equality or insertion. Runtime transformed transitions follow the transformed parent and label. Alternatively, the first opt-in implementation may reject duplicate structural signatures until this case is supported; it must not arbitrarily pick a raw object and assume bijection.

For row comparison, retain the current ordering `(actor, original own-hand index, complete history)`. The exact replacement ordering is `(actor, original own-hand index, path ordinal)`. For each physical row, form the mapped own-hand index and transformed ordinal for every admitted group element, sort these complete keys and deduplicate them. The first distinct key is the representative; the current key's position is its member ordinal; the number of distinct keys is the orbit size. Permutation index is not member index. This handles stabilizers and preserves member masks and existing Q key ordering.

The graph signature proof, weighted role-specific priors, ordered selected outcomes and legal-support closure remain prerequisites. The index does not prove them anew by assumption. Row menus, actor and target continuation must remain checked. External APIs accepting arbitrary histories keep the old validating route; only cursor states created from an admitted immutable index may use the internal fast path. Bind the index to the exact graph, group, iteration/admission owner and generation; do not permit caller-forged ordinal cursors.

## Hidden-future noninterference

An ordinal depends only on the fixed public graph and edges already traversed. It never reads an opponent holding, actual sampled deal, unrevealed board selection, rank, strategy reach, payoff or probability. Subtree counts include potential future public branches, but these are fixed public-game constants. Every pair of compatible worlds sharing the same visible history and own hand therefore receives the same row key and ordinal. A later revealed card changes the cursor only when its public edge is actually traversed.

Use a separate typed visible-prefix ID for callback support/board-index cache access. Advance it only on reveal edges. Do not select a complete future board while at a partial prefix. Complete-board compatibility still determines positive support under the declared conditioned game, exactly as before; zero current reach never deletes supported rows.

## Resource accounting, including Terra's objections

Index retained space is O(G(V+E)) plus existing O(Q) records; this is not a claim of linear CPU preprocessing or lower process memory. Reserve all count/offset arrays, adjacency dispatch, exact signature scratch, group transitions, prefix maps, traversal stacks, vectors and map headers before growth, using caller-supplied remaining work/entry budgets under the existing ceilings.

One conservative starting *scalar-field* reserve is:

`8(V+E) + 2G(V+E) + 2GP + 8G(depth+1) + 128`.

For the original V=99, E=173, G=1, P=13 and depth=14, this is 2,994 scalar fields. This excludes any newly retained Q ordinal lookup keys (charge at least their three integer fields plus map metadata per Q), existing Q records/menus/masks/hand maps, token storage, exact proof scratch, and allocator headers. It is a proposed layout budget to verify against actual arrays, not an accepted byte estimate. If old Q history strings are retained alongside ordinal keys during migration, charge and report both. Original Q=R=1,200 and its four training arrays still contain 9,608 doubles; an index does not reduce that payload.

Preprocessing work must explicitly charge bounded token bytes and sorting/comparison work. Construct lexical token dispatch arrays with a documented comparison envelope. For transformed edges, use prebuilt canonical dispatch/binary lookup, or charge `G * sum(degree^2)` if using linear search. Do not write an O(GE) work receipt while performing uncharged sibling scans. Include group validation, exact interner comparisons/keys, Q setup conversions and all repeated allocation overlap. Checked arithmetic must guard C sums and lexical prefix sums before calculation overflows. A tiny remaining budget must reject before the corresponding dictionary, token copy, sort or scan.

Training work is then modeled explicitly in terms of visited edges, public decisions, hands, G and fixed-word Q lookup: approximately three passes per iteration of incremental G-state transitions and per-decision supported-hand image keys, plus the unchanged finite arithmetic and exact callbacks. Do not remove history cost from a receipt until those history operations are actually absent. Old per-row full-history lookup remains a reference path and a separately named cost model.

## Staged implementation that Luna can start

**Stage A: graph-only index and conformance, no trainer or admission switch.** Add one new immutable native history-index module and direct C++ controls. Build checked subtree counts, lexical offsets and exact transformed transitions; expose root/advance cursors and a validated reference history-to-ordinal conversion/inverse for testing. The index must visit no private worlds, issue no ranks, and retain no expanded history/R table. Compare every occurrence on bounded fixtures with the old literal full-history route. Keep the existing native protocol and engine defaults unchanged.

**Stage B: explicit shadow Q lookup integration.** Derive ordinal keys for existing Q representatives once during setup, preserving the old Q record/order/offset/menu/mask contract. Initially retain and charge old Q history keys as reference data. Stream physical decisions, compare old route and new incremental route/member masks, and then permit a separately selected ordinal lookup path. This is O(Q) reference metadata, not a hidden R member cache. Do not claim a storage improvement while both representations coexist.

**Stage C: trainer integration and new admission model.** After bitwise full-policy/diagnostic/certificate equivalence, remove actual repeated history parsing from the selected learning path and publish its independently auditable work model. Separate Python work that still executes from Python training reservations that no longer execute in native mode. Keep the old model/default/rejection unchanged; use a versioned opt-in plan/admission contract, and a distinct wire version if request semantics change. Do not simply skip the inherited guard or increase 500 million to admit T1000. Publish rank-free admission results before any newly admitted frozen training run.

## Required proof gates

- Exact ordinal uniqueness and ordering against sorted literal histories on identity, G2, larger groups, nonempty fixed initial histories, multi-card flop tokens, and reconvergent/duplicate-signature DAGs.
- Suit composition: advancing then transforming agrees with transforming then advancing; inverse maps recover cursors; all transformed root and child signatures match exactly. Deduplicated member ordinals/masks agree with the old full RowKey route, including mixed stabilizers, holes and zero reach.
- Hidden-future controls: different compatible opponent holdings/future runouts with the same visible history and own hand have identical cursor/row identity. No complete board or opponent hand enters cursor state.
- Bounds: malformed/duplicate tokens, cycles, overflow, low remaining budgets, ownership/generation mismatch, forged ordinal states and missing transformed edges reject before disallowed allocation or training mutation.
- Whole-game integration: all full physical policy probabilities and menus remain bitwise identical to the frozen full-history reference under the unchanged sorted arithmetic; all eight diagnostics and saved independent exact certificates/flags agree, preserving misses.
- Evidence: independently counted visits/lookup operations and actual retained arrays; a source-frozen complete-call study with original and asymmetric/stabilizer controls, full raw artifacts and saved-only replay. No universal speed/memory claim and no assumption that original T1000 now fits.

The bounded implementation scope to start now is Stage A only. It removes no guard, introduces no alternate numerical trajectory, and produces a precise proof-ready replacement for the current repeated full-history operation. Stage B/C should begin only after the index's ordering, suit action and resource model pass independent challenge.
