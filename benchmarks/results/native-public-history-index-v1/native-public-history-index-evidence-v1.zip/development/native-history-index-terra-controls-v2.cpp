#include "exact_public_history_index.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace openpoker::exact_public_graph;
namespace hi=openpoker::exact_public_history_index;
void check(bool x,const char* why){if(!x)throw std::runtime_error(why);}
int main(){try {
 constexpr std::uint64_t unit_bits=0x3ff0000000000000ULL;
 std::vector<Action> actions;
 for(int i=39;i>=0;--i){std::string t="act"+std::to_string(i);actions.push_back({t,0,0,false,t});}
 actions.push_back({"accent",0,0,false,"\xc3\xa9"});
 Graph g;g.vertices.push_back(Vertex::decision(0,actions,std::vector<std::size_t>(actions.size(),1)));g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{unit_bits,unit_bits}));
 Plan p(std::move(g),{{{48,49},unit_bits}},{{{44,45},unit_bits}},{{{0,4,8,12,16}}},10);
 hi::HistoryIndex index(p);auto c=index.root_cursor();std::vector<std::string> tokens;for(auto& a:actions)tokens.push_back(a.token);std::sort(tokens.begin(),tokens.end());
 for(std::size_t i=0;i<actions.size();++i){auto child=index.advance_edge(c,i);auto it=std::lower_bound(tokens.begin(),tokens.end(),actions[i].token);check(child.ordinal()==1+static_cast<std::size_t>(it-tokens.begin()),"wrong lexical ordinal");check(index.history_at_ordinal(child.ordinal())==History{actions[i].token},"wrong inverse history");}
 hi::Limits tight; tight.max_combined_modeled_work=index.receipt().combined_modeled_work_upper+1;
 hi::HistoryIndex limited(p,tight); auto limited_cursor=limited.root_cursor();
 try {(void)limited.advance_edge(limited_cursor,0);throw std::runtime_error("insufficient remaining query work accepted");}catch(const PlanError& e){check(e.code()==ErrorCode::work_limit,"wrong query work error");}
 auto other=hi::HistoryIndex(p);try {(void)other.advance_edge(c,0);throw std::runtime_error("foreign cursor accepted");}catch(const PlanError& e){check(e.code()==ErrorCode::invalid_query,"wrong cross owner error");}
 std::cout<<"PASS 41 shared-child lex ordinals, reversed menus, UTF-8, inverse paths, tight query budget and foreign cursor\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
