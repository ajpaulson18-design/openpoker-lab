import json, math, pathlib, sys
from unittest.mock import patch
ROOT = pathlib.Path(r'C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\native-exact-engine-ci-repo')
sys.path.insert(0, str(ROOT))
from pokerlab import exact_selected_solver as solver
from pokerlab import exact_selected_kernel as kernel_module
from pokerlab.solver_contracts import FourStreetSolveRequest, PostflopActions
from pokerlab.preflop_tree import PreflopConfig
from pokerlab.exact_selected_kernel import ExactSelectedRunoutKernel
from scripts.benchmark_dyadic_selected_solver import case_for, request_for
REPORT = json.loads((ROOT/'benchmarks/results/exact-dyadic-selected-v1/report.json').read_text(encoding='utf-8'))
RECEIPT = json.loads((ROOT/'benchmarks/results/exact-dyadic-selected-v1/receipt.json').read_text(encoding='utf-8'))
T10 = next(x for x in REPORT['samples'] if x['case']=='original' and x['iterations']==10 and x['mode']=='dyadic' and x['sample']==0)
T10_INTEGER = RECEIPT['integer_receipts']['original-T10-dyadic-0']

original = solver._preflight_work
original_rank = kernel_module.rank_hand
original_pair = ExactSelectedRunoutKernel.pair_probability_exact
class AdmissionCaptured(Exception): pass

def one(iterations, mode):
    captured = {}
    calls = {'training':0, 'rank':0, 'pair':0}
    def spy_preflight(kernel, adapter, request, prefix_counts, decision_counts, action_hand_queries, terminal_counts, pair_candidates, layout_upper, unique_prefixes, topology_states, topology_entries, compact_prior_entries=0):
        costs = solver._query_costs(kernel, prefix_counts)
        effective = request.iterations if sum(decision_counts.values()) else 0
        future = sum(costs['lookup'] + n*costs['legal_per_board'] for n in unique_prefixes.values())
        boards0 = prefix_counts[()]
        pair_work = pair_candidates*(costs['pair_fixed'] + boards0*costs['pair_per_board'])
        marginal_calls = sum(effective*c + 3*action_hand_queries[p] for p,c in decision_counts.items())
        marginal_work = sum((effective*c + 3*action_hand_queries[p])*(costs['lookup']+prefix_counts.get(p,0)*costs['marginal_per_board']) for p,c in decision_counts.items())
        terminal_calls = sum((2*effective+6)*c for c in terminal_counts.values())
        terminal_work = sum((2*effective+6)*c*(costs['terminal_fixed']+prefix_counts.get(p,0)*costs['terminal_per_board']+costs['terminal_reach']) for p,c in terminal_counts.items())
        kernel_total = kernel.statistics()['work_units_cumulative']+future+pair_work+marginal_work+terminal_work
        captured.update({'kernel':{'actual_constructor_rankfree_work':kernel.statistics()['work_units_cumulative'],'future_legal_support_upper_work':future,'pair_output_board_scan_upper_work':pair_work,'training_and_diagnostic_marginal_upper_work':marginal_work,'training_and_diagnostic_terminal_upper_work':terminal_work,'whole_request_upper_work':kernel_total,'limit':kernel.limits.max_modeled_work,'terminal_calls_upper':terminal_calls,'marginal_calls_upper':marginal_calls,'pair_candidates':pair_candidates,'all_hand_pairs':kernel.hand_counts[0]*kernel.hand_counts[1]},'counts':{'hand_counts':list(kernel.hand_counts),'boards':len(kernel.selected),'prefix_count':len(prefix_counts),'unique_support_prefixes':len(unique_prefixes),'decision_occurrences':sum(decision_counts.values()),'terminal_occurrences':sum(terminal_counts.values()),'action_hand_queries':sum(action_hand_queries.values()),'topology_states':topology_states,'topology_entries':topology_entries,'layout_upper':layout_upper,'adapter':{'vertices':len(adapter._vertices),'terminal_vertices':len(adapter._records),'retained':adapter._retained,'work_limit':adapter._max_work,'storage_limit':adapter._max_storage},'kernel_storage':{'peak':kernel.statistics()['storage_entries_peak'],'input_entries':kernel._input_entries,'cache_reserved':kernel._cache_reserved_entries}},'costs':costs})
        result = original(kernel, adapter, request, prefix_counts, decision_counts, action_hand_queries, terminal_counts, pair_candidates, layout_upper, unique_prefixes, topology_states, topology_entries, compact_prior_entries)
        captured['admission_receipt'] = result
        raise AdmissionCaptured('stopped after preflight receipt, before info rows/training')
    def forbidden(*a,**k):
        calls['training']+=1
        raise AssertionError('training entered')
    def rank(*a,**k):
        calls['rank']+=1
        return original_rank(*a,**k)
    def pair(*a,**k):
        calls['pair']+=1
        return original_pair(*a,**k)
    req=request_for(case_for('original'),iterations)
    with patch.object(solver,'_preflight_work',new=spy_preflight), patch.object(solver,'train_packed',new=forbidden), patch.object(kernel_module,'rank_hand',new=rank), patch.object(ExactSelectedRunoutKernel,'pair_probability_exact',new=pair):
        try:
            out=solver.solve_four_street_exact_selected(req,rank_cache_boards=64,pair_diagnostics='compact',exact_arithmetic=mode)
            captured['status']='unexpectedly-admitted'; captured['result_summary']={'iterations':out['iterations']}
        except Exception as e:
            captured['status']='rejected-or-failed';captured['error']={'type':type(e).__name__,'message':str(e)}
    captured['calls']=calls
    return captured

out={'version':'exact-selected-original22-admission-diagnostic-v1','source_head':__import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scenarios':{},'saved_T10_report':{'sample':'original T10 dyadic sample 0','raw_sha256':T10['raw_sha256'],'rank_calls':T10['rank_calls'],'training_calls':T10['training_calls'],'pair_query_calls':T10['pair_query_calls'],'kernel_work_actual':30318022,'kernel_work_admitted':39636842,'retained_peak_entries_admitted':365774,'integer_receipt':T10_INTEGER}}
out['scenarios']['original-T10-dyadic-admission-only']=one(10,'dyadic')
for mode in ('fraction','dyadic'):
    out['scenarios'][f'original-T1000-{mode}']=one(1000,mode)
for name, scenario in out['scenarios'].items():
    if 'counts' not in scenario: continue
    c=scenario['counts']; k=scenario['kernel']; lay=c['layout_upper']; ad=c['adapter']; hs=sum(c['hand_counts']); rows=lay['upper_dense_decision_hand_slots']; slots=lay['upper_action_slots']; hist=lay['upper_history_token_entries']; depth=lay['maximum_depth']+1; acts=lay['maximum_actions']; pairs=k['pair_candidates']
    adapter_base=8*ad['vertices']+8; adapter_ret=8*ad['terminal_vertices']+2*hs+16; adapter_calls=k['marginal_calls_upper']+k['terminal_calls_upper']; adapter_work=adapter_base+(8+4*hs)*adapter_calls; adapter_temp=2*hs
    compact_prior=6*hs+32; output_entries=compact_prior+8*pairs+20*rows+2*hist+12*slots+8192
    compact_snapshot=4*compact_prior; whole=k['whole_request_upper_work']+adapter_work+compact_snapshot+lay['upper_requested_layout_loop_entries']+lay['upper_history_lookup_work_entries']+4*c['topology_states']
    kernel_peak=max(k['actual_constructor_rankfree_work']*0+c['kernel_storage']['peak'],c['kernel_storage']['input_entries']+c['kernel_storage']['cache_reserved']+140*hs+800)
    adapter_peak=ad['retained']+2*hs; prefix_entries=64*c['prefix_count']+8192; legal=len(range(c['unique_support_prefixes']))*(2*hs+8); pair_entries=8*pairs
    shared=kernel_peak+adapter_peak+c['topology_entries']+prefix_entries+pair_entries+compact_prior
    info=12*rows+hist; packed=4*slots+12*rows; averages=3*rows+slots; normalized=3*rows+slots; scratch=depth*(4*acts+24)*hs+4*depth*depth*(acts+1)+256; serialized=20*rows+2*hist+12*slots+8192
    phases={'rank_free_prefix_support_peak':shared+legal,'information_and_menu_peak':shared+legal+info,'training_peak':shared+info+packed+averages+scratch,'diagnostic_peak':shared+info+averages+normalized+scratch,'serialization_peak':shared+info+averages+serialized}
    scenario['independent_remaining_admission_forecast']={'adapter':{'constructor_work_upper':adapter_base,'calls_upper':adapter_calls,'work_upper':adapter_work,'work_limit':ad['work_limit'],'retained_entries_upper':adapter_ret,'temporary_entries_upper':adapter_temp,'entry_limit':ad['storage_limit']},'whole_request_work_upper':whole,'whole_request_limit':500000000,'compact_output_entries_upper':output_entries,'output_entry_limit':20000000,'retained_phase_upper_bounds':phases,'retained_peak_entries_upper':max(phases.values()),'retained_entry_limit':25000000}
print(json.dumps(out,sort_keys=True,indent=2))

