"""Package distinct graph-index conformance and baseline profiling evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
INDEX = WORK / 'native-history-index-repo'
BASELINE = WORK / 'native-exact-engine-ci-repo'
FROZEN = 'f80f63ff6769f171b93de32fa22036dfa83650c9'
BASE_FROZEN = 'a05fe2ade71214c13b6d5100e76b7f2102939ea7'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def check_manifest(folder):
    manifest = read_json(folder / 'manifest.json')
    observed = {p.relative_to(folder).as_posix(): sha(p.read_bytes()) for p in folder.rglob('*')
        if p.is_file() and p.suffix not in ('.exe', '.obj') and p.name != 'manifest.json'}
    need(observed == manifest['sha256'], 'Manifest inventory/bytes drift: ' + str(folder))

def authenticate(repo, snapshot, commit):
    helper = WORK / 'exact-selected-independent-review.py'
    need(sha(helper.read_bytes()) == '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5', 'Source auth helper drift')
    scope = {'__name__': 'packaging_source_auth', '__file__': str(helper)}
    exec(compile(helper.read_bytes(), str(helper), 'exec'), scope)
    scope['FROZEN'] = commit
    return scope['source_identity'](repo, snapshot)

def package(name, directories, extra, metadata):
    target = WORK / (name + '.zip')
    need(not target.exists(), 'Existing archive must be retained: ' + str(target))
    entries = {}
    def add(key, path):
        need(key not in entries and path.is_file() and not path.is_symlink() and path.stat().st_size <= 64 * 1024 * 1024,
            'Invalid/repeated archive entry: ' + key)
        entries[key] = path.read_bytes()
    for prefix, folder in directories:
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path.suffix not in ('.exe', '.obj', '.pyc'):
                add(prefix + '/' + path.relative_to(folder).as_posix(), path)
    for key, path in extra:
        add(key, path)
    add('packaging-helper.py', Path(__file__))
    manifest = {'contract': name, **metadata,
        'scope': 'Raw source, controls, policies, receipts and first failures are evidence only. Historical production source is never executed by saved-only reviewers. Executables/objects/bytecode are omitted; their recorded hashes and build identities are retained.',
        'sha256': {key: sha(raw) for key, raw in sorted(entries.items())}}
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, raw in sorted(entries.items()):
            archive.writestr(key, raw)
        archive.writestr('evidence-manifest.json', manifest_raw)
    with zipfile.ZipFile(target) as archive:
        need(set(archive.namelist()) == set(entries) | {'evidence-manifest.json'} and
            len(archive.namelist()) == len(entries) + 1 and archive.testzip() is None, 'Archive inventory/CRC failure')
        for key, raw in entries.items():
            need(archive.read(key) == raw, 'Archived raw bytes drift: ' + key)
    receipt = {'archive': target.name, 'archive_bytes': target.stat().st_size,
        'archive_sha256': sha(target.read_bytes()), 'archive_entries': len(entries) + 1,
        'evidence_manifest_sha256': sha(manifest_raw), **metadata}
    write(WORK / (name + '-receipt.json'), receipt)
    print(json.dumps(receipt))

def main():
    index_folder = WORK / 'native-history-index-frozen-v2'
    before = read_json(index_folder / 'source-before.json')
    need((index_folder / 'source-before.json').read_bytes() == (index_folder / 'source-after.json').read_bytes(), 'Index raw source changed')
    index_auth = authenticate(INDEX, before, FROZEN)
    check_manifest(index_folder)
    receipt = read_json(index_folder / 'receipt.json')
    need(receipt['status'] == 'passed' and receipt['source_and_build_unchanged'], 'Index conformance incomplete')
    introduced = subprocess.check_output(['git', 'diff', '--name-only', FROZEN + '^', FROZEN], cwd=INDEX).decode().splitlines()
    extra = [('introduced-source/' + name, INDEX / name) for name in introduced]
    for path in sorted(WORK.glob('native-history-index*')):
        if path.is_file() and path.suffix in ('.cpp', '.log', '.json', '.md'):
            extra.append(('development/' + path.name, path))
    # Root development logs and earlier helper/build identities remain separate
    # from the committed-source v2 conformance receipt.
    for version in ('v1', 'v2', 'v3'):
        folder = WORK / ('native-history-index-build-' + version)
        for name in ('build.log', 'compiler-version.log', 'native-exact-build-manifest.json'):
            extra.append(('development/build-' + version + '/' + name, folder / name))
    legacy = Path(r'C:\Users\pauls\Documents\Codex\work')
    for name in ('native-history-index-header-f664.hpp', 'native-history-index-controls-adcee.cpp',
                 'native-history-index-first-compile-error-note.txt',
                 'exact-selected-original22-admission-diagnostic.py', 'exact-selected-original22-admission-diagnostic.json'):
        extra.append(('development/' + name, legacy / name))
    package('native-public-history-index-evidence-v1',
        [('committed-conformance', index_folder), ('first-review-include-path-failure', WORK / 'native-history-index-frozen-v1')],
        extra, {'source_commit': FROZEN, 'authenticated_source_files': index_auth['files'],
            'conformance_receipt_sha256': sha((index_folder / 'receipt.json').read_bytes()),
            'integration_scope': 'Graph-only prerequisite; no trainer/API/wire or admission change. Logical fields/characters exclude allocator bytes/capacity/RSS.'})
    profile = WORK / 'native-scoped-phase-profile-v2'
    profile_source = read_json(profile / 'source-before.json')
    base_auth = authenticate(BASELINE, profile_source, BASE_FROZEN)
    check_manifest(profile)
    check_manifest(WORK / 'native-scoped-phase-profile-v1')
    review_manifest = read_json(WORK / 'native-scoped-phase-profile-review-manifest.json')
    for name, digest in review_manifest['sha256'].items():
        need(sha((WORK / name).read_bytes()) == digest, 'Profile review artifact drift: ' + name)
    review = read_json(WORK / 'native-scoped-phase-profile-review.json')
    need(review['outcome'] == 'complete' and review['authoritative_producer_completion']['exit_code'] == 0,
         'Profile review incomplete')
    extra = [('review/' + name, WORK / name) for name in review_manifest['sha256']]
    extra.append(('review/manifest.json', WORK / 'native-scoped-phase-profile-review-manifest.json'))
    for name in ('native-scoped-phase-profile-v1-run.log', 'native-scoped-phase-profile-v2-run.log'):
        extra.append(('development/' + name, WORK / name))
    build = read_json(profile / 'accepted-build-manifest.json')
    for name in build['source_sha256']:
        extra.append(('production-build-inputs/' + name, BASELINE / name))
    package('native-baseline-phase-profile-evidence-v1',
        [('profile-v2', profile), ('compile-only-first-failure-v1', WORK / 'native-scoped-phase-profile-v1')],
        extra, {'source_commit': BASE_FROZEN, 'accepted_production_commit': 'a54483e94e3967e1eaa2fc33fe0733e33fa14a58',
            'authenticated_source_files': base_auth['files'],
            'saved_only_review_sha256': sha((WORK / 'native-scoped-phase-profile-review.json').read_bytes()),
            'integration_scope': 'Three native-only paired observations at prior production source; not new-index timing or Python/API/RSS measurement. Inclusive times overlap; exclusive records partition the instrumented run interval.'})
    authenticate(INDEX, before, FROZEN)
    authenticate(BASELINE, profile_source, BASE_FROZEN)

if __name__ == '__main__':
    main()
