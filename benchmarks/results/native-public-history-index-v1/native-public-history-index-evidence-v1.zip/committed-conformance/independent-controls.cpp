#include "exact_public_history_index.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace openpoker::exact_public_graph;
namespace hi=openpoker::exact_public_history_index;
void check(bool x,const char* why){if(!x)throw std::runtime_error(why);}
int main(){try {
 constexpr std::uint64_t unit_bits=0x3ff0000000000000ULL;
 std::vector<Action> actions;
 for(int i=39;i>=0;--i){std::string t="act"+std::to_string(i);actions.push_back({t,0,0,false,t});}
 actions.push_back({"accent",0,0,false,"\xc3\xa9"});
 Graph g;g.vertices.push_back(Vertex::decision(0,actions,std::vector<std::size_t>(actions.size(),1)));g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{unit_bits,unit_bits}));
 Plan p(std::move(g),{{{48,49},unit_bits}},{{{44,45},unit_bits}},{{{0,4,8,12,16}}},10);
 hi::HistoryIndex index(p);auto c=index.root_cursor();std::vector<std::string> tokens;for(auto& a:actions)tokens.push_back(a.token);std::sort(tokens.begin(),tokens.end());
 for(std::size_t i=0;i<actions.size();++i){auto child=index.advance_edge(c,i);auto it=std::lower_bound(tokens.begin(),tokens.end(),actions[i].token);check(child.ordinal()==1+static_cast<std::size_t>(it-tokens.begin()),"wrong lexical ordinal");check(index.history_at_ordinal(child.ordinal())==History{actions[i].token},"wrong inverse history");}
 hi::Limits tight; tight.max_combined_modeled_work=index.receipt().combined_modeled_work_upper+8*index.suit_map_count();
 hi::HistoryIndex limited(p,tight); auto limited_cursor=limited.root_cursor();
 try {(void)limited.advance_edge(limited_cursor,0);throw std::runtime_error("insufficient remaining query work accepted");}catch(const PlanError& e){check(e.code()==ErrorCode::work_limit,"wrong query work error");}
 auto other=hi::HistoryIndex(p);try {(void)other.advance_edge(c,0);throw std::runtime_error("foreign cursor accepted");}catch(const PlanError& e){check(e.code()==ErrorCode::invalid_query,"wrong cross owner error");}
 auto verify_ledger=[](const hi::HistoryIndex& h,const Plan& plan){
  const auto& r=h.receipt();
  const auto total=r.index_fixed_bookkeeping_entries_actual+r.vertex_class_entries_actual+r.class_record_entries_actual+r.raw_vertex_record_entries_actual+r.class_edge_entries_actual+r.class_edge_string_headers_actual+r.class_lex_order_entries_actual+r.raw_edge_entries_actual+r.raw_edge_string_headers_actual+r.raw_lex_order_entries_actual+r.suit_class_entries_actual+r.transformed_transition_entries_actual+r.retained_token_bytes_actual;
  check(total==r.index_retained_entries_actual,"ledger arithmetic mismatch");
  check(total<=r.index_retained_entries_upper,"retained entries exceed preflight");
  check(r.vertex_class_entries_actual==plan.graph().vertices.size(),"missing vertex classes");
  check(r.raw_vertex_record_entries_actual==2*plan.graph().vertices.size(),"missing raw vertex records");
  check(r.class_record_entries_actual==4*r.continuation_classes,"class record count mismatch");
  check(r.class_edge_entries_actual==2*r.class_edge_entries && r.class_edge_string_headers_actual==r.class_edge_entries && r.class_lex_order_entries_actual==r.class_edge_entries,"class edge ledger mismatch");
  check(r.raw_edge_entries_actual==2*r.raw_edge_entries && r.raw_edge_string_headers_actual==r.raw_edge_entries && r.raw_lex_order_entries_actual==r.raw_edge_entries,"raw edge ledger mismatch");
  check(r.suit_class_entries_actual==r.suit_maps*r.continuation_classes && r.transformed_transition_entries_actual==6*r.transformed_transition_entries,"suit ledger mismatch");
  check(r.combined_peak_entries_upper==r.plan_retained_entries_upper+r.index_retained_entries_upper+r.index_scratch_entries_upper && r.combined_peak_entries_upper<=r.retained_entry_limit,"combined Plan/index cap mismatch");
 };
 verify_ledger(index,p);
 Graph tall;const Action next{"next",0,0,false,"next"};
 for(std::size_t i=0;i<48;++i)tall.vertices.push_back(Vertex::decision(i%2,{next},{i+1}));
 tall.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{unit_bits,unit_bits}));
 Plan tall_plan(std::move(tall),{{{48,49},unit_bits}},{{{44,45},unit_bits}},{{{0,4,8,12,16}}},10);
 hi::HistoryIndex tall_index(tall_plan);verify_ledger(tall_index,tall_plan);
 check(tall_index.receipt().graph_vertices==49 && tall_index.receipt().graph_edges==48,"tall fixture mismatch");
 hi::Limits short_storage;short_storage.max_combined_entries=tall_index.receipt().combined_peak_entries_upper-1;
 try {hi::HistoryIndex rejected(tall_plan,short_storage);throw std::runtime_error("underreserved combined ledger accepted");}catch(const PlanError& e){check(e.code()==ErrorCode::storage_limit,"wrong combined storage error");}
 std::cout<<"PASS wide/tall per-array retained ledger, combined limit, 41 byte-lex reconvergent ordinals, inverse paths, work and owner gates\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}

