"""Committed-source graph-only conformance; never invokes a poker trainer."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK / 'native-history-index-repo'
OUT = WORK / 'native-history-index-frozen-v2'
BUILD = WORK / 'native-history-index-build-v3'
FROZEN = 'f80f63ff6769f171b93de32fa22036dfa83650c9'
AUTH_SHA = '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
TERRA_SHA = '26e7783783a87828c8a0f40e9f9907243b4a6a9f9157a568cc45d29b07e99384'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def snapshot():
    names = git('ls-files', '-z').decode().split('\0')[:-1]
    return {'commit': git('rev-parse', 'HEAD').decode().strip(),
        'status': git('status', '--porcelain', '--untracked-files=all').decode().strip(),
        'sha256': {name: sha((REPO / name).read_bytes()) for name in names}}

def child(name, command, *, timeout=180, env=None):
    result = subprocess.run(command, cwd=REPO, capture_output=True, timeout=timeout, env=env)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    write(OUT / (name + '.status.json'), {'command': command, 'returncode': result.returncode})
    need(result.returncode == 0, name + ' failed; first streams retained')
    return result

def main():
    OUT.mkdir(exist_ok=False)
    (OUT / 'review-helper.py').write_bytes(Path(__file__).read_bytes())
    before = snapshot()
    write(OUT / 'source-before.json', before)
    helper = WORK / 'exact-selected-independent-review.py'
    need(sha(helper.read_bytes()) == AUTH_SHA, 'Source-authentication helper drift')
    namespace = {'__name__': 'history_index_source_auth', '__file__': str(helper)}
    exec(compile(helper.read_bytes(), str(helper), 'exec'), namespace)
    namespace['FROZEN'] = FROZEN
    authenticated = namespace['source_identity'](REPO, before)
    write(OUT / 'source-authentication.json', authenticated)
    # Import only after the complete raw/Git source closure is authenticated.
    sys.path.insert(0, str(REPO))
    from scripts import build_native_exact_four_street as builder
    manifest_path = BUILD / 'native-exact-build-manifest.json'
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    names = (*builder.TARGETS['history-index'][1], 'scripts/build_native_exact_four_street.py',
        'third_party/boost-multiprecision-1.92.0/manifest.json',
        'third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt',
        'third_party/boost-multiprecision-1.92.0/headers.zip')
    need(set(manifest['source_sha256']) == set(names), 'Incomplete build input closure')
    for name in names:
        need(sha((REPO / name).read_bytes()) == manifest['source_sha256'][name], 'Build source drift: ' + name)
    executable = Path(manifest['executable'])
    need(manifest['target'] == 'history-index' and executable.parent == BUILD and
        sha(executable.read_bytes()) == manifest['executable_sha256'], 'Wrong/stale graph-only executable')
    _, headers = builder._dependency()
    def dependency_check():
        for name, raw in headers.items():
            need((BUILD / 'boost-include' / name).read_bytes() == raw, 'Extracted native header drift: ' + name)
    dependency_check()
    (OUT / 'build-manifest.json').write_bytes(manifest_raw)
    source_out = OUT / 'source'
    for name in names:
        target = source_out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((REPO / name).read_bytes())
    for name in ('build.log', 'compiler-version.log'):
        (OUT / name).write_bytes((BUILD / name).read_bytes())
    env = os.environ.copy()
    env['OPENPOKER_NATIVE_HISTORY_INDEX_EXE'] = str(executable)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    child('normal', [sys.executable, '-m', 'unittest', 'tests.test_native_public_history_index', '-v'], env=env)
    child('optimized', [sys.executable, '-O', '-m', 'unittest', 'tests.test_native_public_history_index', '-v'], env=env)
    terra = WORK / 'native-history-index-terra-controls.cpp'
    need(sha(terra.read_bytes()) == TERRA_SHA, 'Independent ledger/control helper drift')
    (OUT / 'independent-controls.cpp').write_bytes(terra.read_bytes())
    target = OUT / 'independent-controls.exe'
    command = [manifest['compiler'], *manifest['flags'], '/I' + str(REPO / 'native'), str(terra),
        '/Fo' + str(OUT / 'independent-controls.obj'), '/Fe' + str(target)]
    child('independent-compile', command)
    checked = child('independent-controls', [str(target)], timeout=60)
    need(b'PASS wide/tall per-array retained ledger' in checked.stdout, 'Independent control marker missing')
    after = snapshot()
    write(OUT / 'source-after.json', after)
    need(after == before, 'Committed source changed during graph conformance')
    namespace['source_identity'](REPO, before)
    dependency_check()
    need(manifest_path.read_bytes() == manifest_raw and sha(executable.read_bytes()) == manifest['executable_sha256'],
        'Source-built helper changed during conformance')
    write(OUT / 'receipt.json', {'status': 'passed', 'source_commit': FROZEN,
        'authenticated_source_files': authenticated['files'], 'dependency_headers': len(headers),
        'source_and_build_unchanged': True, 'normal_and_optimized_controls': True,
        'independent_wide_tall_ledger_and_order_controls': True,
        'header_sha256': before['sha256']['native/exact_public_history_index.hpp'],
        'controls_sha256': before['sha256']['tests/native/exact_public_history_index_controls.cpp'],
        'independent_controls_sha256': TERRA_SHA, 'build_manifest_sha256': sha(manifest_raw),
        'executable_sha256': manifest['executable_sha256'],
        'scope': 'Graph-only controls and explicit Plan/index logical ledger; no solver or CFR trainer call. Plan performs rank-free prior/support setup. No poker quality, larger admission, performance, allocator-byte or RSS claim.'})
    entries = {p.relative_to(OUT).as_posix(): sha(p.read_bytes()) for p in sorted(OUT.rglob('*'))
        if p.is_file() and p.suffix not in ('.exe', '.obj')}
    write(OUT / 'manifest.json', {'sha256': entries})
    print(json.dumps({'status': 'passed', 'source_files': authenticated['files'], 'artifacts': len(entries)}))

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.is_dir() and not (OUT / 'first-failure.json').exists():
            write(OUT / 'first-failure.json', {'type': type(error).__name__, 'message': str(error)})
        raise
