# Scoped native profile review and next integration

The existing profile completed; it was not restarted. Authoritative session 77555 returned terminal exit code 0, six candidate invocations and the complete report manifest below. A subsequent saved-only review exited 0 on session 57842, with no candidate execution or compilation. Production files were not edited.

## Evidence and provenance

The profiled clean checkout is `a05fe2ade71214c13b6d5100e76b7f2102939ea7`; all nine build source files are raw-bound to its full 2,049-file tracked source closure and LF-equivalent to accepted production `a54483e94e3967e1eaa2fc33fe0733e33fa14a58`. The saved-only reviewer reauthenticated committed raw or Git-normalized blobs before loading the external profiling definitions. It imports no repository mathematical implementation and executes no candidate.

Pins:

| Artifact | SHA256 |
| --- | --- |
| Profile v2 manifest | ef2010ce09fde002323b86b7dffca8063006936cf1e942c0bbed0ff211444611 |
| Profile v2 report | 7a7b2e1d3effa290d108cb6445ca9654ff7623e89f42872d6cb9a40ae2c52933 |
| Saved-only receipt | a3cb4155a8a5228790df0a47a3f70db72b7335b749dc84de92d9bee93f17c3d4 |
| Saved-only helper | ab52e22a459607839fda7e8bc98df2531b5dbcb7e28ab186c918ad1f88c4f94d |
| Profiling helper | 8d847c1dc30fdc4423ced754f777eb9aa4eea034849b490b3cf5bd4494804fd3 |
| Accepted build manifest | 178462cac2aa83fac228bb7fed0307f8d4b0c288cc9c5864600573dc154e7e25 |
| Accepted executable | 829db4fbc29e13d5815803cafe0e59a1478f7390308a9130dd53c59e60196873 |
| Instrumented executable | 50522594b65c799ae02e3698e1b549cffd9f4df0536dc98107bb14cd46c72b91 |
| Original frozen whole-study manifest | c92a8a00093a354b9f85da7931f61dec663b3bd7b74119603a9053ff3a52dd88 |

The review checks the full artifact manifest, source before/after, original frozen study inventory, accepted executable, extracted 198-header Boost closure, dependency archive, compile exit 0 and compiler flags. Every transformed native source is reproduced from authenticated source by the saved exact-anchor additions; the generated diff and timer header match. Executables have separate recorded pins; the original profile manifest deliberately excludes `.exe` and `.obj` files. No claim is made that the object file was pinned independently.

Each of three saved requests was run once with the accepted executable and once with the instrumented copy. All six status files say exit 0. Each complete native stdout equals its corresponding frozen stdout byte for byte. The reviewer independently parses every ROW identity and probability bit against the saved complete policy and all 13 DONE fields against its native receipt. The saved payload, including its eight published diagnostics, is byte-bound to the original sample; this review does not newly recompute those diagnostics or add a quality certificate.

The first external build attempt remains in `native-scoped-phase-profile-v1`: compile failure, zero candidate invocations, manifest `4a4740febaa6e1696f0edb4573a57b5360777e6f595c6fe9a2b94d1638890212`. The cause was an instrumentation scope variable name collision, repaired only in the external generator.

The first saved-review attempt passed numerical/timer checks but failed its final inventory gate because importing the saved external helper created `__pycache__`. Its helper and failure log are preserved. Only that newly generated cache was moved to external evidence; original profile artifact bytes were never overwritten. Definition loading now compiles saved bytes without generating caches, and the original profile inventory was restored and checked unchanged. See the separate review-history JSON for those repair pins.

## What the observations establish

Times below are from one instrumented native process per fixture. Exclusive records partition the measured `run()` interval exactly; recursive inclusive records overlap. No medians or general performance claims follow from three different fixtures.

| Saved fixture | Uninstrumented process wall, ms | Instrumented process wall, ms | Instrumented run interval, ms | All history phases exclusive, ms | History fraction of instrumented interval |
| --- | ---: | ---: | ---: | ---: | ---: |
| Original 22-world T10 | 589.2209 | 627.7736 | 498.5580 | 263.7992 | 52.91% |
| Asymmetric weighted | 19.7426 | 22.2846 | 13.1405 | 6.6440 | 50.56% |
| Mixed stabilizer | 18.5846 | 21.4591 | 12.2323 | 7.0711 | 57.81% |

Observed instrumented/uninstrumented process-wall ratios are 1.0654, 1.1288 and 1.1547. These are instrumentation observations: RAII clock calls, record updates, 1,767,442 original-fixture finite-check increments, altered inlining, process startup, reporting and capture affect the comparison. The root interval excludes executable startup and the final timing-report destructor. The difference between process wall and root interval is not independently attributed. This is native-only execution, not Python preparation, serialization, diagnostics or full API time.

Original T10 context-exclusive totals are setup 16.5787 ms, preflight 10.4744 ms, learning 452.4889 ms, output 15.8829 ms and root residual 3.1331 ms. In learning:

| Phase | Calls | Inclusive ms | Exclusive ms |
| --- | ---: | ---: | ---: |
| Decision history lookup | 18,840 | 204.6806 | 122.2093 |
| Reveal parsing | 98,536 | 86.6179 | 86.6179 |
| History transform | 18,840 | 19.1143 | 19.1143 |
| History validation | 39,848 | 47.8649 | 11.9183 |
| Route from root | 18,840 | 8.6225 | 8.6225 |
| Exact terminal callback | 14,100 | 130.0488 | 89.7738 |
| Rational conversion | 28,240 | 39.3402 | 39.3402 |

The inclusive lookup time already contains some parsing, transformation and routing. It must not be added to those inclusive child times. The 263.7992 ms aggregate uses exclusive records only and includes setup/preflight/output history work as well as learning. Terminal callback inclusive includes its rational conversion and rank-cache children. Recursive target-traversal inclusive time exceeds the root interval and is not a disjoint phase share.

The profile establishes enough fixture-specific evidence to integrate incremental history routing next. It also shows that routing from the root alone is a small part of the issue: replacing only `decision_at_history` would leave repeated RowKey/history copying, suit transforms, support-prefix parsing, image sorting and string-map lookup. The 122.2093 ms lookup self time contains those uninstrumented internal operations; it does not separately measure each one. A numeric index must reach `locate_decision_rows` and prefix lookup to address the observed repeated work coherently.

## Bounded Stage B implementation

First integrate the accepted exact public-history index as an explicit opt-in route alongside the old route. Keep the wire version, default, kernel law, numerical traversal and all current admission guards unchanged. The smallest useful integration is a cursor plus numeric Q lookup, not a replacement solver and not an R-row cache.

1. Build the index once after the existing graph/group admission and before learning. Reserve its setup work, scratch and retained fields together with the old Plan, kernel, numeric buffers and any retained Q histories before allocation. Its independent cap is not additional free budget. A combined peak-lifetime ledger must include both the old and new routes during validation.
2. Carry a bounded cursor through the existing traversal: original vertex/ordinal, the group images needed for routing, and current typed revealed-prefix identities. Advance it using the actual chosen public edge. Retain current arithmetic edge order; lexical edge order defines ordinal offsets only. Initial history is common and validated once. An action advances no reveal prefix; a chance edge appends only its current visible reveal. No opponent holding or unrevealed selected-board identity enters cursor keys.
3. At a decision, derive images using `(global actor, original own-hand index, transformed public-path ordinal)`, sort and deduplicate stabilizers exactly as full RowKeys do, then query a Q-sized numeric location map. Preserve existing Q indices, action offsets, ordered menus and distinct-member masks. Derive Q numeric keys by replaying the already retained Q histories once, verifying exact key/order equivalence. This initially retains the Q histories for reference/output; explicitly charge the extra map and cursor metadata and do not describe it as a storage reduction.
4. Cache typed reveal-prefix IDs on index transitions or reuse the existing bounded prefix cache, with an exact once-built numeric-prefix mapping. Terminal and average callbacks receive the same existing board-index vector by prefix ID. This avoids repeated string parsing without changing the exact kernel callback arguments, completed-vector rounding, sorted chance reduction or phase-update schedule.
5. In the first integrated mode, compute old and numeric decision locations and prefix selections together and compare them before any state update. Require equality for every supported hand and every zero-support hole: Q row, offset, menu, member bit and ordered board-index vector. A mismatch aborts before committing a player/average phase. Off-path branches and repeated shared-vertex occurrences must be traversed and checked; vertex ID never substitutes for full public-path identity.
6. Only after shadow equivalence passes should a separately explicit indexed mode avoid old string lookup in learning. Keep old mode available as reference. Further removal of retained Q histories and output reconstruction is a separate storage change with its own peak proof. Do not change forecasts merely because a named old term is absent from the new implementation: use an explicit versioned forecast for the actual selected mode while preserving prior results and guards.

The cursor state is O(GD) at depth D if a group image vector is copied per frame; this must be charged. An in-place push/pop design can reduce retained state, but its saved parent state and exception path still need an explicit bound. Numeric Q keys and map overhead are O(Q), not O(R), and any temporary `G*Q` image storage must be separately admitted or avoided by a single bounded G scratch vector. Stage A continuation/signature arrays remain O(G(V+E)) in counted fields with the already reviewed token-byte/comparison charges; that expression is not an unconditional CPU bound.

## Proof and acceptance gates

The exact history-index prerequisites remain essential: one complete token per edge; unique outgoing tokens; canonical bytewise lexical ordering; prefix before descendants; checked C(v) multiplicity and offsets; fixed initial history; exact continuation equivalence rather than hash-only identity. Shared graph vertices may be reached by distinct histories and must retain distinct ordinals. A flop label containing several cards is one atomic history token, with the same canonical card ordering as the old route. Suit images must be followed from the transformed parent, and member ordinals come from distinct transformed RowKeys rather than permutation position.

Require controls for reconvergent/shared children, identical continuation objects, action-token lexical order differing from menu order, nonempty initial history, flop/turn/river reveals, private-hand swaps, group composition, nontrivial stabilizers, incomplete/zero support and dead branches. Reject malformed cycles, duplicate tokens, incorrect initial prefixes, overflow and exhausted combined budgets before growth. Synthetic tests must show that future board suffix changes cannot change a pre-reveal decision key.

Run full native stdout bit comparisons with the old route on the existing original, asymmetric, mixed-stabilizer and symmetric controls after a fresh source/build freeze. Preserve phase/member receipts, all policies, all eight unchanged diagnostics and independent capped numeric/exact saved-policy certificates. Preserve quality misses. Include admission rejection with zero rank/train calls. A corrected source requires a new evidence set, never overwriting either prior frozen whole study or this external profile.

Then repeat a separately named, equally scoped instrumentation experiment on both old and indexed routes, recording index setup, numeric lookup, residual parsing, callback and whole-process intervals, full output identity and overhead. A fixed fresh-process schedule is needed for a timing claim; the current single-pair observations justify direction only. Report extra retained metadata even if measured learning time improves.

## Capacity limit remains separate

The inherited original T1000 kernel forecast is 2,614,761,482 modeled units: setup/support 2,826,058, marginal 335,446,384 and terminal 2,276,489,040. Even removing all marginal reservation leaves more than 2.279 billion, above the unchanged 500 million cap. The native callback forecast alone is about 1.828 billion. History-index integration therefore must not promise original T1000 admission, equilibrium quality, or unrestricted-range capacity. It is a meaningful measured routing improvement prerequisite; terminal exact-callback repetition and whole-admission reconciliation need a later separately proved slice.
