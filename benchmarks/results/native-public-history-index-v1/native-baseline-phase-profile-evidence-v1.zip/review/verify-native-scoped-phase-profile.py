"""Saved-only authentication; never compile or execute a native candidate."""
import base64
import difflib
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import subprocess
import types
import zipfile

W=Path(__file__).resolve().parent
R=W/'native-exact-engine-ci-repo'
P=W/'native-scoped-phase-profile-v2'
S=W/'native-exact-whole-study-v2'
B=W/'native-exact-engine-ci-build-v1'
FROZEN='a05fe2ade71214c13b6d5100e76b7f2102939ea7'
ACCEPTED='a54483e94e3967e1eaa2fc33fe0733e33fa14a58'
PIN='ef2010ce09fde002323b86b7dffca8063006936cf1e942c0bbed0ff211444611'
AUTH='8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
SAMPLES=('original-22-t10-native-0','asymmetric-weighted-native-0','mixed-stabilizer-native-0')
COUNTERS=('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots','member_checks','expected_member_checks','modeled_work_upper','kernel_work_upper','retained_entries_upper','maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(x,msg):
    if not x:raise ValueError(msg)
def parse(raw):return json.loads(raw)
def inv(p):return {f.relative_to(p).as_posix():sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
def load_module(path,name):
    mod=types.ModuleType(name);mod.__file__=str(path);exec(compile(path.read_bytes(),str(path),'exec'),mod.__dict__);return mod
def closure(p,pin):
    raw=(p/'manifest.json').read_bytes();need(sha(raw)==pin,'manifest pin: '+str(p));m=parse(raw)['sha256'];actual=inv(p)
    need(all(actual.get(k)==v for k,v in m.items()),'artifact hash: '+str(p))
    need(set(actual)-set(m)-{'manifest.json'}==({k for k in actual if Path(k).suffix in ('.exe','.obj')}),'unexpected omitted artifacts')
    return actual,m
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def main():
    receipt=W/'native-scoped-phase-profile-review.json';need(not receipt.exists(),'preserve previous receipt')
    before,m=closure(P,PIN);source=parse((P/'source-before.json').read_bytes())
    need(source==parse((P/'source-after.json').read_bytes()) and source['commit']==FROZEN and source['status']=='','saved source snapshots')
    authpath=W/'exact-selected-independent-review.py';need(sha(authpath.read_bytes())==AUTH,'auth helper pin')
    auth=load_module(authpath,'saved_native_profile_auth');auth.FROZEN=FROZEN
    identity=auth.source_identity(R,source)
    need(identity==parse((P/'source-authentication.json').read_bytes()),'current full source authentication differs')
    # Repository math is never imported. Only saved profiler definitions are loaded.
    profile_helper=P/'profile-helper.py';helper=load_module(profile_helper,'saved_profile_definitions')
    need(profile_helper.read_bytes()==(W/'profile-native-exact-phases.py').read_bytes(),'profile helper drift')
    buildraw=(B/'native-exact-build-manifest.json').read_bytes();build=parse(buildraw)
    need(sha(buildraw)==helper.BUILD_MANIFEST and buildraw==(P/'accepted-build-manifest.json').read_bytes(),'build pin')
    expected_sources={'native/'+n for n in ('exact_four_street_train.cpp','exact_public_graph.hpp','exact_selected_cfr.hpp','exact_selected_kernel.hpp','exact_binary64.hpp')}|{'scripts/build_native_exact_four_street.py'}|{'third_party/boost-multiprecision-1.92.0/'+n for n in ('manifest.json','LICENSE_1_0.txt','headers.zip')}
    need(set(build['source_sha256'])==expected_sources,'build source closure')
    for name,digest in build['source_sha256'].items():
        raw=(R/name).read_bytes();need(sha(raw)==digest==source['sha256'][name],'build source raw '+name)
        need(raw.replace(b'\r\n',b'\n')==git('show',ACCEPTED+':'+name).replace(b'\r\n',b'\n'),'accepted production source '+name)
    executable=Path(build['executable']);need(sha(executable.read_bytes())==helper.EXECUTABLE==build['executable_sha256'],'accepted exe')
    dep=R/'third_party/boost-multiprecision-1.92.0';dm=parse((dep/'manifest.json').read_bytes())
    need(sha((dep/'manifest.json').read_bytes())==build['dependency_manifest_sha256'] and sha((dep/'headers.zip').read_bytes())==build['dependency_archive_sha256'],'dependency pins')
    with zipfile.ZipFile(dep/'headers.zip') as z:headers={i.filename:sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
    need(headers==dm['headers_sha256']==inv(B/'boost-include') and len(headers)==198,'compiler dependency closure')
    transformation=parse((P/'transformation.json').read_bytes());diff=[]
    for v in transformation['files']:
        name=v['file'];raw=(R/'native'/name).read_bytes();need(raw==(P/'production-source'/name).read_bytes() and sha(raw)==v['source_raw_sha256'],'source copy')
        result,patch=helper.transform(raw,name,helper.transformations().get(name,[]));need(result==(P/'instrumented-source'/name).read_bytes() and sha(result)==v['instrumented_sha256'],'exact instrumentation transform');diff.append(patch)
    need(''.join(diff).encode()==(P/'instrumentation.diff').read_bytes(),'recorded exact diff')
    need(sha((P/'instrumented-source/phase_profile.hpp').read_bytes())==transformation['timer_header_sha256'] and (P/'instrumented-source/phase_profile.hpp').read_bytes()==(W/'native-phase-profiler.hpp').read_bytes(),'timer source')
    compile_status=parse((P/'build/status.json').read_bytes());need(compile_status['returncode']==0,'compile exit')
    command=compile_status['command'];need(command[0]==build['compiler'] and command[1:1+len(build['flags'])]==build['flags'],'compiler/flags identity')
    report=parse((P/'report.json').read_bytes());instrumented=P/'build/native-exact-profile.exe'
    need(sha(instrumented.read_bytes())==report['instrumented_executable_sha256'],'instrumented executable hash')
    study_before,sm=closure(S,helper.STUDY_MANIFEST)
    need(report['outcome']=='complete' and report['native_process_invocations']==6 and [x['sample'] for x in report['results']]==list(SAMPLES),'fixed completed schedule')
    deck=tuple(r+s for r in '23456789TJQKA' for s in 'cdhs');summaries=[]
    for v in report['results']:
        name=v['sample'];folder=P/name;raw=parse((S/(name+'.json')).read_bytes());stream=raw['native_streams'][0]
        req,out,err=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'))
        need(stream['returncode']==0 and err==b'' and raw['failure'] is None,'frozen process status')
        need(sha((S/(name+'.json')).read_bytes())==v['frozen_raw_sha256'],'sample pin')
        payload=raw['payload'];nr=payload['operator_census']['native_exact']
        need(sha(req)==nr['request_sha256'] and sha(out)==nr['result_sha256'] and nr['build']['source_sha256']==build['source_sha256'] and nr['build']['executable_sha256']==helper.EXECUTABLE,'wire/build binding')
        need(sha(json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==raw['payload_sha256'],'payload binding')
        need((folder/'request.txt').read_bytes()==req and (folder/'frozen-stdout.txt').read_bytes()==out and parse((folder/'frozen-payload.json').read_bytes())==payload,'profile input identities')
        ts=req.decode('ascii').split();need(ts[0]=='OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1','request contract');pos=21;hands=[]
        for count in map(int,ts[3:5]):
            side=[]
            for _ in range(count):side.append(deck[int(ts[pos])]+deck[int(ts[pos+1])]);pos+=3
            hands.append(side)
        expected={(0 if row['player']=='sb' else 1,row['hand'],tuple(row['history'])):row for row in payload['strategy']}
        for mode in ('uninstrumented','instrumented'):
            path=folder/mode;status=parse((path/'status.json').read_bytes());mode_report=v['modes'][mode]
            need(status['returncode']==0 and status['native_process_scope_only'] is True and math.isfinite(status['process_wall_seconds']) and status['process_wall_seconds']>0,'native exit/wall')
            need(status['process_wall_seconds']==mode_report['process_wall_seconds'] and (path/'stdout.txt').read_bytes()==out,'raw/report result equality')
            lines=out.decode('ascii').splitlines();need(lines[0]=='OPENPOKER_NATIVE_EXACT_FOUR_STREET_RESULT_V1','output contract');seen=set();slots=0
            for line in lines[1:-1]:
                f=line.split('\t');need(f[0]=='ROW','row');p,h,n=map(int,f[1:4]);history=tuple(f[4:4+n]);count=int(f[4+n]);bits=f[5+n:];key=(p,hands[p][h],history)
                need(key not in seen and key in expected,'row key identity');actions=expected[key]['actions']
                need(count==len(bits)==len(actions) and bits==[struct.pack('>d',a['probability']).hex() for a in actions],'full probability bits');seen.add(key);slots+=count
            need(seen==set(expected),'full row coverage');tail=lines[-1].split('\t');need(tail[0]=='DONE' and len(tail)==14,'DONE13 schema')
            counters=dict(zip(COUNTERS,map(int,tail[1:])));need(all(counters[k]==nr[k] for k in COUNTERS) and counters==mode_report['counters'] and counters['expanded_rows']==len(seen) and counters['expanded_action_slots']==slots,'all DONE counters')
            if mode=='uninstrumented':need((path/'stderr.txt').read_bytes()==b'' and mode_report['profile'] is None,'uninstrumented stderr')
            else:
                profile=parse((path/'stderr.txt').read_bytes());need(profile==mode_report['profile']==parse((path/'phase-profile.json').read_bytes()),'raw timer/report identity')
                rec=profile['records'];need(profile['contract']=='external-native-phase-profile-v1' and type(profile['finite_checks']) is int,'timer contract')
                need(len({(a['context'],a['phase']) for a in rec})==len(rec),'duplicate timer record')
                need(all(type(a[k]) is int and a[k]>=0 for a in rec for k in ('calls','inclusive_ns','exclusive_ns')) and all(a['inclusive_ns']>=a['exclusive_ns'] for a in rec),'timer integer bounds')
                roots=[a for a in rec if (a['context'],a['phase'])==('process','process_run')];need(len(roots)==1 and roots[0]['calls']==1,'one root interval')
                total=roots[0]['inclusive_ns'];need(sum(a['exclusive_ns'] for a in rec)==total,'exact exclusive partition')
                byphase={};bycontext={}
                for a in rec:byphase[a['phase']]=byphase.get(a['phase'],0)+a['exclusive_ns'];bycontext[a['context']]=bycontext.get(a['context'],0)+a['exclusive_ns']
                history=sum(n for k,n in byphase.items() if k.startswith('history_'))
                summaries.append({'sample':name,'root_ns':total,'history_exclusive_ns':history,'history_exclusive_fraction':history/total,'exclusive_by_phase_ns':byphase,'exclusive_by_context_ns':bycontext,'records':rec,'walls_seconds':{k:v['modes'][k]['process_wall_seconds'] for k in v['modes']},'counter_identity':counters,'complete_rows':len(seen),'complete_probability_bits':slots})
        need(v['instrumented_over_uninstrumented_observed_wall_ratio']==v['modes']['instrumented']['process_wall_seconds']/v['modes']['uninstrumented']['process_wall_seconds'],'wall ratio')
    first=W/'native-scoped-phase-profile-v1';first_inv,_=closure(first,'4a4740febaa6e1696f0edb4573a57b5360777e6f595c6fe9a2b94d1638890212');failure=parse((first/'first-failure.json').read_bytes());need(failure['candidate_invocations']==0 and failure['stage']=='instrumented-compilation' and parse((first/'build/status.json').read_bytes())['returncode']!=0,'preserved first compile failure')
    need(before==inv(P) and study_before==inv(S) and identity==auth.source_identity(R,source),'source/artifacts unchanged after saved review')
    need(buildraw==(B/'native-exact-build-manifest.json').read_bytes() and sha(executable.read_bytes())==helper.EXECUTABLE and sha(instrumented.read_bytes())==report['instrumented_executable_sha256'],'build stable after review')
    result={'outcome':'complete','review_contract':'saved-native-phase-profile-review-v1','review_helper_sha256':sha(Path(__file__).read_bytes()),'profile_manifest_sha256':PIN,'profile_report_sha256':sha((P/'report.json').read_bytes()),'authoritative_producer_completion':{'session':77555,'exit_code':0,'evidence':'write_stdin terminal result observed by reviewer; six completed candidate calls'},'review_candidate_invocations':0,'review_compilations':0,'source_commit':FROZEN,'accepted_production_commit':ACCEPTED,'source_files':identity['files'],'source_raw_and_committed_authenticated':True,'source_artifact_build_stable':True,'profile_raw_inventory_sha256':before,'study_manifest_sha256':helper.STUDY_MANIFEST,'accepted_build_manifest_sha256':sha(buildraw),'accepted_executable_sha256':helper.EXECUTABLE,'instrumented_executable_sha256':report['instrumented_executable_sha256'],'preserved_v1_inventory_sha256':first_inv,'summary':summaries,'scope':'Saved native-only profile review. Exact stdout and all ROW probability bits/DONE13 counters checked against frozen native output and complete saved payload. No independent game-quality replay here. Inclusive timers overlap; exclusive tagged records partition instrumented run only. One paired observation per fixture; overhead includes altered inlining/bookkeeping; no production CPU-share or speedup claim. Objects are excluded by original manifest; executable pin checked separately.'}
    receipt.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'outcome':'complete','receipt_sha256':sha(receipt.read_bytes()),'source_files':identity['files'],'review_candidate_invocations':0,'samples':len(summaries)}))
if __name__=='__main__':main()
