"""Preserve shared-owner parity and one existing training regression."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,zipfile

WORK=Path(__file__).resolve().parent;ROOT=WORK/'dyprofile-repo'
PACKET=ROOT/'benchmarks/results/native-frozen-grid-shared-owners-v1'
files={}
def sha(raw):return sha256(raw).hexdigest()
def add(name,raw):
    if name in files:raise ValueError('duplicate member')
    files[name]=raw
def file(name,path):add(name,path.read_bytes())
def tree(name,path):
    for p in sorted(path.rglob('*')):
        if p.is_file():file(name+'/'+p.relative_to(path).as_posix(),p)
if PACKET.exists():raise ValueError('immutable packet exists')
tree('snapshot',WORK/'dygrid-shared-snapshot1-normal')
tree('envelope',WORK/'dygrid-shared-envelope1-normal')
default=WORK/'dygrid-shared-reach1-complete-default'
tree('default/source',default/'source')
for n in ('source-identity.json','controller.py','command.json','protocol.json','verified.json','native-build-manifest.json'):
    file('default/'+n,default/n)
for n in ('process.json','request.bin','stdout.bin','stderr.bin'):
    file('default/observed/'+n,default/'observed'/n)
omitted={}
for n,digest in json.loads((default/'protocol.json').read_bytes())['stable_sidecars'].items():
    path=default/'observed'/n;raw=path.read_bytes()
    if sha(raw)!=digest:raise ValueError('sidecar drift')
    if path.stat().st_size>4<<20:
        omitted[n]={'bytes':len(raw),'sha256':digest,'reason':'identical canonical checkpoint bytes already preserved in ten-card evidence; full emitted stream hash was verified'}
    else:file('default/observed/'+n,path)
parity=[]
for name,a,b in (
 ('uniform','dyfrozen-state-frozen1-normal/uniform/stdout.bin','dygrid-shared-snapshot1-normal/uniform/stdout.bin'),
 ('zero-skew','dyfrozen-state-frozen1-normal/zero-skew/stdout.bin','dygrid-shared-snapshot1-normal/zero-skew/stdout.bin'),
 ('guards','dyfrozen-state-frozen1-normal/guards/stdout.bin','dygrid-shared-snapshot1-normal/guards/stdout.bin'),
 ('envelope-v2','dygrid-update-envelope2-formal-normal/stdout.bin','dygrid-shared-envelope1-normal/stdout.bin')):
    old,new=(WORK/a).read_bytes(),(WORK/b).read_bytes()
    if old!=new:raise ValueError('parity drift '+name)
    parity.append({'case':name,'bytes':len(new),'sha256':sha(new),'exact':True})
for label,build_name,source in (
 ('snapshot','dygrid-shared-snapshot1',WORK/'dygrid-shared-snapshot1-normal/source'),
 ('envelope','dygrid-shared-envelope1',WORK/'dygrid-shared-envelope1-normal/source'),
 ('default','dygrid-shared-reach1',default/'source')):
    build=WORK/build_name;manifest=json.loads((build/'native-exact-build-manifest.json').read_bytes())
    for n,digest in manifest['source_sha256'].items():
        if sha((source/n).read_bytes())!=digest:raise ValueError('build closure drift '+label+'/'+n)
    exe=next(build.glob('*.exe'))
    if sha(exe.read_bytes())!=manifest['executable_sha256']:raise ValueError('executable drift')
    file('build/'+label+'/'+exe.name,exe)
    for n in ('native-exact-build-manifest.json','build.log','compiler-version.log'):file('build/'+label+'/'+n,build/n)
for n in ('dygrid-shared-snapshot1-normal.log','dygrid-shared-envelope1-normal.log','dygrid-shared-reach1-complete-default.log'):
    file('logs/'+n,WORK/n)
file('packager.py',Path(__file__))
receipt={'version':'native-frozen-grid-shared-owners-v1','scope':'mechanical shared contracts and exact reach extraction; no raw-update producer, speedup or larger-game acceptance',
 'snapshot_forecast_source_head':'53370bfd67745e704ce03299b6eeae2123dfa449','reach_source_head':'d72aff458b9e115498d47bb176194e129a44a7f4',
 'snapshot_tests':5,'envelope_tests':2,'byte_parity':parity,
 'default_training':json.loads((default/'verified.json').read_bytes()),'canonical_checkpoint_references':omitted,
 'baseline_policy_packet_sha256':'ecb72cd2bcbcdb1fb7089da6401ae558a4d71855daefdda86828b7c3817fbdd5',
 'baseline_envelope_packet_sha256':'dce1e6d5f59773d3e540c1f365664af88e1bf43edd7e44ebb6db4cc42392f4ac',
 'archived_source_executed':False,'system_build_inputs':'SDK/runtime/standard headers not exhaustively attested; bit reproducibility unproven'}
add('receipt.json',(json.dumps(receipt,indent=2)+'\n').encode())
members={n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())}
add('members.json',(json.dumps(members,indent=2)+'\n').encode())
PACKET.mkdir(parents=True,exist_ok=False);archive=PACKET/'verification.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in sorted(files.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or set(z.namelist())!=set(files):raise ValueError('archive CRC/members')
    for n,v in members.items():
        raw=z.read(n)
        if len(raw)!=v['bytes'] or sha(raw)!=v['sha256']:raise ValueError('archive member drift')
manifest={**receipt,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'archive_members':len(files),
          'expanded_bytes':sum(map(len,files.values()))}
(PACKET/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive_bytes','archive_sha256','archive_members','expanded_bytes','canonical_checkpoint_references')},indent=2))
