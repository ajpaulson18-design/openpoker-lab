"""Package completed observations only; no compiler or candidate invocation."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

WORK=Path(__file__).resolve().parent
ROOT=WORK/'dyprofile-repo'
DEST=ROOT/'benchmarks/results/native-frozen-policy-session-v1'
DEST.mkdir(parents=True,exist_ok=False)
SELF=Path(__file__).read_bytes()


def tree(directory,prefix):
    result={}
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            result[prefix+path.relative_to(directory).as_posix()]=path
    return result


def archive(name,files):
    payload={}
    for key,path in files.items():
        if key.startswith('/') or '..' in Path(key).parts:raise ValueError('archive member path')
        body=path if isinstance(path,bytes) else path.read_bytes()
        if len(body)>8<<20:raise ValueError('member byte ceiling')
        payload[key]=body
    payload['packager.py']=SELF
    index={key:{'bytes':len(body),'sha256':sha256(body).hexdigest()} for key,body in sorted(payload.items())}
    payload['members.json']=(json.dumps(index,indent=2,sort_keys=True)+'\n').encode()
    expanded=sum(map(len,payload.values()))
    if expanded>80<<20:raise ValueError('archive expanded byte ceiling')
    target=DEST/(name+'.zip')
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
        for key,body in sorted(payload.items()):
            item=zipfile.ZipInfo(key,(2026,11,21,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
            output.writestr(item,body,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    raw=target.read_bytes()
    if len(raw)>8<<20:raise ValueError('archive compressed byte ceiling')
    with zipfile.ZipFile(target) as check:
        if check.testzip() is not None or set(check.namelist())!=set(payload):raise ValueError('archive integrity')
        for key,body in payload.items():
            if check.read(key)!=body:raise ValueError('archive member drift')
    return {'bytes':len(raw),'members':len(payload),'expanded_bytes':expanded,'sha256':sha256(raw).hexdigest()}


records={}
for mode in ('normal','optimized'):
    files=tree(WORK/('dygrid-session-matrix2-'+mode),'matrix/')
    files.update(tree(WORK/'dygrid-session-candidate1','build/'))
    files['logs/build.log']=WORK/'dygrid-session-candidate1-build.log'
    files['logs/conformance.log']=WORK/('dygrid-session-matrix2-'+mode+'.log')
    files['logs/saved-replay.json']=WORK/('dygrid-session-matrix2-'+mode+'-replay.log')
    for name in ('scripts/replay_native_policy_session.py','scripts/replay_native_grid_raw.py','docs/native-frozen-policy-session.md'):
        files['maintained-source/'+name]=ROOT/name
    records[mode]=archive(mode,files)

files=tree(WORK/'dygrid-session-benchmark1','benchmark/')
files.update(tree(WORK/'dygrid-session-candidate1','build/session/'))
files.update(tree(WORK/'dygrid-session-baseline1','build/baseline/'))
files['logs/benchmark.log']=WORK/'dygrid-session-benchmark1.log'
files['logs/session-build.log']=WORK/'dygrid-session-candidate1-build.log'
files['logs/baseline-build.log']=WORK/'dygrid-session-baseline1-build.log'
records['benchmark']=archive('benchmark',files)

for mode in ('normal','optimized'):
    files=tree(WORK/('dygrid-session-matrix1-'+mode),'original-matrix/')
    files['logs/conformance.log']=WORK/('dygrid-session-matrix1-'+mode+'.log')
    files['capture-omission.txt']=b'Original numerical conformance passed, but the capture omitted its imported raw-reader metadata module. Retained as superseded development evidence; complete-source matrix2 replaces this source-closure claim.\n'
    records['development-'+mode]=archive('development-'+mode,files)

result=json.loads((WORK/'dygrid-session-benchmark1/result.json').read_text())
manifest={'version':'native-frozen-policy-session-v1',
    'native_source_head':'677bf51768b88dd93f76597babf577e686947aa6',
    'complete_observed_source_head':'09a6309',
    'benchmark_source_head':result['source_head'],
    'maintained_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'native_executable_sha256':'b1080580c5e13df4f72311c7dd14a517e719aab6a72dc7009ca63fe8f29b5666',
    'observed_successes_per_mode':12,'observed_rejections_per_mode':7,
    'domain_forecast_work':316294067,'work_ceiling':500000000,'maximum_actual_matrix_work':223700123,
    'maximum_output_bytes':1936776,'output_ceiling':2100000,
    'benchmarked_workload':result,'saved_replay_candidate_calls':0,'archived_source_executed':False,
    'scope':'immutable two-board raw session only; no policy transition, training, quality, RSS or wider admission',
    'archives':records,
    'system_build_inputs':'SDK/runtime/standard headers not exhaustively byte-attested; bit reproducibility unproven'}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(records,indent=2))
