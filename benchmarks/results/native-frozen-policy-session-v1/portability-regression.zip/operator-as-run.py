from hashlib import sha256
import json
from pathlib import Path
import struct

WORK=Path(__file__).resolve().parent


def image(path):
    raw=path.read_bytes();pe=struct.unpack_from('<I',raw,0x3c)[0]
    if raw[:2]!=b'MZ' or raw[pe:pe+4]!=b'PE\0\0':raise ValueError('PE image framing')
    count=struct.unpack_from('<H',raw,pe+6)[0];optional=struct.unpack_from('<H',raw,pe+20)[0]
    sections={}
    for i in range(count):
        start=pe+24+optional+40*i
        name=raw[start:start+8].rstrip(b'\0').decode('ascii')
        virtual,rva,size,offset=struct.unpack_from('<4I',raw,start+8)
        sections[name]={'virtual_bytes':virtual,'rva':rva,'raw_bytes':size,
            'sha256':sha256(raw[offset:offset+size]).hexdigest()}
    return {'sha256':sha256(raw).hexdigest(),'sections':sections}


before=image(WORK/'dygrid-session-candidate1/native-virtual-frozen-policy-session.exe')
after=image(WORK/'dygrid-session-candidate2/native-virtual-frozen-policy-session.exe')
result={'scope':'same MSVC compiler/flags, whitespace-only C++ layout repair; section comparison is not a general binary reproducibility claim',
    'before':before,'after':after,'text_section_identical':before['sections']['.text']==after['sections']['.text'],
    'sections_identical':{name:before['sections'][name]==value for name,value in after['sections'].items()},
    'operator_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
target=WORK/'dyprofile-repo/benchmarks/results/native-frozen-policy-session-v1/portability-binary-sections.json'
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'text_section_identical':result['text_section_identical'],'sections_identical':result['sections_identical']},indent=2))
