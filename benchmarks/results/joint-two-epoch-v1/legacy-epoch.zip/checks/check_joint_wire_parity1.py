"""Compare retained native streams only; never execute native or project math."""
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def observed(directory):
    result = {}
    for path in directory.rglob('process.json'):
        data = json.loads(path.read_bytes())
        if data['status'] != 'exited' or not data['actual_exit_observed'] or data['failures']:
            raise ValueError('process did not exit cleanly: ' + str(path))
        values = []
        for name, record in zip(('stdout.bin', 'stderr.bin'), data['streams']):
            body = (path.parent / name).read_bytes()
            if (len(body), len(body), sha(body)) != (record['observed_bytes'], record['saved_bytes'], record['sha256']):
                raise ValueError('saved stream mismatch: ' + str(path))
            values.append(body)
        result[path.parent.relative_to(directory).as_posix()] = (data['returncode'], *values)
    if not result:
        raise ValueError('no observed process records')
    return result

def compare(label, left, right):
    a, b = observed(WORK / left), observed(WORK / right)
    if set(a) != set(b) or a != b:
        raise ValueError('native streams differ: ' + label)
    return {'label': label, 'observed_requests': len(a),
            'stdout_bytes': sum(len(v[1]) for v in a.values()),
            'requests': {name: {'exit': item[0], 'stdout_sha256': sha(item[1]),
                                'stderr_sha256': sha(item[2])} for name, item in sorted(a.items())}}

def main():
    results = [compare(name, name + '-normal', name + '-optimized') for name in (
        'joint-two-epoch1', 'joint-chance1', 'joint-epoch3', 'joint-legacy-prepared1',
        'joint-legacy-epoch1', 'joint-legacy-public1')]
    results.append(compare('historical-public-exact', 'sparse-two-epoch1-normal', 'joint-legacy-public1-normal'))
    legacy = observed(WORK / 'joint-legacy-epoch1-normal')
    if len(legacy) != 1 or sha(next(iter(legacy.values()))[1]) != '1331d8a2a92b44212328ce7c8990b0cff747b53dd08a77772249e3002855323f':
        raise ValueError('historical synthetic component output changed')
    out = WORK / 'joint-two-epoch-parity1.json'
    if out.exists():
        raise ValueError('fresh parity receipt required')
    body = (json.dumps({'status': 'all-retained-native-streams-exact', 'comparisons': results,
                       'scope': 'Byte equality of existing saved streams; no new executions or runtime comparison.'},
                      sort_keys=True, indent=2) + '\n').encode()
    out.write_bytes(body)
    print(json.dumps({'comparisons': len(results), 'receipt_sha256': sha(body),
                      'matched_process_records': sum(row['observed_requests'] for row in results)}))

if __name__ == '__main__':
    main()
