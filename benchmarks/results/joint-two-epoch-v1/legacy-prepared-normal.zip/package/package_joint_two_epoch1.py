"""Package saved joint-foundation evidence; never run native or archived code.

All inputs are authenticated before any output directory is created. Source
reconstructed from Git is labelled canonical evidence, never a raw checkout.
The eight ZIPs are external staging artifacts; this script does not publish.
"""
from __future__ import annotations

import ast
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'dyprofile-repo'
OUT = WORK / 'joint-two-epoch-package1'
MAX_MEMBER = 8 << 20
MAX_EXPANDED = 80 << 20
MAX_ARCHIVE = 8 << 20
MAX_MEMBERS = 4096
CAPTURE_HEAD = '8c42ee1410992bd5be8deb4ab65dd4ec649a1135'
INTRODUCED = 'b033782d606f72642ea890166f123d94f4823fd5'
FIXTURE1_HEAD = 'ae88da49bf7326c03b1fbb0861e0ca632049f584'
FIXTURE3_HEAD = '78825aa44eb250a6999ff4b155ed1466f02f3232'
FULL_SUITE_HEAD = 'f127f090c9da3a06bfc9adfb503c0d06172a2495'
SCOPE = 'Deterministic PROOF9 two-joint-observation foundation; no RNG, convergence, quality, full-range admission, RSS or runtime claim.'
# Existing independently pinned historical mixed-checkout exceptions, copied
# from the maintained source authenticator; each also requires its exact blob.
HISTORICAL_MIXED = {
    'native/training_phase_profile.hpp': ('b57fd7ed3ef7eb9bb711816b456abf53d603cb6d84ccf72594412bf279f3c022', '3000ccc8ee4d0dd89bf86153fffd876efa4f54aa'),
    'native/training_phase_trace.hpp': ('ec33454507a44d7cafd4f5da13eaffbc79da4cbd8e9f2ff190c16059031b52ee', 'e74f23f184fdee0b48d59c6cb21b4efa4258d617'),
}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(body):
    return sha256(body).hexdigest()


def read(path, cap=MAX_MEMBER):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= cap, 'input member boundary: ' + str(path))
    with path.open('rb') as source:
        raw = source.read(cap + 1)
    require(len(raw) <= cap and len(raw) == path.stat().st_size, 'input grew during read: ' + str(path))
    return raw


def unique(pairs):
    value = {}
    for key, entry in pairs:
        require(key not in value, 'duplicate JSON member')
        value[key] = entry
    return value


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique)


def load(path):
    return decode(read(path, 1 << 20))


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode('ascii')


def git(*arguments):
    result = subprocess.run(['git', *arguments], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    require(result.returncode == 0, 'read-only Git object lookup failed: ' + arguments[0])
    require(len(result.stdout) <= MAX_MEMBER, 'Git object output boundary')
    return result.stdout


def name(value):
    path = PurePosixPath(value)
    require(type(value) is str and value and str(path) == value and not path.is_absolute() and
            '..' not in path.parts and '\\' not in value and ':' not in value,
            'unsafe archive/source path')
    require(path.suffix.lower() not in {'.exe', '.obj', '.o', '.dll', '.so', '.dylib', '.pdb', '.lib', '.exp', '.pyc'},
            'executable/object artifact refused')
    return value


def add(files, member, raw):
    member = name(member)
    require(member not in files and type(raw) is bytes and len(raw) <= MAX_MEMBER, 'duplicate/oversized member: ' + member)
    files[member] = raw


def add_path(files, member, path):
    add(files, member, read(path))


def add_tree(files, prefix, directory):
    require(directory.is_dir() and not directory.is_symlink(), 'missing evidence directory: ' + str(directory))
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'evidence symlink refused')
        if path.is_file():
            add_path(files, prefix + '/' + path.relative_to(directory).as_posix(), path)


def tree(head):
    require(type(head) is str and re.fullmatch('[0-9a-f]{40}', head) is not None, 'source commit grammar')
    return {entry.split('\t', 1)[1]: entry.split('\t', 1)[0].split()[2]
            for entry in git('ls-tree', '-r', head).decode('utf-8').splitlines()}


def variants(canonical):
    values = {digest(canonical)}
    if b'\r' not in canonical:
        values.add(digest(canonical.replace(b'\n', b'\r\n')))
    return values


def authentic_source(directory):
    identity = load(directory / 'source-identity.json')
    head = identity['head']; hashes = identity['raw_sha256']; blobs = identity['committed_blobs']
    require(0 < len(hashes) <= 128 and set(hashes) == set(blobs), 'source raw/blob complete inventory')
    actual = {path.relative_to(directory / 'source').as_posix()
              for path in (directory / 'source').rglob('*') if path.is_file()}
    require(actual == set(hashes), 'captured source member set mismatch')
    committed = tree(head)
    for member, expected in hashes.items():
        name(member); raw = read(directory / 'source' / member)
        require(digest(raw) == expected and committed.get(member) == blobs[member], 'captured raw/blob mismatch: ' + member)
        canonical = git('show', head + ':' + member)
        require(expected in variants(canonical) or HISTORICAL_MIXED.get(member) == (expected, blobs[member]),
                'captured bytes differ from committed source: ' + member)
    native = load(directory / 'native-build-manifest.json')
    for member, expected in native['source_sha256'].items():
        require(member in hashes, 'native source missing from captured closure')
        raw = read(directory / 'source' / member)
        lf = raw.replace(b'\r\n', b'\n').replace(b'\r', b'\n')
        require(digest(raw) == expected or native.get('source_lf_sha256', {}).get(member) == digest(lf),
                'captured/native source hash link differs: ' + member)
    return {'kind': 'original-captured-raw-source', 'head': head, 'files': len(hashes),
            'source_identity_sha256': digest(read(directory / 'source-identity.json')),
            'native_manifest_sha256': digest(read(directory / 'native-build-manifest.json')),
            'native_executable_sha256': native['executable_sha256']}


def observed(directory):
    result = {}
    for receipt_path in sorted(directory.rglob('process.json')):
        receipt = load(receipt_path); parent = receipt_path.parent
        require(receipt['status'] == 'exited' and receipt['actual_exit_observed'] is True and
                receipt['automatic_retries'] == 0 and not receipt['failures'] and
                type(receipt['returncode']) is int, 'missing actual observed process exit')
        request = read(parent / 'request.bin')
        require(receipt['request_sha256'] == digest(request), 'process request digest mismatch')
        require(len(receipt['streams']) == 2, 'process stream inventory')
        output = []
        for filename, entry in zip(('stdout.bin', 'stderr.bin'), receipt['streams']):
            raw = read(parent / filename)
            require(entry['observed_bytes'] == entry['saved_bytes'] == len(raw) and entry['sha256'] == digest(raw),
                    'process stream byte/hash mismatch')
            output.append(digest(raw))
        result[parent.relative_to(directory).as_posix()] = {'exit': receipt['returncode'],
            'stdout_sha256': output[0], 'stderr_sha256': output[1]}
    require(result, 'missing process receipts: ' + str(directory))
    return result


def build_metadata(files, prefix, build, captured_manifest=None):
    manifest_path = build / 'native-exact-build-manifest.json'
    for member in ('build.log', 'compiler-version.log', 'native-exact-build-manifest.json'):
        add_path(files, prefix + '/' + member, build / member)
    if captured_manifest is not None:
        require(read(manifest_path) == read(captured_manifest), 'run/build manifest raw bytes differ')
    return load(manifest_path)


def run_tree(files, prefix, directory, expected_count, expected_codes):
    source = authentic_source(directory)
    receipts = observed(directory)
    require(len(receipts) == expected_count and set(entry['exit'] for entry in receipts.values()) <= set(expected_codes),
            'unexpected run process count or exit set')
    add_tree(files, prefix, directory)
    return {'prefix': prefix, 'source': source, 'processes': receipts}


def reconstruction(files, prefix, head, members, native=None, explanation=''):
    """Canonical Git bytes are evidence, not the missing original raw checkout."""
    members = sorted(set(members)); committed = tree(head); records = []
    require(0 < len(members) <= 128, 'reconstructed complete source closure size')
    for member in members:
        name(member); require(member in committed, 'missing reconstructed Git member')
        canonical = git('show', head + ':' + member)
        if native is not None and member in native['source_sha256']:
            expected = native['source_sha256'][member]
            require(expected in variants(canonical) or
                    native.get('source_lf_sha256', {}).get(member) == digest(canonical.replace(b'\r\n', b'\n')) or
                    HISTORICAL_MIXED.get(member) == (expected, committed[member]), 'reconstructed/native source link differs')
        add(files, prefix + '/source/' + member, canonical)
        records.append({'path': member, 'blob': committed[member], 'bytes': len(canonical), 'sha256': digest(canonical),
                        'recorded_native_raw_sha256': None if native is None else native['source_sha256'].get(member)})
    record = {'version': 'canonical-git-reconstruction-v1', 'head': head, 'files': records,
              'original_raw_checkout_captured': False, 'explanation': explanation,
              'source_context_is_execution_attestation': False}
    add(files, prefix + '/CANONICAL-GIT-RECONSTRUCTION.json', encoded(record))
    return {'prefix': prefix, 'head': head, 'files': len(records), 'kind': 'canonical-git-reconstruction-only'}


def oracle_names(head):
    # Parse only the literal metadata tuple; never execute archived Python.
    syntax = ast.parse(git('show', head + ':scripts/replay_native_frozen_policy_state.py'))
    for statement in syntax.body:
        if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'ORACLE_SOURCES'
                                                     for target in statement.targets):
            value = ast.literal_eval(statement.value)
            require(type(value) is tuple and all(type(member) is str for member in value), 'literal oracle source inventory')
            return value
    raise ValueError('missing literal oracle metadata tuple')


def add_log(files, filename, prefix='checks'):
    add_path(files, prefix + '/' + filename, WORK / filename)


def whole_packet(mode):
    files = {}; directory = WORK / ('joint-two-epoch1-' + mode)
    record = run_tree(files, 'matrix', directory, 13, (0, 2))
    require(record['source']['head'] == CAPTURE_HEAD, 'whole matrix capture source head')
    require(sum(item['exit'] == 0 for item in record['processes'].values()) == 6 and
            sum(item['exit'] == 2 for item in record['processes'].values()) == 7, 'whole success/refusal split')
    build_metadata(files, 'build', WORK / 'joint-two-epoch2-build', directory / 'native-build-manifest.json')
    replay = load(WORK / ('joint-two-epoch-replay1-' + mode + '.log'))
    require(replay['status'] == 'all-joint-two-epoch-rows-exact' and replay['candidate_calls'] == 0 and
            replay['archived_source_executed'] is False and replay['observed_source_head'] == CAPTURE_HEAD,
            'saved current replayer result missing')
    add_log(files, 'joint-two-epoch1-' + mode + '.log')
    add_log(files, 'joint-two-epoch-replay1-' + mode + '.log')
    return files, [record]


def components_packet():
    files = {}; records = []
    for label, count in (('joint-chance1', 1), ('joint-epoch3', 1)):
        for mode in ('normal', 'optimized'):
            directory = WORK / (label + '-' + mode)
            records.append(run_tree(files, label + '/' + mode, directory, count, (0,)))
            add_log(files, label + '-' + mode + '.log')
        build_metadata(files, label + '/build', WORK / (label + '-build'),
                       WORK / (label + '-normal/native-build-manifest.json'))
    return files, records


def legacy_component_packet(label):
    files = {}; records = []
    require(label in ('joint-legacy-epoch1', 'joint-legacy-public1'), 'legacy component selector')
    for mode in ('normal', 'optimized'):
        directory = WORK / (label + '-' + mode)
        records.append(run_tree(files, label + '/' + mode, directory, 1 if 'epoch' in label else 13,
                                (0,) if 'epoch' in label else (0, 2)))
        add_log(files, label + '-' + mode + '.log')
    build_metadata(files, label + '/build', WORK / (label + '-build'),
                   WORK / (label + '-normal/native-build-manifest.json'))
    # Shared legacy/parity/history context is retained once in the Epoch ZIP.
    # The split changes archive boundaries only, never the evidence contents.
    if label == 'joint-legacy-epoch1':
        for filename in ('joint-two-epoch-parity1.json', 'check_joint_wire_parity1.py', 'joint-two-epoch-parity1.log',
                         'sfs1-full-unit-f127f09.log', 'sfs1-full-unit-f127f09.receipt.log'):
            add_log(files, filename)
        receipt = read(WORK / 'sfs1-full-unit-f127f09.receipt.log').decode('utf-8')
        require('head=' + FULL_SUITE_HEAD in receipt and 'exit=0' in receipt, 'earlier full-suite source/exit receipt')
        add(files, 'metadata/full-suite-scope.json', encoded({'head': FULL_SUITE_HEAD,
            'scope': 'Earlier revision whole-unit-suite log only; not latest native or current-HEAD full-suite coverage.'}))
    return files, records


def legacy_prepared_packet(mode):
    files = {}; records = []
    require(mode in ('normal', 'optimized'), 'legacy Prepared interpreter selector')
    # This old harness has per-process binary-identity receipts, not captured
    # raw source. Keep that distinction instead of manufacturing source capture.
    build = build_metadata(files, 'joint-legacy-prepared1/build', WORK / 'joint-legacy-prepared1-build')
    manifest_hash = digest(read(WORK / 'joint-legacy-prepared1-build/native-exact-build-manifest.json'))
    directory = WORK / ('joint-legacy-prepared1-' + mode)
    receipts = observed(directory); require(len(receipts) == 114, 'legacy Prepared complete case count')
    for path in directory.rglob('native-identity.json'):
        identity = load(path)
        require(identity['expected_sha256'] == identity['before_sha256'] == identity['after_sha256'] == build['executable_sha256'] and
                identity['captured_manifest_sha256'] == manifest_hash, 'legacy Prepared build identity link')
    add_tree(files, 'joint-legacy-prepared1/' + mode, directory)
    records.append({'prefix': 'joint-legacy-prepared1/' + mode, 'processes': receipts,
                    'raw_source_capture_available': False})
    add_log(files, 'joint-legacy-prepared1-' + mode + '.log')
    records.append(reconstruction(files, 'joint-legacy-prepared1/reconstruction', FIXTURE3_HEAD,
        (*build['source_sha256'], *oracle_names(FIXTURE3_HEAD), 'tests/test_native_prepared_public_chance.py',
         'scripts/replay_native_frozen_policy_state.py'), build,
        'Legacy Prepared harness retained process streams and executable/build hashes, but no original raw source copy.'))
    return files, records


def development_packet():
    files = {}; records = []
    # The first package attempt refused an oversized compressed legacy ZIP
    # before creating OUT. Preserve exact failed script bytes and its log.
    failed_packager = read(WORK / 'package_joint_two_epoch1-first.py.txt')
    failed_log = read(WORK / 'joint-two-epoch-package1.log')
    require(b'compressed archive cap: legacy' in failed_log,
            'missing original packaging cap refusal')
    add(files, 'packaging-cap-refusal/package_joint_two_epoch1-first.py.txt', failed_packager)
    add(files, 'packaging-cap-refusal/joint-two-epoch-package1.log', failed_log)
    add(files, 'packaging-cap-refusal/classification.json', encoded({
        'classification': 'packaging-size-cap refusal before output; not arithmetic or native admission failure',
        'failed_packager_sha256': digest(failed_packager), 'failure_log_sha256': digest(failed_log),
        'output_directory_created': False, 'native_calls': 0, 'limits_raised': False,
        'repair': 'Split legacy evidence by component and interpreter mode, retaining all streams and sources.'}))
    first = WORK / 'joint-two-epoch1-build'
    failure = load(first / 'build-failure.json')
    require(failure['target'] == 'virtual-joint-two-epoch' and failure['returncode'] == 2,
            'first compile failure receipt')
    for filename in ('build.log', 'compiler-version.log', 'build-failure.json'):
        add_path(files, 'first-compile/' + filename, first / filename)
    add_log(files, 'joint-two-epoch1-build.log')
    completed = load(WORK / 'joint-two-epoch2-build/native-exact-build-manifest.json')
    records.append(reconstruction(files, 'first-compile/reconstruction', INTRODUCED, completed['source_sha256'],
        explanation='First /WX C4018 signed/unsigned compile failure has no source SHA manifest. Reconstructed complete target closure at the coordinator-pinned introduced commit; not original failed raw checkout bytes.'))
    for number, head, why in ((1, FIXTURE1_HEAD, 'Duplicate-stage expected type lost to earlier row-cap resource rejection.'),
                              (2, CAPTURE_HEAD, 'Synthetic duplicate fixture used inconsistent two-epoch union limits.')):
        label = 'joint-epoch' + str(number)
        directory = WORK / (label + '-normal')
        entry = run_tree(files, label, directory, 1, (2,))
        require(entry['source']['head'] == head, 'fixture-failure source pin')
        entry['classification'] = 'synthetic-control-fixture failure; not native raw R/A parity failure'
        entry['description'] = why; records.append(entry)
        build_metadata(files, label + '/build', WORK / (label + '-build'), directory / 'native-build-manifest.json')
        add_log(files, label + '-normal.log'); add_log(files, label + '-build.log')
    add(files, 'metadata/development-scope.json', encoded({'failures_preserved': 4,
        'raw_or_policy_numerical_failure_claimed': False,
        'first_compile': 'C2220 under /WX with C4018 at probe line250; repaired unsigned selector bound literals.',
        'fixture_change_commits': ['4013a93bfc8b5c25482cffd7f55dae40c4b17332', FIXTURE3_HEAD],
        'successful_fixture_source': FIXTURE3_HEAD, 'native_success_source_capture': CAPTURE_HEAD,
        'all_reconstructed_source_is_evidence_only': True}))
    return files, records


def finish_archive(label, files, records):
    add_path(files, 'package/package_joint_two_epoch1.py', Path(__file__))
    add(files, 'metadata/context.json', encoded({'scope': SCOPE, 'archive': label,
        'captured_whole_head': CAPTURE_HEAD, 'fixture3_head': FIXTURE3_HEAD,
        'native_executables_and_object_files_included': False, 'archived_code_executed': False,
        'invocation_evidence': 'Captured commands, streams and actual exits, not independent syscall attestations.',
        'system_build_inputs': 'Compiler hash retained; SDK/system headers/linker/runtime not exhaustively byte-attested.'}))
    members = [{'path': member, 'bytes': len(body), 'sha256': digest(body)} for member, body in sorted(files.items())]
    manifest = {'version': 'joint-two-epoch-archive-v1', 'archive': label, 'members': members,
                'source_and_process_authentication': records,
                'limits': {'member_bytes': MAX_MEMBER, 'expanded_bytes': MAX_EXPANDED, 'archive_bytes': MAX_ARCHIVE}}
    add(files, 'MANIFEST.json', encoded(manifest))
    expanded = sum(map(len, files.values()))
    require(len(files) <= MAX_MEMBERS and expanded <= MAX_EXPANDED, 'archive member/expanded cap: ' + label)
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for member, body in sorted(files.items()):
            info = zipfile.ZipInfo(member, date_time=(2026, 1, 1, 0, 0, 0))
            info.create_system = 3; info.external_attr = 0o100644 << 16
            archive.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    raw = buffer.getvalue()
    require(len(raw) <= MAX_ARCHIVE,
            f'compressed archive cap: {label}: actual={len(raw)} bytes, limit={MAX_ARCHIVE} bytes')
    # Bounded readback verifies deflate output, member inventory and hashes.
    with zipfile.ZipFile(BytesIO(raw)) as archive:
        require(archive.namelist() == sorted(files), 'archive readback member set/order')
        for info in archive.infolist():
            require(info.file_size == len(files[info.filename]) <= MAX_MEMBER and info.compress_type == zipfile.ZIP_DEFLATED,
                    'archive readback member limits')
            with archive.open(info) as source:
                body = source.read(MAX_MEMBER + 1)
            require(body == files[info.filename], 'archive readback bytes differ')
    return raw, {'file': label + '.zip', 'bytes': len(raw), 'sha256': digest(raw),
                 'expanded_bytes': expanded, 'members': len(files), 'manifest_sha256': digest(files['MANIFEST.json'])}


def main():
    require(not OUT.exists() and OUT.parent.resolve() == WORK.resolve(), 'fresh external output required')
    # All evidence/source/process validation and bounded compression precedes
    # creation of the output directory. No current/archived math is imported.
    prepared = []
    for label, factory in (('normal', lambda: whole_packet('normal')),
                           ('optimized', lambda: whole_packet('optimized')),
                           ('components', components_packet),
                           ('legacy-prepared-normal', lambda: legacy_prepared_packet('normal')),
                           ('legacy-prepared-optimized', lambda: legacy_prepared_packet('optimized')),
                           ('legacy-epoch', lambda: legacy_component_packet('joint-legacy-epoch1')),
                           ('legacy-public', lambda: legacy_component_packet('joint-legacy-public1')),
                           ('development', development_packet)):
        files, records = factory(); raw, record = finish_archive(label, files, records)
        prepared.append((raw, record))
    parity = load(WORK / 'joint-two-epoch-parity1.json')
    require(len(parity['comparisons']) == 7, 'complete seven-part parity record')
    summary = {'version': 'joint-two-epoch-package-v1', 'scope': SCOPE,
               'archives': [record for _raw, record in prepared],
               'packager_sha256': digest(read(Path(__file__))), 'parity': parity,
               'publication_performed': False, 'native_calls': 0, 'archived_source_executed': False}
    OUT.mkdir()
    for raw, record in prepared:
        with (OUT / record['file']).open('xb') as output:
            output.write(raw)
    with (OUT / 'manifest.json').open('xb') as output:
        output.write(encoded(summary))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
