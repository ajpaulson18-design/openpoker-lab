"""Alternate the two admitted ten-card modes using one authenticated executable."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
from statistics import median
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'dycomplement-src1'
STUDY=WORK/'dycomplement-cohort2'
PUBLICATION=WORK/'dyadic-phase-payload-repo'
OUT=WORK/'dycomplement-timing-pairs1'
HEAD='4ec292925b300a983ba897b3c996dd6b0bacc457'
PAIRS=4

def require(condition,message):
    if not condition:
        raise RuntimeError(message)

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    with path.open('rb') as stream:
        return {'bytes':path.stat().st_size,'sha256':file_digest(stream,'sha256').hexdigest()}

def save(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write('\n')

def snapshot(expected):
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD,
            'timing source HEAD differs')
    require(not subprocess.check_output(['git','-c','core.fsmonitor=false','status',
                                        '--porcelain=v1','--untracked-files=all'],cwd=SOURCE),
            'timing source must stay clean')
    actual={}
    for name,record in expected.items():
        path=SOURCE/name
        require(path.resolve().is_relative_to(SOURCE) and not path.is_symlink(),
                'timing source path differs')
        digest=identity(path)['sha256']
        require(digest==record['raw_sha256'],'timing source raw bytes differ')
        actual[name]=digest
    return actual

def main():
    OUT.mkdir(exist_ok=False)
    observations=[]
    try:
        require(shutil.disk_usage(OUT).free>1<<30,'timing disk reserve')
        frozen=read(STUDY/'source.json')
        expected=frozen['files']
        before=snapshot(expected)
        save(OUT/'source-before.json',before)
        build=read(STUDY/'build/native-exact-build-manifest.json')
        exe=Path(build['executable'])
        require(identity(exe)['sha256']==build['executable_sha256'] and
                all(before[name]==digest for name,digest in build['source_sha256'].items()),
                'timing executable or native source closure differs')
        current=read(STUDY/'result.json')
        require(current['head']==HEAD and current['training_invocations']==1 and
                read(STUDY/'terminal.json')['status']=='complete' and
                read(WORK/'dycomplement-launch2/completion.json')['returncode']==0,
                'accepted source study incomplete')
        directory=PUBLICATION/'benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1'
        indexed=read(directory/'manifest.json')
        require(identity(directory/'manifest.json')['sha256']==before[
                    'benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1/manifest.json'] and
                identity(directory/'verification.zip')['sha256']==indexed['archive']['sha256'] and
                indexed['sweep_capture']==current['sweep_capture'] and
                current['complement_comparison']['combined_divisions_removed']==139_514,
                'accepted indexed comparison differs')
        modes={'indexed':('TRAIN_TEN_INDEXED_CACHE',indexed),
               'complement':('TRAIN_TEN_COMPLEMENT',current)}
        sys.path.insert(0,str(SOURCE))
        from tests.virtual_frozen_run_control import run_bounded_dyadic_probe
        save(OUT/'configuration.json',{'source_head':HEAD,'native_executable':str(exe),
            'executable_sha256':build['executable_sha256'],'pairs':PAIRS,
            'order':[['indexed','complement'] if pair%2==0 else ['complement','indexed'] for pair in range(PAIRS)],
            'source_study_manifest':identity(directory/'manifest.json'),
            'scope':'same frozen executable and host, alternating admitted modes, complete native calls and streamed transport'})
        for pair in range(PAIRS):
            order=('indexed','complement') if pair%2==0 else ('complement','indexed')
            for mode in order:
                label=f'pair-{pair+1}-{mode}'
                target=OUT/label
                target.mkdir()
                request,baseline=modes[mode]
                require(identity(exe)['sha256']==build['executable_sha256'],'binary drift before timing call')
                observed=run_bounded_dyadic_probe([str(exe),str(target/'page-images')],request,target/'process')
                require(observed['actual_exit_observed'] and observed['returncode']==0 and
                        not observed['failures'] and observed['automatic_retries']==0,
                        'timing call failed; preserve its first result')
                require(identity(exe)['sha256']==build['executable_sha256'],'binary drift after timing call')
                native=observed['streams'][0]
                require(native['sha256']==baseline['checkpoint_inputs']['stream']['sha256'] and
                        native['wire_sha256']==baseline['sweep_capture']['wire_sha256'] and
                        native['saved_bytes']==9_833_076 and native['observed_bytes']==57_236_692,
                        'timing numerical stream or complete wire differs')
                counts=read(target/'page-images/paging.json')
                require(counts==baseline['paging']['counts'],'timing pager counters differ')
                for image in baseline['checkpoint_inputs']['sweep_images']:
                    require(identity(target/'page-images'/image['name'])==
                            {key:image[key] for key in ('bytes','sha256')},'timing checkpoint differs')
                for name in ('policy.bin','policy.json','rank-index.json'):
                    require(identity(target/'page-images'/name)==identity(STUDY/'page-images'/name),
                            'timing policy or rank index differs')
                require(read(target/'page-images/quantizer.json')==baseline['quantizer'],
                        'timing quantizer invocation count differs')
                row_directory=target/'page-images-rows'
                require({p.name for p in row_directory.iterdir()}==
                        {p.name for p in (STUDY/'page-images-rows').iterdir()},
                        'timing directory artifact set differs')
                for path in row_directory.iterdir():
                    require(identity(path)==identity(STUDY/'page-images-rows'/path.name),
                            'timing directory content differs')
                observation={'pair':pair+1,'mode':mode,'seconds':observed['duration_seconds'],
                    'memory':observed['memory'],'request':request,'retained_sha256':native['sha256'],
                    'wire_sha256':native['wire_sha256'],'paging':counts}
                observations.append(observation)
                save(target/'verified.json',observation)
                print(json.dumps({'pair':pair+1,'mode':mode,'seconds':observation['seconds']}),flush=True)
        closure={}
        for module in tuple(sys.modules.values()):
            filename=getattr(module,'__file__',None)
            if not filename:
                continue
            path=Path(filename).resolve()
            if path.is_relative_to(SOURCE):
                name=path.relative_to(SOURCE).as_posix()
                require(name in before and identity(path)['sha256']==before[name],'imported timing source differs')
                closure[name]=before[name]
        after=snapshot(expected)
        require(before==after,'timing source inventory changed')
        save(OUT/'source-after.json',after)
        times={mode:[item['seconds'] for item in observations if item['mode']==mode] for mode in modes}
        ratios=[next(item['seconds'] for item in observations if item['pair']==pair and item['mode']=='complement')/
                next(item['seconds'] for item in observations if item['pair']==pair and item['mode']=='indexed')
                for pair in range(1,PAIRS+1)]
        result={'status':'same_executable_alternating_timing_complete','source_head':HEAD,
            'pairs':PAIRS,'training_invocations':len(observations),'observations':observations,
            'seconds':times,'median_seconds':{mode:median(values) for mode,values in times.items()},
            'paired_complement_to_indexed_ratios':ratios,'median_paired_ratio':median(ratios),
            'raw_source_stable':True,'source_files':len(before),'imported_source_closure':closure,
            'all_complete_streams_and_checkpoint_images_exact':True,
            'quality_evidence':'native-dyadic-quantizer-complement-v1',
            'limits':'one Windows host and this ten-card T2 fixture, four alternating pairs'}
        save(OUT/'result.json',result)
        save(OUT/'terminal.json',{'status':'complete','training_invocations':len(observations)})
        print(json.dumps({'median_seconds':result['median_seconds'],'median_paired_ratio':median(ratios)}),flush=True)
    except BaseException as error:
        save(OUT/'terminal.json',{'status':'failed','training_invocations_completed':len(observations),
                                'first_error':type(error).__name__+': '+str(error)})
        raise

if __name__=='__main__':
    main()
