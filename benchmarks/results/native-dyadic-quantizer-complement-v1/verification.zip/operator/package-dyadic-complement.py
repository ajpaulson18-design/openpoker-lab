"""Archive the exact ten-card quantizer study and matched native timings."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'dyadic-phase-payload-repo'
HEAD = '4ec292925b300a983ba897b3c996dd6b0bacc457'
RESULT = ROOT / 'benchmarks/results/native-dyadic-quantizer-complement-v1'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def collect(mode, baseline, files):
    cohort = WORK / 'dycomplement-cohort2'
    operator = WORK / 'dycomplement-launch2'
    final = read(cohort / 'result.json')
    outer = read(operator / 'completion.json')
    source = read(cohort / 'source.json')
    hashes = {k: v['raw_sha256'] for k, v in source['files'].items()}
    require(final['head'] == outer['head'] == source['head'] == HEAD and
            final['training_invocations'] == 1 and outer['mode'] == f'train_{mode}' and
            outer['actual_exit_observed'] and outer['returncode'] == 0 and not outer['failures'] and
            outer['raw_source_stable'] and read(cohort / 'terminal.json')['status'] == 'complete' and
            read(operator / 'source-before.json') == read(operator / 'source-after.json') == hashes,
            'source or lifecycle differs')
    require(read(operator / 'operator-launch.json')['operator_sha256'] ==
            digest(WORK / 'trusted-virtual-dyadic-training-launch-v28.py'), 'launcher differs')
    for boot_path in (operator / 'bootstrap.json', cohort / 'saved-review-bootstrap.json'):
        boot = read(boot_path)
        require(boot['initial_cache_scan']['project_bytecode_files'] ==
                boot['final_cache_scan']['project_bytecode_files'] == 0 and
                all(hashes.get(k) == v for k, v in boot['compiled'].items()), 'bootstrap sources differ')
    build_path = cohort / 'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(all(hashes.get(k) == v for k, v in build['source_sha256'].items()) and
            digest(Path(build['executable'])) == build['executable_sha256'], 'native build differs')
    for child in (f'admit_{mode}', f'train_{mode}', 'saved-review'):
        receipt = read(cohort / child / 'process.json')
        require(receipt['status'] == 'exited' and receipt['returncode'] == 0 and
                receipt['actual_exit_observed'] and not receipt['failures'] and
                receipt['automatic_retries'] == 0, 'native or replay exit differs')
        if child != 'saved-review':
            binding = read(cohort / child / 'binary-identity.json')
            require(binding['before_sha256'] == binding['after_sha256'] == build['executable_sha256'] and
                    binding['build_manifest_sha256'] == digest(build_path), 'native child identity differs')

    base_path = ROOT / baseline / 'manifest.json'
    prior = read(base_path)
    before = prior['saved_only_replay']
    after = final['saved_only_replay']
    require(hashes[baseline + '/manifest.json'] == digest(base_path) and
            hashes[baseline + '/verification.zip'] == digest(ROOT / baseline / 'verification.zip') ==
            prior['archive']['sha256'], 'accepted baseline evidence differs')
    require(before['profile_and_br'] == after['profile_and_br'] and
            before['work_actual'] == after['work_actual'] and before['work_plan'] == after['work_plan'] and
            prior['quality_gate'] == final['quality_gate'] and after['native_producer_calls'] == 0 and
            after['checkpoint_verification'] == 'independent_compact_digest', 'replay result differs')
    capture = final['sweep_capture']
    require(prior['sweep_capture'] == capture and prior['checkpoint_inputs'] == final['checkpoint_inputs'],
            'complete output or checkpoint digest differs')
    native = read(cohort / f'train_{mode}/process.json')
    require(native['sweep_capture'] == capture and
            digest(cohort / f'train_{mode}/stdout.bin') == after['saved_output_sha256'] ==
            before['saved_output_sha256'], 'native output bytes differ')
    for image in final['checkpoint_inputs']['sweep_images']:
        p = cohort / 'page-images' / image['name']
        require(p.stat().st_size == image['bytes'] and digest(p) == image['sha256'], 'saved image differs')
    admission = final['admission']
    comparison = final['complement_comparison']
    require(admission['complement_division'] is True and
            {k: v for k, v in admission.items() if k != 'complement_division'} == prior['admission'] and
            before['combined_divisions'] == comparison['combined_divisions_before'] == 325_666 and
            after['combined_divisions'] == comparison['combined_divisions_after'] == 186_152 and
            comparison['combined_divisions_removed'] == 139_514,
            'named admission or exact division comparison differs')
    for name, folder in (('operator', operator), ('cohort', cohort)):
        for p in sorted(folder.rglob('*')):
            require(not p.is_symlink(), 'linked evidence path')
            if not p.is_file():
                continue
            rel = p.relative_to(folder)
            if name == 'cohort' and (rel.parts[0] == 'source' or
                (rel.parts[0] == 'build' and p != build_path) or
                rel.as_posix() in ('page-images/committed.bin', 'page-images/staged.bin',
                                  f'train_{mode}/stdout.bin')):
                continue
            files[f'{name}/{rel.as_posix()}'] = p
    return final, native, build_path, hashes


def main():
    baseline = 'benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1'
    files = {'operator/package-dyadic-complement.py': Path(__file__),
             'operator/trusted-virtual-dyadic-training-launch-v28.py':
                 WORK / 'trusted-virtual-dyadic-training-launch-v28.py'}
    study, native, build_path, hashes = collect('ten_complement', baseline, files)
    failed = WORK / 'dycomplement-cohort1/terminal.json'
    first = read(failed)
    require(first['status'] == 'failed' and first['receipt']['training_invocations_entered'] == 0 and
            'compiler unavailable' in first['receipt']['first_error'], 'pretraining failure differs')
    files['initial-pretraining/terminal.json'] = failed
    files['initial-pretraining/exit.json'] = WORK / 'dycomplement-launch1/exit.json'

    policy = WORK / 'dycomplement-policy-build2/native-exact-build-manifest.json'
    controls = read(policy)
    require(all(hashes[k] == v for k, v in controls['source_sha256'].items()) and
            digest(Path(controls['executable'])) == controls['executable_sha256'],
            'native controls source or executable differs')
    files['controls/native-exact-build-manifest.json'] = policy
    for suffix in ('', '-opt'):
        folder = WORK / f'dycomplement-policy-test2{suffix}'
        log = folder.with_suffix('.log')
        raw = log.read_text(encoding='utf-8-sig')
        require('Ran 6 tests' in raw and raw.rstrip().endswith('OK') and 'skipped' not in raw,
                'quantizer controls incomplete')
        files[f'controls/{folder.name}.log'] = log
        for name in ('process.json', 'stdout.bin', 'stderr.bin', 'native-identity.json'):
            files[f'controls/{folder.name}/{name}'] = folder / name
        receipt = read(folder / 'process.json')
        binding = read(folder / 'native-identity.json')
        require(receipt['actual_exit_observed'] and receipt['returncode'] == 0 and not receipt['failures'] and
                binding['before_sha256'] == binding['after_sha256'] == controls['executable_sha256'],
                'native controls observed receipt differs')
    for suffix in ('normal', 'opt'):
        log = WORK / f'dycomplement-training-controls-{suffix}.log'
        raw = log.read_text(encoding='utf-8-sig')
        require('Ran 25 tests' in raw and raw.rstrip().endswith('OK') and 'skipped' not in raw,
                'training admission controls incomplete')
        files[f'controls/training-{suffix}.log'] = log

    timing_dir = WORK / 'dycomplement-timing-pairs1'
    timing = read(timing_dir / 'result.json')
    require(timing['status'] == 'same_executable_alternating_timing_complete' and
            timing['all_complete_streams_and_checkpoint_images_exact'] and timing['raw_source_stable'] and
            timing['source_head'] == HEAD and timing['training_invocations'] == 8 and
            read(timing_dir / 'terminal.json') == {'status': 'complete', 'training_invocations': 8} and
            read(timing_dir / 'source-before.json') == read(timing_dir / 'source-after.json') == hashes and
            read(timing_dir / 'configuration.json')['executable_sha256'] == read(build_path)['executable_sha256'],
            'matched timing evidence differs')
    files['timing/compare-dyadic-complement-timing.py'] = WORK / 'compare-dyadic-complement-timing.py'
    for name in ('configuration.json', 'result.json', 'terminal.json', 'source-before.json', 'source-after.json'):
        files[f'timing/{name}'] = timing_dir / name
    for item in timing['observations']:
        label = f"pair-{item['pair']}-{item['mode']}"
        require(item['retained_sha256'] == study['sweep_capture']['retained_sha256'] and
                item['wire_sha256'] == study['sweep_capture']['wire_sha256'],
                'timed bytes differ from accepted study')
        for name in ('verified.json', 'process/process.json', 'page-images/quantizer.json'):
            files[f'timing/{label}/{name}'] = timing_dir / label / name

    RESULT.mkdir(exist_ok=False)
    archive = RESULT / 'verification.zip'
    inventory = {n: {'bytes': p.stat().st_size, 'sha256': digest(p)} for n, p in files.items()}
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=6) as z:
        for n, p in files.items():
            z.write(p, n)
        z.writestr('inventory.json', json.dumps(inventory, indent=2, sort_keys=True) + '\n')
    with ZipFile(archive) as z:
        require(z.testzip() is None, 'archive CRC differs')
        for n, expected in inventory.items():
            with z.open(n) as f:
                require(z.getinfo(n).file_size == expected['bytes'] and
                        hashlib.file_digest(f, 'sha256').hexdigest() == expected['sha256'],
                        'archive member differs')
    manifest = {
        'version': 'native-dyadic-quantizer-complement-v1',
        'scope': 'Fixed indexed ten-card T2 fixture, exact complement quantization.',
        'source_head': HEAD, 'source_files': len(hashes), 'baseline': baseline,
        'baseline_manifest_sha256': digest(ROOT / baseline / 'manifest.json'),
        'pretraining_failure': first['receipt']['first_error'],
        'training_invocations': 1, 'native_seconds': native['duration_seconds'],
        'quality_gate': study['quality_gate'],
        'exploitability': study['saved_only_replay']['profile_and_br']['exploitability'],
        'comparison': study['complement_comparison'], 'sweep_capture': study['sweep_capture'],
        'work_plan': study['saved_only_replay']['work_plan'],
        'work_actual': study['saved_only_replay']['work_actual'],
        'timing': timing,
        'archive': {'path': 'verification.zip', 'bytes': archive.stat().st_size,
                    'sha256': digest(archive), 'members': len(inventory) + 1},
    }
    with (RESULT / 'manifest.json').open('x', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({k: manifest[k] for k in ('source_head', 'comparison', 'archive')}))


if __name__ == '__main__':
    main()
