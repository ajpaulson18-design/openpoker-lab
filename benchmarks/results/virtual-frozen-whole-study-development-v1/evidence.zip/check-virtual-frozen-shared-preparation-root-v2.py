import hashlib,json,subprocess,sys
from pathlib import Path
base=Path.cwd(); repo=base/'work/virtual-frozen-update-repo'; out=base/'work/virtual-frozen-shared-preparation-controls-root-v2'; out.mkdir(exist_ok=False)
files=list((repo/'tests').glob('*virtual_frozen*.py'))+[repo/'tests/virtual_betting_template_reference.py']
def pins():return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=pins(); receipt={'before':before,'runs':[]}
for mode,args in [('normal',[]),('optimized',['-O'])]:
    result=subprocess.run([sys.executable,'-B',*args,'-m','unittest','tests.test_virtual_frozen_shared_preparation','tests.test_virtual_frozen_value_reference','tests.test_virtual_frozen_sample_reference','tests.test_virtual_frozen_update_reference','-v'],cwd=repo,capture_output=True,check=False)
    (out/(mode+'.stdout.log')).write_bytes(result.stdout);(out/(mode+'.stderr.log')).write_bytes(result.stderr)
    receipt['runs'].append({'mode':mode,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    if result.returncode: break
receipt['after']=pins();receipt['stable']=before==receipt['after'];(out/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));sys.exit(0 if receipt['stable'] and len(receipt['runs'])==2 and all(r['returncode']==0 for r in receipt['runs']) else 1)



