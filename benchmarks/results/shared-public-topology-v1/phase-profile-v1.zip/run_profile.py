"""Separate, instrumented phase-allocation profile for shared public topology.

This is a descriptive one-pass study, not a performance sample. Run only after
its formal paired study has completed. It makes one fresh child solve per mode.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tracemalloc

EXPECTED_COMMIT = "e0e50a60264fe995074570ea4a72f666cec9c017"
DIAGNOSTICS = (
    "value_sb", "value_bb", "sb_best_response_value",
    "bb_best_response_value", "nash_conv",
)


def _script_hash() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _write_once(path: Path, data: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(data)


def _write_json_once(path: Path, value) -> bytes:
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")
    _write_once(path, raw)
    return raw


def _source_api(source_root: Path):
    sys.path.insert(0, str(source_root))
    from scripts.benchmark_selected_operator import _identity, _request
    return _identity, _request


def _traced_snapshot(label: str) -> dict:
    current, peak = tracemalloc.get_traced_memory()
    return {"label": label, "current_bytes": current,
            "cumulative_peak_bytes": peak}


def _child(source_root: Path, output: Path, mode: str) -> int:
    from unittest.mock import patch

    identity, make_request = _source_api(source_root)
    before = identity()
    _write_json_once(output / "source-before.json", before)
    if before.get("commit") != EXPECTED_COMMIT or before.get("status"):
        raise RuntimeError("Source must be the exact clean frozen commit before profiling.")

    case = json.loads((source_root / "benchmarks/four-street-integration-v1.json").read_text(encoding="utf-8"))["case"]
    request = make_request(case, 10)
    if request.iterations != 10:
        raise AssertionError("Only the fixed ten-iteration request is allowed.")

    from pokerlab import packed_operator_cfr, selected_operator_solver
    original_train = packed_operator_cfr.train_packed
    original_diagnostics = selected_operator_solver._evaluate_prepared
    phases: list[dict] = []

    def train_wrapper(*args, **kwargs):
        record = {"phase": "packed-trainer", "entry": _traced_snapshot("entry")}
        phases.append(record)
        try:
            return original_train(*args, **kwargs)
        finally:
            record["exit"] = _traced_snapshot("exit")

    def diagnostics_wrapper(*args, **kwargs):
        record = {"phase": "vector-diagnostics", "entry": _traced_snapshot("entry")}
        phases.append(record)
        try:
            return original_diagnostics(*args, **kwargs)
        finally:
            record["exit"] = _traced_snapshot("exit")

    script_hash = _script_hash()
    tracemalloc.start()
    returned = False
    fullcall_snapshot = None
    try:
        with patch.object(packed_operator_cfr, "train_packed", train_wrapper), \
             patch.object(selected_operator_solver, "_evaluate_prepared", diagnostics_wrapper):
            payload = selected_operator_solver.solve_four_street_operator(
                request, rank_cache_boards=64, strategy_storage="packed",
                public_topology=mode,
            )
        returned = True
        fullcall_snapshot = _traced_snapshot("full-call-after-return")
        _write_json_once(output / "raw-policy.json", payload)
    finally:
        # patch contexts restore both callables on ordinary and exceptional exits.
        exception_snapshot = (_traced_snapshot("exception-exit")
                             if tracemalloc.is_tracing() and not returned else None)
        if tracemalloc.is_tracing():
            tracemalloc.stop()
        after = identity()
        _write_json_once(output / "phase-records.json", {
            "mode": mode,
            "instrumentation": "unittest.mock wrappers call each original exactly once; tracemalloc starts before solve",
            "boundaries": phases,
            "complete_returned_output": returned,
            "full_call_after_return": fullcall_snapshot,
            "exception_exit_snapshot": exception_snapshot,
            "interpretation": (
                "Boundary peaks are cumulative since tracemalloc.start and include prior phases. "
                "Boundary current bytes are separate observations; they are not retained-object claims."
            ),
        })
        _write_json_once(output / "source-after.json", after)
        _write_json_once(output / "child-status.json", {
            "mode": mode,
            "returned_complete_output": returned,
            "source_unchanged": after == before,
            "source_clean": not bool(after.get("status")),
            "script_sha256_before": script_hash,
            "script_sha256_after": _script_hash(),
        })
    if after != before:
        raise RuntimeError("Source identity changed during this child solve.")
    if script_hash != _script_hash():
        raise RuntimeError("Profiling script changed during this child solve.")
    return 0


def _windows_process_peak() -> int | None:
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes

    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in (
                "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
                "PagefileUsage", "PeakPagefileUsage")]

    counters = Counters()
    counters.cb = ctypes.sizeof(counters)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return int(counters.PeakWorkingSetSize)


def _finite_diagnostics(payload: dict) -> bool:
    import math
    return all(type(payload.get(key)) in (int, float) and math.isfinite(payload[key])
               for key in DIAGNOSTICS)


def _complete_policy(payload: dict) -> bool:
    count = payload.get("info_sets")
    rows = payload.get("strategy")
    return (type(count) is int and count >= 0 and type(rows) is list and
            len(rows) == count)


def _pair_probabilities(payload: dict) -> bool:
    import math
    pairs = payload.get("private_pair_probabilities")
    return (type(pairs) is list and bool(pairs) and all(
        type(row) is dict and type(row.get("sb_hand")) is str and
        type(row.get("bb_hand")) is str and
        type(row.get("probability")) in (int, float) and
        math.isfinite(row["probability"]) and row["probability"] >= 0
        for row in pairs))


def _operator_counters(payload: dict) -> bool:
    statistics = payload.get("operator_statistics")
    cache = payload.get("rank_cache")
    statistic_fields = ("post_constructor_pair_board_checks", "rank_calls",
                        "rank_vector_peak_entries")
    cache_fields = ("board_capacity", "hits", "misses", "evictions",
                    "retained_peak_rank_slots",
                    "retained_plus_construction_peak_reference_slots")
    return (
        type(statistics) is dict and all(type(statistics.get(k)) is int and statistics[k] >= 0
                                         for k in statistic_fields) and
        type(cache) is dict and all(type(cache.get(k)) is int and cache[k] >= 0
                                    for k in cache_fields) and
        cache.get("board_capacity") == 64 and cache.get("released_after_diagnostics") is True
    )


def _parity(literal: dict, shared: dict) -> dict:
    literal_policy = _complete_policy(literal)
    shared_policy = _complete_policy(shared)
    literal_diagnostics = _finite_diagnostics(literal)
    shared_diagnostics = _finite_diagnostics(shared)
    literal_pairs = _pair_probabilities(literal)
    shared_pairs = _pair_probabilities(shared)
    literal_counters = _operator_counters(literal)
    shared_counters = _operator_counters(shared)
    checks = {
        "literal_complete_policy_present": literal_policy,
        "shared_complete_policy_present": shared_policy,
        "complete_policy_rows_identical": (
            literal_policy and shared_policy and
            literal["info_sets"] == shared["info_sets"] and
            literal["strategy"] == shared["strategy"]),
        "literal_five_diagnostics_present_finite": literal_diagnostics,
        "shared_five_diagnostics_present_finite": shared_diagnostics,
        "five_diagnostics_identical": (
            literal_diagnostics and shared_diagnostics and
            all(literal[k] == shared[k] for k in DIAGNOSTICS)),
        "literal_pair_probabilities_present": literal_pairs,
        "shared_pair_probabilities_present": shared_pairs,
        "private_pair_probabilities_identical": (
            literal_pairs and shared_pairs and
            literal["private_pair_probabilities"] == shared["private_pair_probabilities"]),
        "literal_operator_counters_present": literal_counters,
        "shared_operator_counters_present": shared_counters,
        "operator_counters_identical": (
            literal_counters and shared_counters and
            literal["operator_statistics"] == shared["operator_statistics"] and
            literal["rank_cache"] == shared["rank_cache"]),
    }
    return {
        "checks": checks,
        "all_requested_parity_checks_passed": all(checks.values()),
        "diagnostic_fields": {
            k: {"literal": literal.get(k), "shared": shared.get(k)} for k in DIAGNOSTICS
        },
    }


def _parent(source_root: Path, output: Path) -> dict:
    identity, _ = _source_api(source_root)
    if output.exists():
        raise FileExistsError("Choose a new external output folder; existing records are immutable.")
    resolved = output.resolve()
    if resolved == source_root.resolve() or source_root.resolve() in resolved.parents:
        raise ValueError("All profiling records must be outside the source checkout.")
    output.mkdir(parents=True)
    script_hash = _script_hash()
    source_before = identity()
    if source_before.get("commit") != EXPECTED_COMMIT or source_before.get("status"):
        raise RuntimeError("Source must be the exact clean frozen commit before profiling.")
    _write_json_once(output / "protocol.json", {
        "version": "shared-public-topology-phase-allocation-profile-v1",
        "source_commit": EXPECTED_COMMIT,
        "source_identity": source_before,
        "script_sha256": script_hash,
        "case": "benchmarks/four-street-integration-v1.json via scripts.benchmark_selected_operator._request",
        "request": {"worlds": 22, "iterations": 10, "strategy_storage": "packed",
                    "rank_cache_boards": 64, "native_executable": None,
                    "modes": ["literal", "shared"]},
        "children": "One fresh process for each mode; zero retries. Child files are retained on failure.",
        "scope": (
            "One separately labeled instrumented phase-allocation observation, not a fixed timing sample. "
            "Instrumentation calls differ from the formal study. Traced peaks are cumulative across phases; "
            "boundary current bytes are snapshots and do not establish retained memory or construction savings. "
            "The shared compiler still constructs the literal source tree before releasing it."
        ),
    })
    _write_json_once(output / "source-before.json", source_before)
    failures = []
    for mode in ("literal", "shared"):
        child_dir = output / mode
        child_dir.mkdir()
        command = [sys.executable, "-B", str(Path(__file__).resolve()), "--child",
                   "--source-root", str(source_root), "--child-output", str(child_dir), "--mode", mode]
        try:
            process = subprocess.run(command, cwd=source_root, capture_output=True, check=False)
            _write_once(child_dir / "child-stdout.raw", process.stdout)
            _write_once(child_dir / "child-stderr.raw", process.stderr)
            _write_json_once(child_dir / "process-status.json", {"returncode": process.returncode})
            if process.returncode:
                failures.append({"mode": mode, "returncode": process.returncode,
                                 "stage": "child", "message": "See retained raw stderr and partial child files."})
                break
            status = json.loads((child_dir / "child-status.json").read_text(encoding="utf-8"))
            required = ("raw-policy.json", "phase-records.json", "source-before.json",
                        "source-after.json", "child-status.json")
            missing = [name for name in required if not (child_dir / name).is_file()]
            if (missing or status.get("returned_complete_output") is not True or
                    status.get("source_unchanged") is not True or status.get("source_clean") is not True or
                    status.get("script_sha256_before") != script_hash or
                    status.get("script_sha256_after") != script_hash):
                failures.append({"mode": mode, "stage": "child-records",
                                 "message": "Child records are incomplete or failed their source/output check.",
                                 "missing": missing, "child_status": status})
                break
        except BaseException as exc:
            failures.append({"mode": mode, "stage": "launch-or-records",
                             "error_type": type(exc).__name__, "message": str(exc)})
            break

    source_after = None
    try:
        source_after = identity()
    except BaseException as exc:
        failures.append({"stage": "post-run-source-identity", "error_type": type(exc).__name__,
                         "message": str(exc)})
    try:
        script_hash_after = _script_hash()
    except BaseException as exc:
        script_hash_after = None
        failures.append({"stage": "post-run-script-identity", "error_type": type(exc).__name__,
                         "message": str(exc)})
    _write_json_once(output / "source-after.json", source_after)
    identities_match = source_before == source_after
    script_matches = script_hash == script_hash_after
    if not identities_match:
        failures.append({"stage": "source-identity", "message": "Source identity changed during profiling."})
    if not script_matches:
        failures.append({"stage": "script-identity", "message": "Profiler script identity changed during profiling."})

    parity = None
    # Do not parse policies if any child failed or source/script identity drifted.
    if not failures and identities_match and script_matches:
        try:
            # Both complete raw policies are on disk before this first parse.
            literal = json.loads((output / "literal/raw-policy.json").read_text(encoding="utf-8"))
            shared = json.loads((output / "shared/raw-policy.json").read_text(encoding="utf-8"))
            parity = _parity(literal, shared)
            _write_json_once(output / "parity.json", parity)
            if not parity["all_requested_parity_checks_passed"]:
                failures.append({"stage": "parity", "message": "One or more requested policy/diagnostic/pair/counter checks failed.",
                                 "failed_checks": [key for key, passed in parity["checks"].items() if not passed]})
        except BaseException as exc:
            failures.append({"stage": "parity-parse-or-check", "error_type": type(exc).__name__,
                             "message": str(exc)})

    try:
        parent_peak = _windows_process_peak()
    except BaseException as exc:
        parent_peak = None
        failures.append({"stage": "parent-process-peak", "error_type": type(exc).__name__,
                         "message": str(exc)})
    final = {
        "outcome": "complete" if not failures and identities_match and script_matches and
                   parity is not None and parity["all_requested_parity_checks_passed"] else "failed",
        "failures": failures,
        "source_unchanged": identities_match,
        "script_sha256_before": script_hash,
        "script_sha256_after": script_hash_after,
        "parent_process_peak_working_set_bytes": parent_peak,
        "parent_peak_scope": "Coordinator process only; child solve working sets are separate processes.",
        "parity": parity,
    }
    _write_json_once(output / "profile-summary.json", final)
    return final


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(
        r"C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\topology-repo"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--child", action="store_true")
    parser.add_argument("--child-output", type=Path)
    parser.add_argument("--mode", choices=("literal", "shared"))
    args = parser.parse_args()
    source_root = args.source_root.resolve()
    if args.child:
        if args.child_output is None or args.mode is None:
            parser.error("--child requires --child-output and --mode")
        return _child(source_root, args.child_output.resolve(), args.mode)
    if args.output is None:
        parser.error("--output is required for the coordinator")
    result = _parent(source_root, args.output)
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return 0 if result["outcome"] == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
