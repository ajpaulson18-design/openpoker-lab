"""Strict external development engine/control build with first streams retained."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK / "native-active-frame-repo"
OUT = WORK / ("native-active-engine-build-" + sys.argv[1])
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def put(name, value):
    (OUT / name).write_bytes((json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
OUT.mkdir(exist_ok=False)
accepted = json.loads((WORK / "native-indexed-work-plan-engine-build-v3/native-exact-build-manifest.json").read_bytes())
compiler = Path(accepted["compiler"])
vcvars = compiler.parents[6] / "Auxiliary/Build/vcvars64.bat"
setup = OUT / "setup.cmd"
setup.write_text('@call "' + str(vcvars) + '" >nul\n@if errorlevel 1 exit /b 1\n@set\n', encoding="utf-8")
configured = subprocess.run(["cmd.exe", "/d", "/c", str(setup)], capture_output=True)
(OUT / "setup-stderr.log").write_bytes(configured.stderr)
if configured.returncode:
    raise RuntimeError("compiler environment setup failed")
environment = os.environ.copy()
for line in configured.stdout.decode("utf-8", "replace").splitlines():
    key, sep, value = line.partition("=")
    if sep and key.upper() in ("PATH", "INCLUDE", "LIB", "LIBPATH"):
        environment[key.upper()] = value
for key in ("CL", "_CL_", "LINK", "_LINK_"):
    environment.pop(key, None)
names = ["native/exact_four_street_train.cpp", "native/exact_selected_cfr.hpp", "native/exact_indexed_routing.hpp",
    "native/exact_public_history_index.hpp", "native/exact_public_graph.hpp", "native/exact_selected_kernel.hpp",
    "native/exact_binary64.hpp", "tests/native/exact_selected_cfr_controls.cpp", "scripts/build_native_exact_four_street.py"]
before = {name:sha(REPO / name) for name in names}
put("source-before.json", before)
for name in names:
    target = OUT / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((REPO / name).read_bytes())
command = [sys.executable, "-B", "-m", "scripts.build_native_exact_four_street", "--target", "engine", "--output-dir", str(OUT / "engine")]
with (OUT / "engine-stdout.log").open("wb") as stdout, (OUT / "engine-stderr.log").open("wb") as stderr:
    built = subprocess.run(command, cwd=REPO, env=environment, stdout=stdout, stderr=stderr)
put("status.json", {"engine_returncode":built.returncode,"command":command})
if built.returncode:
    raise SystemExit(built.returncode)
manifest = json.loads((OUT / "engine/native-exact-build-manifest.json").read_bytes())
control = OUT / "cfr-controls.exe"
control_command = [manifest["compiler"], *manifest["flags"], str(REPO / "tests/native/exact_selected_cfr_controls.cpp"),
    "/Fo" + str(OUT / "cfr-controls.obj"), "/Fe" + str(control)]
compiled = subprocess.run(control_command, cwd=OUT, env=environment, capture_output=True)
(OUT / "control-compile-stdout.log").write_bytes(compiled.stdout)
(OUT / "control-compile-stderr.log").write_bytes(compiled.stderr)
put("status.json", {"engine_returncode":0,"control_compile_returncode":compiled.returncode,"command":control_command})
if compiled.returncode:
    raise SystemExit(compiled.returncode)
ran = subprocess.run([str(control)], cwd=OUT, capture_output=True)
(OUT / "control-stdout.log").write_bytes(ran.stdout)
(OUT / "control-stderr.log").write_bytes(ran.stderr)
after = {name:sha(REPO / name) for name in names}
put("source-after.json", after)
receipt = {"engine_returncode":0,"control_compile_returncode":0,"control_run_returncode":ran.returncode,
    "source_stable":before == after,"engine_executable_sha256":manifest["executable_sha256"],"control_sha256":sha(control)}
put("status.json", receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(ran.returncode if before == after else 3)
