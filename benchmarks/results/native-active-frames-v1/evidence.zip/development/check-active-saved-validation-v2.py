"""Compatibility of current study validation with ten preserved V3 observations."""
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
out = work / "native-active-saved-validation-v2"
out.mkdir(exist_ok=False)
names = ("scripts/benchmark_native_active_frames.py", "tests/test_benchmark_native_active_frames.py")
def sha(raw): return hashlib.sha256(raw).hexdigest()
before = {name: sha((repo / name).read_bytes()) for name in names}
(out / "source-before.json").write_text(json.dumps(before, indent=2))
sys.path.insert(0, str(repo))
from scripts import benchmark_native_active_frames as study
from scripts import benchmark_suit_quotient_solver as quotient
from scripts import benchmark_equivariant_selected_solver as equivariant
from pokerlab import native_exact_four_street as native
deps = SimpleNamespace(quotient=quotient, equivariant=equivariant, native=native)
prior = work / "native-indexed-admission-study-continuation-v2"
manifest = json.loads((prior / "manifest.json").read_bytes())
receipts = []
for path in sorted(prior.glob("*.stdout.bin")):
    raw_bytes = path.read_bytes()
    if sha(raw_bytes) != manifest["sha256"][path.name]:
        raise ValueError("prior artifact drift")
    raw = json.loads(raw_bytes)
    if not raw.get("payload") or raw.get("native_admission") != "indexed-v1":
        continue
    # Adapt only study-level invocation labels. All policy, wire and receipt bytes
    # remain the prior source's observation; this is no new training/quality proof.
    raw["native_traversal"] = "value-cursor"
    entry = (raw["case"], raw["iterations"], "value-cursor", raw["sample"])
    cases = {raw["case"]: raw["request_case"]}
    result = study.validate(raw, entry, deps, cases)
    if result["status"] != "complete":
        raise ValueError("expected saved completion")
    receipts.append({"artifact": path.name, "sha256": sha(raw_bytes)})
after = {name: sha((repo / name).read_bytes()) for name in names}
(out / "source-after.json").write_text(json.dumps(after, indent=2))
if before != after or len(receipts) != 10:
    raise ValueError("source drift or wrong completion count")
(out / "receipt.json").write_text(json.dumps({"status":"pass","cases":receipts,
    "projection":"Added study-level native_traversal=value-cursor only; no policy/wire/receipt modification.",
    "scope":"Saved-only validator compatibility, not new training or quality evidence."}, indent=2))
print(json.dumps({"status":"pass","cases":len(receipts)}))

