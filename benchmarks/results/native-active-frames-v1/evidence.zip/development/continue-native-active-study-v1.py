"""Reuse two immutable observations; launch only the 35 unattempted requests.

The frozen producer remains 0be1a85. Correct only the parent validator's
expectation of optional active-payload metadata; raw V4/ROUTE/ADMISSION/FRAME
proof requirements, policy digests and all mathematical checks remain unchanged.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
prior = work / "native-active-frames-study-v1"
output = work / "native-active-frames-study-continuation-v1"
engine = work / "native-active-engine-build-v1/engine/native-exact-four-street-train.exe"
sys.path.insert(0, str(repo))
from scripts import benchmark_native_active_frames as study
source = study._authenticate_source()
if source["commit"] != "0be1a858fb5983df21698d97b2a1f8e5e7295505":
    raise ValueError("frozen producer source differs")
def sha(raw): return hashlib.sha256(raw).hexdigest()
manifest_raw = (prior / "manifest.json").read_bytes()
manifest = json.loads(manifest_raw)
for name, digest in manifest["files"].items():
    if sha((prior / name).read_bytes()) != digest:
        raise ValueError("prior manifest artifact drift: " + name)
captures = json.loads((prior / "capture-time-sha256.json").read_bytes())
study._check_captured(prior, captures)
if json.loads((prior / "source-before.json").read_bytes()) != source or json.loads((prior / "source-after.json").read_bytes()) != source:
    raise ValueError("prior source differs")
saved = {}
for entry in study.SCHEDULE[:2]:
    identifier = study.label(entry)
    status = json.loads((prior / (identifier + "-process-status.json")).read_bytes())
    stdout = (prior / (identifier + ".stdout.bin")).read_bytes()
    stderr = (prior / (identifier + ".stderr.bin")).read_bytes()
    if status["returncode"] != 0 or sha(stdout) != status["stdout_sha256"] or sha(stderr) != status["stderr_sha256"]:
        raise ValueError("prior process capture differs")
    saved[entry] = subprocess.CompletedProcess([], 0, stdout, stderr)
original_validate, original_need = study.validate, study._need
counts = {"reused": 0, "new_producers": 0}
def validate_actual_schema(raw, entry, deps, cases):
    if entry[2] != "active-frames":
        return original_validate(raw, entry, deps, cases)
    payload = raw.get("payload")
    if payload is None:
        return original_validate(raw, entry, deps, cases)
    original_need(payload.get("training_backend") == "native-exact-four-street-active-frames-v4" and
        payload.get("native_traversal") == "active-frames" and
        payload.get("native_routing") in (None, "indexed") and
        payload.get("native_admission") in (None, "indexed-v1"),
        "active payload differs from its frozen actual schema")
    def require(value, message):
        if message == "backend/traversal/admission marker mismatch":
            return  # Exact active schema independently checked above; raw proof below is unchanged.
        return original_need(value, message)
    with patch.object(study, "_need", new=require):
        return original_validate(raw, entry, deps, cases)
def invoke(command):
    entry = (command[command.index("--child") + 1], int(command[command.index("--iterations") + 1]),
        command[command.index("--traversal") + 1], int(command[command.index("--sample") + 1]))
    if entry in saved:
        counts["reused"] += 1
        return saved[entry]
    counts["new_producers"] += 1
    return subprocess.run(command, cwd=repo, capture_output=True, check=False)
protocol = {"source": source["commit"], "prior_manifest_sha256": sha(manifest_raw),
    "prior_capture_map_sha256": sha((prior / "capture-time-sha256.json").read_bytes()),
    "reused_entries": study.SCHEDULE[:2], "new_entries": study.SCHEDULE[2:],
    "correction": "Accept absent active top-level native_routing/native_admission while independently requiring active backend/traversal and unchanged raw V4/ROUTE/ADMISSION/FRAME proofs. No payload mutation.",
    "helper_sha256": sha(Path(__file__).read_bytes()), "counts": counts}
protocol_path = work / "native-active-frames-study-continuation-v1-protocol.json"
with protocol_path.open("x") as stream:
    json.dump(protocol, stream, indent=2)
with patch.object(study, "validate", new=validate_actual_schema), patch.object(study, "_run_child", new=invoke):
    result = study.run(output, engine)
protocol["counts"] = counts
protocol["result"] = result
with (work / "native-active-frames-study-continuation-v1-completion.json").open("x") as stream:
    json.dump(protocol, stream, indent=2)
print(json.dumps(protocol["result"]), flush=True)
raise SystemExit(0 if result["outcome"] == "complete" else 1)
