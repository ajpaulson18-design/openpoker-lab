"""Configure the installed compiler for a durable development test invocation."""
import json
import os
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
engine = work / "native-active-engine-build-v1/engine/native-exact-four-street-train.exe"
manifest = json.loads((engine.parent / "native-exact-build-manifest.json").read_bytes())
out = work / ("native-active-development-tests-" + sys.argv[1])
out.mkdir(exist_ok=False)
compiler = Path(manifest["compiler"])
setup = out / "setup.cmd"
setup.write_text('@call "' + str(compiler.parents[6] / "Auxiliary/Build/vcvars64.bat") + '" >nul\n@if errorlevel 1 exit /b 1\n@set\n')
configured = subprocess.run(["cmd.exe", "/d", "/c", str(setup)], capture_output=True)
(out / "setup-stderr.log").write_bytes(configured.stderr)
if configured.returncode:
    raise SystemExit(configured.returncode)
environment = os.environ.copy()
for line in configured.stdout.decode("utf-8", "replace").splitlines():
    key, sep, value = line.partition("=")
    if sep and key.upper() in ("PATH", "INCLUDE", "LIB", "LIBPATH"):
        environment[key.upper()] = value
environment["OPENPOKER_NATIVE_EXACT_FOUR_STREET_EXE"] = str(engine)
environment["OPENPOKER_NATIVE_ACTIVE_CONTROL_DIR"] = str(out / "independent")
command = [sys.executable, "-B", *sys.argv[2:]]
with (out / "stdout.log").open("wb") as stdout, (out / "stderr.log").open("wb") as stderr:
    result = subprocess.run(command, cwd=repo, env=environment, stdout=stdout, stderr=stderr)
(out / "status.json").write_text(json.dumps({"command": command, "returncode": result.returncode}, indent=2))
print(json.dumps({"out": str(out), "returncode": result.returncode}), flush=True)
raise SystemExit(result.returncode)
