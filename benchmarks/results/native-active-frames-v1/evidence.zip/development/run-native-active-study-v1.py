"""Durable launcher for the fixed study, with authoritative process completion."""
import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
output = work / "native-active-frames-study-v1"
engine = work / "native-active-engine-build-v1/engine/native-exact-four-street-train.exe"
command = [sys.executable, "-B", "-m", "scripts.benchmark_native_active_frames",
           "--output", str(output), "--native-executable", str(engine)]
with (work / "native-active-frames-study-v1.stdout.log").open("xb") as stdout, \
     (work / "native-active-frames-study-v1.stderr.log").open("xb") as stderr:
    result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
status = {"command": command, "returncode": result.returncode}
with (work / "native-active-frames-study-v1-launch-status.json").open("x") as stream:
    json.dump(status, stream, indent=2)
print(json.dumps(status), flush=True)
raise SystemExit(result.returncode)
