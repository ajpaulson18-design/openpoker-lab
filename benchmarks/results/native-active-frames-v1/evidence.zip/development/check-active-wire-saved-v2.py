"""Saved-only conformance against the immutable prior V3 capacity records."""
import base64
import hashlib
import json
from pathlib import Path
import sys

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
out = work / "native-active-wire-saved-v2"
out.mkdir(exist_ok=False)
names = ["scripts/benchmark_native_active_frames.py", "tests/test_benchmark_native_active_frames.py"]
def sha(raw): return hashlib.sha256(raw).hexdigest()
before = {name: sha((repo / name).read_bytes()) for name in names}
(out / "source-before.json").write_text(json.dumps(before, indent=2))
sys.path.insert(0, str(repo))
from scripts import benchmark_native_active_frames as study
prior = work / "native-indexed-admission-study-continuation-v2"
manifest = json.loads((prior / "manifest.json").read_bytes())
receipts = []
for path in sorted(prior.glob("*.stdout.bin")):
    raw_bytes = path.read_bytes()
    if sha(raw_bytes) != manifest["sha256"][path.name]:
        raise ValueError("prior artifact drift: " + path.name)
    raw = json.loads(raw_bytes)
    payload = raw.get("payload")
    if not payload or raw.get("native_admission") != "indexed-v1":
        continue
    request = base64.b64decode(raw["native_streams"][0]["request"], validate=True)
    census = payload["operator_census"]
    got = study._wire_census(request, expected_header="OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_V3",
        expected_iterations=raw["iterations"], expected_hands=census["kernel"]["hands"],
        direct=census["direct_topology"])
    expected = census["native_exact"]["indexed_admission"]
    if any(expected[name] != value for name, value in got["admission_amounts"].items()):
        raise ValueError("removed forecast differs: " + path.name)
    if got["group_size"] != census["native_exact"]["group_size"]:
        raise ValueError("group differs: " + path.name)
    receipts.append({"artifact":path.name,"sha256":sha(raw_bytes),
        "request_sha256":sha(request),"forecast":got["admission_amounts"],"group_size":got["group_size"]})
after = {name: sha((repo / name).read_bytes()) for name in names}
(out / "source-after.json").write_text(json.dumps(after, indent=2))
if before != after or len(receipts) != 10:
    raise ValueError("source drift or wrong indexed completion count: " + str(len(receipts)))
(out / "receipt.json").write_text(json.dumps({"status":"pass","cases":receipts,
    "scope":"Saved-only raw V3 graph/group/removed-work conformance. No solve, replay or archived source execution."}, indent=2))
print(json.dumps({"status":"pass","cases":len(receipts)}))

