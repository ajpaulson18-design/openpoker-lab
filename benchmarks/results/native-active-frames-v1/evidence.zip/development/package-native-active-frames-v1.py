"""Package immutable study/development/source evidence after independent acceptance."""
import hashlib
import json
from pathlib import Path
import zipfile

work = Path(__file__).resolve().parent
repo = work / "native-active-frame-repo"
output = work / "native-active-frames-evidence-v1.zip"
if output.exists():
    raise ValueError("evidence archive already exists")
def sha(raw): return hashlib.sha256(raw).hexdigest()
completion = json.loads((work / "native-active-frames-study-continuation-v1-completion.json").read_bytes())
if completion["result"]["outcome"] != "complete" or completion["counts"] != {"reused":2,"new_producers":35}:
    raise ValueError("distinct-attempt study is incomplete")
review = work / "native-active-frames-independent-review-v1"
if not review.is_dir():
    raise ValueError("independent review is required before packaging")
accepted = [path for path in review.rglob("receipt.json")
            if json.loads(path.read_bytes()).get("status") == "passed"]
if len(accepted) != 1:
    raise ValueError("one completed independent acceptance receipt is required")
members = {}
def add(name, path):
    if name in members or not path.is_file() or path.is_symlink():
        raise ValueError("duplicate/nonordinary evidence input: " + name)
    members[name] = path.read_bytes()
directories = ("native-active-frames-study-v1", "native-active-frames-study-continuation-v1",
    "native-active-frames-independent-review-v1", "native-active-engine-build-v1",
    "native-active-cfr-controls-v2", "native-active-development-tests-independent-v1",
    "native-active-development-tests-active-v2", "native-active-development-tests-combined-v3",
    "native-active-development-tests-optimized-v4", "native-active-wire-saved-v1",
    "native-active-wire-saved-v2", "native-active-saved-validation-v1", "native-active-saved-validation-v2")
for name in directories:
    for path in sorted((work / name).rglob("*")):
        if path.is_file() and not any(part in ("__pycache__", "boost-include") for part in path.parts):
            add("evidence/" + name + "/" + path.relative_to(work / name).as_posix(), path)
for pattern in ("*active*.py", "active-*.log", "active-*-source-*.txt", "active-*-preserved.cpp",
    "native-active-*.log", "native-active-*.json", "native-active-*.txt"):
    for path in sorted(work.glob(pattern)):
        name = "development/" + path.name
        if name not in members and path != Path(__file__):
            add(name, path)
source = json.loads((work / "native-active-frames-study-v1/source-before.json").read_bytes())
if source["commit"] != "0be1a858fb5983df21698d97b2a1f8e5e7295505":
    raise ValueError("wrong frozen source")
for name, digest in source["sha256"].items():
    # Full closure maps authenticate every tracked file. Capture executable/math
    # source and canonical contracts here without recursively embedding old archives.
    selected = (name.startswith(("pokerlab/", "scripts/", "native/", "tests/")) and
        Path(name).suffix in (".py", ".hpp", ".cpp")) or name.startswith("third_party/boost-multiprecision-") or name in (
            "AGENTS.md", ".gitattributes", ".github/workflows/native-exact-four-street.yml",
            "docs/native-active-frames.md", "docs/decisions/DECISION_LOG.md")
    if selected:
        path = repo / name
        if sha(path.read_bytes()) != digest:
            raise ValueError("frozen capture source drift: " + name)
        add("source/" + name, path)
add("development/package-native-active-frames-v1.py", Path(__file__))
add("development/exact-selected-independent-review.py", work / "exact-selected-independent-review.py")
manifest = {"contract":"native-active-frames-archive-v1","producer_commit":source["commit"],
    "source_scope":"All tracked raw/Git maps retained; executable/math/test sources and pinned dependencies captured, prior historical artifact contents referenced by those maps rather than recursively copied.",
    "files":{name:sha(raw) for name,raw in sorted(members.items())}}
manifest_raw = (json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
with zipfile.ZipFile(output,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(members.items()): archive.writestr(name,raw)
    archive.writestr("manifest.json",manifest_raw)
receipt = {"archive":output.name,"bytes":output.stat().st_size,"entries":len(members)+1,
    "sha256":sha(output.read_bytes()),"manifest_sha256":sha(manifest_raw)}
with (work / "native-active-frames-package-v1.json").open("x") as stream:
    json.dump(receipt,stream,indent=2)
print(json.dumps(receipt),flush=True)
