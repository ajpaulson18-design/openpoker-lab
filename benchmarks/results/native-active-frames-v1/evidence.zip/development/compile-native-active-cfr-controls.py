"""Reuse authenticated V4 engine inputs; compile and run controls separately."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
REPO = WORK / "native-active-frame-repo"
BUILD = WORK / "native-active-engine-build-v1/engine"
OUT = WORK / "native-active-cfr-controls-v2"
OUT.mkdir(exist_ok=False)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def put(name, value):
    (OUT / name).write_bytes((json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
manifest = json.loads((BUILD / "native-exact-build-manifest.json").read_bytes())
if any(sha(REPO / name) != digest for name,digest in manifest["source_sha256"].items()):
    raise ValueError("engine source changed before direct controls")
compiler = Path(manifest["compiler"])
vcvars = compiler.parents[6] / "Auxiliary/Build/vcvars64.bat"
setup = OUT / "setup.cmd"
setup.write_text('@call "' + str(vcvars) + '" >nul\n@if errorlevel 1 exit /b 1\n@set\n', encoding="utf-8")
configured = subprocess.run(["cmd.exe", "/d", "/c", str(setup)], capture_output=True)
(OUT / "setup-stderr.log").write_bytes(configured.stderr)
if configured.returncode:
    raise RuntimeError("compiler environment unavailable")
environment = os.environ.copy()
for line in configured.stdout.decode("utf-8", "replace").splitlines():
    key, sep, value = line.partition("=")
    if sep and key.upper() in ("PATH", "INCLUDE", "LIB", "LIBPATH"):
        environment[key.upper()] = value
for key in ("CL", "_CL_", "LINK", "_LINK_"):
    environment.pop(key, None)
names = [*manifest["source_sha256"], "tests/native/exact_selected_cfr_controls.cpp"]
before = {name:sha(REPO / name) for name in names}
put("source-before.json", before)
for name in names:
    target = OUT / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((REPO / name).read_bytes())
command = [manifest["compiler"], *manifest["flags"], "/I" + str(REPO / "native"),
    str(REPO / "tests/native/exact_selected_cfr_controls.cpp"), "/Fo" + str(OUT / "controls.obj"), "/Fe" + str(OUT / "controls.exe")]
result = subprocess.run(command, cwd=OUT, env=environment, capture_output=True)
(OUT / "compiler-stdout.log").write_bytes(result.stdout)
(OUT / "compiler-stderr.log").write_bytes(result.stderr)
put("status.json", {"compile_returncode":result.returncode,"command":command})
if result.returncode:
    raise SystemExit(result.returncode)
ran = subprocess.run([str(OUT / "controls.exe")], cwd=OUT, capture_output=True)
(OUT / "run-stdout.log").write_bytes(ran.stdout)
(OUT / "run-stderr.log").write_bytes(ran.stderr)
after = {name:sha(REPO / name) for name in names}
put("source-after.json", after)
receipt = {"compile_returncode":0,"run_returncode":ran.returncode,"source_stable":before==after,"control_sha256":sha(OUT / "controls.exe")}
put("status.json", receipt)
print(json.dumps(receipt), flush=True)
raise SystemExit(ran.returncode if before==after else 3)
