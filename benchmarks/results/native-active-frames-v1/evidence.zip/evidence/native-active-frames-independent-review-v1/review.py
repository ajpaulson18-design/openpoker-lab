"""Independent saved-only active-frame review. Never invokes a producer.

Raw/Git source, 198-header build, prior failure, continuation and archive are
authenticated before importing current independent replay/certificate modules.
The public DAG census/orbit/FRAME checks below use only this file's parser.
"""
import argparse
import base64
from collections import Counter, deque
from contextlib import ExitStack
import hashlib
from itertools import combinations, permutations
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics
import struct
import sys
import types
from unittest.mock import patch
import zipfile

COMMIT = '0be1a858fb5983df21698d97b2a1f8e5e7295505'
AUTH = '8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
CONTINUATION = 'd32352f9efc9b6d7c9cb458a4e5a6262d77868b5e17510d24f2fd09ffac8d643'
EXE = 'a362bbcb9d732ba019a362b194cdb5c2e70115403108b0b5a6808a975e7ea6b5'
BUILD = 'e1637cca2e2abfa41735ec3e5bd093f431531cdc72185bdf943e9109b85c1a3e'
DECK = tuple(r+s for r in '23456789TJQKA' for s in 'cdhs')
ORDER = {c:i for i,c in enumerate(DECK)}
METRICS = ('value_sb','value_bb','sb_best_response_value','bb_best_response_value',
           'sb_gain','bb_gain','nash_conv','exploitability')
BASE = ('original-22-t10','payoff-varied-t10','blocker-18','asymmetric-weighted','mixed-stabilizer','physical-g6')
MATRIX = ('original-weighted-2x2','balanced-4x4-unit','balanced-8x8-unit','balanced-16x16-unit','asymmetric-2x16-unit')
MODES = ('value-cursor','active-frames')
SCHEDULE = [(n,10,m,0) for n in BASE for m in MODES]
SCHEDULE += [('original-22-t10',10,'active-frames',1),('original-22-t10',10,'value-cursor',1),
             ('original-22-t10',10,'value-cursor',2),('original-22-t10',10,'active-frames',2)]
SCHEDULE += [('original-22-t10',t,m,0) for t in (40,60,100) for m in MODES]
SCHEDULE += [('payoff-varied-t100',100,m,0) for m in MODES]
SCHEDULE += [(n,t,'active-frames',0) for n in MATRIX for t in (10,100,1000)
             if (n,t) not in ((MATRIX[0],10),(MATRIX[0],100))]
DONE = ('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots',
        'member_checks','expected_member_checks','modeled_work_upper','kernel_work_upper','retained_entries_upper',
        'maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls')
ROUTE = ('q_rows map_entries map_upper r_lookup_entries old_q_histories_retained q_routes q_routes_upper '
         'q_tokens q_tokens_upper roots roots_upper edges edges_upper decisions decisions_upper prefixes prefixes_upper '
         'decision_comparisons prefix_comparisons legacy_extensions legacy_rows legacy_prefixes router_work router_work_upper '
         'index_work index_work_upper index_entries index_entries_upper router_retained router_retained_upper '
         'setup_scratch_upper query_scratch_upper cursor_fields cursor_frames_upper combined_work combined_entries '
         'caller_work caller_entries old_kernel_overlap old_history_forecast final_router_entries').split()
ADMISSION = ('plan_legacy_lookup_removed plan_legacy_action_removed trainer_legacy_history_removed plan_setup_work '
             'index_setup_work router_setup_work trainer_history_retained marginal_calls_upper marginal_calls_actual '
             'marginal_reuse combined_work combined_entries').split()
FRAME = ('group_size frames image_slots header_entries workspace_entries workspace_setup_work view_fields lease_fields '
         'borrowed_entries_upper flow_per_visit flow_work_upper validation_work_upper activations activations_upper '
         'released_frames release_calls final_active_frames final_workspace_entries value_cursor_learning_calls '
         'router_owned_workspace combined_work combined_entries').split()
RESOURCE = re.compile(r'\b(?:admission|capacity|limit|cap|forecast|budget|ceiling|preflight|envelope)\b[^\n]*\bexceeded\b'
    r'|\bexceeds?\b[^\n]*\b(?:envelope|ceiling|limit|cap|capped|slots|states|depth|decisions|rows|work)\b'
    r'|\b(?:is |are )?capped at\b|\bno retained-entry allowance remains\b'
    r'|\bindexed router whole-work limit is below its bounded schedule scan floor\b'
    r'|\bhistory-index bounded input scan exceeds remaining combined work before token scan\b',re.I)

def check(value, message):
    if not value:
        raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def bits(value): return struct.pack('>d',value).hex()
def label(entry): return f'{entry[0]}-t{entry[1]}-{entry[2]}-p{entry[3]}'
def write(path,value):
    with path.open('xb') as stream:
        stream.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
def bounded(message):
    return type(message) is str and not re.search(r'\b(?:stale|unsupported|missing|mismatch|invalid|requires|wrong|unknown)\b|already reserved|cannot exceed',message,re.I) and RESOURCE.search(message) is not None

def inventory(root):
    check(root.is_dir() and not root.is_symlink(),'ordinary evidence directory required')
    result={}
    for path in root.rglob('*'):
        check(not path.is_symlink(),'symlink evidence rejected')
        if path.is_file():
            check(path.stat().st_size<=256*1024*1024,'individual saved artifact cap')
            result[path.relative_to(root).as_posix()]=path.read_bytes()
    check(sum(map(len,result.values()))<=1024*1024*1024,'saved inventory cap')
    return result

def manifested(root,pin,parse):
    files=inventory(root)
    check(sha(files['manifest.json'])==pin,'external manifest pin')
    manifest=parse(files['manifest.json'])
    check(manifest['version']=='native-active-frames-evidence-manifest-v1','manifest contract')
    hashes=manifest['files']
    check(set(files)==set(hashes)|{'manifest.json'},'full evidence inventory')
    for name,digest in hashes.items():
        check(str(PurePosixPath(name))==name and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,
              'noncanonical evidence path')
        check(sha(files[name])==digest,'manifest artifact '+name)
    return files

def literal_range(expression):
    rows=[];seen=set()
    for token in expression.split(','):
        match=re.fullmatch(r'([2-9TJQKA][cdhs])([2-9TJQKA][cdhs])(?::([0-9]+(?:\.[0-9]+)?))?',token)
        check(match is not None,'independent fixture literal range grammar')
        a,b,weight=match.groups();hand=''.join(sorted((a,b)))
        value=float(weight) if weight else 1.
        check(a!=b and hand not in seen and math.isfinite(value) and value>0,'independent fixture prior')
        seen.add(hand);rows.append({'hand':hand,'weight_hex':value.hex()})
    check(0<len(rows)<=16,'independent structural replay holding cap')
    return rows

def cases_from_data(repo,parse):
    original=dict(parse((repo/'benchmarks/four-street-integration-v1.json').read_bytes())['case'],id='original-22-exact-product-study')
    def small(identifier,sb,bb):
        street={'bet_sizes':[.5],'raise_sizes':[],'max_raises':0,'include_all_in':False}
        return dict(id=identifier,sb_range=sb,bb_range=bb,
            config={'starting_stack':[2,2],'small_blind':.5,'big_blind':1,'raise_sizes':[.5],'max_raises':1,'include_all_in':False},
            runouts=['2c3c4h5s6h','2d3d4h5s6h'],flop_config=dict(street),turn_config=dict(street),river_config=dict(street))
    result={'original-22-t10':original,'original-weighted-2x2':dict(original),
        'blocker-18':small('blocker-conditioned-18-worlds-v1','AcAh,AdAh,2cAh,2dAh','KcKh,KdKh,3cKh,3dKh'),
        'asymmetric-weighted':small('weighted-asymmetric-suit-exchange-v1','AcAh:0.7,AdAh:0.3','KcKh:0.4,KdKh:0.6'),
        'mixed-stabilizer':small('mixed-suit-stabilizer-v1','AcAd','KcKd')}
    payoff=small('payoff-varied-private-flush-v1','AcQc,AdQd','KcJc,KdJd');payoff['runouts']=['2c3c7c9hTs','2d3d7d9hTs']
    result.update({'payoff-varied-t10':payoff,'payoff-varied-t100':dict(payoff),
        'physical-g6':dict(original,id='active-frame-physical-s3-v1',sb_range='AdAh,AdAs,AhAs',bb_range='KdKh,KdKs,KhKs',runouts=['2c3c4c7c8c'])})
    for name in MATRIX[1:]:
        counts=(2,16) if name==MATRIX[-1] else (int(name.split('-')[1].split('x')[0]),)*2
        case=dict(original,id='canonical-distinct-unit-'+name)
        for key,pool,count in zip(('sb_range','bb_range'),(('Ad','As','Qd','Qs','Ac','Ah','9c','9d'),('Kd','Ks','Jd','Jh','Qc','Qh','8d','8s')),counts):
            values=[]
            candidates=[tuple(t.split(':')[0][i:i+2] for i in (0,2)) for t in original[key].split(',')]+list(combinations(sorted(pool,key=ORDER.__getitem__),2))
            for pair in candidates:
                value=''.join(sorted(pair,key=ORDER.__getitem__))
                if value not in values and len(values)<count: values.append(value)
            check(len(values)==count,'canonical synthetic hand count')
            case[key]=','.join(values)
        result[name]=case
    return result

def board_inputs(case):
    result=[]
    for token in case['runouts']:
        check(len(token)==10,'fixed full selected board')
        cards=tuple(token[i:i+2] for i in range(0,10,2))
        check(all(c in ORDER for c in cards) and len(set(cards))==5,'fixed distinct selected cards')
        result.append(tuple(sorted(cards[:3],key=ORDER.__getitem__))+cards[3:])
    check(len(set(result))==len(result),'duplicate selected board')
    return sorted(result,key=lambda row:tuple(ORDER[c] for c in row))

def suit_group(wire):
    seats=[{(tuple(sorted(row['hand'])),row['weight_bits']) for row in side} for side in wire['ranges']]
    boards=set(map(tuple,wire['boards']));result=[]
    for image in permutations('cdhs'):
        def card(c):return c[0]+image['cdhs'.index(c[1])]
        if any({(tuple(sorted(map(card,pair))),weight) for pair,weight in side}!=side for side in seats):continue
        mapped=set()
        for board in boards:
            row=tuple(map(card,board));mapped.add(tuple(sorted(row[:3],key=ORDER.__getitem__))+row[3:])
        if mapped==boards:result.append(image)
    check(tuple('cdhs') in result,'suit identity absent')
    return result

def visible(history):
    result=[]
    for token in history:
        if token.startswith('flop@'):
            check(not result and len(token)==11,'invalid flop history');result.extend(token[i:i+2] for i in (5,7,9))
        elif token.startswith('turn@'):
            check(len(result)==3 and len(token)==7,'invalid turn history');result.append(token[5:])
        elif token.startswith('river@'):
            check(len(result)==4 and len(token)==8,'invalid river history');result.append(token[6:])
    check(all(c in ORDER for c in result) and len(set(result))==len(result),'invalid revealed cards')
    return tuple(result)

def transformed(history,image):
    def card(c):return c[0]+image['cdhs'.index(c[1])]
    result=[]
    for token in history:
        if token.startswith('flop@'):result.append('flop@'+''.join(sorted((card(token[i:i+2]) for i in (5,7,9)),key=ORDER.__getitem__)))
        elif token.startswith('turn@'):result.append('turn@'+card(token[5:]))
        elif token.startswith('river@'):result.append('river@'+card(token[6:]))
        else:result.append(token)
    return tuple(result)

def graph_census(wire,payload):
    """Bounded literal full-history walk; verifier-only rows, no producer graph APIs."""
    initial=tuple(wire['initial_history']);stack=[(wire['root'],initial)]
    visits=decisions=terminals=dh=actions=he=rb=depth=0;ht=len(initial)
    initial_bytes=sum(map(len,initial));hb=initial_bytes;transition_tokens=transition_bytes=0
    rows={};all_prefixes=set();marginals=set();supported={};decision_histories=set()
    while stack:
        node,history=stack.pop();v=wire['vertices'][node];visits+=1
        check(visits<=250000 and len(history)-len(initial)<=64,'independent occurrence/depth cap')
        ht+=len(history);hb+=sum(map(len,history));depth=max(depth,len(history)-len(initial))
        check(ht<=16000000 and hb<=16000000,'independent history budget')
        prefix=visible(history);indexes=tuple(i for i,b in enumerate(wire['boards']) if tuple(b[:len(prefix)])==prefix)
        check(indexes,'revealed prefix absent selected boards');all_prefixes.add(prefix)
        if prefix not in supported:
            sides=[set(),set()]
            for i,a in enumerate(wire['ranges'][0]):
                for j,b in enumerate(wire['ranges'][1]):
                    private=a['hand']+b['hand']
                    if len(set(private))==4 and any(not set(private).intersection(wire['boards'][k]) for k in indexes):
                        sides[0].add(i);sides[1].add(j)
            supported[prefix]=sides
        if v['kind']=='D':
            check(history not in decision_histories,'duplicate semantic decision history');decision_histories.add(history)
            decisions+=1;actor=v['actor'];a=len(v['actions']);dh+=len(wire['ranges'][actor]);actions+=a
            he+=len(history)+a;rb+=sum(map(len,history))+64*a;marginals.add(indexes)
            for h in supported[prefix][actor]:
                key=(actor,h,history);check(key not in rows and len(rows)<2000000,'independent R-row cap/identity');rows[key]=v['actions']
            edges=[(act['token'],child) for act,child in zip(v['actions'],v['children'])]
        elif v['kind']=='C':edges=[(('flop@','turn@','river@')[v['street']-1]+s,child) for s,child in v['branches']]
        else:terminals+=1;edges=[]
        transition_tokens+=len(edges);transition_bytes+=sum(len(t) for t,_ in edges)
        stack.extend((child,history+(token,)) for token,child in edges)
        check(len(stack)<=250000 and len(all_prefixes)<=2000000 and rb<=16000000,'structural verifier storage budget')
    direct=payload['operator_census']['direct_topology']
    for key,value in dict(expanded_logical_visits=visits,decision_occurrences=decisions,terminal_occurrences=terminals,maximum_depth=depth,
            logical_history_token_work=ht-len(initial)+transition_tokens,logical_history_token_bytes=hb-initial_bytes+transition_bytes).items():
        check(direct[key]==value,'independent graph census '+key)
    group=suit_group(wire);G=len(group);T=wire['iterations']
    lookup=G*(128*ht+256*dh);one=G*(16*he+4*rb+8*(depth+1)*dh+16*(depth+1)*visits)
    handmaps=[{tuple(sorted(r['hand'])):i for i,r in enumerate(side)} for side in wire['ranges']]
    orbits={};q_tokens=0
    for key,menu in rows.items():
        actor,h,history=key;members=set()
        for image in group:
            mappedhand=tuple(sorted(c[0]+image['cdhs'.index(c[1])] for c in wire['ranges'][actor][h]['hand']))
            k=(actor,handmaps[actor][mappedhand],transformed(history,image))
            check(k in rows and rows[k]==menu,'suit image lacks exact ordered row/menu closure');members.add(k)
        canonical_key=min(members)
        if canonical_key not in orbits:orbits[canonical_key]=len(menu);q_tokens+=len(canonical_key[2])
    return dict(visits=visits,decisions=decisions,terminals=terminals,depth=depth,group_size=G,expanded_rows=len(rows),
        expanded_action_slots=sum(map(len,rows.values())),quotient_rows=len(orbits),quotient_action_slots=sum(orbits.values()),q_tokens=q_tokens,
        rows=rows,amounts=dict(plan_legacy_lookup_removed=3*T*lookup,plan_legacy_action_removed=6*T*32*actions,
        trainer_legacy_history_removed=3*T*one,trainer_history_retained=4*one),marginal_calls_upper=len(all_prefixes),marginal_calls_actual=len(marginals))

def proof_record(line,tag,mode,names):
    cells=line.split('\t');check(cells[:2]==[tag,mode] and len(cells)==len(names)+2,'raw '+tag+' shape')
    result={}
    for cell in cells[2:]:
        key,sep,value=cell.partition('=')
        check(sep and key not in result and value.isascii() and value.isdecimal() and len(value)<=20,'invalid raw proof integer')
        result[key]=int(value)
    check(set(result)==set(names),'raw '+tag+' field closure')
    return result

def validate_completed(raw,entry,case):
    name,T,mode,sample=entry;x=raw['payload'];nc=x['operator_census']['native_exact']
    encoded=canonical(x)
    check((sha(encoded),len(encoded))==(raw['payload_sha256'],raw['payload_bytes']),'complete payload hash/length')
    if mode=='active-frames':
        check(x.get('training_backend')=='native-exact-four-street-active-frames-v4' and x.get('native_traversal')=='active-frames','actual active schema')
        for key,value in (('native_routing','indexed'),('native_admission','indexed-v1')):
            check(key not in x or x[key]==value,'optional active marker must be absent or exact, never null')
    else:
        check(x.get('training_backend')=='native-exact-four-street-indexed-admission-v3' and x.get('native_routing')=='indexed' and
              x.get('native_admission')=='indexed-v1' and 'native_traversal' not in x,'strict V3 schema')
    for key,value in (('chance_contract','exact-product-selected-v1'),('conversion_contract','exact-product-vectors-binary64-v1'),
            ('training_reduction','suit-equivariant-sorted-chance-binary64-v1'),('pair_diagnostics','compact-exact-product-inputs-v1')):
        check(x.get(key)==value,'complete contract '+key)
    check('private_pair_probabilities' not in x and 'compatible_private_pairs' not in x,'unexpected production pair rows')
    check(all(type(x.get(k)) in (float,int) and math.isfinite(x[k]) for k in METRICS),'all eight finite metrics')
    check(x['operator_census']['stored_complete_worlds']==x['operator_census']['stored_prefix_pair_edges']==0,'production world/pair storage')
    stream=raw['native_streams'][0]
    check(set(stream)=={'request','stdout','stderr','returncode'} and stream['returncode']==0,'native stream closure')
    request,output,error=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'))
    check(not error and (sha(request),sha(output),len(request),len(output))==
          (nc['request_sha256'],nc['result_sha256'],nc['request_bytes'],nc['result_bytes']),'native streams/payload binding')
    wire=parse_wire(request,mode);check(wire['iterations']==T and wire['rank_cache_boards']==64,'wire schedule/cache')
    expected_ranges=[literal_range(case[key]) for key in ('sb_range','bb_range')]
    check(x['chance_input_snapshot']=={'contract':'exact-product-selected-v1','ranges':expected_ranges},'compact exact fixture snapshot')
    for side,expected in zip(wire['ranges'],expected_ranges):
        check([{'hand':''.join(sorted(row['hand'])),'weight_hex':struct.unpack('>d',bytes.fromhex(row['weight_bits']))[0].hex()}
               for row in side]==expected,'original wire range index/prior bits')
    check([tuple(b) for b in wire['boards']]==board_inputs(case) and x['selected_runouts']==[list(b) for b in board_inputs(case)],'original selected ordered boards')
    census=graph_census(wire,x);lines=output.decode('ascii').splitlines()
    expected_magic='OPENPOKER_NATIVE_EXACT_FOUR_STREET_'+('ACTIVE_FRAMES_RESULT_V4' if mode=='active-frames' else 'INDEXED_ADMISSION_RESULT_V3')
    check(lines[0]==expected_magic,'native result protocol')
    records={};rawrows=[];phase=0
    for line in lines[1:]:
        cells=line.split('\t');tag=cells[0]
        if tag=='ROW':check(phase==0,'ROW after proof');rawrows.append(cells)
        else:
            expected_tags=('DONE','ROUTE','ADMISSION','FRAME') if mode=='active-frames' else ('DONE','ROUTE','ADMISSION')
            check(phase<len(expected_tags) and tag==expected_tags[phase],'unknown/duplicate/out-of-order result record')
            records[tag]=line;phase+=1
    check(phase==(4 if mode=='active-frames' else 3),'missing proof record')
    cells=records['DONE'].split('\t');check(len(cells)==14 and all(v.isascii() and v.isdecimal() and len(v)<=20 for v in cells[1:]),'DONE13 shape')
    done=dict(zip(DONE,map(int,cells[1:])));check(all(nc[k]==v for k,v in done.items()),'DONE/payload equality')
    route=proof_record(records['ROUTE'],'ROUTE','indexed',ROUTE);admission=proof_record(records['ADMISSION'],'ADMISSION','indexed-v1',ADMISSION)
    check(nc['indexed_routing']==dict(route,mode='indexed') and nc['indexed_admission']==dict(admission,mode='indexed-v1'),'raw route/admission receipt binding')
    for k in ('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots'):
        check(done[k]==census[k],'independent row/orbit census '+k)
    check(done['expanded_rows']==x['info_sets'] and done['member_checks']==done['expected_member_checks']==2*T*x['info_sets'] and
          done['maximum_numeric_workspace_slots']==4*done['quotient_action_slots'] and done['final_numeric_workspace_slots']==0 and done['rank_calls']>0,'member/workspace guards')
    check(raw['counts']['python_rank']==done['rank_calls'] and raw['native_observations']=={'learning_completed':True,'rank_calls':done['rank_calls']},'observed completed ranks')
    payloadrows={}
    for row in x['strategy']:
        actor={'sb':0,'bb':1}[row['player']];handidx=[r['hand'] for r in expected_ranges[actor]].index(row['hand']);history=tuple(row['history']);key=(actor,handidx,history)
        check(key not in payloadrows and key in census['rows'],'complete supported semantic row identity')
        menu=census['rows'][key];check(len(row['actions'])==len(menu),'ordered action count')
        check(row['revealed_board']==list(visible(history)) and row['street']==('preflop' if len(visible(history))==0 else {3:'flop',4:'turn',5:'river'}[len(visible(history))]),'row visible scope')
        for a,b in zip(row['actions'],menu):
            check(a['name']==b['name'] and a['history_key']==b['token'] and bits(a['amount'])==b['amount_bits'] and bits(a['raise_to'])==b['raise_to_bits'] and
                  type(a['probability']) in (int,float) and math.isfinite(a['probability']) and 0<=a['probability']<=1,'full ordered action/menu bits')
        payloadrows[key]=row
    check(set(payloadrows)==set(census['rows']) and len(rawrows)==len(payloadrows),'all supported rows present')
    seen=set()
    for cells in rawrows:
        check(len(cells)>=6 and all(s.isdecimal() and len(s)<=12 for s in cells[1:4]),'ROW scalar shape')
        actor,h,n=map(int,cells[1:4]);check(n<=64 and len(cells)>4+n,'ROW history bound');history=tuple(cells[4:4+n]);count=int(cells[4+n]);key=(actor,h,history)
        check(key in payloadrows and key not in seen and len(cells)==5+n+count and cells[5+n:]==[bits(a['probability']) for a in payloadrows[key]['actions']],'every raw policy bit')
        seen.add(key)
    check(seen==set(payloadrows),'native ROW completeness')
    for k,v in dict(roots=3*T,edges=3*T*(census['visits']-1),decisions=3*T*census['decisions'],prefixes=T*(2*census['terminals']+census['decisions'])).items():
        check(route[k]==route[k+'_upper']==v,'independent schedule '+k)
    check(route['q_rows']==route['map_entries']==route['map_upper']==route['q_routes']==route['q_routes_upper']==census['quotient_rows'] and
          route['q_tokens']==route['q_tokens_upper']==census['q_tokens'],'Q construction history/token identity')
    check(all(route[k]==0 for k in ('r_lookup_entries','decision_comparisons','prefix_comparisons','legacy_extensions','legacy_rows','legacy_prefixes','final_router_entries')) and
          route['old_q_histories_retained']==1 and route['cursor_fields']==(3 if mode=='active-frames' else 196),'indexed scope/cursor lifetime')
    check(all(type(route[k]) is int and 0<=route[k]<=route[k+'_upper'] for k in ('router_work','index_work','index_entries','router_retained')),'route bounds')
    check(all(admission[k]==v for k,v in census['amounts'].items()) and admission['marginal_calls_upper']==census['marginal_calls_upper'] and
          admission['marginal_calls_actual']==census['marginal_calls_actual'] and admission['marginal_reuse']==1 and
          route['old_history_forecast']==census['amounts']['trainer_history_retained'],'independent indexed removals/marginal reuse')
    combined=admission['plan_setup_work']+admission['index_setup_work']+admission['router_setup_work']+route['router_work_upper']+route['index_work_upper']+route['caller_work']
    check(combined==admission['combined_work']==route['combined_work']==done['modeled_work_upper']<=500000000 and
          admission['combined_entries']==route['combined_entries']==done['retained_entries_upper']<=2000000,'shared native whole ledger')
    res=x['operator_census']['whole_request_admission']['native_additional_admission']
    check(wire['limits'][4]==wire['limits'][7]==res['native_work_limit'] and wire['limits'][5]==wire['limits'][8]==res['native_entries_limit'] and
          combined<=res['native_work_limit'] and done['retained_entries_upper']<=res['native_entries_limit'] and done['kernel_work_upper']<=wire['limits'][1],'host remaining capacity')
    if mode=='active-frames':
        frame=proof_record(records['FRAME'],'FRAME','active-v1',FRAME);check(nc['active_frames']==dict(frame,mode='active-v1'),'raw FRAME binding')
        D=census['depth'];G=census['group_size'];H=max(map(len,wire['ranges']));active=3*T*census['visits'];workspace=64+(D+1)*(3+8*G);borrowed=4*(D+4)*6
        expected=dict(group_size=G,frames=D+1,image_slots=(D+1)*G,header_entries=3*(D+1),workspace_entries=workspace,workspace_setup_work=workspace,
            view_fields=3,lease_fields=3,borrowed_entries_upper=borrowed,flow_per_visit=88+8*G,flow_work_upper=workspace+active*(88+8*G),
            validation_work_upper=32*(1+G+H*(1+G))*route['decisions']+64*route['prefixes'],activations=active,activations_upper=active,
            released_frames=active,release_calls=active,final_active_frames=0,final_workspace_entries=0,value_cursor_learning_calls=0,router_owned_workspace=1,
            combined_work=combined,combined_entries=done['retained_entries_upper'])
        check(frame==expected,'independent full FRAME22 algebra')
        check(route['cursor_frames_upper']==workspace+borrowed and route['caller_entries']>=workspace+borrowed and
              route['caller_work']>=frame['flow_work_upper'] and route['router_work_upper']>=frame['validation_work_upper'],'FRAME correct owner component accounting')
    else:check('active_frames' not in nc,'V3 unexpectedly active')
    if name=='physical-g6':check(census['group_size']==6 and census['quotient_rows']<census['expanded_rows'],'noncommuting G6 fixture')
    return {k:v for k,v in census.items() if k!='rows'}


def parse_wire(raw, traversal):
    check(type(raw) is bytes and len(raw)<=64*1024*1024 and raw.endswith(b"\n"),"invalid native input envelope")
    tokens=raw.decode("ascii").split();check(len(tokens)<=10000000,"native input token cap")
    pos=0
    def take():
        nonlocal pos
        check(pos<len(tokens),"truncated native input")
        text=tokens[pos];pos+=1
        check(0<len(text)<=64 and all(32<ord(c)<127 for c in text),"invalid native token")
        return text
    def nat(ceiling):
        text=take();check(text.isdecimal() and len(text)<=12,"invalid natural field")
        value=int(text);check(value<=ceiling,"native natural exceeds independent cap");return value
    def fp():
        text=take();check(len(text)==16 and all(c in "0123456789abcdef" for c in text),"invalid exact FP bits")
        value=struct.unpack(">d",bytes.fromhex(text))[0];check(math.isfinite(value),"nonfinite native money/prior")
        return text
    check(take()==("OPENPOKER_NATIVE_EXACT_FOUR_STREET_ACTIVE_FRAMES_V4" if traversal=="active-frames" else "OPENPOKER_NATIVE_EXACT_FOUR_STREET_INDEXED_ADMISSION_V3"),"wrong input magic")
    iterations=nat(10000);cache=nat(64);h0,h1=nat(16),nat(16);b=nat(64);n=nat(250000);e=nat(1000000);root=nat(max(n-1,0));initial_n=nat(64)
    check(iterations>=10 and cache and h0 and h1 and b and n,"unsupported fixed input dimensions")
    caps=(65536,500000000,2000000,1<<30,500000000,2000000,16000000,500000000,2000000,1000000,2000000)
    limits=[nat(cap) for cap in caps];check(all(limits),"zero native limit")
    ranges=[]
    for h in (h0,h1):
        side=[]
        for _ in range(h):
            a,c=nat(51),nat(51);weight=fp();check(a!=c and struct.unpack(">d",bytes.fromhex(weight))[0]>0,"invalid positive holding")
            side.append({"hand":[DECK[a],DECK[c]],"weight_bits":weight})
        check(len({tuple(sorted(row["hand"])) for row in side})==h,"duplicate private holding")
        ranges.append(side)
    boards=[[DECK[nat(51)] for _ in range(5)] for _ in range(b)]
    check(all(len(set(outcome))==5 and outcome[:3]==sorted(outcome[:3],key=ORDER.__getitem__) for outcome in boards) and
         boards==sorted(boards,key=lambda outcome:tuple(ORDER[c] for c in outcome)) and len({tuple(v) for v in boards})==b,"noncanonical or duplicate native selected boards")
    initial=[take() for _ in range(initial_n)];vertices=[];edges=0
    for _ in range(n):
        tag=take()
        if tag=="D":
            actor=nat(1);count=nat(32);check(count>0,"empty action menu");actions=[];children=[]
            for _ in range(count):
                action={"name":take(),"amount_bits":fp(),"raise_to_bits":fp(),"full_raise":bool(nat(1)),"token":take()}
                actions.append(action);children.append(nat(n-1))
            check(len({a["token"] for a in actions})==count,"duplicate native action tokens")
            vertices.append({"kind":"D","actor":actor,"actions":actions,"children":children});edges+=count
        elif tag=="C":
            street=nat(3);index=nat(6);count=nat(64);check(street and count and index==street+3,"wrong native reveal index/street")
            branches=[(take(),nat(n-1)) for _ in range(count)];check(len({v[0] for v in branches})==count,"duplicate chance labels")
            vertices.append({"kind":"C","street":street,"card_index":index,"branches":branches});edges+=count
        elif tag in ("F","S"):
            winner=nat(1) if tag=="F" else None
            contributions=[fp(),fp()];check(all(struct.unpack(">d",bytes.fromhex(value))[0]>=0 for value in contributions),"negative terminal money")
            vertices.append({"kind":tag,"winner":winner,"contribution_bits":contributions})
        else:raise ValueError("unknown native wire field/vertex tag")
    check(pos==len(tokens) and edges==e,"unknown trailing native fields or edge mismatch")
    def children(v):return v["children"] if v["kind"]=="D" else [child for _,child in v["branches"]] if v["kind"]=="C" else []
    degrees=[0]*n
    for vertex in vertices:
        for child in children(vertex):degrees[child]+=1
    queue=deque(i for i,d in enumerate(degrees) if d==0);order=[]
    while queue:
        i=queue.popleft();order.append(i)
        for child in children(vertices[i]):
            degrees[child]-=1
            if degrees[child]==0:queue.append(child)
    check(len(order)==n,"native graph cycle")
    reached={root};depth={root:0}
    for i in order:
        check(i in reached,"native graph unreachable vertex")
        for child in children(vertices[i]):
            reached.add(child);depth[child]=max(depth.get(child,0),depth[i]+1)
            check(depth[child]<=64,"independent numeric graph depth cap")
    return {"iterations":iterations,"rank_cache_boards":cache,"ranges":ranges,"boards":boards,"vertices":vertices,
        "root":root,"initial_history":initial,"edges":edges,"limits":limits,"maximum_depth":max(depth.values())}


def build_identity(repo,build,parse):
    exe=Path(build['executable']);manifest=exe.parent/'native-exact-build-manifest.json'
    raw=manifest.read_bytes();bm=parse(raw)
    check(sha(raw)==build['manifest_sha256']==BUILD and sha(exe.read_bytes())==build['executable_sha256']==EXE,'externally pinned engine/build bytes')
    names={'native/exact_four_street_train.cpp','native/exact_public_graph.hpp','native/exact_public_history_index.hpp',
        'native/exact_indexed_routing.hpp','native/exact_selected_cfr.hpp','native/exact_selected_kernel.hpp','native/exact_binary64.hpp',
        'scripts/build_native_exact_four_street.py','third_party/boost-multiprecision-1.92.0/manifest.json',
        'third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt','third_party/boost-multiprecision-1.92.0/headers.zip'}
    check(set(build['source_sha256'])==names and bm['source_sha256']==build['source_sha256'] and bm['executable_sha256']==EXE and
          all(sha((repo/k).read_bytes())==v for k,v in build['source_sha256'].items()),'complete build source closure')
    check('/fp:strict' in build['flags'] and '/O2' in build['flags'] and '/W4' in build['flags'] and '/WX' in build['flags'] and
          '/DBOOST_MP_STANDALONE' in build['flags'] and bm['flags']==build['flags'],'strict frozen build flags')
    depdir=repo/'third_party/boost-multiprecision-1.92.0'
    expected={'manifest.json':'4d6f33341887e35a0c29e9dc5da2a326d546427940c2b16b485db0c61b042555',
        'headers.zip':'33c422ab3ebfa9e86c62f41f372ec2b9c2cefa303f1885391aa4d8250ef2f831',
        'LICENSE_1_0.txt':'c9bff75738922193e67fa726fa225535870d2aa1059f91452c411736284ad566'}
    check(all(sha((depdir/k).read_bytes())==v for k,v in expected.items()),'pinned dependency artifacts')
    dep=parse((depdir/'manifest.json').read_bytes())
    with zipfile.ZipFile(depdir/'headers.zip') as z:
        entries=[i for i in z.infolist() if not i.is_dir()]
        check(len(entries)==198 and len({i.filename for i in entries})==198,'198 unique packaged headers')
        headers={i.filename:sha(z.read(i)) for i in entries}
    check(headers==dep['headers_sha256'] and len(headers)==dep['header_count']==198,'packaged header pins')
    actual=inventory(exe.parent/'boost-include')
    check({k:sha(v) for k,v in actual.items()}==headers,'actual compiled include header closure')
    return {'manifest':sha(raw),'executable':sha(exe.read_bytes()),'headers':headers,'sources':build['source_sha256']}

def capture_check(files,identifier,raw,parse):
    check(files[identifier+'.raw.json']==files[identifier+'.stdout.bin'],'retained JSON is exact original stdout')
    status=parse(files[identifier+'-process-status.json'])
    check(status==dict(returncode=0,stdout_sha256=sha(files[identifier+'.stdout.bin']),stderr_sha256=sha(files[identifier+'.stderr.bin'])),'raw process-status binding')
    for index,stream in enumerate(raw['native_streams']):
        prefix=f'{identifier}-native-{index}'
        for kind in ('request','stdout','stderr'):
            check(files[prefix+'-'+kind+'.bin']==base64.b64decode(stream[kind],validate=True),'decoded native artifact original bytes')
        expected={'returncode':stream['returncode'],**{kind+'_sha256':sha(base64.b64decode(stream[kind],validate=True)) for kind in ('request','stdout','stderr')}}
        check(parse(files[prefix+'-status.json'])==expected,'native status capture binding')

def inspect_child(raw,entry,case,runtime):
    name,T,mode,sample=entry
    check((raw['case'],raw['iterations'],raw['native_traversal'],raw['sample'],raw['routing'],raw['native_admission'],raw['traced'])==
          (name,T,mode,sample,'indexed','indexed-v1',False) and raw['request_case']==case and raw['runtime']==runtime,'fixed child identity/runtime/case')
    check(not raw.get('source_build_guard_failure'),'child source/build failure')
    check(type(raw['seconds']) in (float,int) and math.isfinite(raw['seconds']) and raw['seconds']>0 and
          raw['python_allocation_peak_bytes'] is None and type(raw['process_peak_bytes']) is int and raw['process_peak_bytes']>0,'timing/allocation metadata')
    calls=raw['counts'];names={'python_trainer','native_invoke','python_rank','rank_before_native','pair','world','legacy'}
    check(set(calls)==names and all(type(calls[k]) is int and calls[k]>=0 for k in names-{'rank_before_native'}) and
          (calls['rank_before_native'] is None or type(calls['rank_before_native']) is int and calls['rank_before_native']==0),'call counter types')
    check(not any(calls[k] for k in ('python_trainer','pair','world','legacy')) and len(raw['native_streams'])==calls['native_invoke']<=1,'forbidden producer paths')
    status=raw['status'];check(status in ('complete','host-admission-rejected','native-resource-rejected'),'unexpected child status')
    if status=='complete':
        check(raw['failure'] is None and type(raw['payload']) is dict and calls['native_invoke']==1 and calls['rank_before_native']==0,'completion evidence')
        return validate_completed(raw,entry,case)
    check((name,T) not in {(n,10) for n in BASE}|{('payoff-varied-t100',100)},'required complete control rejected')
    check(raw['payload'] is None and type(raw['failure']) is dict and bounded(raw['failure']['message']) and calls['python_rank']==0,'bounded rejection with no contradictory payload')
    if status=='host-admission-rejected':
        check(raw['failure']['type']=='ValueError' and calls['native_invoke']==0 and not raw['native_streams'] and
              raw['native_observations']=={'learning_completed':False,'rank_calls':0},'host rejection observation')
    else:
        check(raw['failure']['type']=='NativeFailure' and calls['native_invoke']==1 and calls['rank_before_native']==0 and
              raw['native_observations']=={'learning_completed':None,'rank_calls':None},'native rejected internals remain unknown')
        stream=raw['native_streams'][0];error=base64.b64decode(stream['stderr'],validate=True).decode('utf-8','strict')
        check(stream['returncode']==2 and not base64.b64decode(stream['stdout'],validate=True) and
              error.startswith('native exact four-street rejected:') and bounded(error),'specific native budget exit')
        parse_wire(base64.b64decode(stream['request'],validate=True),mode)
    return None

FORBIDDEN = (
    'pokerlab.exact_selected_solver.solve_four_street_exact_selected',
    'pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.__init__',
    'pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.terminal_values_exact',
    'pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.joint_marginals_exact',
    'pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.pair_probability_exact',
    'pokerlab.exact_selected_kernel.rank_hand','pokerlab.cards.rank_hand',
    'pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.__init__',
    'pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.marginals',
    'pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.terminal',
    'pokerlab.suit_quotient_plan.SuitQuotientPlan.__init__','pokerlab.suit_quotient_cfr.train_suit_quotient',
    'pokerlab.equivariant_packed_cfr.train_equivariant_packed','pokerlab.packed_operator_cfr.train_packed',
    'pokerlab.preflop_solver._enumerate_physical_worlds','pokerlab.selected_runout_operator.SelectedRunoutOperator._iter_worlds',
    'pokerlab.native_selected_operator.train_native_selected','pokerlab.native_selected_dag.train_native_selected_dag',
    'pokerlab.native_public_cfr.train_native_public','pokerlab.native_exact_four_street._invoke',
    'pokerlab.native_exact_four_street.train','pokerlab.native_exact_four_street.wire',
    'pokerlab.native_exact_four_street.admit','pokerlab.native_exact_four_street.parse_policy','subprocess.Popen')

def replay_one(case,payload,saved,numeric_replay,cert,physical,auth,out,identifier):
    result={};before=sha(canonical(payload));build_calls=[]
    try:
        numeric=numeric_replay(payload,case['sb_range'],case['bb_range'],config=case['config'],runouts=case['runouts'],
            flop_config=case['flop_config'],turn_config=case['turn_config'],river_config=case['river_config'])
    except ValueError as error:
        check(bounded(str(error)) and saved['numeric']['status']=='resource-unverified','unexpected numeric verifier failure: '+str(error))
        result['numeric']={'status':'resource-unverified','error':str(error)}
        check(saved['quality_gate'] is None,'unverified numeric result has no quality pass')
    else:
        check(saved['numeric']['status']=='complete' and numeric['checked_information_sets']==payload['info_sets'],'numeric coverage/status')
        v=numeric['value_sb'];b0=numeric['sb_best_response_value'];b1=numeric['bb_best_response_value'];g0=max(0.,b0-v);g1=max(0.,b1+v)
        metrics=dict(value_sb=v,value_bb=-v,sb_best_response_value=b0,bb_best_response_value=b1,sb_gain=g0,bb_gain=g1,nash_conv=g0+g1,exploitability=(g0+g1)/2)
        gaps={k:abs(payload[k]-metrics[k]) for k in METRICS}
        check(all(math.isfinite(v) and v<=1e-10 for v in gaps.values()),'fresh complete numeric replay gap')
        check(set(saved['numeric_metric_gaps'])==set(METRICS) and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1e-10 for v in saved['numeric_metric_gaps'].values()),'saved numeric tolerance flags')
        check(all(bits(numeric[k])==bits(saved['numeric']['result'][k]) for k in ('value_sb','value_bb','sb_best_response_value','bb_best_response_value','nash_conv')),'fresh/saved numeric replay identity')
        result['numeric']={'status':'complete','metric_gaps':gaps,'checked_information_sets':numeric['checked_information_sets']}
    original=physical.build_model
    def counted(*args,**kwargs):
        build_calls.append(1);check(len(build_calls)<=3,'unchanged compact verifier bounded builds');return original(*args,**kwargs)
    try:
        with patch.object(physical,'build_model',new=counted):
            fresh=cert.evaluate_exact(case,payload)
    except ValueError as error:
        check(bounded(str(error)) and saved['exact']['status']=='resource-unverified','unexpected exact verifier failure: '+str(error))
        check(saved['quality_gate'] is None,'resource-unverified exact is not quality pass')
        result['exact']={'status':'resource-unverified','error':str(error),'physical_model_calls':len(build_calls)}
    else:
        exact=fresh['exact_certificate'];old=saved['exact'];check(old['status']=='complete','fresh exact/saved status')
        check(fresh['physical_model_builds']==len(build_calls)==3 and fresh['production_pair_rows']==fresh['training_calls']==fresh['native_calls']==0,'capped verification-only expansion')
        check(fresh['compact_input_canonical_sha256']==before and fresh['verification_expansion_canonical_sha256']==exact['input_policy_canonical_sha256'],'compact/expanded certificate provenance')
        check(all(exact[k]==old['result']['exact_certificate'][k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256','input_case_canonical_sha256')),'fresh exact metrics/policy binding')
        m={k:auth.bounded_fraction(value) for k,value in exact['metrics'].items()};threshold=auth.bounded_fraction(exact['threshold'])
        check(threshold==auth.bounded_fraction('1/1000') and type(exact['threshold_met']) is bool and exact['threshold_met']==(m['nash_conv']<=threshold),'exact unchanged rational quality threshold')
        check(m['value_bb']==-m['value_sb'] and m['sb_best_response_gain']==max(0,m['sb_best_response_value']-m['value_sb']) and
              m['bb_best_response_gain']==max(0,m['bb_best_response_value']+m['value_sb']) and
              m['nash_conv']==m['sb_best_response_gain']+m['bb_best_response_gain'] and m['exploitability']*2==m['nash_conv'],'exact rational metric identities')
        check(saved['quality_gate']==(exact['threshold_met'] if result['numeric']['status']=='complete' else None),'saved quality gate recomputation')
        result['exact']={'status':'complete','threshold':exact['threshold'],'threshold_met':exact['threshold_met'],
            'normalized_policy_sha256':exact['normalized_policy_sha256'],'metrics':exact['metrics'],'physical_model_calls':3}
        write(out/(identifier+'-fresh-certificate.json'),fresh)
    check(sha(canonical(payload))==before,'fresh replay mutated original saved payload')
    check(type(saved['forbidden_production_calls']) is dict and not any(saved['forbidden_production_calls'].values()),'saved verifier production calls')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('repo','study','prior-study','output-dir','continuation-protocol','completion','continuation-helper'):
        p.add_argument('--'+name,type=Path,required=True)
    for name in ('manifest-sha256','report-sha256','prior-manifest-sha256','protocol-sha256','completion-sha256','confirmed-terminal-handle'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--terminal-exit-code',type=int,required=True)
    a=p.parse_args();check((a.confirmed_terminal_handle,a.terminal_exit_code)==('38898',0),'authoritative continuation terminal confirmation required')
    repo,study,prior,out=(getattr(a,k).resolve() for k in ('repo','study','prior_study','output_dir'))
    check(not out.exists() and all(root!=out and root not in out.parents for root in (repo,study,prior)),'new external review result directory required')
    out.mkdir(parents=True);stage='authentication';own=sha(Path(__file__).read_bytes())
    try:
        ap=Path(__file__).resolve().parents[1]/'exact-selected-independent-review.py'
        authraw=ap.read_bytes();check(sha(authraw)==AUTH,'pinned source authentication helper')
        # Compile authenticated stdlib-only definitions without importing from disk or writing caches.
        auth=types.ModuleType('pinned_external_source_auth');auth.__file__=str(ap)
        exec(compile(authraw,str(ap),'exec'),auth.__dict__);auth.FROZEN=COMMIT;parse=auth.parse
        files=manifested(study,a.manifest_sha256,parse);oldfiles=manifested(prior,a.prior_manifest_sha256,parse)
        check(sha(files['report.json'])==a.report_sha256,'external final report pin')
        external={str(path.resolve()):path.read_bytes() for path in (a.continuation_protocol,a.completion,a.continuation_helper)}
        protocolraw=external[str(a.continuation_protocol.resolve())];completionraw=external[str(a.completion.resolve())]
        check(sha(protocolraw)==a.protocol_sha256 and sha(completionraw)==a.completion_sha256 and
              sha(external[str(a.continuation_helper.resolve())])==CONTINUATION,'outer continuation pins')
        outer=parse(protocolraw);completion=parse(completionraw)
        check(outer['source']==completion['source']==COMMIT and outer['helper_sha256']==completion['helper_sha256']==CONTINUATION and
              outer['reused_entries']==completion['reused_entries']==[list(v) for v in SCHEDULE[:2]] and
              outer['new_entries']==completion['new_entries']==[list(v) for v in SCHEDULE[2:]],'continuation fixed producer identities')
        check(outer['counts']=={'reused':0,'new_producers':0} and completion['counts']=={'reused':2,'new_producers':35} and
              completion['result']=={'outcome':'complete','calls_captured':37,'failure':None},'35 new and two reused producer accounting')
        check(outer['prior_manifest_sha256']==completion['prior_manifest_sha256']==a.prior_manifest_sha256 and
              outer['prior_capture_map_sha256']==completion['prior_capture_map_sha256']==sha(oldfiles['capture-time-sha256.json']),'prior immutable capture provenance')
        source=parse(files['source-before.json'])
        check(source['commit']==COMMIT and source['status']=='' and all(parse(snapshot[k])==source for snapshot in (files,oldfiles)
              for k in ('source-before.json','source-after.json')),'frozen before/after source snapshots')
        identity=auth.source_identity(repo,source)
        protocol=parse(files['protocol.json']);oldprotocol=parse(oldfiles['protocol.json']);report=parse(files['report.json']);oldreport=parse(oldfiles['report.json'])
        cases=cases_from_data(repo,parse)
        for proto in (protocol,oldprotocol):
            check(proto['version']=='native-active-frames-fixed-study-v1' and proto['source_commit']==COMMIT and proto['source_sha256']==source['sha256'] and
                  proto['schedule']==[list(v) for v in SCHEDULE] and proto['cases']==cases,'independent fixed protocol/cases/source')
            check(proto['aliases']==[[MATRIX[0],10,'original-22-t10',10,0],[MATRIX[0],100,'original-22-t10',100,0]],'capacity aliases do not add producer calls')
        check(oldprotocol==protocol,'prior/final producer protocol identity')
        check(report['source_commit']==COMMIT and report['calls_planned']==report['calls_attempted']==report['calls_captured']==len(report['samples'])==37 and report['failure'] is None,'complete final report')
        check(oldreport['calls_planned']==37 and oldreport['calls_attempted']==2 and oldreport['calls_captured']==1 and
              oldreport['failure']['sample']==label(SCHEDULE[1]) and oldreport['failure']['message']=='backend/traversal/admission marker mismatch','preserved first parent-schema failure')
        build=parse(files['build-before.json'])
        check(build==protocol['build'] and all(parse(snapshot[k])==build for snapshot in (files,oldfiles) for k in ('build-before.json','build-after.json')),'build before/after binding')
        build_snapshot=build_identity(repo,build,parse)
        for snapshot in (files,oldfiles):
            captured=parse(snapshot['capture-time-sha256.json'])
            check(all(name in snapshot and sha(snapshot[name])==digest for name,digest in captured.items()),'capture-time raw closure')
            proof=parse(snapshot['source-auth-proof.json'])
            check(proof['commit']==COMMIT and proof['tracked_raw_sha256']==source['sha256'] and proof['closure_count']==len(source['sha256']) and proof['raw_or_normalized_blob_match'] is True,'saved full source proof')
        for entry in SCHEDULE[:2]:
            identifier=label(entry)
            for name,raw in oldfiles.items():
                if name.startswith(identifier) and not name.endswith('-first-failure.json') and '-verification.json' not in name:
                    check(name in files and files[name]==raw,'two preserved producer observations exact bytes: '+name)
        # All source/build/raw authentication is complete before ANY project math import.
        stage='raw schedule proof';raws={};structural={};expected_capture=set();statuses=Counter()
        for summary,entry in zip(report['samples'],SCHEDULE):
            identifier=label(entry);raw=parse(files[identifier+'.stdout.bin']);capture_check(files,identifier,raw,parse)
            expected_summary={k:v for k,v in raw.items() if k not in ('payload','native_streams')};expected_summary['artifact']=identifier+'.raw.json'
            check(canonical(summary)==canonical(expected_summary),'report summary must equal original observation '+identifier)
            structural[identifier]=inspect_child(raw,entry,cases[entry[0]],protocol['runtime']);raws[identifier]=raw;statuses[raw['status']]+=1
            expected_capture.update(identifier+s for s in ('.stdout.bin','.stderr.bin','-process-status.json','.raw.json'))
            for index in range(len(raw['native_streams'])):
                expected_capture.update(f'{identifier}-native-{index}-{kind}.bin' for kind in ('request','stdout','stderr'))
                expected_capture.add(f'{identifier}-native-{index}-status.json')
        check(set(parse(files['capture-time-sha256.json']))==expected_capture,'exact scheduled capture inventory')
        stage='protected current independent mathematics';sys.dont_write_bytecode=True;sys.path.insert(0,str(repo))
        from scripts import four_street_validation as physical, exact_selected_compact_certificate as cert
        from scripts.preflop_validation import replay_policy as numeric_replay
        forbidden=Counter({name:0 for name in FORBIDDEN});fresh={}
        def reject(name):
            def blocked(*_args,**_kwargs):
                forbidden[name]+=1;raise AssertionError('forbidden producer path during saved replay: '+name)
            return blocked
        with ExitStack() as guard:
            for name in FORBIDDEN:guard.enter_context(patch(name,new=reject(name)))
            for entry in SCHEDULE:
                identifier=label(entry);raw=raws[identifier]
                if raw['status']!='complete':continue
                stage='fresh replay '+identifier
                fresh[identifier]=replay_one(cases[entry[0]],raw['payload'],parse(files[identifier+'-verification.json']),
                    numeric_replay,cert,physical,auth,out,identifier)
                print(identifier,fresh[identifier]['numeric']['status'],fresh[identifier]['exact']['status'],flush=True)
        check(not any(forbidden.values()),'no production/native/training entries during replay')
        stage='independent report reduction';pairs={};groups={}
        for entry in SCHEDULE:groups.setdefault((entry[0],entry[1],entry[3]),{})[entry[2]]=label(entry)
        for key,modes in groups.items():
            if set(modes)!=set(MODES):continue
            left,right=(modes[m] for m in MODES)
            if left not in fresh or right not in fresh:continue
            a1,b1=(raws[v]['payload'] for v in (left,right))
            check(canonical(a1['strategy'])==canonical(b1['strategy']) and a1['chance_input_snapshot']==b1['chance_input_snapshot'] and
                  all(bits(a1[k])==bits(b1[k]) for k in METRICS),'complete paired rows, action and metric bits')
            comparison=dict(complete_rows=len(a1['strategy']),policy_and_action_rows_bitwise_identical=True,all_eight_metric_binary64_identical=True,
                value_cursor_seconds=raws[left]['seconds'],active_frames_seconds=raws[right]['seconds'])
            exact=[fresh[v]['exact'] for v in (left,right)]
            if all(e['status']=='complete' for e in exact):
                check(all(exact[0][k]==exact[1][k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256')),'paired exact rational policy/certificate identity')
                comparison.update(exact_certificate_metrics_and_flags_identical=True,threshold_met=exact[0]['threshold_met'])
            else:comparison.update(exact_certificate_metrics_and_flags_identical=None,exact_certificate_statuses=[e['status'] for e in exact])
            name=left+'__vs__'+right;claimed=report['paired_comparisons'][name]
            check(all(canonical(claimed[k])==canonical(value) for k,value in comparison.items()) and parse(files[name+'-comparison.json'])==claimed,'paired report derivation')
            pairs[name]=comparison
        check(set(pairs)==set(report['paired_comparisons']),'no extra or missing pair claims')
        repeats={}
        for mode in MODES:
            ids=[label(('original-22-t10',10,mode,i)) for i in range(3)]
            check(all(canonical(raws[i]['payload']['strategy'])==canonical(raws[ids[0]]['payload']['strategy']) and
                      all(bits(raws[i]['payload'][k])==bits(raws[ids[0]]['payload'][k]) for k in METRICS) for i in ids),'three-repeat policy/metric identity')
            repeats[mode]=statistics.median(raws[i]['seconds'] for i in ids)
            check(report['original_t10_three_pair_medians_seconds'][mode]==repeats[mode],'three-pair descriptive median')
        misses=[label(entry) for entry in SCHEDULE if label(entry) in fresh and
                (fresh[label(entry)]['numeric']['status']!='complete' or fresh[label(entry)]['exact'].get('threshold_met') is not True)]
        check(report['quality_misses_or_unverified_retained']==misses,'all actual quality misses/unknowns retained')
        stage='final source/build/artifact stability'
        check(auth.source_identity(repo,source)['raw_sha256']==identity['raw_sha256'] and inventory(study)==files and inventory(prior)==oldfiles and
              build_identity(repo,build,parse)==build_snapshot and sha(Path(__file__).read_bytes())==own and
              all(Path(name).read_bytes()==raw for name,raw in external.items()),'source/build/raw/outer/helper drift')
        qcounts=Counter((value['exact']['status'],value['exact'].get('threshold_met')) for value in fresh.values())
        maxgap=max((max(v['numeric']['metric_gaps'].values()) for v in fresh.values() if v['numeric']['status']=='complete'),default=0.)
        receipt=dict(status='passed',source_commit=COMMIT,source_files=identity['files'],helper_sha256=own,authentication_helper_sha256=AUTH,
            manifest_sha256=a.manifest_sha256,report_sha256=a.report_sha256,prior_manifest_sha256=a.prior_manifest_sha256,
            continuation_helper_sha256=CONTINUATION,continuation_protocol_sha256=a.protocol_sha256,completion_sha256=a.completion_sha256,
            authoritative_terminal_handle='38898',terminal_exit_code=0,actual_unique_producer_observations=37,reused_observations=2,new_continuation_producers=35,
            independent_candidate_calls=0,forbidden_production_calls=dict(forbidden),counts=dict(statuses),pairs=pairs,
            original_t10_three_pair_medians_seconds=repeats,max_fresh_numeric_gap=maxgap,
            exact_status_counts={str(k):v for k,v in qcounts.items()},fresh=fresh,structural=structural,
            build=build_snapshot,source_before_after_stable=True,artifacts_before_after_stable=True,
            continuation_null_marker_limitation='Continuation accepts null optional markers. This review independently requires absence or exact non-null values; all raw complete outputs satisfy that stricter contract.',
            preserved_failure='Initial parent schema guard stopped after two actual producer observations, one parent-accepted. Both raw observations reused without rerunning or mutation.',
            archive_status='deferred: raw/source/build/math receipt precedes outer packaging; a separate exact-path archive audit is required',
            scope='37 fixed finite selected-runout observations. Fresh independent numeric replay and unchanged capped compact exact certificates. Verifier limits are unknown quality, never passes. Structural raw-wire/support/orbit checks do not constitute a new independent legal graph-isomorphism proof. Descriptive three-pair API medians only; no native memory, CPU causality or universal performance claim.')
        write(out/'receipt.json',receipt)
        print(json.dumps({'status':'passed','receipt_sha256':sha((out/'receipt.json').read_bytes()),'counts':dict(statuses),'max_numeric_gap':maxgap,'pairs':len(pairs)},sort_keys=True),flush=True)
    except BaseException as error:
        write(out/'first-failure.json',{'stage':stage,'type':type(error).__name__,'message':str(error),'helper_sha256':own})
        raise

if __name__=='__main__':main()
