"""Archive the two exact terminal-scaling comparisons against accepted outputs."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'dyadic-phase-payload-repo'
HEAD = '704fea69e9cb453c46b40c971061cc60d7ee3643'
RESULT = ROOT / 'benchmarks/results/native-dyadic-terminal-scaling-v1'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def collect(label, mode, baseline, baseline_head, cases, files):
    cohort = WORK / f'dyfactor-{label}-cohort1'
    operator = WORK / f'dyfactor-{label}-launch1'
    final = read(cohort / 'result.json')
    outer = read(operator / 'completion.json')
    source = read(cohort / 'source.json')
    hashes = {k: v['raw_sha256'] for k, v in source['files'].items()}
    require(final['head'] == outer['head'] == source['head'] == HEAD and
            final['training_invocations'] == 1 and outer['mode'] == f'train_{mode}' and
            outer['actual_exit_observed'] and outer['returncode'] == 0 and not outer['failures'] and
            outer['raw_source_stable'] and read(cohort / 'terminal.json')['status'] == 'complete' and
            read(operator / 'source-before.json') == read(operator / 'source-after.json') == hashes,
            'source or lifecycle differs')
    require(read(operator / 'operator-launch.json')['operator_sha256'] ==
            digest(WORK / 'trusted-virtual-dyadic-training-launch-v27.py'), 'launcher differs')
    for boot_path in (operator / 'bootstrap.json', cohort / 'saved-review-bootstrap.json'):
        boot = read(boot_path)
        require(boot['initial_cache_scan']['project_bytecode_files'] ==
                boot['final_cache_scan']['project_bytecode_files'] == 0 and
                all(hashes.get(k) == v for k, v in boot['compiled'].items()), 'bootstrap sources differ')
    build_path = cohort / 'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(all(hashes.get(k) == v for k, v in build['source_sha256'].items()) and
            digest(Path(build['executable'])) == build['executable_sha256'], 'native build differs')
    for child in (f'admit_{mode}', f'train_{mode}', 'saved-review'):
        receipt = read(cohort / child / 'process.json')
        require(receipt['status'] == 'exited' and receipt['returncode'] == 0 and
                receipt['actual_exit_observed'] and not receipt['failures'] and
                receipt['automatic_retries'] == 0, 'native or replay exit differs')
        if child != 'saved-review':
            binding = read(cohort / child / 'binary-identity.json')
            require(binding['before_sha256'] == binding['after_sha256'] == build['executable_sha256'] and
                    binding['build_manifest_sha256'] == digest(build_path), 'native child identity differs')

    base_path = ROOT / baseline / 'manifest.json'
    prior = read(base_path)
    before = prior['saved_only_replay']
    after = final['saved_only_replay']
    require(hashes[baseline + '/manifest.json'] == digest(base_path) and
            hashes[baseline + '/verification.zip'] == digest(ROOT / baseline / 'verification.zip') ==
            prior['archive']['sha256'], 'accepted baseline evidence differs')
    require(before['profile_and_br'] == after['profile_and_br'] and
            before['work_actual'] == after['work_actual'] and before['work_plan'] == after['work_plan'] and
            prior['quality_gate'] == final['quality_gate'] and after['native_producer_calls'] == 0 and
            after['checkpoint_verification'] == 'independent_compact_digest', 'replay result differs')
    capture = final['sweep_capture']
    require(prior['sweep_capture'] == capture and prior['checkpoint_inputs'] == final['checkpoint_inputs'],
            'complete output or checkpoint digest differs')
    native = read(cohort / f'train_{mode}/process.json')
    require(native['sweep_capture'] == capture and
            digest(cohort / f'train_{mode}/stdout.bin') == after['saved_output_sha256'] ==
            before['saved_output_sha256'], 'native output bytes differ')
    for image in final['checkpoint_inputs']['sweep_images']:
        p = cohort / 'page-images' / image['name']
        require(p.stat().st_size == image['bytes'] and digest(p) == image['sha256'], 'saved image differs')
    admission = final['admission']
    sweeps = admission['requested_sweeps']
    terminals = admission['folds'] + admission['showdowns']
    removed = 4 * sweeps * terminals
    require(removed == cases, 'terminal work count differs')
    for name, folder in (('operator', operator), ('cohort', cohort)):
        for p in sorted(folder.rglob('*')):
            require(not p.is_symlink(), 'linked evidence path')
            if not p.is_file():
                continue
            rel = p.relative_to(folder)
            if name == 'cohort' and (rel.parts[0] == 'source' or
                (rel.parts[0] == 'build' and p != build_path) or
                rel.as_posix() in ('page-images/committed.bin', 'page-images/staged.bin',
                                  f'train_{mode}/stdout.bin')):
                continue
            files[f'{label}/{name}/{rel.as_posix()}'] = p
    return {
        'baseline_commit': baseline_head, 'baseline_path': baseline,
        'sweeps': sweeps, 'terminals_per_sweep': terminals,
        'wide_multiplications_before': 2 * removed, 'wide_multiplications_after': removed,
        'wide_multiplications_removed': removed,
        'retained_policy_sha256': after['saved_output_sha256'], 'wire_sha256': capture['wire_sha256'],
        'wire_bytes': capture['contract']['wire_bytes'], 'checkpoint_digests': capture['frames'],
        'quality_gate': final['quality_gate'], 'exploitability': after['profile_and_br']['exploitability'],
        'source_files': len(hashes), 'native_seconds': native['duration_seconds'],
        'native_memory': native.get('memory'),
    }

def main():
    files = {'operator/package-dyadic-terminal-scaling.py': Path(__file__),
             'operator/trusted-virtual-dyadic-training-launch-v27.py':
                 WORK / 'trusted-virtual-dyadic-training-launch-v27.py'}
    ten = collect('ten', 'ten_indexed_cache',
                  'benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1',
                  '53b8aa1a609d1113ef3e739fab105f2600d1150f', 1329176, files)
    nine = collect('nine', 'proof9_linear32',
                   'benchmarks/results/native-dyadic-proof9-linear32-v1',
                   '99e9263863caded61d4f9cd93111f49c0f1baf32', 4350336, files)
    quotient_report = WORK / 'dyadic-division-complement-oracle-n10.json'
    quotient = read(quotient_report)
    require(quotient['recorded_combined_divisions'] == 325666 and
            quotient['one_complement_per_eligible_row'] == 139514 and
            quotient['projected_combined_divisions'] == 186152 and
            quotient['exact_grid_rows_compared'] == 238392 and
            quotient['baseline_manifest_sha256'] == digest(ROOT / ten['baseline_path'] / 'manifest.json'),
            'saved-only complement comparison differs')
    files['quantizer-projection/receipt.json'] = quotient_report
    files['quantizer-projection/verifier.py'] = WORK / 'verify-dyadic-division-complement-n10.py'
    for kind in ('normal', 'opt'):
        log = WORK / f'dyfactor-controls-{kind}1.log'
        raw_log = log.read_text(encoding='utf-8-sig')
        require('Ran 38 tests' in raw_log and raw_log.rstrip().endswith('OK'),
                f'{kind} focused control log differs')
        files[f'controls/{kind}.log'] = log
    RESULT.mkdir(exist_ok=False)
    archive = RESULT / 'verification.zip'
    inventory = {n: {'bytes': p.stat().st_size, 'sha256': digest(p)} for n, p in files.items()}
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=6) as z:
        for n, p in files.items():
            z.write(p, n)
        z.writestr('inventory.json', json.dumps(inventory, indent=2, sort_keys=True) + '\n')
    with ZipFile(archive) as z:
        require(z.testzip() is None, 'archive CRC differs')
        for n, expected in inventory.items():
            with z.open(n) as f:
                require(z.getinfo(n).file_size == expected['bytes'] and
                        hashlib.file_digest(f, 'sha256').hexdigest() == expected['sha256'],
                        'archive member differs')
    manifest = {'version': 'native-dyadic-terminal-scaling-v1', 'source_head': HEAD,
                'scope': 'Exact terminal scaling and byte parity for the fixed N9 and N10 studies.',
                'metering': 'Existing conservative modeled work and storage receipts are preserved.',
                'ten': ten, 'nine': nine, 'quantizer_complement_saved_only': quotient,
                'archive': {'path': 'verification.zip', 'bytes': archive.stat().st_size,
                            'sha256': digest(archive), 'members': len(inventory) + 1}}
    with (RESULT / 'manifest.json').open('x', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({k: manifest[k] for k in ('source_head', 'archive')}))

if __name__ == '__main__':
    main()
