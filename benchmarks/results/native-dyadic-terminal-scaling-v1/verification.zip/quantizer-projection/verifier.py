"""Count exact last-division opportunities in authenticated N10 T2 images."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import struct

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'dyadic-phase-payload-repo'
MANIFEST = ROOT / 'benchmarks/results/native-dyadic-indexed-cache-ten-card-accepted-v1/manifest.json'
COHORT = WORK / 'dyidx-ten-cohort1'
OUTPUT = WORK / 'dyadic-division-complement-oracle-n10.json'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def bound_read(path, extent, digest):
    with path.open('rb') as f:
        data = f.read(extent + 1)
    require(len(data) == extent and sha256(data).hexdigest() == digest, f'identity differs: {path.name}')
    return data

def complement_policy(values):
    """Recover the final positive quotient and remainder by grid conservation."""
    grid = 1 << 52
    positive = [i for i, v in enumerate(values) if v > 0]
    if not positive:
        units, extra = divmod(grid, len(values))
        return tuple(units + (i < extra) for i in range(len(values)))
    if len(positive) == 1:
        return tuple(grid if i == positive[0] else 0 for i in range(len(values)))
    denominator = sum(values)
    units = [0] * len(values)
    remainder = [0] * len(values)
    for i in positive[:-1]:
        units[i], remainder[i] = divmod(values[i] * grid, denominator)
    remainder_sum = sum(remainder)
    carry = 0
    for _ in range(len(positive) - 2):
        if remainder_sum < denominator:
            break
        remainder_sum -= denominator
        carry += 1
    require(0 <= remainder_sum < denominator, 'remainder reduction exceeded its bound')
    last = positive[-1]
    units[last] = grid - sum(units) - carry - (remainder_sum != 0)
    remainder[last] = denominator - remainder_sum if remainder_sum else 0
    # This extra divmod is the independent checker, outside the candidate.
    require((units[last], remainder[last]) == divmod(values[last] * grid, denominator),
            'complement quotient or remainder differs from direct division')
    left = grid - sum(units)
    require(0 <= left < len(positive), 'invalid grid remainder')
    for i in sorted(positive, key=lambda j: (-remainder[j], j))[:left]:
        units[i] += 1
    return tuple(units)


def main():
    raw = MANIFEST.read_bytes()
    manifest = json.loads(raw)
    plan = manifest['admission']
    rows, slots, bits = (plan[k] for k in ('rows', 'slots', 'value_bits'))
    average, regret = (plan[k] for k in ('packed_average_limbs', 'packed_regret_limbs'))
    require((rows, slots, bits, plan['requested_sweeps']) == (119196, 281066, 644, 2),
            'accepted N10 T2 geometry required')
    images = {image['name']: image for image in manifest['checkpoint_inputs']['sweep_images']}
    require([image['name'] for image in manifest['checkpoint_inputs']['sweep_images']] ==
            ['staged.bin', 'committed.bin'], 'image roles differ')
    def image(name):
        record = images[name]
        require(record['bytes'] == 8 * (average + regret), 'image extent differs')
        return bound_read(COHORT / 'page-images' / name, record['bytes'], record['sha256'])
    first = image('staged.bin')
    last = image('committed.bin')
    directory = manifest['row_directory']
    require(directory['rows_bytes'] == 32 * rows, 'directory extent differs')
    records = bound_read(COHORT / 'page-images-rows/rows.bin',
                         directory['rows_bytes'], directory['rows_sha256'])
    stream = manifest['checkpoint_inputs']['stream']
    numeric = bound_read(COHORT / 'train_ten_indexed_cache/stdout.bin', stream['bytes'], stream['sha256'])
    prelude = 8 + 16*8 + 11*8 + 1105*96
    row_end = prelude + 24 * rows
    sweep_block = 8 * slots + 4 * 12 * 8
    policy_offsets = (row_end + sweep_block, row_end + 2 * sweep_block)
    next_a = next_r = next_slot = 0
    populations = [Counter(), Counter()]
    for i in range(rows):
        history, packed, slot = struct.unpack_from('<3Q', numeric, prelude + 24*i)
        menu = (packed >> 16) & 255
        w0, w1, w2, w3 = struct.unpack_from('<4Q', records, 32*i)
        require(w0 == history and slot == (w1 & 0xffffffff) == next_slot and 2 <= menu <= 4 and
                (w3 >> 16) == (packed & 0xffff), 'row metadata differs')
        shift_a, shift_r = w2 >> 48, w3 & 0xffff
        a, r = w1 >> 32, w2 & 0xffffffff
        require((a, r) == (next_a, next_r) and 0 <= max(shift_a, shift_r) < bits, 'row extent differs')
        strides = [(bits-shift_r+63)//64, (bits-shift_a+63)//64]
        for index, (data, start, stride, shift) in enumerate((
            (first, average + r, strides[0], shift_r),
            (last, a, strides[1], shift_a)
        )):
            width = 8 * stride
            values = [int.from_bytes(data[8*start + j*width:8*start + (j+1)*width], 'little')
                      for j in range(menu)]
            require(all(v.bit_length() <= bits-shift for v in values), 'compact row width differs')
            populations[index][sum(v > 0 for v in values)] += 1
            expected_units = struct.unpack_from(f'<{menu}Q', numeric, policy_offsets[index] + 8 * slot)
            require(complement_policy(values) == expected_units, 'complement policy differs from saved grid')
        next_a += menu * strides[1]
        next_r += menu * strides[0]
        next_slot += menu
    require((next_a, next_r, next_slot) == (average, regret, slots), 'complete image geometry differs')
    expected = manifest['quantizer']['combined_divisions']
    counts = [{str(p): c[p] for p in range(5)} for c in populations]
    divisions = sum(p*n for c in populations for p, n in c.items() if p > 1)
    eligible = sum(n for c in populations for p, n in c.items() if p > 1)
    require(divisions == expected, 'independent division census differs from native receipt')
    report = {
        'baseline_manifest_sha256': sha256(raw).hexdigest(),
        'checkpoint_inputs': manifest['checkpoint_inputs'],
        'row_directory_sha256': directory['rows_sha256'],
        'positive_regret_rows_before_sweep_2': counts[0],
        'positive_average_rows_at_export': counts[1],
        'recorded_combined_divisions': divisions,
        'one_complement_per_eligible_row': eligible,
        'projected_combined_divisions': divisions - eligible,
        'exact_grid_rows_compared': 2 * rows,
        'scope': 'Saved-only candidate arithmetic against accepted N10 T2 images; native quantizer unmodified.',
    }
    with OUTPUT.open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'checkpoint_inputs'}))

if __name__ == '__main__':
    main()
