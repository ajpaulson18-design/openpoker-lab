"""Package one source-frozen linear32 exactness run and preserve its quality result."""
import argparse, hashlib, json, subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
W=Path(__file__).resolve().parent
R=W/'dyadic-phase-payload-repo'
C=W/'dyl32-nine-cohort2'
O=W/'dyl32-nine-launch2'
D=R/'benchmarks/results/native-dyadic-proof9-linear32-v1'
def req(ok,msg):
    if not ok: raise ValueError(msg)
def read(p): return json.loads(p.read_bytes())
def ident(p):
    with p.open('rb') as f: return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
def main():
    a=argparse.ArgumentParser()
    a.add_argument('--head',required=True)
    a.add_argument('--control-log',type=Path,action='append',required=True)
    x=a.parse_args()
    run=read(C/'result.json'); outer=read(O/'completion.json')
    req(run['head']==outer['head']==x.head and run['training_invocations']==1 and
        run['status']=='saved_linear32_exact_replay_pass' and run['exactness_accepted'] and
        outer['mode']=='train_proof9_linear32' and outer['raw_source_stable'] and outer['returncode']==0 and
        outer['actual_exit_observed'] and not outer['failures'] and
        read(C/'terminal.json')['status']=='complete','frozen run incomplete')
    source=read(C/'source.json')
    hashes={k:v['raw_sha256'] for k,v in source['files'].items()}
    req(read(O/'source-before.json')==read(O/'source-after.json')==hashes,'raw source changed')
    for p in (O/'bootstrap.json',C/'saved-review-bootstrap.json'):
        b=read(p)
        req(not b['initial_cache_scan']['project_bytecode_files'] and not b['final_cache_scan']['project_bytecode_files'] and
            all(hashes.get(k)==v for k,v in b['compiled'].items()),'executed source differs')
    build=read(C/'build/native-exact-build-manifest.json')
    req(all(hashes[k]==v for k,v in build['source_sha256'].items()) and
        ident(Path(build['executable']))['sha256']==build['executable_sha256'],'native source or binary changed')
    for label in ('admit_proof9_linear32','train_proof9_linear32','saved-review'):
        p=read(C/label/'process.json')
        req(p['returncode']==0 and p['actual_exit_observed'] and not p['failures'] and
            p['automatic_retries']==0,'child exit differs')
        if label!='saved-review':
            b=read(C/label/'binary-identity.json')
            req(b['before_sha256']==b['after_sha256']==build['executable_sha256'] and
                b['build_manifest_sha256']==ident(C/'build/native-exact-build-manifest.json')['sha256'],'binary identity differs')
    replay=run['saved_only_replay']; capture=run['sweep_capture']
    stream=C/'train_proof9_linear32/stdout.bin'
    req(ident(stream)==run['checkpoint_inputs']['stream'] and
        replay['saved_output_sha256']==capture['retained_sha256']==ident(stream)['sha256'] and
        replay['native_producer_calls']==0 and replay['checkpoint_verification']=='independent_compact_digest' and
        replay['checkpoint_epochs']==capture['frames'] and len(capture['frames'])==32 and
        replay['wire_sha256']==capture['wire_sha256'] and replay['wire_bytes']==capture['contract']['wire_bytes']==171408812 and
        run['quality_gate']==replay['quality_gate'],'independent replay binding differs')
    for p in run['checkpoint_inputs']['sweep_images']:
        req(ident(C/'page-images'/p['name'])=={k:p[k] for k in ('bytes','sha256')},'final image differs')
    from fractions import Fraction
    ev=replay['profile_and_br']['exploitability']; gate=run['quality_gate']
    passed=Fraction(int(ev['numerator']),int(ev['denominator']))<=Fraction(1,10)
    req(gate=={'metric':'exploitability_bb','threshold':{'numerator':'1','denominator':'10'},
        'status':'pass' if passed else 'miss','passed':passed},'quality threshold changed')
    projection_file=read(W/'dyadic-linear32-source-closed-35db93a.json')
    projection=projection_file['forecast']
    closure=projection_file['source_closure']
    req(closure['head']==x.head and {k:v['raw_sha256'] for k,v in closure['files'].items()}==hashes,
        'forecast full raw source inventory differs from native cohort')
    req(projection['source_head']==x.head and projection['raw_source_stable'] and
        projection['native_producer_calls']==projection['hand_rank_calls']==0,'forecast provenance differs')
    q=projection['linear32']
    req(q['components']==run['admission']['component_work'] and
        q['entries']==run['admission']['entries'] and
        q['payload_bits']==run['admission']['payload_bits'] and
        q['wire_bytes']==capture['contract']['wire_bytes'] and
        q['parent_work']==run['admission']['parent_work'] and
        q['composed_total']==run['admission']['planned_total_work']+capture['contract']['copy_work'],
        'forecast differs from admission')
    req(read(O/'operator-launch.json')['operator_sha256']==ident(W/'trusted-virtual-dyadic-training-launch-v27.py')['sha256'] and
        projection['external_script_sha256']==ident(W/'project-dyadic-linear32-9b404.py')['sha256'],
        'archived execution helpers differ')
    baseline=R/'benchmarks/results/native-dyadic-proof9-quality32-v1'
    previous=read(baseline/'manifest.json')
    req(previous['source_head']=='38f77e49cf2271e5400ee439a6141d86f5161e47' and
        previous['quality_gate']['status']=='miss' and
        all(hashes[path.relative_to(R).as_posix()]==ident(path)['sha256'] for path in
            (baseline/'manifest.json',baseline/'verification.zip')),'equal-weight baseline differs')
    base_archive=baseline/'verification.zip'
    req(ident(base_archive)=={k:previous['archive'][k] for k in ('bytes','sha256')},'baseline archive differs')
    with ZipFile(base_archive) as z:
        saved=z.read('cohort/train_proof9_q32/stdout.bin')
    new=stream.read_bytes()
    req(hashlib.sha256(saved).hexdigest()==previous['saved_only_replay']['saved_output_sha256'] and
        len(saved)==len(new)==16084908 and saved[:8]==b'OPLDSQ31' and new[:8]==b'OPLDSL31',
        'paired numerical streams differ from the named contracts')
    prelude=8+16*8+11*8+1105*96+24420*24
    end=prelude+32*(58164*8+4*12*8)
    req(saved[8:end]==new[8:end] and
        capture['frames'][0]==previous['sweep_capture']['frames'][0] and
        capture['frames'][31]!=previous['sweep_capture']['frames'][31] and
        saved[end:end+58164*8+24420]!=new[end:end+58164*8+24420],
        'paired current policy/root identity or weighted average differs from expected behavior')
    comparison={'baseline_commit':'9b404f3d7a8c8b89dfdb52236a1032666b7860ee',
        'baseline_stream_sha256':hashlib.sha256(saved).hexdigest(),'paired_numeric_prefix_sha256':hashlib.sha256(new[8:end]).hexdigest(),
        'identical_current_policy_and_root_blocks':32,'first_checkpoint_equal':True,
        'final_checkpoint_and_export_differ':True,
        'equal_weight_exploitability':previous['saved_only_replay']['profile_and_br']['exploitability'],
        'linear_weight_exploitability':ev,'baseline_quality_gate':previous['quality_gate']}
    files={}
    for label,root in (('cohort',C),('operator',O)):
        for p in sorted(root.rglob('*')):
            req(not p.is_symlink(),'linked evidence')
            if not p.is_file(): continue
            rel=p.relative_to(root)
            if label=='cohort' and (rel.parts[0]=='source' or
                rel.parts[0]=='build' and p.name!='native-exact-build-manifest.json' or
                rel.parts[0]=='page-images' and p.name in ('committed.bin','staged.bin')): continue
            files[f'{label}/{rel.as_posix()}']=p
    for target in ('state','policy','training'):
        name={'state':'dyq32-state-build3','policy':'dyq32-policy-build1','training':'dyl32-training-build1'}[target]
        p=W/name/'native-exact-build-manifest.json'; b=read(p)
        req(ident(Path(b['executable']))['sha256']==b['executable_sha256'],'control executable changed')
        files[f'controls/{target}/native-exact-build-manifest.json']=p
        for k,v in b['source_sha256'].items():
            req(ident(R/k)['sha256']==v,'control source changed')
            raw=(R/k).read_bytes()
            committed=subprocess.check_output(['git','show',x.head+':'+k],cwd=R)
            req(raw==committed or raw.replace(b'\r\n',b'\n')==committed,'control source differs from frozen commit')
            files['controls/source/'+k]=R/k
    for mode in ('normal2','opt2'):
        for target in ('trainer','state','policy'):
            root=W/f'dyl32-controls-{mode}-{target}'
            req(root.is_dir() and any(root.rglob('process.json')),'missing control process evidence')
            for p in sorted(root.rglob('*')):
                if not p.is_file():continue
                rel=p.relative_to(root)
                if p.suffix=='.bin' and (p.name in ('committed.bin','staged.bin','rows.bin') or p.stat().st_size>100000):continue
                files[f'controls/{mode}/{target}/{rel.as_posix()}']=p
    external=(Path(__file__),W/'trusted-virtual-dyadic-training-launch-v27.py',
        W/'project-dyadic-linear32-9b404.py',W/'project-dyadic-linear32-source-closed-9b404.py',W/'dyadic-linear32-source-closed-35db93a.json',
        *x.control_log)
    req(len(x.control_log)==2 and {p.name for p in x.control_log}==
        {'dyl32-controls-normal2.log','dyl32-controls-opt2.log'},'final normal and optimized logs required')
    for p in x.control_log:
        raw=p.read_bytes()
        req(b'\nOK' in raw and b'FAILED' not in raw and b'skipped=' not in raw,'controls did not all pass')
    for p in external: files['external/'+p.name]=p
    req(files.get('cohort/train_proof9_linear32/stdout.bin')==stream and stream.stat().st_size==16084908,
        'retained all-sweep numerical stream missing from archive')
    first=read(W/'dyl32-nine-cohort1/terminal.json')
    req(first['status']=='failed' and first['receipt']['training_invocations_entered']==0 and
        read(W/'dyl32-nine-launch1/exit.json')['returncode']==1,'first preflight rejection differs')
    for label,relative in (('cohort','dyl32-nine-cohort1/terminal.json'),
                           ('operator','dyl32-nine-launch1/exit.json'),
                           ('admission','dyl32-nine-cohort1/admit_proof9_linear32/stdout.bin')):
        files[f'preflight-rejection/{label}.json']=W/relative
    inventory={k:ident(v) for k,v in files.items()}
    D.mkdir(exist_ok=False)
    archive=D/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as z:
        for k,v in files.items():z.write(v,k)
        z.writestr('inventory.json',json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    req(archive.stat().st_size<50<<20,'archive allowance')
    with ZipFile(archive) as z:
        req(z.testzip() is None,'archive CRC')
        for k,v in inventory.items():
            with z.open(k) as f:
                req(z.getinfo(k).file_size==v['bytes'] and hashlib.file_digest(f,'sha256').hexdigest()==v['sha256'],'archive member differs')
    manifest={'version':'native-dyadic-linear32-evidence-v1','source_head':x.head,
        'status':'accepted_proof9_linear32_exact_training_and_replay','scope':'Fixed N9 game only; exact replay and quality target are separate.',
        'training_invocations':1,'quality_gate':gate,'equal_weight_comparison':comparison,'preserved_preflight_rejection':first,'admission':run['admission'],
        'checkpoint_inputs':run['checkpoint_inputs'],'sweep_capture':capture,'saved_only_replay':replay,
        'paging':run['paging'],'policy_spill':run['policy_spill'],'row_directory':run['row_directory'],
        'quantizer':run['quantizer'],'operator':outer,'source_files':len(hashes),
        'source_inventory_sha256':ident(C/'source.json')['sha256'],
        'native_process':read(C/'train_proof9_linear32/process.json'),
        'independent_forecast':{'path':'external/dyadic-linear32-source-closed-35db93a.json',**ident(W/'dyadic-linear32-source-closed-35db93a.json')},
        'archive':{'path':'verification.zip',**ident(archive),'members':len(inventory)+1}}
    with (D/'manifest.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({'destination':str(D),'archive':manifest['archive'],'quality_gate':gate}))
if __name__=='__main__':main()
