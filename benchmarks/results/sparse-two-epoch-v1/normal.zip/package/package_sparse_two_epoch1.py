from __future__ import annotations

import hashlib
import io
import json
import os
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

WORK = Path(__file__).resolve().parent
REPO = WORK / "dyprofile-repo"
OUT = REPO / "benchmarks" / "results" / "sparse-two-epoch-v1"
NORMAL = WORK / "sparse-two-epoch1-normal"
OPTIMIZED = WORK / "sparse-two-epoch1-optimized"
FAILED_BUILD = WORK / "sparse-two-epoch1-build"
BUILT = WORK / "sparse-two-epoch2-build"
BASELINE = "8652d5d2c5f929f18ee363d40f7ec20a03748a6b"
INTRODUCED = "ef1601a8078cd901ea52cc4f7be74de99ec5fb28"
FIXED = "b4240aa3f0797426e28f18342e47fb3f864a8f98"
CAPTURE_HEAD = "41ae6727523abec3044bd32ae93b321d8d2b5bed"
MAX_MEMBER = 8 * 1024 * 1024
MAX_EXPANDED = 80 * 1024 * 1024
MAX_ARCHIVE = 8 * 1024 * 1024


def fail(message: str) -> None:
    raise RuntimeError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    result = subprocess.run(["git", *args], cwd=REPO, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, check=False)
    if result.returncode != 0:
        fail(f"git {args[0]} failed: {result.stderr.decode('utf-8', 'replace')[:1000]}")
    return result.stdout


def git_text(*args: str) -> str:
    return git(*args).decode("ascii").strip()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode("utf-8")


def safe_path(name: str) -> str:
    if "\\" in name or name.startswith("/"):
        fail(f"unsafe archive path: {name!r}")
    p = PurePosixPath(name)
    if not name or any(part in ("", ".", "..") for part in p.parts):
        fail(f"unsafe archive path: {name!r}")
    return p.as_posix()


def put(files: dict[str, bytes], name: str, data: bytes) -> None:
    name = safe_path(name)
    if name in files:
        fail(f"duplicate archive member: {name}")
    if len(data) > MAX_MEMBER:
        fail(f"archive member exceeds 8 MiB: {name} ({len(data)} bytes)")
    files[name] = data


def add_tree(files: dict[str, bytes], source: Path, prefix: str) -> None:
    if not source.is_dir():
        fail(f"missing evidence directory: {source}")
    for path in sorted(source.rglob("*")):
        if path.is_symlink():
            fail(f"symlink refused in evidence: {path}")
        if path.is_file():
            rel = path.relative_to(source).as_posix()
            put(files, f"{prefix}/{rel}", path.read_bytes())


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def add_common(files: dict[str, bytes], matrix: Path) -> None:
    add_tree(files, matrix, "matrix")
    build_inputs = {
        "build/build.log": BUILT / "build.log",
        "build/compiler-version.log": BUILT / "compiler-version.log",
        "build/native-exact-build-manifest.json": BUILT / "native-exact-build-manifest.json",
    }
    for member, path in build_inputs.items():
        if not path.is_file():
            fail(f"missing build metadata: {path}")
        put(files, member, path.read_bytes())
    logs = {
        "checks/native-tests-normal.log": WORK / "sparse-two-epoch1-normal.log",
        "checks/native-tests-optimized.log": WORK / "sparse-two-epoch1-optimized.log",
        "checks/pure-math-normal.log": WORK / "sparse-two-epoch-reference1-normal.log",
        "checks/pure-math-optimized.log": WORK / "sparse-two-epoch-reference1-optimized.log",
        "checks/saved-replay-normal.log": WORK / "sparse-two-epoch-replay1-normal.log",
        "checks/saved-replay-optimized.log": WORK / "sparse-two-epoch-replay1-optimized.log",
        "checks/normal-optimized-parity.log": WORK / "sparse-two-epoch1-parity.log",
    }
    for member, path in logs.items():
        if not path.is_file():
            fail(f"missing retained check log: {path}")
        put(files, member, path.read_bytes())
    put(files, "package/package_sparse_two_epoch1.py", Path(__file__).read_bytes())
    context = {
        "baseline_head": BASELINE,
        "candidate_fix_commit": FIXED,
        "matrix_source_capture_head": CAPTURE_HEAD,
        "scope": "two deterministic uniform PROOF9 observations per request; no RNG, convergence, solved-quality, N11, realistic-range, RSS, or runtime claim",
        "source_capture": "matrix/source files are checked against their raw SHA-256 inventory and committed-blob map at the captured HEAD",
        "binary_claim": "native executable bytes are intentionally not in this archive; only saved build metadata and its executable hash are present",
    }
    put(files, "metadata/package-context.json", json_bytes(context))


def verify_matrix_pair() -> dict:
    normal_identity = read_json(NORMAL / "source-identity.json")
    optimized_identity = read_json(OPTIMIZED / "source-identity.json")
    if normal_identity != optimized_identity:
        fail("normal/optimized source identity files differ")
    identity = normal_identity
    if identity.get("head") != CAPTURE_HEAD:
        fail("unexpected captured source HEAD")
    raw_hashes = identity.get("raw_sha256", {})
    blobs = identity.get("committed_blobs", {})
    if not raw_hashes or set(raw_hashes) != set(blobs):
        fail("captured raw-hash and committed-blob path sets differ")
    source_dir = NORMAL / "source"
    actual_paths = {p.relative_to(source_dir).as_posix() for p in source_dir.rglob("*") if p.is_file()}
    if actual_paths != set(raw_hashes):
        fail("captured source tree does not exactly match source identity path set")
    blob_checks = 0
    for path, expected in raw_hashes.items():
        data = (source_dir / Path(path)).read_bytes()
        if sha(data) != expected:
            fail(f"captured raw source hash mismatch: {path}")
        oid = git_text("rev-parse", f"{CAPTURE_HEAD}:{path}")
        if oid != blobs[path]:
            fail(f"committed blob map mismatch at captured HEAD: {path}")
        blob_checks += 1
    normal_build = read_json(NORMAL / "native-build-manifest.json")
    optimized_build = read_json(OPTIMIZED / "native-build-manifest.json")
    if normal_build != optimized_build:
        fail("normal/optimized native build manifests differ")
    matrix_source_hashes = normal_build.get("source_sha256", {})
    matrix_lf_hashes = normal_build.get("source_lf_sha256", {})
    if not set(matrix_lf_hashes).issubset(matrix_source_hashes):
        fail("matrix LF hash paths are not a subset of build source paths")
    for path in matrix_source_hashes:
        if path not in raw_hashes:
            fail(f"matrix build source missing from captured source identity: {path}")
        data = (source_dir / Path(path)).read_bytes()
        lf = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        if sha(data) != matrix_source_hashes[path] and not (path in matrix_lf_hashes and sha(lf) == matrix_lf_hashes[path]):
            fail(f"captured source is not linked to matrix build manifest: {path}")
    build = read_json(BUILT / "native-exact-build-manifest.json")
    if build.get("target") != "virtual-sparse-two-epoch":
        fail("unexpected native build target")
    src_hash = build.get("source_sha256", {})
    lf_hash = build.get("source_lf_sha256", {})
    if not set(lf_hash).issubset(src_hash):
        fail("build LF hash paths are not a subset of build source paths")
    for path in src_hash:
        data = (source_dir / Path(path)).read_bytes()
        lf = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        raw_matches = sha(data) == src_hash[path]
        lf_matches = path in lf_hash and sha(lf) == lf_hash[path]
        if not raw_matches and not lf_matches:
            fail(f"captured source is not linked to build manifest hashes: {path}")
    for field in ("compiler_sha256", "executable_sha256", "dependency_archive_sha256", "dependency_manifest_sha256"):
        if build.get(field) != normal_build.get(field):
            fail(f"matrix and build metadata pin differs: {field}")
    if build.get("compiler_sha256") != "fe251ef50a1545b1b0835ee17b1e785459712b38d79e45b5c1d3d28970a36619":
        fail("unexpected compiler hash in build manifest")
    if build.get("dependency_archive_sha256") != "33c422ab3ebfa9e86c62f41f372ec2b9c2cefa303f1885391aa4d8250ef2f831":
        fail("unexpected Boost dependency archive pin")

    case_plan = read_json(NORMAL / "case-plan.json")
    expected_success = {entry[0] for entry in case_plan["cases"]}
    summary = read_json(NORMAL / "matrix-results.json")
    if summary.get("successful_observed_requests") != 6 or summary.get("rejected_observed_requests") != 7:
        fail("retained matrix summary does not state six successes and seven rejections")
    outcomes: dict[str, dict] = {}
    stdout_hashes: dict[str, str] = {}
    for label, root in (("normal", NORMAL), ("optimized", OPTIMIZED)):
        dirs = sorted(p.parent.name for p in root.glob("*/process.json"))
        if len(dirs) != 13 or len(set(dirs)) != 13:
            fail(f"{label} run does not contain exactly 13 process records")
        current: dict[str, dict] = {}
        for case in dirs:
            base = root / case
            process = read_json(base / "process.json")
            if process.get("status") != "exited" or not process.get("actual_exit_observed") or process.get("automatic_retries") != 0:
                fail(f"invalid saved process receipt: {label}/{case}")
            rc = process.get("returncode")
            stdout = (base / "stdout.bin").read_bytes()
            stderr = (base / "stderr.bin").read_bytes()
            if len(stdout) != process["streams"][0]["saved_bytes"] or sha(stdout) != process["streams"][0]["sha256"]:
                fail(f"saved stdout disagrees with receipt: {label}/{case}")
            if len(stderr) != process["streams"][1]["saved_bytes"] or sha(stderr) != process["streams"][1]["sha256"]:
                fail(f"saved stderr disagrees with receipt: {label}/{case}")
            current[case] = {"returncode": rc, "stdout": stdout, "stderr": stderr}
        if set(dirs) != set(outcomes) and label == "optimized":
            fail("normal and optimized process case sets differ")
        if label == "normal":
            outcomes = current
        else:
            for case in sorted(outcomes):
                if outcomes[case]["returncode"] != current[case]["returncode"]:
                    fail(f"normal/optimized exit mismatch: {case}")
                if outcomes[case]["stdout"] != current[case]["stdout"]:
                    fail(f"normal/optimized stdout mismatch: {case}")
        success_names = {name for name, record in current.items() if record["returncode"] == 0}
        rejected_names = {name for name, record in current.items() if record["returncode"] == 2}
        if success_names != expected_success or len(rejected_names) != 7 or len(success_names) != 6:
            fail(f"{label} exits are not six successes and seven exit-2 rejections")
        if len(success_names | rejected_names) != 13:
            fail(f"{label} has an unexpected process exit code")
        stdout_hashes[label] = sha(b"".join(outcomes[name]["stdout"] for name in sorted(outcomes)))

    for name in ("normal", "optimized"):
        run_log = (WORK / f"sparse-two-epoch1-{name}.log").read_text(encoding="utf-8")
        math_log = (WORK / f"sparse-two-epoch-reference1-{name}.log").read_text(encoding="utf-8")
        replay_log = read_json(WORK / f"sparse-two-epoch-replay1-{name}.log")
        if "Ran 1 test" not in run_log or "OK" not in run_log:
            fail(f"saved {name} native test log does not show success")
        if "Ran 10 tests" not in math_log or "OK" not in math_log:
            fail(f"saved {name} independent math log does not show ten passing checks")
        if replay_log.get("status") != "all-two-epoch-rows-exact":
            fail(f"saved {name} replay log not successful")
    parity = (WORK / "sparse-two-epoch1-parity.log").read_text(encoding="utf-8")
    if "'streams': 13" not in parity or "'all_identical': True" not in parity:
        fail("saved parity receipt does not confirm all thirteen streams identical")
    return {
        "captured_source_head": CAPTURE_HEAD,
        "captured_source_raw_files": len(raw_hashes),
        "committed_blob_links_verified": blob_checks,
        "native_build_source_files": len(src_hash),
        "build_commit": FIXED,
        "compiler_sha256": build["compiler_sha256"],
        "dependency_archive_sha256": build["dependency_archive_sha256"],
        "normal_optimized_case_count": 13,
        "normal_optimized_stdout_identical": True,
        "success_exits_each": 6,
        "expected_rejection_exit_2_each": 7,
        "saved_stdout_concat_sha256_sorted_cases": stdout_hashes,
        "native_test_logs": "one test passed in normal and optimized modes",
        "pure_math_checks": "ten tests passed in normal and optimized modes",
        "saved_replay": "all two-epoch rows exact in normal and optimized logs",
        "parity_log": "13 streams all identical",
    }


def development_files() -> tuple[dict[str, bytes], dict]:
    failure_json = FAILED_BUILD / "build-failure.json"
    failure_log = FAILED_BUILD / "build.log"
    compiler_log = FAILED_BUILD / "compiler-version.log"
    for path in (failure_json, failure_log, compiler_log):
        if not path.is_file():
            fail(f"missing retained development failure evidence: {path}")
    failure = read_json(failure_json)
    if failure.get("target") != "virtual-sparse-two-epoch" or failure.get("returncode") != 2:
        fail("unexpected first compile-failure receipt")
    log = failure_log.read_text(encoding="utf-8", errors="replace")
    if "work_forecast" not in log or "metadata_word_forecast" not in log:
        fail("first failure log does not preserve the Catalog qualification errors")
    build = read_json(BUILT / "native-exact-build-manifest.json")
    paths = sorted(build["source_sha256"])
    files: dict[str, bytes] = {}
    source_map = {}
    for path in paths:
        oid = git_text("rev-parse", f"{INTRODUCED}:{path}")
        raw = git("cat-file", "blob", oid)
        source_map[path] = {"git_blob": oid, "bytes": len(raw), "sha256": sha(raw)}
        put(files, f"development/source/{path}", raw)
    old = git("show", f"{INTRODUCED}:native/virtual_sparse_two_epoch_forecast.hpp")
    fixed = git("show", f"{FIXED}:native/virtual_sparse_two_epoch_forecast.hpp")
    old_text = old.decode("utf-8")
    fixed_text = fixed.decode("utf-8")
    if "c::work_forecast(l)" not in old_text or "c::metadata_word_forecast(l)" not in old_text:
        fail("introduced commit does not preserve the mistaken Catalog qualification")
    if "c::Catalog::work_forecast(l)" not in fixed_text or "c::Catalog::metadata_word_forecast(l)" not in fixed_text:
        fail("candidate fix commit does not show the exact owning-class qualification")
    put(files, "development/build-failure.json", failure_json.read_bytes())
    put(files, "development/build.log", failure_log.read_bytes())
    put(files, "development/compiler-version.log", compiler_log.read_bytes())
    reconstruction = {
        "source_commit": INTRODUCED,
        "source_tree_method": "exact committed Git blob contents recovered with rev-parse and cat-file; no source checkout was executed",
        "source_files": source_map,
        "source_file_count": len(source_map),
        "original_raw_checkout_attestation": False,
        "provenance_limit": "this is reconstructed committed source, not attestation of the raw checkout used for the first failed compilation",
        "failure_classification": "compile-time Catalog method qualification error; not a numerical or mathematical miss",
        "preserved_error_names": ["work_forecast", "metadata_word_forecast"],
        "correcting_commit": FIXED,
        "binary_or_object_included": False,
    }
    put(files, "development/source-reconstruction.json", json_bytes(reconstruction))
    put(files, "package/package_sparse_two_epoch1.py", Path(__file__).read_bytes())
    return files, reconstruction


def zip_bytes(files: dict[str, bytes]) -> tuple[bytes, dict[str, dict[str, object]]]:
    if "members.json" in files:
        fail("reserved inner inventory name collision")
    expanded = sum(len(v) for v in files.values())
    if expanded > MAX_EXPANDED:
        fail(f"expanded archive exceeds 80 MiB: {expanded}")
    inventory = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(files.items())}
    members_data = json_bytes(inventory)
    if len(members_data) > MAX_MEMBER:
        fail("inner members.json exceeds the member size ceiling")
    full_inventory = dict(inventory)
    full_inventory["members.json"] = {"bytes": len(members_data), "sha256": sha(members_data)}
    expanded += len(members_data)
    if expanded > MAX_EXPANDED:
        fail(f"expanded archive including members.json exceeds 80 MiB: {expanded}")
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        info = zipfile.ZipInfo("members.json", (2026, 11, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, members_data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    result = payload.getvalue()
    if len(result) > MAX_ARCHIVE:
        fail(f"ZIP exceeds 8 MiB: {len(result)}")
    return result, full_inventory


def main() -> None:
    if OUT.exists():
        fail(f"refusing to overwrite existing package directory: {OUT}")
    packaging_head = git_text("rev-parse", "HEAD")
    if git_text("rev-parse", "--verify", f"{BASELINE}^{{commit}}") != BASELINE:
        fail("assigned baseline commit is unavailable")
    ancestor = subprocess.run(["git", "merge-base", "--is-ancestor", FIXED, CAPTURE_HEAD], cwd=REPO)
    if ancestor.returncode != 0:
        fail("candidate build commit is not an ancestor of captured matrix source HEAD")
    verification = verify_matrix_pair()
    normal_files: dict[str, bytes] = {}
    optimized_files: dict[str, bytes] = {}
    add_common(normal_files, NORMAL)
    add_common(optimized_files, OPTIMIZED)
    development, reconstruction = development_files()
    packets = {
        "normal.zip": normal_files,
        "optimized.zip": optimized_files,
        "development.zip": development,
    }
    archives: dict[str, bytes] = {}
    inventories: dict[str, dict[str, dict[str, object]]] = {}
    for name, files in packets.items():
        for path in files:
            suffix = Path(path).suffix.lower()
            if suffix in {".exe", ".obj", ".dll", ".pdb"}:
                fail(f"binary/object member prohibited by packet scope: {path}")
        archive, inventory = zip_bytes(files)
        archives[name] = archive
        inventories[name] = inventory
    packager = Path(__file__).read_bytes()
    manifest = {
        "schema": "sparse-two-epoch-evidence-package-v1",
        "baseline_head": BASELINE,
        "packaging_checkout_head": packaging_head,
        "candidate_build_commit": FIXED,
        "introduced_failure_commit": INTRODUCED,
        "matrix_source_capture_head": CAPTURE_HEAD,
        "scope": "two deterministic uniform PROOF9 observations per request; no RNG, convergence, solved-quality, N11, realistic-range, RSS, or runtime claim",
        "verification": verification,
        "development_source_reconstruction": reconstruction,
        "binary_claim": "native executable bytes and compiler object bytes are not packaged; native build metadata retains executable SHA-256 and complete source hash links",
        "limits": {"max_member_bytes": MAX_MEMBER, "max_expanded_archive_bytes": MAX_EXPANDED,
                   "max_archive_bytes": MAX_ARCHIVE, "safe_posix_paths": True,
                   "sorted_member_inventory": True, "member_inventory_file": "members.json",
                   "rootcase_directories": ["matrix"]},
        "package_script": {"source_path": "../package_sparse_two_epoch1.py", "bytes": len(packager), "sha256": sha(packager)},
        "archives": {
            name: {"bytes": len(data), "sha256": sha(data),
                   "expanded_bytes": sum(int(x["bytes"]) for x in inventories[name].values()),
                   "member_count": len(inventories[name]),
                   "inventory": inventories[name]}
            for name, data in sorted(archives.items())
        },
    }
    OUT.mkdir(parents=True, exist_ok=False)
    for name, data in archives.items():
        (OUT / name).write_bytes(data)
    manifest_data = json_bytes(manifest)
    (OUT / "manifest.json").write_bytes(manifest_data)
    print(json.dumps({"output": str(OUT), "archives": {
        name: {"bytes": len(data), "sha256": sha(data), "member_count": len(inventories[name]),
               "expanded_bytes": sum(int(x["bytes"]) for x in inventories[name].values())}
        for name, data in sorted(archives.items())},
        "manifest_bytes": len(manifest_data), "manifest_sha256": sha(manifest_data),
        "source_capture_head": CAPTURE_HEAD, "source_files": verification["captured_source_raw_files"],
        "normal_optimized_13_case_stdout_identical": verification["normal_optimized_stdout_identical"]},
        sort_keys=True))


if __name__ == "__main__":
    main()



