#include "exact_public_graph.hpp"
#include <iostream>
#include <vector>
#include <string>
using namespace openpoker::exact_public_graph;
constexpr std::uint64_t money_one_bits=0x3ff0000000000000ULL;
Graph simple() {
  Action a{"check",0,0,false,"check"};
  Graph g; g.vertices.push_back(Vertex::decision(0,{a},{1}));
  g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{money_one_bits,money_one_bits})); return g;
}
void run(const char* name, Graph g, bool reject) {
  try {
    Plan p(std::move(g),{{{48,49},money_one_bits}},{{{44,45},money_one_bits}},{{{0,4,8,12,16}}},10);
    std::cout<<name<<": accepted, group="<<p.group().size()<<", rows="<<p.rows().size()<<"\n";
    if(reject) throw std::runtime_error("unexpected acceptance");
  } catch (const PlanError& e) {
    std::cout<<name<<": rejected: "<<e.what()<<"\n";
    if(!reject) throw;
  }
}
int main() {
  int errors=0;
  auto check=[&](const char* n, Graph g, bool bad) {try {run(n,std::move(g),bad);} catch(const std::exception& e){++errors; std::cout<<"FAIL "<<n<<": "<<e.what()<<"\n";}};
  check("clean",simple(),false);
  {auto g=simple();g.vertices[1].children.push_back(0);check("terminal inactive cycle",std::move(g),true);}
  {auto g=simple();g.vertices[0].branches.push_back({"2c3c4c",0});check("decision inactive branch",std::move(g),true);}
  {auto g=simple();g.vertices[0].children[0]=0;check("active cycle",std::move(g),true);}
  {auto g=simple();g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{money_one_bits,money_one_bits}));check("unreachable vertex",std::move(g),true);}
  {Graph g;g.vertices.push_back(Vertex::chance(Street::flop,9,{{"2c3c4c",1}}));g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{money_one_bits,money_one_bits}));check("flop wrong card index",std::move(g),true);}
  {auto g=simple();g.initial_history={"turn@5c"};check("turn before flop",std::move(g),true);}
  try {
    Graph g; g.initial_history={"flop@2c3c4c","turn@5c"};
    g.vertices.push_back(Vertex::chance(Street::river,6,{{"6c",1}}));
    g.vertices.push_back(Vertex::terminal(TerminalKind::showdown,2,{money_one_bits,money_one_bits}));
    Plan p(std::move(g),{{{48,49},money_one_bits}},{{{44,45},money_one_bits}},
      {{{0,4,8,12,16}},{{0,4,8,12,21}}},10);
    const auto indexes=p.prefix_board_indexes(History{"flop@2c3c4c","turn@5c"});
    std::cout<<"incomplete chance: ACCEPTED matching_boards="<<indexes.size()<<" branches=1\n";
    ++errors;
  } catch(const PlanError& e) {std::cout<<"incomplete chance: rejected: "<<e.what()<<"\n";}
  std::cout<<"failures="<<errors<<"\n";return errors?1:0;
}


