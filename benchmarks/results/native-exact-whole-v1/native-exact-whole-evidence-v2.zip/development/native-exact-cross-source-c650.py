import hashlib,json,struct
from pathlib import Path
work=Path(__file__).resolve().parent
pins=[('native-exact-whole-study-v1','255933b35d81f0a344bec0e2d2340c8ba84fa3a22151c1093717a8fc46684e18'),('native-exact-whole-study-v2','c92a8a00093a354b9f85da7931f61dec663b3bd7b74119603a9053ff3a52dd88')]
def need(c,m):
 if not c:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def read_study(name,pin):
 p=work/name; blobs={x.relative_to(p).as_posix():x.read_bytes() for x in p.rglob('*') if x.is_file()};need(sha(blobs['manifest.json'])==pin,'manifest pin');m=json.loads(blobs['manifest.json']);need(set(blobs)==set(m['sha256'])|{'manifest.json'},'inventory');need(all(sha(blobs[k])==v for k,v in m['sha256'].items()),'raw artifacts');return blobs
before=[read_study(*x) for x in pins];metrics=('value_sb','value_bb','sb_best_response_value','bb_best_response_value','sb_gain','bb_gain','nash_conv','exploitability')
def bits(v):return struct.pack('>d',v).hex()
labels=['original-22-t10-native-0','original-22-t10-native-1','original-22-t10-native-2','original-22-t10-native-traced','payoff-varied-t100-native-0','blocker-18-native-0','asymmetric-weighted-native-0','mixed-stabilizer-native-0']
counts=[]
for label in labels:
 a,b=[json.loads(x[label+'.json'])['payload'] for x in before]
 def rows(p):return {(r['player'],r['hand'],tuple(r['history'])):(tuple((x['name'],bits(x['amount']),bits(x['raise_to']),x['history_key'],bits(x['probability'])) for x in r['actions']),r['street'],tuple(r['revealed_board'])) for r in p['strategy']}
 ra,rb=rows(a),rows(b);need(len(ra)==len(a['strategy']) and len(rb)==len(b['strategy']) and ra==rb,'policy bits '+label);need(all(bits(a[k])==bits(b[k]) for k in metrics),'metric bits '+label);counts.append({'label':label,'rows':len(ra)})
need([read_study(*x) for x in pins]==before,'study bytes drift');receipt={'status':'passed','samples':counts,'metric_fields':list(metrics),'scope':'Cross-source saved policy/menu/metric bit identity only; timing not compared, no production execution.'}
out=work/'native-exact-cross-source-c650-receipt.json';need(not out.exists(),'refuse overwrite');out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf8');print(json.dumps(receipt))
