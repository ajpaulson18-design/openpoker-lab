#include "C:/Users/pauls/Documents/Codex/2026-10-26/files-pasted-by-the-user-i/work/native-exact-engine-repo/native/exact_selected_cfr.hpp"
int main() {
  namespace epg = openpoker::exact_public_graph;
  using namespace openpoker::exact_selected_kernel;
  const auto one=0x3ff0000000000000ULL;
  epg::Graph g;
  g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::showdown,2,{one,one}));
  g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::fold,0,{one,one}));
  std::vector<epg::Action> menu{{"check",0,0,false,"check"},{"fold",0,0,false,"fold"}};
  g.vertices.push_back(epg::Vertex::decision(0,menu,{0,1})); g.root_id=2;
  WeightedHand a{{5,6},one}, b{{7,8},one}; SelectedBoard board{{0,1,2,3,4}};
  epg::Plan plan(std::move(g),{a},{b},{board},10);
  openpoker::exact_selected_cfr::Trainer trainer(plan);
  auto result=trainer.run();
  return result.quotient_policy.size()==2 ? 0 : 1;
}
