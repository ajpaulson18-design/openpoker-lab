#include "C:/Users/pauls/Documents/Codex/2026-10-26/files-pasted-by-the-user-i/work/native-exact-engine-repo/native/exact_public_graph.hpp"
#include <cassert>
namespace epg=openpoker::exact_public_graph;
using openpoker::exact_selected_kernel::WeightedHand; using openpoker::exact_selected_kernel::SelectedBoard;
const std::uint64_t unit_bits=0x3ff0000000000000ULL;
std::vector<WeightedHand> sb{{{48,44},unit_bits},{{49,45},unit_bits}}, bb{{{40,36},unit_bits},{{41,37},unit_bits}};
std::vector<SelectedBoard> boards{{{{0,4,20,30,35}}},{{{1,5,21,30,35}}}};
std::vector<epg::Action> menu{{"check",0,0,false,"check"},{"fold",0,0,false,"fold"}};
epg::Graph chance_graph(std::size_t cardidx=4, bool omit=false) {
 epg::Graph g; g.root_id=4;
 g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::showdown,2,{unit_bits,unit_bits}));
 g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::fold,0,{unit_bits,unit_bits}));
 g.vertices.push_back(epg::Vertex::decision(0,menu,{0,1})); g.vertices.push_back(epg::Vertex::decision(0,menu,{0,1}));
 auto branches=std::vector<epg::Branch>{{"2c3c7c",2},{"2d3d7d",3}}; if(omit) branches.pop_back();
 g.vertices.push_back(epg::Vertex::chance(epg::Street::flop,cardidx,std::move(branches))); return g;
}
bool rejects(epg::Graph g) { try { epg::Plan p(std::move(g),sb,bb,boards,10); } catch(const epg::PlanError&) { return true; } return false; }
int main(){
 assert(!rejects(chance_graph()));
 assert(rejects(chance_graph(9)));
 assert(rejects(chance_graph(4,true)));
 epg::Graph terminal; terminal.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::showdown,2,{unit_bits,unit_bits})); terminal.vertices[0].children.push_back(0); assert(rejects(std::move(terminal)));
 epg::Graph decision; decision.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::showdown,2,{unit_bits,unit_bits})); decision.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::fold,0,{unit_bits,unit_bits})); decision.vertices.push_back(epg::Vertex::decision(0,menu,{0,1})); decision.root_id=2; decision.vertices[2].branches.push_back({"x",0}); assert(rejects(std::move(decision)));
}

