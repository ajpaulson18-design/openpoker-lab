#include "C:/Users/pauls/Documents/Codex/2026-10-26/files-pasted-by-the-user-i/work/native-exact-engine-repo/native/exact_public_graph.hpp"
#include <cassert>
int main() {
  namespace epg = openpoker::exact_public_graph;
  using openpoker::exact_selected_kernel::WeightedHand;
  using openpoker::exact_selected_kernel::SelectedBoard;
  const auto one = 0x3ff0000000000000ULL;
  epg::Graph g; g.root_id=4;
  g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::showdown, 2, {0,0}));
  g.vertices.push_back(epg::Vertex::terminal(epg::TerminalKind::fold, 0, {one,one}));
  std::vector<epg::Action> menu{{"check",0,0,false,"check"},{"fold",0,0,false,"fold"}};
  g.vertices.push_back(epg::Vertex::decision(0,menu,{0,1}));
  g.vertices.push_back(epg::Vertex::decision(0,menu,{0,1}));
  g.vertices.push_back(epg::Vertex::chance(epg::Street::flop,4,{{"2c3c7c",2},{"2d3d7d",3}}));
  std::vector<WeightedHand> sb{{{48,44},one},{{49,45},one}};
  std::vector<WeightedHand> bb{{{40,36},one},{{41,37},one}};
  std::vector<SelectedBoard> boards{{{{0,4,20,30,35}}},{{{1,5,21,30,35}}}};
  epg::Plan plan(std::move(g),sb,bb,boards,10);
  assert(plan.group().size() >= 2);
  assert(plan.rows().size() == 2);
  epg::History h{"flop@2c3c7c"};
  auto rows=plan.locate_decision_rows(0,h,menu);
  unsigned n=0;
  for (std::size_t i=0;i<rows.size();++i) if(rows[i]) { ++n; assert(plan.locate({0,i,h})==*rows[i]); }
  assert(n > 0);
  return 0;
}




