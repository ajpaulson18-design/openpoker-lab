"""Development-only full physical policy comparison; no frozen claim."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).with_name('native-exact-engine-repo')))
from scripts.benchmark_suit_quotient_solver import case_for, request_for
from pokerlab.exact_selected_solver import _prepare_exact_selected, solve_four_street_exact_selected
from pokerlab.native_exact_four_street import train
build = Path(__file__).with_name('native-exact-engine-development-build')
exe = build / 'native-exact-four-street-train.exe'
name = sys.argv[1] if len(sys.argv) > 1 else 'payoff-varied-t10'
request = request_for(case_for(name), 10)
prepared = _prepare_exact_selected(request, rank_cache_boards=64, pair_diagnostics='compact',
    exact_arithmetic='dyadic', training_reduction='suit-equivariant', strategy_storage='suit-quotient', quotient_lookup='per-decision')
native, receipt = train(prepared, executable=exe, rank_cache_boards=64)
reference = solve_four_street_exact_selected(request, rank_cache_boards=64, pair_diagnostics='compact',
    exact_arithmetic='dyadic', training_reduction='suit-equivariant', strategy_storage='suit-quotient', quotient_lookup='per-decision')
expected = {}
for row in reference['strategy']:
    player = 0 if row['player'] == 'sb' else 1
    hand = next(i for i, value in enumerate(prepared.kernel.hands[player]) if ''.join(value) == row['hand'])
    expected[player, hand, tuple(row['history'])] = [action['probability'] for action in row['actions']]
if set(native) != set(expected):
    raise ValueError('policy support mismatch')
differences = [key for key in native if [value.hex() for value in native[key]] != [value.hex() for value in expected[key]]]
if differences:
    raise ValueError('native policy bits differ: ' + repr([(key, native[key], expected[key]) for key in differences[:3]]))
print(json.dumps({'case': name, 'physical_rows': len(native), 'all_policy_bits_identical': True,
    'native': {key:value for key,value in receipt.items() if key!='build'},
    'scope': 'Development full policy parity only. Existing Python rules/kernel/trainer comparison; independent saved-policy quality not yet run.'}, sort_keys=True))
