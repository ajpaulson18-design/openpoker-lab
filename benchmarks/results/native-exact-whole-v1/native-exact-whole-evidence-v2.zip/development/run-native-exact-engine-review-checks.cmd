@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
set "OPENPOKER_NATIVE_EXACT_FOUR_STREET_EXE=C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\native-exact-engine-development-build\native-exact-four-street-train.exe"
"C:\Users\pauls\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -O -m unittest tests.test_native_exact_four_street.NativeExactFourStreetCompiledTests.test_direct_graph_adversaries_and_full_cfr_phase_controls tests.test_benchmark_native_exact_four_street -v
exit /b %errorlevel%
