"""Saved-only independent native exact whole-game review; never runs producer."""
import argparse,base64,hashlib,importlib.util,itertools,json,math,struct,sys
from pathlib import Path
from fractions import Fraction
from contextlib import ExitStack
from unittest.mock import patch
PIN='8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
COMMIT='52aa21f343aa769c4aeabf6fb7eb7c6be6816f96'
MANIFEST='255933b35d81f0a344bec0e2d2340c8ba84fa3a22151c1093717a8fc46684e18'
REPORT='e4aa2fa8f85b3c3567b90349784c44bcf451ed327bf40e35fc86c39a27c70fbc'
AFTER='9c2701151c44f386fe836a94b93fc3e04988368dfc506e13be404e06e9572b09'
METRICS=('value_sb','value_bb','sb_best_response_value','bb_best_response_value','sb_gain','bb_gain','nash_conv','exploitability')
SCHEDULE=[('original-22-t10',mode,i,False) for i in range(3) for mode in (('python','native') if i%2==0 else ('native','python'))]+[('original-22-t10',m,'traced',True) for m in ('python','native')]+[(name,m,0,False) for name in ('payoff-varied-t100','blocker-18','asymmetric-weighted','mixed-stabilizer','original-22-qreject') for m in ('python','native')]
SUITS='cdhs'; DECK=tuple(r+s for r in '23456789TJQKA' for s in SUITS); ORDER={c:i for i,c in enumerate(DECK)}
def check(v,m):
 if not v: raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_helper(name):
 p=Path(__file__).with_name(name);spec=importlib.util.spec_from_file_location('review_helper_'+name.replace('-','_').replace('.','_'),p);obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
def hand(h,m):return tuple(sorted(c[0]+m[c[1]] for c in h))
def board(b,m):return tuple(sorted((c[0]+m[c[1]] for c in b[:3]),key=ORDER.__getitem__))+tuple(c[0]+m[c[1]] for c in b[3:])
def history(h,m):
 out=[]
 for t in h:
  if t.startswith('flop@'):out.append('flop@'+''.join(sorted((t[i]+m[t[i+1]] for i in (5,7,9)),key=ORDER.__getitem__)))
  elif t.startswith(('turn@','river@')):out.append(t[:-1]+m[t[-1]])
  else:out.append(t)
 return tuple(out)
def bits(v):return struct.pack('>d',v).hex()
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--study',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--confirmed-terminal-handle',required=True);p.add_argument('--terminal-exit-code',type=int,required=True);a=p.parse_args()
 check((a.confirmed_terminal_handle,a.terminal_exit_code)==('25869',0),'unconfirmed producer status')
 repo=a.repo.resolve();study=a.study.resolve();out=a.output_dir.resolve();check(not out.exists() and repo not in out.parents and study not in out.parents,'new external output required');out.mkdir()
 ap=Path(__file__).with_name('exact-selected-independent-review.py');check(sha(ap.read_bytes())==PIN,'authentication helper pin');auth=load_helper(ap.name);auth.FROZEN=COMMIT;parse=auth.parse
 saved={p.relative_to(study).as_posix():p.read_bytes() for p in study.rglob('*') if p.is_file()};check(sha(saved['manifest.json'])==MANIFEST,'manifest pin');manifest=parse(saved['manifest.json']);check(manifest['source_commit']==COMMIT and set(saved)==set(manifest['sha256'])|{'manifest.json'},'inventory')
 for n,v in manifest['sha256'].items():check(Path(n).name==n and sha(saved[n])==v,'artifact '+n)
 check(sha(saved['report.json'])==REPORT and sha(saved['source-after.json'])==AFTER,'report/source pin')
 source=parse(saved['source-before.json']);check(parse(saved['source-after.json'])==source,'source drift recorded');identity=auth.source_identity(repo,source)
 protocol=parse(saved['protocol.json']);report=parse(saved['report.json']);check(protocol['source_commit']==report['source_commit']==COMMIT and protocol['version']=='native-exact-four-street-fixed-study-v1' and protocol['schedule']==[list(i) for i in SCHEDULE],'protocol/schedule');check(report['calls_planned']==report['calls_completed']==18 and report['failure'] is None and len(report['samples'])==18,'producer status')
 build=protocol['build'];exe=Path(build['executable']);bp=exe.parent/'native-exact-build-manifest.json';br=bp.read_bytes();bm=parse(br)
 check(sha(br)==build['manifest_sha256'] and sha(exe.read_bytes())==build['executable_sha256'],'build bytes')
 names={'native/exact_four_street_train.cpp','native/exact_public_graph.hpp','native/exact_selected_cfr.hpp','native/exact_selected_kernel.hpp','native/exact_binary64.hpp','scripts/build_native_exact_four_street.py','third_party/boost-multiprecision-1.92.0/manifest.json','third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt','third_party/boost-multiprecision-1.92.0/headers.zip'}
 check(set(build['source_sha256'])==names and bm['source_sha256']==build['source_sha256'] and bm['executable_sha256']==build['executable_sha256'] and all(sha((repo/n).read_bytes())==v for n,v in build['source_sha256'].items()),'build closure')
 sys.path.insert(0,str(repo));from scripts import four_street_validation as physical, exact_selected_compact_certificate as cert
 from scripts.preflop_validation import compare_result
 forbidden=['pokerlab.exact_selected_solver.solve_four_street_exact_selected','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.__init__','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.terminal_values_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.joint_marginals_exact','pokerlab.exact_selected_kernel.ExactSelectedRunoutKernel.pair_probability_exact','pokerlab.exact_selected_kernel.rank_hand','pokerlab.cards.rank_hand','pokerlab.dyadic_selected_arithmetic.DyadicSelectedArithmeticPlan.__init__','pokerlab.suit_quotient_plan.SuitQuotientPlan.__init__','pokerlab.suit_quotient_cfr.train_suit_quotient','pokerlab.equivariant_packed_cfr.train_equivariant_packed','pokerlab.packed_operator_cfr.train_packed','pokerlab.preflop_solver._enumerate_physical_worlds','pokerlab.selected_runout_operator.SelectedRunoutOperator._iter_worlds','pokerlab.native_selected_operator.train_native_selected','pokerlab.native_selected_dag.train_native_selected_dag','pokerlab.native_public_cfr.train_native_public','pokerlab.native_exact_four_street._invoke','subprocess.Popen']
 payloads={};certs={};orbits=[];gaps=[];models={};raws={}
 with ExitStack() as guard:
  for target in forbidden:guard.enter_context(patch(target,side_effect=AssertionError('forbidden '+target)))
  for record,entry in zip(report['samples'],SCHEDULE):
   name,mode,sample,traced=entry;label=f'{name}-{mode}-{sample}';raw=parse(saved[label+'.json']);raws[label]=raw
   check(record.get('artifact')==label+'.json' and {k:v for k,v in record.items() if k!='artifact'}=={k:v for k,v in raw.items() if k not in ('payload','native_streams')},'report binding '+label)
   check((raw['case'],raw['mode'],raw['sample'],raw['traced'])==entry and raw['runtime']==protocol['runtime'],'sample '+label)
   check(math.isfinite(raw['seconds']) and raw['seconds']>0 and isinstance(raw['process_peak_bytes'],int) and raw['process_peak_bytes']>0,'timing')
   check((isinstance(raw['python_allocation_peak_bytes'],int) and raw['python_allocation_peak_bytes']>0) if traced else raw['python_allocation_peak_bytes'] is None,'trace')
   counts=raw['counts'];check(not any(counts[k] for k in ('pair','world','legacy')),'forbidden producer counters')
   if name.endswith('qreject'):
    check(raw['payload'] is None and raw['failure'] and raw['iterations']==1000 and not any(counts[k] for k in ('python_trainer','native_invoke','python_rank')) and not raw['native_streams'],'pretraining rejection');continue
   x=raw['payload'];T=100 if name.endswith('t100') else 10;check(x is not None and raw['failure'] is None and raw['iterations']==T,'missing policy');encoded=json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode();check((sha(encoded),len(encoded))==(raw['payload_sha256'],raw['payload_bytes']),'payload digest')
   case=protocol['cases'][name];models.setdefault(name,physical.build_model(case));model=models[name]
   expanded=dict(x,compatible_private_pairs=model.counts['compatible_pairs'],private_pair_probabilities=[{'sb_hand':r['sb_hand'],'bb_hand':r['bb_hand'],'probability':float(Fraction(r['fraction']))} for r in model.counts['pair_probabilities']]);replay=physical.replay_policy(expanded,case);compare_result(expanded,replay)
   v=replay['value_sb'];b0=replay['sb_best_response_value'];b1=replay['bb_best_response_value'];g0=max(0.,b0-v);g1=max(0.,b1+v);mm=dict(value_sb=v,value_bb=-v,sb_best_response_value=b0,bb_best_response_value=b1,sb_gain=g0,bb_gain=g1,nash_conv=g0+g1,exploitability=(g0+g1)/2)
   delta={k:abs(x[k]-mm[k]) for k in METRICS};check(all(math.isfinite(x[k]) and delta[k]<=1e-10 for k in METRICS),'physical metric mismatch '+label);gaps.append(delta)
   fresh=cert.evaluate_exact(case,x);old=parse(saved[label+'-verification.json'])['exact_compact_certificate'];f=fresh['exact_certificate'];z=old['exact_certificate'];check(all(f[k]==z[k] for k in ('metrics','threshold','threshold_met','normalized_policy_sha256')) and fresh['compact_input_canonical_sha256']==old['compact_input_canonical_sha256'],'exact certificate '+label)
   (out/(label+'-fresh-certificate.json')).write_text(json.dumps(fresh,sort_keys=True,indent=2,allow_nan=False),encoding='utf8');certs[label]=f;payloads[label]=x
   if mode!='native':continue
   check(counts['native_invoke']==1 and counts['python_trainer']==0 and counts['rank_before_native']==0 and len(raw['native_streams'])==1,'native counters')
   stream=raw['native_streams'][0];rq,rs,err=(base64.b64decode(stream[k],validate=True) for k in ('request','stdout','stderr'));nc=x['operator_census']['native_exact'];check(stream['returncode']==0 and not err and (sha(rq),sha(rs),len(rq),len(rs))==(nc['request_sha256'],nc['result_sha256'],nc['request_bytes'],nc['result_bytes']),'native stream')
   lines=rs.decode('ascii').splitlines();check(lines[0]=='OPENPOKER_NATIVE_EXACT_FOUR_STREET_RESULT_V1','native header');ranges=x['chance_input_snapshot']['ranges'];rows={(r['player'],r['hand'],tuple(r['history'])):r for r in x['strategy']};seen=set()
   done=[line.split('\t') for line in lines[1:] if line.startswith('DONE\t')];fields_order=('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots','member_checks','expected_member_checks','modeled_work_upper','kernel_work_upper','retained_entries_upper','maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls');check(len(done)==1 and len(done[0])==14 and [int(v) for v in done[0][1:]]==[nc[k] for k in fields_order],'DONE counters '+label)
   for line in lines[1:]:
    fields=line.split('\t')
    if fields[0]!='ROW':check(fields[0]=='DONE','unexpected native record');continue
    player=int(fields[1]);index=int(fields[2]);n=int(fields[3]);hist=tuple(fields[4:4+n]);count=int(fields[4+n]);values=fields[5+n:];check(player in (0,1) and 0<=index<len(ranges[player]) and len(values)==count,'ROW dimensions');key=('sb' if player==0 else 'bb',ranges[player][index]['hand'],hist);check(key in rows and key not in seen,'ROW identity');seen.add(key);check(values==[bits(a['probability']) for a in rows[key]['actions']],'ROW probabilities '+label)
   check(len(seen)==len(rows)==x['info_sets'] and nc['member_checks']==2*T*len(rows) and nc['maximum_numeric_workspace_slots']==4*nc['quotient_action_slots'] and nc['final_numeric_workspace_slots']==0,'native row/counters')
   outcomes,rng=physical._case_inputs(case)[-2:];group=[]
   for perm in itertools.permutations(SUITS):
    m=dict(zip(SUITS,perm))
    if all({hand(h,m):Fraction.from_float(float(w)) for h,w in side.items()}=={h:Fraction.from_float(float(w)) for h,w in side.items()} for side in rng) and {board(b,m) for b in outcomes}==set(outcomes):group.append(m)
   keys=model.expected_infos;classes={}
   for k,node in keys.items():
    images={(k[0],''.join(hand((k[1][:2],k[1][2:]),m)),history(k[2],m)) for m in group};check(all(q in keys and tuple((a.name,a.amount,a.raise_to,a.token) for a in keys[q].actions)==tuple((a.name,a.amount,a.raise_to,a.token) for a in node.actions) for q in images),'group/menu closure');classes[min(images)]=(len(images),len(node.actions))
    ref=rows[('sb' if k[0]==0 else 'bb',k[1],k[2])];check(all([bits(a['probability']) for a in ref['actions']]==[bits(a['probability']) for a in rows[('sb' if q[0]==0 else 'bb',q[1],q[2])]['actions']] for q in images),'orbit bits')
   check((nc['group_size'],nc['quotient_rows'],nc['quotient_action_slots'])==(len(group),len(classes),sum(c for _,c in classes.values())),'physical quotient census '+label);orbits.append({'label':label,'group':len(group),'rows':len(keys),'q_rows':len(classes),'q_slots':sum(c for _,c in classes.values()),'orbit_sizes':sorted({n for n,_ in classes.values()})})
 for name,_,sample,traced in SCHEDULE:
  if name.endswith('qreject'):continue
  p=f'{name}-python-{sample}';n=f'{name}-native-{sample}';check(payloads[p]['strategy']==payloads[n]['strategy'] and all(bits(payloads[p][k])==bits(payloads[n][k]) for k in METRICS),'paired bits '+p);check(certs[p]['metrics']==certs[n]['metrics'] and certs[p]['threshold_met']==certs[n]['threshold_met'],'paired exact '+p)
 check(len(payloads)==16 and len(orbits)==8,'sample coverage');check(auth.source_identity(repo,source)['raw_sha256']==identity['raw_sha256'],'source drift');check({p.relative_to(study).as_posix():p.read_bytes() for p in study.rglob('*') if p.is_file()}==saved and bp.read_bytes()==br and sha(exe.read_bytes())==build['executable_sha256'],'artifact/build drift')
 receipt={'status':'passed','source_commit':COMMIT,'source_files':identity['files'],'manifest_sha256':MANIFEST,'report_sha256':REPORT,'executable_sha256':build['executable_sha256'],'complete_policies':len(payloads),'paired_comparisons':8,'pretraining_rejections':2,'quality_passes':sum(v['threshold_met'] for v in certs.values()),'quality_misses':sum(not v['threshold_met'] for v in certs.values()),'max_metric_gap':max(max(g.values()) for g in gaps),'orbits':orbits,'scope':'Saved policies and native ROW bits; no production trainer or candidate executable invoked; no independent full input graph equivalence claim.'}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True),encoding='utf8');print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
