"""Saved raw native request versus independent legal numeric graph proof.

No candidate execution, production wire/parser, ranker, solver, kernel or trainer.
Full frozen source/build/artifacts authenticate before independent math imports.
"""
import argparse
import base64
from fractions import Fraction
from collections import deque
from contextlib import ExitStack
import hashlib
import importlib.abc
import importlib.util
from itertools import permutations
import json
import math
from pathlib import Path
import struct
import sys
from unittest.mock import patch
import zipfile

FROZEN = "c6508947ad12a51db87bf2b41616c966ee5d339a"
AUTH_SHA = "8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5"
MANIFEST_SHA = "c92a8a00093a354b9f85da7931f61dec663b3bd7b74119603a9053ff3a52dd88"
REPORT_SHA = "aeea8234946e4f8357fe94a8aa3987f5cfe402cf1e18f450d14e767cef9a306c"
AFTER_SHA = "8bb0f9204337d5fedd5d3b4707128671407c655afe0176739d79a285caae5957"
BUILD_SHA = "178462cac2aa83fac228bb7fed0307f8d4b0c288cc9c5864600573dc154e7e25"
EXE_SHA = "829db4fbc29e13d5815803cafe0e59a1478f7390308a9130dd53c59e60196873"
DEP_SHA = "4d6f33341887e35a0c29e9dc5da2a326d546427940c2b16b485db0c61b042555"
ZIP_SHA = "33c422ab3ebfa9e86c62f41f372ec2b9c2cefa303f1885391aa4d8250ef2f831"
LICENSE_SHA = "c9bff75738922193e67fa726fa225535870d2aa1059f91452c411736284ad566"
BUILD_SOURCES = {"native/exact_four_street_train.cpp", "native/exact_public_graph.hpp", "native/exact_selected_cfr.hpp",
    "native/exact_selected_kernel.hpp", "native/exact_binary64.hpp", "scripts/build_native_exact_four_street.py",
    "third_party/boost-multiprecision-1.92.0/manifest.json", "third_party/boost-multiprecision-1.92.0/LICENSE_1_0.txt",
    "third_party/boost-multiprecision-1.92.0/headers.zip"}
MATH_SOURCES = ("scripts/four_street_validation.py", "scripts/turn_river_validation.py", "scripts/preflop_validation.py", "pokerlab/cards.py")
DECK = tuple(rank+suit for rank in "23456789TJQKA" for suit in "cdhs")
ORDER = {card:index for index,card in enumerate(DECK)}
COUNTERS = ("expanded_rows", "expanded_action_slots", "group_size", "quotient_rows", "quotient_action_slots", "member_checks",
    "expected_member_checks", "modeled_work_upper", "kernel_work_upper", "retained_entries_upper",
    "maximum_numeric_workspace_slots", "final_numeric_workspace_slots", "rank_calls")
FORBIDDEN = ("pokerlab.native_exact_four_street", "pokerlab.exact_selected_kernel", "pokerlab.dyadic_selected_arithmetic",
    "pokerlab.exact_selected_solver", "pokerlab.suit_quotient_plan", "pokerlab.suit_quotient_cfr", "pokerlab.equivariant_packed_cfr",
    "pokerlab.preflop_solver", "pokerlab.preflop_tree", "pokerlab.river_tree", "pokerlab.postflop_solver", "pokerlab.cfr")


def need(value,message):
    if not value:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def write(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n",encoding="utf-8",newline="\n")


def bits(value):return struct.pack(">d",float(value)).hex()


def inventory(folder):
    result={}
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            need(not path.is_symlink() and path.stat().st_size<=64*1024*1024,"linked/oversized artifact")
            result[path.relative_to(folder).as_posix()]=path.read_bytes()
    need(sum(map(len,result.values()))<=256*1024*1024,"oversized study inventory")
    return result


def build_auth(repo,protocol,source,parse):
    identity=protocol["build"];exe=Path(identity["executable"])
    raw=(exe.parent/"native-exact-build-manifest.json").read_bytes()
    need(sha(raw)==identity["manifest_sha256"]==BUILD_SHA,"actual build manifest pin drift")
    build=parse(raw)
    need(build["contract"]=="native-exact-build-v1" and build["target"]=="engine" and build["license"]=="BSL-1.0","wrong build contract")
    expected={name:source["sha256"][name] for name in BUILD_SOURCES}
    need(set(expected)==BUILD_SOURCES and build["source_sha256"]==identity["source_sha256"]==expected,"full nine-source build closure mismatch")
    expected_lf={name:sha((repo/name).read_bytes().replace(b"\r\n",b"\n")) for name in BUILD_SOURCES if not name.endswith(".zip")}
    need(build["source_lf_sha256"]==expected_lf,"build LF source closure mismatch")
    need(build["executable_sha256"]==identity["executable_sha256"]==sha(exe.read_bytes())==EXE_SHA and
         Path(build["executable"]).resolve()==exe.resolve(),"actual executable bytes changed")
    for key in ("compiler","compiler_version","flags","platform"):need(build[key]==identity[key],"build metadata mismatch: "+key)
    need("/fp:strict" in build["flags"] and "/fp:fast" not in build["flags"],"strict FP build missing")
    dep_path=repo/"third_party/boost-multiprecision-1.92.0"
    need(sha((dep_path/"manifest.json").read_bytes())==build["dependency_manifest_sha256"]==DEP_SHA and
         sha((dep_path/"headers.zip").read_bytes())==build["dependency_archive_sha256"]==ZIP_SHA and
         sha((dep_path/"LICENSE_1_0.txt").read_bytes())==LICENSE_SHA and build["dependency_headers"]==198 and
         build["dependency_commit"]=="1f7acd34fe929573c131e869867dc1d12b8080b6","dependency pins differ")
    dep=parse((dep_path/"manifest.json").read_bytes())
    with zipfile.ZipFile(dep_path/"headers.zip") as packed:
        rows={info.filename:packed.read(info) for info in packed.infolist() if not info.is_dir()}
        need(len(rows)==198 and {name:sha(value) for name,value in rows.items()}==dep["headers_sha256"],"pinned headers archive inventory differs")
    include=exe.parent/"boost-include"
    need({name:sha(value) for name,value in inventory(include).items()}==dep["headers_sha256"],"actual extracted build headers differ")
    return {"manifest_sha256":BUILD_SHA,"executable_sha256":EXE_SHA,"source_sha256":expected,
        "dependency_headers_verified":198,"dependency_archive_sha256":ZIP_SHA,"actual_executable_executed":False}


def parse_wire(raw):
    need(type(raw) is bytes and len(raw)<=64*1024*1024 and raw.endswith(b"\n"),"invalid native input envelope")
    tokens=raw.decode("ascii").split();need(len(tokens)<=200000,"native input token cap")
    pos=0
    def take():
        nonlocal pos
        need(pos<len(tokens),"truncated native input")
        text=tokens[pos];pos+=1
        need(0<len(text)<=64 and all(32<ord(c)<127 for c in text),"invalid native token")
        return text
    def nat(ceiling):
        text=take();need(text.isdecimal() and len(text)<=12,"invalid natural field")
        value=int(text);need(value<=ceiling,"native natural exceeds independent cap");return value
    def fp():
        text=take();need(len(text)==16 and all(c in "0123456789abcdef" for c in text),"invalid exact FP bits")
        value=struct.unpack(">d",bytes.fromhex(text))[0];need(math.isfinite(value),"nonfinite native money/prior")
        return text
    need(take()=="OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1","wrong input magic")
    iterations=nat(10000);cache=nat(64);h0,h1=nat(4),nat(4);b=nat(8);n=nat(2048);e=nat(16384);root=nat(max(n-1,0));initial_n=nat(32)
    need(iterations>=10 and cache and h0 and h1 and b and n,"unsupported fixed input dimensions")
    caps=(65536,500000000,2000000,1<<30,500000000,2000000,16000000,500000000,25000000,1000000,2000000)
    limits=[nat(cap) for cap in caps];need(all(limits),"zero native limit")
    ranges=[]
    for h in (h0,h1):
        side=[]
        for _ in range(h):
            a,c=nat(51),nat(51);weight=fp();need(a!=c and struct.unpack(">d",bytes.fromhex(weight))[0]>0,"invalid positive holding")
            side.append({"hand":[DECK[a],DECK[c]],"weight_bits":weight})
        need(len({tuple(sorted(row["hand"])) for row in side})==h,"duplicate private holding")
        ranges.append(side)
    boards=[[DECK[nat(51)] for _ in range(5)] for _ in range(b)]
    need(all(len(set(outcome))==5 and outcome[:3]==sorted(outcome[:3],key=ORDER.__getitem__) for outcome in boards) and
         boards==sorted(boards,key=lambda outcome:tuple(ORDER[c] for c in outcome)) and len({tuple(v) for v in boards})==b,"noncanonical or duplicate native selected boards")
    initial=[take() for _ in range(initial_n)];vertices=[];edges=0
    for _ in range(n):
        tag=take()
        if tag=="D":
            actor=nat(1);count=nat(32);need(count>0,"empty action menu");actions=[];children=[]
            for _ in range(count):
                action={"name":take(),"amount_bits":fp(),"raise_to_bits":fp(),"full_raise":bool(nat(1)),"token":take()}
                actions.append(action);children.append(nat(n-1))
            need(len({a["token"] for a in actions})==count,"duplicate native action tokens")
            vertices.append({"kind":"D","actor":actor,"actions":actions,"children":children});edges+=count
        elif tag=="C":
            street=nat(3);index=nat(6);count=nat(8);need(street and count and index==street+3,"wrong native reveal index/street")
            branches=[(take(),nat(n-1)) for _ in range(count)];need(len({v[0] for v in branches})==count,"duplicate chance labels")
            vertices.append({"kind":"C","street":street,"card_index":index,"branches":branches});edges+=count
        elif tag in ("F","S"):
            winner=nat(1) if tag=="F" else None
            contributions=[fp(),fp()];need(all(struct.unpack(">d",bytes.fromhex(value))[0]>=0 for value in contributions),"negative terminal money")
            vertices.append({"kind":tag,"winner":winner,"contribution_bits":contributions})
        else:raise ValueError("unknown native wire field/vertex tag")
    need(pos==len(tokens) and edges==e,"unknown trailing native fields or edge mismatch")
    def children(v):return v["children"] if v["kind"]=="D" else [child for _,child in v["branches"]] if v["kind"]=="C" else []
    degrees=[0]*n
    for vertex in vertices:
        for child in children(vertex):degrees[child]+=1
    queue=deque(i for i,d in enumerate(degrees) if d==0);order=[]
    while queue:
        i=queue.popleft();order.append(i)
        for child in children(vertices[i]):
            degrees[child]-=1
            if degrees[child]==0:queue.append(child)
    need(len(order)==n,"native graph cycle")
    reached={root};depth={root:0}
    for i in order:
        need(i in reached,"native graph unreachable vertex")
        for child in children(vertices[i]):
            reached.add(child);depth[child]=max(depth.get(child,0),depth[i]+1)
            need(depth[child]<=32,"independent numeric graph depth cap")
    return {"iterations":iterations,"rank_cache_boards":cache,"ranges":ranges,"boards":boards,"vertices":vertices,
        "root":root,"initial_history":initial,"edges":edges,"limits":limits,"maximum_depth":max(depth.values())}


def compare_graph(parsed,case,physical):
    parsed_case=physical._case_inputs(case)
    outcomes,ranges=parsed_case[-2:]
    expected_ranges=[[{"hand":list(hand),"weight_bits":bits(weight)} for hand,weight in side.items()] for side in ranges]
    need(parsed["ranges"]==expected_ranges,"raw ordered physical holdings/prior bits differ from independent case parser")
    need(parsed["boards"]==[list(outcome) for outcome in outcomes],"raw selected ordered boards differ from independent case parser")
    model=physical.build_model(case)
    history=tuple(parsed["initial_history"])
    need(history==getattr(model.root,"history",()),"native root initial visible history differs")
    pending=[(parsed["root"],model.root,history,())];visits=decisions=chance=terminals=flag_count=0;menus={};tail_proofs=[]
    while pending:
        index,node,history,visible=pending.pop();visits+=1
        need(visits<=physical.MAX_STATES and len(history)<=physical.MAX_DEPTH,"paired graph traversal exceeds unchanged physical cap")
        vertex=parsed["vertices"][index]
        if isinstance(node,physical._Decision):
            decisions+=1
            need(vertex["kind"]=="D" and vertex["actor"]==node.player and history==tuple(node.history) and visible==tuple(node.board),"native decision actor/full history/visible board differs from independent legal graph")
            expected=[{"name":a.name,"amount_bits":bits(a.amount),"raise_to_bits":bits(a.raise_to),"token":a.token} for a in node.actions]
            need([{k:v for k,v in action.items() if k!="full_raise"} for action in vertex["actions"]]==expected,"native ordered legal action/money/token menu differs")
            flag_count+=len(expected)
            need((node.player,history) not in menus,"duplicate complete decision history")
            menus[(node.player,history)]=node
            for action,native_child,child in reversed(list(zip(node.actions,vertex["children"],node.children))):
                pending.append((native_child,child,history+(action.token,),visible))
        elif isinstance(node,physical.Reveal):
            chance+=1
            street={3:1,4:2,5:3}[node.board_length]
            need(vertex["kind"]=="C" and vertex["street"]==street and vertex["card_index"]==street+3 and history==tuple(node.history),"native reveal street/index/history differs")
            expected={"".join(prefix) if node.board_length==3 else prefix[-1]:(prefix,child) for prefix,child in node.branches.items()}
            observed=dict(vertex["branches"])
            need(set(observed)==set(expected),"native chance has missing/extra independent legal reveal branch")
            label=("flop","turn","river")[street-1]+"@"
            for text,(prefix,child) in reversed(list(expected.items())):
                pending.append((observed[text],child,history+(label+text,),tuple(prefix)))
        elif isinstance(node,physical._Terminal):
            terminals+=1
            expected_kind="F" if node.kind=="fold" else "S"
            expected_bits=[bits(value) for value in node.contributions]
            if vertex["kind"]=="C":
                worlds=[w for w in model.worlds if tuple(w["board"][:len(visible)])==visible]
                need(worlds,"zero-support early terminal tail")
                leaves=[]; stack=[(index,visible,worlds)]
                while stack:
                    tail_id,prefix,subset=stack.pop(); tail=parsed["vertices"][tail_id]
                    need(subset,"native tail contains unsupported branch")
                    need(tail["kind"]!="D","native early-terminal tail contains decision")
                    if tail["kind"]=="C":
                        size={0:3,3:4,4:5}.get(len(prefix));need(size is not None,"invalid remaining reveal depth")
                        street={3:1,4:2,5:3}[size]
                        need(tail["street"]==street and tail["card_index"]==street+3,"incorrect remaining reveal sequence")
                        partitions={}
                        for world in subset:
                            newprefix=tuple(world["board"][:size]); label="".join(newprefix) if size==3 else newprefix[-1]
                            partitions.setdefault(label,[]).append(world)
                        branches=dict(tail["branches"]);need(set(branches)==set(partitions),"native tail has missing/extra physical outcome branch")
                        for label,part in partitions.items():stack.append((branches[label],tuple(part[0]["board"][:size]),part))
                    else:
                        need(len(prefix)==5,"native tail ends before complete selected board")
                        need(tail["kind"]==expected_kind and tail["winner"]==node.winner and tail["contribution_bits"]==expected_bits,"native tail leaf kind/winner/original money differs")
                        for world in subset:leaves.append(world)
                def identity(w):return (w["hands"],w["board"])
                need(len(leaves)==len(worlds) and len({identity(w) for w in leaves})==len(worlds) and {identity(w) for w in leaves}=={identity(w) for w in worlds},"tail does not partition each world once")
                def aggregate(group):
                    result={}
                    for world in group:
                        pair=world["hands"]; mass=world["weight"]; sign=(1 if node.winner==0 else -1) if node.kind=="fold" else world["sign"]
                        payoff=Fraction.from_float(min(node.contributions))*sign
                        old=result.get(pair,(Fraction(0),Fraction(0)));result[pair]=(old[0]+mass,old[1]+mass*payoff)
                    return result
                need(aggregate(leaves)==aggregate(worlds),"tail pairwise exact masses/payoffs differ")
                tail_proofs.append({"history":list(history),"visible_board":list(visible),"worlds":len(worlds),"private_pairs":len(aggregate(worlds)),"leaf_worlds":len(leaves),"kind":node.kind,"winner":node.winner,"contribution_bits":expected_bits})
            else:
                need(vertex["kind"]==expected_kind and vertex["winner"]==node.winner and vertex["contribution_bits"]==expected_bits,"native terminal kind/winner/original global money bits differ")
        else:raise ValueError("unknown independent physical node")
    need(visits==model.counts["public_states"] and decisions==model.counts["decisions"],"unfolded native/independent logical occurrence counts differ")
    return model,menus,{"logical_occurrences":visits,"decisions":decisions,"chance_occurrences":chance,"terminals":terminals,
        "decision_actor_menu_money_history_and_standard_chance_terminal_fields_match":True,
        "chance_only_terminal_tail_proofs":tail_proofs,
        "strict_graph_isomorphism":not bool(tail_proofs),
        "tail_scope":"Exact physical per-pair mass/payoff equality; no branchwise rounded callback or training trajectory equivalence claim.",
        "full_raise_boolean_flags_authenticated_not_independently_rederived":flag_count,
        "scope":"Full_raise has no independent Action property and is checked only as a wire Boolean; all actual legal child transitions and original money are independently matched. It is native signature metadata, not independent betting-rule evidence."}


def map_history(history,image):
    result=[];mapping=dict(zip("cdhs",image))
    def card(c):return c[0]+mapping[c[1]]
    for token in history:
        if token.startswith("flop@"):
            result.append("flop@"+"".join(sorted((card(token[i:i+2]) for i in (5,7,9)),key=ORDER.__getitem__)))
        elif token.startswith("turn@") or token.startswith("river@"):
            at=token.index("@");result.append(token[:at+1]+card(token[at+1:]))
        else:result.append(token)
    return tuple(result)


def independent_q(parsed,model):
    priors=[{tuple(row["hand"]):row["weight_bits"] for row in side} for side in parsed["ranges"]]
    boards={tuple(value) for value in parsed["boards"]};group=[]
    for image in permutations("cdhs"):
        mapping=dict(zip("cdhs",image))
        def card(c):return c[0]+mapping[c[1]]
        if any({tuple(sorted(card(c) for c in hand)):weight for hand,weight in side.items()}!=side for side in priors):continue
        changed={tuple(sorted((card(c) for c in value[:3]),key=ORDER.__getitem__))+tuple(card(c) for c in value[3:]) for value in boards}
        if changed==boards:group.append(image)
    representatives={}
    for key,node in model.expected_infos.items():
        player,holding,history=key;images=[]
        for image in group:
            mapping=dict(zip("cdhs",image));hand=(holding[:2],holding[2:])
            changed=(player,"".join(sorted(c[0]+mapping[c[1]] for c in hand)),map_history(history,image))
            need(changed in model.expected_infos,"independent weighted group loses supported legal row")
            other=model.expected_infos[changed]
            need([(a.name,bits(a.amount),bits(a.raise_to),a.token) for a in node.actions]==
                 [(a.name,bits(a.amount),bits(a.raise_to),a.token) for a in other.actions],"independent group loses legal ordered menu")
            images.append(changed)
        representative=min(images)
        if representative in representatives:need(representatives[representative]==len(node.actions),"orbit menu width differs")
        representatives[representative]=len(node.actions)
    return {"group_size":len(group),"group":["".join(v) for v in group],"quotient_rows":len(representatives),
        "quotient_action_slots":sum(representatives.values())}


def compare_stdout(raw,parsed,payload,model,menus):
    need(len(raw)<=32*1024*1024,"native output too large")
    lines=raw.decode("ascii").splitlines();need(lines and lines[0]=="OPENPOKER_NATIVE_EXACT_FOUR_STREET_RESULT_V1","wrong native output magic")
    payload_rows={}
    for row in payload["strategy"]:
        key=(0 if row["player"]=="sb" else 1,row["hand"],tuple(row["history"]))
        need(key not in payload_rows,"duplicate saved complete policy row");payload_rows[key]=row
    need(set(payload_rows)==set(model.expected_infos),"saved complete policy support differs from independent legal rows")
    seen=set();slots=0;proof=[]
    for line in lines[1:-1]:
        fields=line.split("\t");need(fields[0]=="ROW" and len(fields)>=6,"unknown native result record")
        player,hand_index,length=map(int,fields[1:4])
        need(player in (0,1) and 0<=hand_index<len(parsed["ranges"][player]) and 0<=length<=32,"malformed native policy key")
        history=tuple(fields[4:4+length]);count=int(fields[4+length]);values=fields[5+length:]
        need(len(fields)==5+length+count and count>0,"native policy record has extra/truncated fields")
        holding="".join(parsed["ranges"][player][hand_index]["hand"]);key=(player,holding,history)
        need(key not in seen and key in model.expected_infos,"native output duplicate/unsupported full-history row")
        node=model.expected_infos[key];row=payload_rows[key]
        need(len(node.actions)==count==len(row["actions"]),"native output/legal/payload menu count differs")
        expected=[bits(action["probability"]) for action in row["actions"]]
        need(values==expected,"raw native output bits differ from saved complete policy")
        for action,saved in zip(node.actions,row["actions"]):
            need((saved["name"],bits(saved["amount"]),bits(saved["raise_to"]),saved["history_key"])==
                 (action.name,bits(action.amount),bits(action.raise_to),action.token),"saved policy menu differs from independent legal graph")
        need(tuple(row["revealed_board"])==tuple(node.board) and row["street"]=={0:"preflop",3:"flop",4:"turn",5:"river"}[len(node.board)],"saved row visible-board/street differs")
        seen.add(key);slots+=count
        proof.append({"player":player,"holding":holding,"history":list(history),"probability_bits":values})
    need(seen==set(model.expected_infos),"native output lacks supported legal rows")
    tail=lines[-1].split("\t");need(tail[0]=="DONE" and len(tail)==14 and all(v.isdecimal() for v in tail[1:]),"native DONE unknown/missing fields")
    counters=dict(zip(COUNTERS,map(int,tail[1:])))
    q=independent_q(parsed,model)
    expected={"expanded_rows":len(seen),"expanded_action_slots":slots,"group_size":q["group_size"],"quotient_rows":q["quotient_rows"],
        "quotient_action_slots":q["quotient_action_slots"],"member_checks":2*parsed["iterations"]*len(seen),
        "expected_member_checks":2*parsed["iterations"]*len(seen),"maximum_numeric_workspace_slots":4*q["quotient_action_slots"],"final_numeric_workspace_slots":0}
    need(all(counters[key]==value for key,value in expected.items()),"independent native DONE row/group/Q/member counts differ")
    receipt=payload["operator_census"]["native_exact"]
    need(all(receipt[key]==value for key,value in counters.items()),"native DONE differs from saved receipt")
    need(counters["modeled_work_upper"]<=parsed["limits"][7] and counters["kernel_work_upper"]<=counters["modeled_work_upper"] and
         counters["retained_entries_upper"]<=parsed["limits"][8] and counters["rank_calls"]>0,"native recorded caps/rank receipt mismatch")
    return {"counts":counters,"independent_group_and_Q":q,"rows":proof,"all_raw_probability_bits_match_saved_complete_policy":True}


class DenyProduction(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if any(fullname==name or fullname.startswith(name+".") for name in FORBIDDEN):raise AssertionError("production import forbidden: "+fullname)
        return None


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo",type=Path,required=True);parser.add_argument("--study",type=Path,required=True)
    parser.add_argument("--proof",type=Path,required=True);parser.add_argument("--confirmed-terminal-handle",required=True)
    parser.add_argument("--terminal-exit-code",type=int,required=True)
    args=parser.parse_args();repo,study,proof=args.repo.resolve(),args.study.resolve(),args.proof.resolve()
    need(args.confirmed_terminal_handle=="11220" and args.terminal_exit_code==0,"lead-confirmed producer terminal success required")
    need(not proof.exists() and repo not in proof.parents and study not in proof.parents,"new external proof directory required")
    proof.mkdir(parents=True);stage="authentication";failure=None
    try:
        authpath=Path(__file__).with_name("exact-selected-independent-review.py");need(sha(authpath.read_bytes())==AUTH_SHA,"authentication helper pin changed")
        spec=importlib.util.spec_from_file_location("native_wire_auth",authpath);auth=importlib.util.module_from_spec(spec);spec.loader.exec_module(auth);auth.FROZEN=FROZEN
        saved=inventory(study);need(sha(saved["manifest.json"])==MANIFEST_SHA and sha(saved["report.json"])==REPORT_SHA and sha(saved["source-after.json"])==AFTER_SHA,"external study pins differ")
        manifest=auth.parse(saved["manifest.json"])
        need(manifest["source_commit"]==FROZEN and set(saved)==set(manifest["sha256"])|{"manifest.json"},"manifest inventory/source mismatch")
        for name,digest in manifest["sha256"].items():need(sha(saved[name])==digest,"study artifact drift: "+name)
        source=auth.parse(saved["source-before.json"]);authenticated=auth.source_identity(repo,source)
        need(auth.parse(saved["source-after.json"])==source,"captured source changed")
        protocol=auth.parse(saved["protocol.json"]);report=auth.parse(saved["report.json"])
        need(protocol["source_commit"]==report["source_commit"]==FROZEN and protocol["version"]=="native-exact-four-street-fixed-study-v1" and
             report["failure"] is None and report["calls_completed"]==report["calls_planned"]==18,"producer incomplete or protocol changed")
        build=build_auth(repo,protocol,source,auth.parse)
        (proof/"review-helper.py").write_bytes(Path(__file__).read_bytes());write(proof/"source-authentication.json",authenticated)
        for name in MATH_SOURCES:
            target=proof/"math-source"/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((repo/name).read_bytes())
        # Authentication is complete before any project mathematics imports.
        guard=DenyProduction();sys.meta_path.insert(0,guard);sys.dont_write_bytecode=True;sys.path.insert(0,str(repo))
        results=[]
        try:
            with ExitStack() as guards:
                guards.enter_context(patch("subprocess.Popen",side_effect=AssertionError("candidate/process execution forbidden")))
                guards.enter_context(patch("pokerlab.cards.rank_hand",side_effect=AssertionError("production rank forbidden")))
                from scripts import four_street_validation as physical
                need(not any(name in sys.modules for name in FORBIDDEN),"forbidden production math imported")
                for entry in protocol["schedule"]:
                    name,mode,sample,traced=entry
                    if mode!="native":continue
                    artifact="-".join(map(str,entry[:3]))+".json";raw=auth.parse(saved[artifact])
                    if name.endswith("qreject"):
                        need(raw["payload"] is None and raw["native_streams"]==[] and raw["counts"]["native_invoke"]==raw["counts"]["python_rank"]==0,"rejected native request has wire/rank/candidate work")
                        continue
                    stage="native-wire-legal-graph:"+artifact
                    need(raw["failure"] is None and raw["mode"]=="native" and raw["counts"]["native_invoke"]==1 and
                         raw["counts"]["rank_before_native"]==0 and len(raw["native_streams"])==1,"native raw sample identity/status mismatch")
                    stream=raw["native_streams"][0];need(set(stream)=={"request","stdout","stderr","returncode"},"unexpected stream fields")
                    request,stdout,stderr=(base64.b64decode(stream[key],validate=True) for key in ("request","stdout","stderr"))
                    need(stream["returncode"]==0 and stderr==b"","native process failed")
                    payload=raw["payload"];native=payload["operator_census"]["native_exact"]
                    need(sha(request)==native["request_sha256"] and sha(stdout)==native["result_sha256"] and len(request)==native["request_bytes"] and
                         len(stdout)==native["result_bytes"] and native["build"]==protocol["build"],"native stream/build hash mismatch")
                    encoded=json.dumps(payload,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
                    need(sha(encoded)==raw["payload_sha256"] and len(encoded)==raw["payload_bytes"],"complete payload raw binding changed")
                    parsed=parse_wire(request);need(parsed["iterations"]==raw["iterations"] and parsed["rank_cache_boards"]==64,"wire iterations/cache differs from request")
                    model,menus,legal=compare_graph(parsed,protocol["cases"][name],physical)
                    output=compare_stdout(stdout,parsed,payload,model,menus)
                    folder=proof/artifact.removesuffix(".json");folder.mkdir()
                    (folder/"native-request.txt").write_bytes(request);(folder/"native-stdout.txt").write_bytes(stdout)
                    checked={"artifact":artifact,"raw_artifact_sha256":sha(saved[artifact]),"request_sha256":sha(request),"stdout_sha256":sha(stdout),
                        "payload_sha256":raw["payload_sha256"],"independent_physical_counts":model.counts,"legal_graph_proof":legal,"output_proof":output}
                    write(folder/"proof.json",checked);results.append({key:value for key,value in checked.items() if key!="output_proof"})
                    print(artifact+" raw wire/legal graph/output bits matched",flush=True)
                need(len(results)==8,"expected eight successful native raw samples")
        finally:sys.meta_path.remove(guard)
        stage="after-authentication"
        need(auth.source_identity(repo,source)==authenticated,"source changed during raw wire proof")
        need(inventory(study)==saved,"source study artifact bytes/inventory changed")
        need(build_auth(repo,protocol,source,auth.parse)==build,"actual build changed during saved proof")
        receipt={"outcome":"accepted","source_commit":FROZEN,"source_files_authenticated":authenticated["files"],"build":build,
            "manifest_sha256":MANIFEST_SHA,"report_sha256":REPORT_SHA,"study_artifact_sha256":{name:sha(value) for name,value in saved.items()},
            "source_artifacts_and_build_unchanged_after":True,"producer_terminal_handle":args.confirmed_terminal_handle,"producer_terminal_exit_code":0,
            "native_samples_independently_checked":len(results),"case_proofs":results,"review_candidate_calls":0,"review_production_kernel_rank_training_calls":0,
            "forbidden_modules":list(FORBIDDEN),"math_source_sha256":{name:source["sha256"][name] for name in MATH_SOURCES},
            "review_helper_sha256":sha(Path(__file__).read_bytes()),"authentication_helper_sha256":AUTH_SHA,
            "limitation":"Independent model has no full_raise flag. Raw flags are bounded Booleans authenticated by frozen source/wire; actual actor/action money/token/child transitions and all terminal money are independently verified. No independent full_raise classification claim.",
            "scope":"Sol original strict wire proof, completed by Terra with exact chance-only terminal-tail equivalence. Strict isomorphism is false where tails occur. No branchwise rounded callback or training trajectory equivalence claim; no candidate execution."}
        write(proof/"receipt.json",receipt)
    except BaseException as exc:
        failure={"stage":stage,"error_type":type(exc).__name__,"error":str(exc)};write(proof/"first-failure.json",failure)
    files=sorted(path for path in proof.rglob("*") if path.is_file())
    write(proof/"manifest.json",{"sha256":{path.relative_to(proof).as_posix():sha(path.read_bytes()) for path in files}})
    print(json.dumps({"outcome":"failed" if failure else "accepted","failure":failure,
        "receipt_sha256":None if failure else sha((proof/"receipt.json").read_bytes()),"proof_manifest_sha256":sha((proof/"manifest.json").read_bytes())}),flush=True)
    return 1 if failure else 0


if __name__=="__main__":raise SystemExit(main())
