"""Authenticate current frozen source again, then diagnose saved terminal bits."""
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

work=Path(__file__).resolve().parent;repo=work/'native-exact-engine-repo';study=work/'native-exact-whole-study-v1'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
review=load('wire_diagnostic_review',work/'native-exact-wire-review-attempt1.py')
auth=load('wire_diagnostic_auth',work/'exact-selected-independent-review.py');auth.FROZEN=review.FROZEN
source=auth.parse((study/'source-before.json').read_bytes());auth.source_identity(repo,source)
review.build_auth(repo,auth.parse((study/'protocol.json').read_bytes()),source,auth.parse)
sys.dont_write_bytecode=True;sys.path.insert(0,str(repo));guard=review.DenyProduction();sys.meta_path.insert(0,guard)
with patch('subprocess.Popen',side_effect=AssertionError('no process')),patch('pokerlab.cards.rank_hand',side_effect=AssertionError('no production rank')):
    from scripts import four_street_validation as physical
    raw=auth.parse((study/'original-22-t10-native-0.json').read_bytes());wire=review.parse_wire(base64.b64decode(raw['native_streams'][0]['request']))
    case=auth.parse((study/'protocol.json').read_bytes())['cases']['original-22-t10'];model=physical.build_model(case)
    pending=[(wire['root'],model.root,())];mismatches=[]
    while pending:
        index,node,history=pending.pop();vertex=wire['vertices'][index]
        if isinstance(node,physical._Decision):
            for action,native_child,child in zip(node.actions,vertex['children'],node.children):pending.append((native_child,child,history+(action.token,)))
        elif isinstance(node,physical.Reveal):
            branches=dict(vertex['branches']);prefix=('flop','turn','river')[vertex['street']-1]+'@'
            for board,child in node.branches.items():
                label=''.join(board) if node.board_length==3 else board[-1];pending.append((branches[label],child,history+(prefix+label,)))
        else:
            expected=[review.bits(value) for value in node.contributions]
            if vertex['contribution_bits']!=expected or vertex['winner']!=node.winner:
                mismatches.append({'history':history,'native':vertex,'independent':{'kind':node.kind,'winner':node.winner,'contributions':node.contributions,'contribution_bits':expected},
                    'same_matched_minimum':min(vertex['contribution_bits'])==min(expected)})
auth.source_identity(repo,source)
result={'source_commit':review.FROZEN,'candidate_calls':0,'mismatch_count':len(mismatches),'mismatches':mismatches}
out=work/'native-exact-wire-money-diagnostic.json'
if out.exists():raise ValueError('refuse overwrite')
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'mismatch_count':len(mismatches),'first':mismatches[0] if mismatches else None,'all_same_matched_minimum':all(row['same_matched_minimum'] for row in mismatches),'diagnostic_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
