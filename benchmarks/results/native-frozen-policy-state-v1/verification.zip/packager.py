"""Package already observed immutable controls; no compilation/native execution."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,zipfile

WORK=Path(__file__).resolve().parent
ROOT=WORK/'dyprofile-repo'
PACKET=ROOT/'benchmarks/results/native-frozen-policy-state-v1'
files={}
def add(name,raw):
    if name in files:raise ValueError('duplicate member '+name)
    files[name]=raw
def file(name,path):add(name,path.read_bytes())
def tree(name,path):
    for p in sorted(path.rglob('*')):
        if p.is_file():file(name+'/'+p.relative_to(path).as_posix(),p)
def sha(raw):return sha256(raw).hexdigest()
def verified_sources(label,manifest,source):
    for name,digest in manifest['source_sha256'].items():
        raw=source(name)
        if sha(raw)!=digest:raise ValueError(label+' source mismatch '+name)
        add(label+'/source/'+name,raw)
def build(label,path,source):
    manifest=json.loads((path/'native-exact-build-manifest.json').read_bytes())
    for n in ('native-exact-build-manifest.json','build.log','compiler-version.log'):file(label+'/'+n,path/n)
    executable=next(path.glob('*.exe'))
    if sha(executable.read_bytes())!=manifest['executable_sha256']:raise ValueError('executable drift')
    file(label+'/'+executable.name,executable)
    verified_sources(label,manifest,source)

if PACKET.exists():raise ValueError('immutable packet already exists')
historical=ROOT/'benchmarks/results/frozen-q52-update-reference-v1/verification.zip'
if sha(historical.read_bytes())!='f34e7c7e76da800d0d9067f1c73c6cdbbadc7f053f8c6920d495ac8f041c6687':raise ValueError('historical packet drift')
with zipfile.ZipFile(historical) as old:
    def baseline_source(name):
        if name.startswith('third_party/'):return (ROOT/name).read_bytes()
        return old.read('source/'+name)
    build('legacy-before',WORK/'dyfrozen-state-base1',baseline_source)
def after_source(name):
    raw=(ROOT/name).read_bytes()
    if name=='scripts/build_native_exact_four_street.py':
        raw=raw.replace(b'if target == "virtual-dyadic-state-controls" else "Frozen Q52 policy import/read conformance only; no update, training, solver or capacity acceptance."\n                  if target == "virtual-frozen-policy-state-controls"',b'if target == "virtual-dyadic-state-controls"')
    return raw
build('legacy-after',WORK/'dyfrozen-state-legacy2',after_source)
build('native-build',WORK/'dyfrozen-state-frozen1',lambda name:(ROOT/name).read_bytes())
for mode in ('normal','optimized'):
    tree('formal/'+mode,WORK/('dyfrozen-state-frozen1-'+mode))
    file('logs/'+mode+'.log',WORK/('dyfrozen-state-frozen1-'+mode+'.log'))
    file('replay/'+mode+'.json',WORK/('dyfrozen-state-frozen1-'+mode+'-replay-current.log'))
for name in ('dyfrozen-state-frozen1-normal-replay.log','dyfrozen-state-frozen1-normal-replay-fixed.log',
             'dyfrozen-state-frozen1-saved-controls.log','dyfrozen-state-frozen1-saved-controls-fixed.log',
             'dyfrozen-state-frozen1-saved-controls-current-normal.log',
             'dyfrozen-state-controls2-normal.log','dyfrozen-state-controls3-normal.log',
             'dyfrozen-state-legacy2-controls.log','dyfrozen-state-base1.stdout','dyfrozen-state-base1.stderr',
             'dyfrozen-state-legacy2.stdout','dyfrozen-state-legacy2.stderr'):
    file('retained/'+name,WORK/name)
tree('legacy-after/observed',WORK/'dyfrozen-state-legacy2-controls')
file('packager.py',Path(__file__))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
names=('scripts/replay_native_frozen_policy_state.py','tests/test_frozen_policy_saved_replay.py',
       '.github/workflows/native-frozen-policy-state.yml','docs/native-frozen-policy-state.md')
for name in names:file('maintained-source/'+name,ROOT/name)
before=(WORK/'dyfrozen-state-base1.stdout').read_bytes();after=(WORK/'dyfrozen-state-legacy2.stdout').read_bytes()
if before!=after or len(before)!=48753 or sha(before)!='e939f1a865ac94fc791299a4c9b21fef19490a31fdc7615aa7d4954d3d47c26e':raise ValueError('legacy output parity')
receipt={
    'version':'native-frozen-policy-state-evidence-v1','native_source_head':'a776062',
    'observed_source_head':'5ae1757e560e249975a28c9f215cff47953eea9c','maintained_head':head,
    'scope':'complete resident Q52 import/read conformance; no raw update, training, quality, runtime or capacity improvement',
    'native_cases_per_mode':9,'normal_tests':5,'optimized_tests':5,'read_rows_per_profile':24420,'slots_per_profile':58164,
    'native_rank_calls':0,'native_contractions':0,'native_training_sweeps':0,'native_quantizer_work':0,
    'legacy_control_tests':11,'legacy_stdout_bytes':len(before),'legacy_stdout_sha256':sha(before),
    'saved_replay_candidate_calls':0,'archived_source_executed':False,
    'retained_failures':['oversized stdout declaration rejected before child launch','mixed historical header provenance refused before math replay'],
    'legacy_before_source':'exact raw sources recovered from pinned PR325 packet; third-party source individually hash checked',
    'legacy_after_builder_recovery':'remove only the newly added explicit target scope branch; exact original build manifest SHA required',
    'system_build_inputs':'SDK/runtime/standard headers not exhaustively attested; bit reproducibility unproven',
}
add('receipt.json',(json.dumps(receipt,indent=2)+'\n').encode())
members={name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(files.items())}
add('members.json',(json.dumps(members,indent=2)+'\n').encode())
PACKET.mkdir(parents=True,exist_ok=False)
archive=PACKET/'verification.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or set(z.namelist())!=set(files):raise ValueError('archive CRC/members')
    for name,expected in members.items():
        raw=z.read(name)
        if len(raw)!=expected['bytes'] or sha(raw)!=expected['sha256']:raise ValueError('archive member drift')
manifest={**receipt,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'archive_members':len(files)}
(PACKET/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
