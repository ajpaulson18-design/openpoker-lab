import json,hashlib
from pathlib import Path
w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=w/'native-indexed-capacity-census-attempt1.json';b=w/'native-indexed-capacity-census-recovery-v1.json';h1=w/'native-indexed-capacity-census-attempt1.py';h2=w/'native-indexed-capacity-census-recovery-v1.py';first=json.loads(a.read_bytes());second=json.loads(b.read_bytes());invalid={0,1,3,6,9,12,13,14};assert first['source_unchanged'] and second['source_unchanged'] and first['source_before']==second['source_before'] and len(first['rows'])==15 and len(second['rows'])==8;hsh1=sha(h1);hsh2=sha(h2);lookup={(r['case'],r['iterations']):r for r in second['rows']};rows=[]
for i,old in enumerate(first['rows']):
 key=(old['case'],old['iterations'])
 if i in invalid:
  new=lookup[key];assert (i>=12 or new['range_snapshot_requested']==old['range_snapshot_requested']);assert new['recovery_helper_sha256']==hsh2;source='recovery-v1';record=new
 else:
  assert old['first_actual_reject']['type']=='ValueError' and all(x==0 for x in old['forbidden_calls'].values());source='first-attempt';record=old
 assert all(v==0 for v in record['forbidden_calls'].values());rows.append({'schedule_index':i,'evidence_source':source,'helper_sha256':hsh2 if i in invalid else hsh1,'record':record})
out=w/'native-indexed-capacity-census-merged-v1.json';assert not out.exists();report={'status':'complete','scope':'Rank-free admission census, modeled work only; no solve, quality or performance claim. Helper-invalid first rows rerun only; original production rejections retained. External physical census explicitly examines candidate pair-board cells; no production pair probability/world enumeration.','source_before':second['source_before'],'source_after':second['source_after'],'first_attempt_json_sha256':sha(a),'first_helper_sha256':hsh1,'recovery_json_sha256':sha(b),'recovery_helper_sha256':hsh2,'rerun_indices':sorted(invalid),'preserved_first_production_rejection_indices':[i for i in range(15) if i not in invalid],'rows':rows};out.write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf8');print('merged',sha(out),'rows',len(rows))
