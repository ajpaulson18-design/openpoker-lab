"""External rank-free capacity census for the published native indexed model.

This is a diagnostic only: it runs existing Python admission and native
rank-free admission/wire construction, never rank, train, invoke native, scan
worlds, or query pair probabilities. All admission caps remain unchanged.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback


BASE = Path(r"C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i")
REPO = BASE / "work" / "native-indexed-ci-repo"
STUDY = BASE / "work" / "native-indexed-study-v2"
AUTH = BASE / "work" / "native-indexed-study-v2-source-auth.json"
OUT = BASE / "work" / "native-indexed-capacity-census.json"
EXPECTED_HEAD = "1eba0e147e8430e139379d5fb037a5efaad928f2"
AUTHENTICATED_SOURCE = "322cb53158969a89a1dfaee477c8118033aa7a47"
OPTIONS = {
    "rank_cache_boards": 64,
    "pair_diagnostics": "compact",
    "exact_arithmetic": "dyadic",
    "training_reduction": "suit-equivariant",
    "strategy_storage": "suit-quotient",
    "quotient_lookup": "per-decision",
}
SCHEDULE = tuple(
    [("original-weighted-2x2", 2, 2, t) for t in (10, 100, 1000)]
    + [(f"balanced-{h}x{h}-unit", h, h, t)
       for h in (4, 8, 16) for t in (10, 100, 1000)]
    + [(f"asymmetric-2x16-unit", 2, 16, t) for t in (10, 100, 1000)]
)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _git(*args: str, data: bytes | None = None) -> bytes:
    return subprocess.check_output(["git", *args], cwd=REPO, input=data)


def _authenticate_source() -> dict:
    """Authenticate saved closure, pinned current HEAD, and clean raw tree."""
    head = _git("rev-parse", "HEAD").decode("ascii").strip()
    status = _git("status", "--porcelain", "--untracked-files=all").decode("utf-8")
    if head != EXPECTED_HEAD or status:
        raise RuntimeError(f"source checkout drift: HEAD={head!r}, status={status[:500]!r}")
    auth_raw = AUTH.read_bytes()
    auth = json.loads(auth_raw)
    if (auth.get("commit") != AUTHENTICATED_SOURCE or
            auth.get("git_raw_or_normalized_committed_blobs_match") is not True or
            auth.get("raw_committed_blob_files") != 775 or
            auth.get("normalized_committed_blob_files") != 1295 or
            len(auth.get("raw_sha256", {})) != 2070):
        raise RuntimeError("frozen study source-closure receipt failed validation")
    if _git("diff", "--quiet", f"{AUTHENTICATED_SOURCE}..{EXPECTED_HEAD}", "--", "native", "pokerlab", "scripts"):
        raise RuntimeError("published implementation paths differ from authenticated study source")
    tracked = _git("ls-files", "-z").decode("utf-8").rstrip("\0").split("\0")
    observed = {name: _sha((REPO / name).read_bytes()) for name in tracked}
    tree_records = _git("ls-tree", "-rz", "--full-tree", EXPECTED_HEAD).rstrip(b"\0").split(b"\0")
    blobs = {}
    for item in tree_records:
        metadata, name = item.split(b"\t", 1)
        mode, kind, oid = metadata.split()
        if kind != b"blob" or mode not in (b"100644", b"100755"):
            raise RuntimeError("nonordinary tracked source entry")
        blobs[name.decode("utf-8")] = oid.decode("ascii")
    if set(observed) != set(blobs):
        raise RuntimeError("tracked working source closure differs from pinned Git tree")
    content = ("\n".join(tracked) + "\n").encode("utf-8")
    normalized = _git("hash-object", "--stdin-paths", data=content).decode("ascii").splitlines()
    raw_count = normalized_count = 0
    for name, normalized_oid in zip(tracked, normalized):
        raw = (REPO / name).read_bytes()
        raw_oid = hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()
        if raw_oid == blobs[name]:
            raw_count += 1
        elif normalized_oid == blobs[name]:
            normalized_count += 1
        else:
            raise RuntimeError(f"working bytes do not authenticate to pinned Git blob: {name}")
    if raw_count + normalized_count != len(tracked):
        raise RuntimeError("incomplete raw/normalized Git authentication")
    return {
        "head": head,
        "status": status,
        "tracked_files": len(tracked),
        "raw_git_blob_files": raw_count,
        "normalized_git_blob_files": normalized_count,
        "authenticated_study_source_commit": AUTHENTICATED_SOURCE,
        "study_source_auth_sha256": _sha(auth_raw),
        "study_source_auth_raw_paths": len(auth["raw_sha256"]),
        "production_paths_identical_to_authenticated_source": True,
        "working_tree_sha256": _sha(json.dumps(observed, sort_keys=True, separators=(",", ":")).encode()),
    }


def _weighted_hands(range_text: str) -> list[str]:
    return [token.split(":", 1)[0] for token in range_text.split(",")]


def _expanded_range(original: str, pool: tuple[str, ...], size: int, deck: tuple[str, ...]) -> str:
    import itertools

    first = _weighted_hands(original)
    values = list(first)
    seen = set(first)
    if len(values) == size:
        return ",".join(values)
    ordered = sorted(pool, key=deck.index)
    for a, b in itertools.combinations(ordered, 2):
        hand = "".join(sorted((a, b)))
        if hand not in seen:
            values.append(hand)
            seen.add(hand)
        if len(values) == size:
            break
    if len(values) != size:
        raise RuntimeError("candidate pool did not produce requested distinct holdings")
    return ",".join(values)


def _request_for(case, iterations, h0, h1, deck):
    from scripts.benchmark_suit_quotient_solver import request_for

    if h0 == h1 == 2:
        selected_case = dict(case)
    else:
        # Existing first two holdings remain in the same order. Every appended
        # holding has unit weight; this defines a separate synthetic prior.
        sb_pool = ("Ad", "As", "Qd", "Qs", "Ac", "Ah", "9c", "9d")
        bb_pool = ("Kd", "Ks", "Jd", "Jh", "Qc", "Qh", "8d", "8s")
        selected_case = dict(case)
        selected_case["sb_range"] = _expanded_range(case["sb_range"], sb_pool, h0, deck)
        selected_case["bb_range"] = _expanded_range(case["bb_range"], bb_pool, h1, deck)
    return request_for(selected_case, iterations), selected_case


def _blocked_count(hand, selected):
    return sum(bool(set(hand).intersection(board)) for board in selected)


def _physical_snapshot(prepared):
    kernel = prepared.kernel
    hands = [["".join(hand) for hand in side] for side in kernel.hands]
    weights = [[float(value).hex() for value in side] for side in kernel.weights]
    selected = [[*flop, turn, river] for flop, turn, river in kernel.selected]
    per_hand_board_support = [
        [len(selected) - _blocked_count(hand, selected) for hand in side]
        for side in kernel.hands
    ]
    board_pair_occurrences = 0
    pair_board_cells = 0
    for left, right in __import__("itertools").product(kernel.hands[0], kernel.hands[1]):
        for board in selected:
            if not set(left).intersection(board) and not set(right).intersection(board) and not set(left).intersection(right):
                board_pair_occurrences += 1
            pair_board_cells += 1
    z = kernel.normalizer
    return {
        "hands": hands,
        "weight_hex": weights,
        "selected_boards_ordered": selected,
        "selected_board_count": len(selected),
        "per_hand_compatible_board_counts": per_hand_board_support,
        "candidate_pair_board_cells_inspected_by_external_rank_free_census": pair_board_cells,
        "compatible_pair_board_occurrences_rank_free": board_pair_occurrences,
        "exact_global_normalizer": {"numerator": str(z.numerator), "denominator": str(z.denominator)},
        "exact_global_normalizer_positive": z > 0,
    }


def _terminal_shape(prepared, iterations):
    from pokerlab.shared_public_topology import TerminalVertex
    from pokerlab.preflop_solver import _revealed_board
    from pokerlab.exact_selected_solver import _query_costs, _tokens

    counts = {"fold": 0, "showdown": 0}
    board_multiplicity = {"fold": 0, "showdown": 0}
    by_prefix = {"fold": {}, "showdown": {}}
    for occurrence in prepared.topology.iter_occurrences():
        vertex = prepared.topology.vertices[occurrence.vertex_id]
        if not isinstance(vertex, TerminalVertex):
            continue
        kind = "fold" if vertex.kind == "fold" else "showdown"
        prefix = _tokens(_revealed_board(occurrence.history))
        matching = prepared.prefix_counts.get(prefix, 0)
        counts[kind] += 1
        board_multiplicity[kind] += matching
        by_prefix[kind][prefix] = by_prefix[kind].get(prefix, 0) + 1
    costs = _query_costs(prepared.kernel, prepared.prefix_counts)
    calls = {kind: 0 for kind in counts}
    board_query_visits = {kind: 0 for kind in counts}
    work_upper = {kind: 0 for kind in counts}
    for kind in counts:
        for prefix, occurrence_count in by_prefix[kind].items():
            matching = prepared.prefix_counts[prefix]
            query_count = (2 * iterations + 6) * occurrence_count
            calls[kind] += query_count
            board_query_visits[kind] += query_count * matching
            work_upper[kind] += query_count * (costs["terminal_fixed"] + matching * costs["terminal_per_board"] + costs["terminal_reach"])
    return {
        "terminal_occurrences": counts,
        "sum_matching_selected_boards_by_kind": board_multiplicity,
        "training_callback_calls_2T_by_kind": {kind: 2 * iterations * counts[kind] for kind in counts},
        "training_board_batch_visits_2T_by_kind": {kind: 2 * iterations * board_multiplicity[kind] for kind in counts},
        "admitted_query_calls_including_six_diagnostic_passes_by_kind": calls,
        "admitted_matching_board_visits_by_kind": board_query_visits,
        "existing_kernel_modeled_work_upper_by_kind": work_upper,
        "existing_kernel_terminal_work_upper": prepared.admission["kernel"]["training_and_diagnostic_terminal_upper_work"],
        "split_work_sum_matches_admission": sum(work_upper.values()) == prepared.admission["kernel"]["training_and_diagnostic_terminal_upper_work"],
        "scope": "Logical callbacks, selected-board batches, and existing modeled work only; not CPU time, native kernel time, or a claim about rank implementation cost.",
    }


def _admission_record(prepared, reservation, wire):
    return {
        "python_preflight": prepared.admission,
        "direct_topology": prepared.direct_receipt,
        "layout_upper": prepared.layout_upper,
        "native_rank_free_admission": reservation,
        "native_wire_bytes": len(wire),
        "native_wire_sha256": _sha(wire),
        "whole_history_R_output_bounds": {
            "expanded_rows_upper": prepared.layout_upper["upper_dense_decision_hand_slots"],
            "expanded_action_slots_upper": prepared.layout_upper["upper_action_slots"],
            "history_token_entries_upper": prepared.layout_upper["upper_history_token_entries"],
            "history_token_bytes_upper": prepared.layout_upper["upper_history_token_bytes"],
            "serialized_strategy_entries_upper": prepared.admission["retained_storage"]["serialized_strategy_entries_upper"],
        },
        "Q_storage_actual_rows": None,
        "Q_storage_note": "No quotient plan or information rows were allocated; Q row/map actuals are intentionally unknown in this rank-free census.",
    }


def main() -> int:
    before = _authenticate_source()
    # Only after full tracked-tree and frozen-source authentication do imports
    # of repository solver code occur.
    sys.path.insert(0, str(REPO))
    from unittest.mock import patch
    from scripts.benchmark_suit_quotient_solver import case_for, request_for
    from pokerlab import exact_selected_solver as solver
    from pokerlab import exact_selected_kernel as kernel_module
    from pokerlab import native_exact_four_street as native
    from pokerlab import suit_quotient_cfr as quotient_cfr
    from pokerlab import suit_quotient_plan as quotient_plan
    from pokerlab import equivariant_packed_cfr as equivariant_cfr
    from pokerlab import preflop_solver
    from pokerlab import selected_runout_operator
    from pokerlab.cards import DECK

    original = case_for("original-22-t10")
    rows = []
    first_unexpected = None
    for name, h0, h1, iterations in SCHEDULE:
        record = {"case": name, "hand_counts_requested": [h0, h1], "iterations": iterations,
                  "first_actual_reject": None, "phase": None, "forbidden_calls":
                  {"rank": 0, "python_train": 0, "native_invoke": 0, "world": 0, "pair": 0}}
        try:
            request, selected_case = _request_for(original, iterations, h0, h1, DECK)
            record["range_snapshot_requested"] = [request.sb_range, request.bb_range]
            record["runouts_requested"] = list(request.runouts)
            record["synthetic_unit_weight_case"] = not (name == "original-weighted-2x2")
            record["phase"] = "python_preflight"

            def forbidden(label, key):
                def fail(*_args, **_kwargs):
                    record["forbidden_calls"][key] += 1
                    raise AssertionError("forbidden census path: " + label)
                return fail

            with patch.object(kernel_module, "rank_hand", new=forbidden("rank", "rank")), \
                 patch.object(kernel_module.ExactSelectedRunoutKernel, "pair_probability_exact", new=forbidden("pair", "pair")), \
                 patch.object(quotient_cfr, "train_suit_quotient", new=forbidden("Q trainer", "python_train")), \
                 patch.object(equivariant_cfr, "train_equivariant_packed", new=forbidden("equivariant trainer", "python_train")), \
                 patch.object(solver, "train_packed", new=forbidden("packed trainer", "python_train")), \
                 patch.object(quotient_plan.SuitQuotientPlan, "__init__", new=forbidden("quotient plan", "python_train")), \
                 patch.object(native, "_invoke", new=forbidden("native invoke", "native_invoke")), \
                 patch("subprocess.Popen", new=forbidden("subprocess", "native_invoke")), \
                 patch.object(preflop_solver, "_enumerate_physical_worlds", new=forbidden("world enumerator", "world")), \
                 patch.object(selected_runout_operator.SelectedRunoutOperator, "_iter_worlds", new=forbidden("world iterator", "world")):
                prepared = solver._prepare_exact_selected(request, **OPTIONS)
                record["prepared"] = True
                record["physical_rank_free"] = _physical_snapshot(prepared)
                if not record["physical_rank_free"]["exact_global_normalizer_positive"]:
                    raise RuntimeError("synthetic request has zero exact global normalizer")
                record["terminal_shape"] = _terminal_shape(prepared, iterations)
                record["phase"] = "native_rank_free_admission"
                reservation = native.admit(prepared)
                record["phase"] = "native_rank_free_wire"
                wire = native.wire(prepared, iterations, rank_cache_boards=64, routing="indexed")
                record["actual_admission"] = _admission_record(prepared, reservation, wire)
                record["first_actual_reject"] = None
                record["phase"] = "rank_free_admission_complete"
        except BaseException as exc:
            record["first_actual_reject"] = {"type": type(exc).__name__, "message": str(exc)[:1000]}
            if record.get("prepared"):
                record["reject_phase"] = record.get("phase")
            else:
                record["reject_phase"] = "python_preflight"
            if isinstance(exc, AssertionError) and str(exc).startswith("forbidden census path:"):
                first_unexpected = first_unexpected or {"row": len(rows), "error": record["first_actual_reject"]}
        rows.append(record)
        # Persist each row so a later unforeseen census error cannot erase
        # first failures already observed. No attempt is repeated.
        partial = {
            "version": "native-indexed-rank-free-capacity-census-v1",
            "status": "in_progress",
            "source_before": before,
            "planned_rows": len(SCHEDULE),
            "completed_rows": len(rows),
            "rows": rows,
            "first_unexpected": first_unexpected,
            "scope": "Admission-only diagnostic. No ranking, training, native invocation, pair probability query, or world enumeration; caps unchanged; modeled units are not CPU/RSS and no quality conclusion is made.",
        }
        OUT.write_text(json.dumps(partial, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")

    after = _authenticate_source()
    if before != after:
        first_unexpected = first_unexpected or {"error": "source identity changed during census"}
    result = {
        "version": "native-indexed-rank-free-capacity-census-v1",
        "status": "complete" if first_unexpected is None and len(rows) == len(SCHEDULE) else "completed_with_unexpected_control",
        "source_before": before,
        "source_after": after,
        "source_unchanged": before == after,
        "planned_rows": len(SCHEDULE),
        "completed_rows": len(rows),
        "rows": rows,
        "first_unexpected": first_unexpected,
        "schedule": [{"case": n, "hands": [a, b], "iterations": t} for n, a, b, t in SCHEDULE],
        "scope": "Admission-only diagnostic. No ranking, training, native invocation, pair probability query, or world enumeration; caps unchanged; modeled units are not CPU/RSS and no quality conclusion is made.",
    }
    OUT.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUT), "status": result["status"], "rows": len(rows),
                      "source_unchanged": result["source_unchanged"],
                      "first_unexpected": first_unexpected}, separators=(",", ":")))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
