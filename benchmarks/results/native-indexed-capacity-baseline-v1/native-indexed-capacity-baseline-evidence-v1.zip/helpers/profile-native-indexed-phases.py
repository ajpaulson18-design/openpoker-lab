"""External instrumented native copies and frozen-wire paired profile controls."""
import base64
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import zipfile

WORK=Path(__file__).resolve().parent
REPO=WORK/'native-indexed-ci-repo'
STUDY=WORK/'native-indexed-study-v2'
OUT=WORK/'native-indexed-phase-profile-v2'
BUILD=WORK/'native-indexed-engine-corrected-build-v2'
FROZEN='1eba0e147e8430e139379d5fb037a5efaad928f2'
ACCEPTED='322cb53158969a89a1dfaee477c8118033aa7a47'
AUTH_SHA='8171ead3ba108f8200f15e85696f40d109ed894209fa7d77598780b83c1401c5'
STUDY_MANIFEST='9c695cf6b07e0b895bf04c58cc804ae0e2a0ced8bf86ad3ab27f9222481d1275'
BUILD_MANIFEST=None
EXECUTABLE='89a52e596f39d328b1f39e46ddcd29236ee321ff9da25cae1c292beedc3efec8'
SAMPLES=tuple(name+'-'+mode+'-0' for name in ('original-22-t10','asymmetric-weighted','mixed-stabilizer') for mode in ('full-history','indexed'))
DECK=tuple(rank+suit for rank in '23456789TJQKA' for suit in 'cdhs')
COUNTERS=('expanded_rows','expanded_action_slots','group_size','quotient_rows','quotient_action_slots','member_checks','expected_member_checks',
    'modeled_work_upper','kernel_work_upper','retained_entries_upper','maximum_numeric_workspace_slots','final_numeric_workspace_slots','rank_calls')

def need(value,message):
    if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def snapshot():
    names=git('ls-files','-z').decode().split('\0')[:-1]
    return {'commit':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain','--untracked-files=all').decode().strip(),
        'sha256':{name:sha((REPO/name).read_bytes()) for name in names}}
def inventory(folder):return {p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file()}

def transform(raw,name,anchors):
    text=raw.decode('utf-8').replace('\r\n','\n');original=text
    for anchor,addition in anchors:
        need(text.count(anchor)==1,'nonunique/missing exact textual instrumentation anchor: '+name+' '+anchor)
        text=text.replace(anchor,anchor+'\n'+addition,1)
    return text.encode(),''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='production/'+name,tofile='instrumented/'+name))

def scope(phase,context=None):
    extra='' if context is None else ', opl_phase_profile::Context::'+context
    return '    opl_phase_profile::Scope opl_profile_scope_'+phase+'(opl_phase_profile::Phase::'+phase+extra+');'

def transformations():
    return {
      'exact_four_street_train.cpp':[
        ('// Explicit one-process exact-product four-street trainer. Integration pending.','#include "phase_profile.hpp"'),
        ('int run() {',scope('process_run','process')),
        ('    Writer writer;',scope('output','output')),
        ('int main() {','    opl_phase_profile::Report opl_profile_report;')],
      'exact_public_graph.hpp':[
        ('          rank_cache_boards_(rank_cache_boards), limits_(std::move(limits)) {',scope('plan_setup','setup')),
        ('        std::span<const Action> menu) const {',scope('history_lookup')),
        ('inline const Vertex& Plan::decision_at_history(std::span<const std::string> history) const {',scope('history_route')),
        ('inline History Plan::transform_history(std::span<const std::string> history, const SuitMap& mapping) const {',scope('history_transform')),
        ('inline std::vector<Card> revealed_cards(std::span<const std::string> history) {',scope('history_parse')),
        ('inline void Plan::validate_query_history(std::span<const std::string> history) const {',scope('history_validation'))],
      'exact_selected_kernel.hpp':[
        ('          source_hands_{std::move(sb), std::move(bb)}, boards_(std::move(boards)) {',scope('kernel_setup')),
        ('    [[nodiscard]] MarginalVectors marginals(std::span<const std::size_t> indexes) {',scope('marginal_callback')),
        ('        TerminalKind kind, double payoff, std::span<const double> opponent_reach) {',scope('terminal_callback')),
        ('    const CachedRanks& rank_vectors(std::size_t board) {',scope('rank_cache')),
        ('    double convert(const Integer& numerator, const Integer& denominator) {',scope('rational_conversion'))],
      'exact_selected_cfr.hpp':[
        ('inline double finite(double value) {','    ++opl_phase_profile::finite_checks;'),
        ('    Result run_impl(RunMode mode) {',scope('trainer_run','setup')),
        ('    void preflight() {',scope('trainer_preflight','preflight')),
        ('    void populate_marginal_keys() {',scope('marginal_key_setup','setup')),
        ('    void prepare_indexed_shadow() {',scope('router_setup','setup')),
        ('    void rematch() {',scope('rematch')),
        ('    void responder(std::size_t player) {',scope('responder')),
        ('                  std::size_t player, const Cursor* cursor = nullptr) {',scope('target_traversal')),
        ('    void average_pass(double factor) {',scope('average_pass')),
        ('                 double factor, const Cursor* cursor = nullptr) {',scope('average_traversal')),
        ('    void stage(const graph::RowLocation& location, std::size_t count, const Vector& increment) {',scope('member_stage'))],
      'exact_indexed_routing.hpp':[
        ('        const Cursor& cursor, std::uint8_t actor, std::span<const graph::Action> complete_menu) const {',scope('indexed_lookup')),
        ('    [[nodiscard]] const std::vector<std::size_t>& prefix_board_indexes(const Cursor& cursor) const {',scope('indexed_prefix'))],
    }

def check_policy(stdout,request,raw):
    tokens=request.decode('ascii').split();need(tokens[0]=='OPENPOKER_NATIVE_EXACT_FOUR_STREET_V1','wrong wire')
    h0,h1=int(tokens[3]),int(tokens[4]);position=1+9+11;holdings=[]
    for count in (h0,h1):
        side=[]
        for _ in range(count):
            side.append(DECK[int(tokens[position])]+DECK[int(tokens[position+1])]);position+=3
        holdings.append(side)
    expected={(0 if row['player']=='sb' else 1,row['hand'],tuple(row['history'])):row for row in raw['payload']['strategy']}
    lines=stdout.decode('ascii').splitlines();need(lines[0]=='OPENPOKER_NATIVE_EXACT_FOUR_STREET_RESULT_V1','wrong output')
    seen=set();slots=0
    for line in lines[1:-1]:
        parts=line.split('\t');need(parts[0]=='ROW','wrong row');player,hand,length=map(int,parts[1:4]);history=tuple(parts[4:4+length]);n=int(parts[4+length]);values=parts[5+length:]
        key=(player,holdings[player][hand],history);need(key not in seen and key in expected and len(values)==n==len(expected[key]['actions']),'row coverage/menu mismatch')
        need(values==[struct.pack('>d',a['probability']).hex() for a in expected[key]['actions']],'profile full policy probability bits differ')
        seen.add(key);slots+=n
    need(seen==set(expected),'incomplete profile output')
    tail=lines[-1].split('\t');need(tail[0]=='DONE' and len(tail)==14,'DONE schema mismatch')
    counters=dict(zip(COUNTERS,map(int,tail[1:])));receipt=raw['payload']['operator_census']['native_exact']
    need(all(receipt[key]==value for key,value in counters.items()) and counters['expanded_rows']==len(seen) and counters['expanded_action_slots']==slots,'profile counter bits differ')
    return {'rows':len(seen),'action_slots':slots,'all_full_policy_and_counter_bits_match':True,'counters':counters}

def compiler_environment(compiler,directory):
    script=directory/'environment.cmd';vcvars=Path(compiler).parents[6]/'Auxiliary/Build/vcvars64.bat'
    script.write_text('@call "'+str(vcvars)+'" >nul\n@if errorlevel 1 exit /b 1\n@set\n',encoding='utf-8')
    setup=subprocess.run(['cmd.exe','/d','/c',str(script)],capture_output=True,check=False)
    (directory/'environment-stderr.log').write_bytes(setup.stderr);need(setup.returncode==0,'compiler environment setup failed')
    environment=os.environ.copy()
    for line in setup.stdout.decode('utf-8','replace').splitlines():
        key,separator,value=line.partition('=')
        if separator and key.upper() in ('PATH','INCLUDE','LIB','LIBPATH'):environment[key.upper()]=value
    for key in ('CL','_CL_','LINK','_LINK_'):environment.pop(key,None)
    return environment

def main():
    need(not OUT.exists(),'new external profile directory required; preserve first failure')
    OUT.mkdir();stage='authentication';failure=None;results=[];candidate_calls=0
    try:
        source=snapshot();write(OUT/'source-before.json',source)
        authpath=WORK/'exact-selected-independent-review.py';need(sha(authpath.read_bytes())==AUTH_SHA,'authentication helper pin mismatch')
        spec=importlib.util.spec_from_file_location('native_profile_auth',authpath);auth=importlib.util.module_from_spec(spec);spec.loader.exec_module(auth);auth.FROZEN=FROZEN
        authenticated=auth.source_identity(REPO,source);write(OUT/'source-authentication.json',authenticated)
        publication=auth.parse((REPO/'benchmarks/results/native-indexed-routing-v1/manifest.json').read_bytes())
        need(publication['sha256']['v2-review-receipt.json']=='22e89779d838581371094c4087f94982063b77314d8994303ad0e41f1429e105','publication review pin mismatch')
        saved=inventory(STUDY);need(sha(saved['manifest.json'])==STUDY_MANIFEST,'saved frozen-study pin mismatch');sm=auth.parse(saved['manifest.json'])
        need(set(saved)==set(sm['sha256'])|{'manifest.json'} and all(sha(saved[name])==value for name,value in sm['sha256'].items()),'saved study closure changed')
        buildraw=(BUILD/'native-exact-build-manifest.json').read_bytes();need(sha(buildraw)==auth.parse(saved['protocol.json'])['build']['manifest_sha256'],'build manifest changed');build=auth.parse(buildraw)
        need(build['contract']=='native-exact-build-v1' and build['target']=='engine' and len(build['source_sha256'])==11,'wrong accepted native build')
        for name,digest in build['source_sha256'].items():
            need(source['sha256'][name]==digest,'current accepted build source drift: '+name)
            accepted=git('show',ACCEPTED+':'+name)
            need(accepted.replace(b'\r\n',b'\n')==(REPO/name).read_bytes().replace(b'\r\n',b'\n'),'production differs from accepted commit: '+name)
        exe=Path(build['executable']);need(sha(exe.read_bytes())==build['executable_sha256']==EXECUTABLE,'accepted executable changed')
        dependency=REPO/'third_party/boost-multiprecision-1.92.0';dep=auth.parse((dependency/'manifest.json').read_bytes())
        need(sha((dependency/'manifest.json').read_bytes())==build['dependency_manifest_sha256'] and sha((dependency/'headers.zip').read_bytes())==build['dependency_archive_sha256'] and build['dependency_headers']==198 and build['license']=='BSL-1.0','dependency pins changed')
        with zipfile.ZipFile(dependency/'headers.zip') as archive:
            headers={i.filename:archive.read(i) for i in archive.infolist() if not i.is_dir()}
        need(len(headers)==198 and {name:sha(raw) for name,raw in headers.items()}==dep['headers_sha256'],'dependency archive closure mismatch')
        need({name:sha(raw) for name,raw in inventory(BUILD/'boost-include').items()}==dep['headers_sha256'],'actual compiler headers differ')
        (OUT/'accepted-build-manifest.json').write_bytes(buildraw);(OUT/'profile-helper.py').write_bytes(Path(__file__).read_bytes())
        transformed=OUT/'instrumented-source';original=OUT/'production-source';transformed.mkdir();original.mkdir();changes=[];diff=[]
        phaseheader=(WORK/'native-indexed-phase-profiler.hpp').read_bytes();(transformed/'phase_profile.hpp').write_bytes(phaseheader)
        for name in ('exact_four_street_train.cpp','exact_public_graph.hpp','exact_selected_cfr.hpp','exact_selected_kernel.hpp','exact_binary64.hpp','exact_public_history_index.hpp','exact_indexed_routing.hpp'):
            raw=(REPO/'native'/name).read_bytes();(original/name).write_bytes(raw)
            altered,patchtext=transform(raw,name,transformations().get(name,[]));
            if name=='exact_selected_cfr.hpp':
                t=altered.decode();before='            for (unsigned iteration = 1; iteration <= plan_.iterations(); ++iteration) {';after='            if (receipt_.member_checks != receipt_.expected_member_checks ||';need(t.count(before)==t.count(after)==1,'learning context anchors');t=t.replace(before,'            { '+scope('learning_interval','learning')+'\n'+before).replace(after,'            }\n'+after);altered=t.encode();patchtext=''.join(difflib.unified_diff(raw.decode().replace('\r\n','\n').splitlines(True),t.splitlines(True),fromfile='production/'+name,tofile='instrumented/'+name))
            (transformed/name).write_bytes(altered);diff.append(patchtext)
            changes.append({'file':name,'source_raw_sha256':sha(raw),'instrumented_sha256':sha(altered),'anchors':len(transformations().get(name,[]))})
        (OUT/'instrumentation.diff').write_text(''.join(diff),encoding='utf-8',newline='\n');write(OUT/'transformation.json',{'source_commit':FROZEN,'accepted_production_commit':ACCEPTED,'files':changes,'timer_header_sha256':sha(phaseheader),'exact_anchor_replacements_only':True})
        stage='instrumented-compilation';directory=OUT/'build';directory.mkdir();instrumented_exe=directory/'native-exact-profile.exe'
        environment=compiler_environment(build['compiler'],directory)
        command=[build['compiler'],*build['flags'],'/I'+str(transformed),str(transformed/'exact_four_street_train.cpp'),'/Fo'+str(directory/'profile.obj'),'/Fe'+str(instrumented_exe)]
        compiled=subprocess.run(command,capture_output=True,cwd=directory,env=environment,timeout=180)
        (directory/'compiler-stdout.log').write_bytes(compiled.stdout);(directory/'compiler-stderr.log').write_bytes(compiled.stderr);write(directory/'status.json',{'returncode':compiled.returncode,'command':command})
        need(compiled.returncode==0,'instrumented compile failed')
        instrumented_sha=sha(instrumented_exe.read_bytes())
        for sample in SAMPLES:
            stage='fresh-native-profile:'+sample
            raw=auth.parse(saved[sample+'.stdout.bin']);stream=raw['native_streams'][0];request,expected,error=(base64.b64decode(stream[key],validate=True) for key in ('request','stdout','stderr'))
            need(stream['returncode']==0 and error==b'' and raw['failure'] is None,'saved native sample failed')
            receipt=raw['payload']['operator_census']['native_exact'];need(receipt['build']['executable_sha256']==EXECUTABLE and receipt['build']['source_sha256']==build['source_sha256'] and sha(request)==receipt['request_sha256'] and sha(expected)==receipt['result_sha256'],'saved sample/build byte binding differs')
            encoded=json.dumps(raw['payload'],sort_keys=True,separators=(',',':'),allow_nan=False).encode();need(sha(encoded)==raw['payload_sha256'],'saved complete payload changed')
            folder=OUT/sample;folder.mkdir();(folder/'request.txt').write_bytes(request);(folder/'frozen-stdout.txt').write_bytes(expected);write(folder/'frozen-payload.json',raw['payload'])
            paired={}
            for mode,path in (('instrumented',instrumented_exe),):
                target=folder/mode;target.mkdir();need(sha(path.read_bytes())==(EXECUTABLE if mode=='uninstrumented' else instrumented_sha),'profile executable drift')
                candidate_calls+=1;start=time.perf_counter()
                process=subprocess.run([str(path)],input=request,capture_output=True,timeout=180,check=False)
                elapsed=time.perf_counter()-start
                (target/'stdout.txt').write_bytes(process.stdout);(target/'stderr.txt').write_bytes(process.stderr);write(target/'status.json',{'returncode':process.returncode,'process_wall_seconds':elapsed,'native_process_scope_only':True})
                need(process.returncode==0,'native profile process failed')
                need(process.stdout==expected,'instrumentation/uninstrumented native stdout differs from frozen policy/counter bits')
                identity={'all_full_policy_and_counter_bits_match':True,'rows':raw['payload']['info_sets']}
                if mode=='uninstrumented':need(process.stderr==b'','unexpected uninstrumented stderr');profile=None
                else:
                    profile=auth.parse(process.stderr);need(profile['contract']=='external-native-phase-profile-v1','bad timer report')
                    records=profile['records'];need(all(type(v[key]) is int and v[key]>=0 for v in records for key in ('calls','inclusive_ns','exclusive_ns')),'invalid timing counters')
                    total=[v for v in records if v['context']=='process' and v['phase']=='process_run'];need(len(total)==1 and total[0]['calls']==1,'missing native root timer')
                    # Exclusive records partition the instrumented run apart
                    # from timer/report boundary overhead, never sum inclusives.
                    need(sum(v['exclusive_ns'] for v in records)==total[0]['inclusive_ns'],'exclusive timing nesting does not partition root interval')
                    write(target/'phase-profile.json',profile)
                paired[mode]={'process_wall_seconds':elapsed,**identity,'profile':profile}
            results.append({'sample':sample,'frozen_raw_sha256':sha(saved[sample+'.stdout.bin']),'modes':paired,
                'instrumented_wall_only':paired['instrumented']['process_wall_seconds']})
            print(sample+' fresh instrumented/uninstrumented bits matched',flush=True)
        stage='after-authentication';need(snapshot()==source and auth.source_identity(REPO,source)==authenticated,'source changed during external profiling')
        need(inventory(STUDY)==saved,'immutable study bytes changed');need((BUILD/'native-exact-build-manifest.json').read_bytes()==buildraw and sha(exe.read_bytes())==EXECUTABLE and sha(instrumented_exe.read_bytes())==instrumented_sha,'build drift')
        write(OUT/'source-after.json',source)
        report={'outcome':'complete','source_commit':FROZEN,'accepted_production_commit':ACCEPTED,'source_files':authenticated['files'],'native_process_invocations':candidate_calls,
            'instrumented_executable_sha256':instrumented_sha,'results':results,'source_and_study_and_build_unchanged':True,
            'scope':'Six saved-wire fresh native-only instrumented calls, three fixtures in both routing modes. No Python legal preparation, diagnostics, serialization or independent replay timing. Instrumentation adds per-scope steady_clock bookkeeping and finite-check increments; it changes inlining and costs. Inclusive times overlap; only exclusive records partition the instrumented process run. Observed wall ratios are instrumentation overhead observations, not benchmarks, general speedups or causal production CPU shares. No Stage B/C capacity claim.'}
        write(OUT/'report.json',report)
    except BaseException as exc:
        failure={'stage':stage,'error_type':type(exc).__name__,'error':str(exc),'candidate_invocations':candidate_calls};write(OUT/'first-failure.json',failure)
    files=[p for p in OUT.rglob('*') if p.is_file() and p.suffix not in ('.obj','.exe')]
    write(OUT/'manifest.json',{'sha256':{p.relative_to(OUT).as_posix():sha(p.read_bytes()) for p in sorted(files)}})
    print(json.dumps({'outcome':'failed' if failure else 'complete','failure':failure,'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'candidate_invocations':candidate_calls}),flush=True)
    return 1 if failure else 0
if __name__=='__main__':raise SystemExit(main())
