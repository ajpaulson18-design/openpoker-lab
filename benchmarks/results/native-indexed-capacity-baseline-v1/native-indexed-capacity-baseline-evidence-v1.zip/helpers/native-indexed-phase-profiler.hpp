#pragma once
// External instrumentation only. Never part of the production source/build.
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
namespace opl_phase_profile {
enum class Phase:std::size_t { process_run, plan_setup, kernel_setup, trainer_preflight, trainer_run,
    marginal_key_setup, marginal_callback, terminal_callback, rank_cache, rational_conversion,
    history_lookup, history_route, history_transform, history_parse, history_validation,
    rematch, responder, target_traversal, average_pass, average_traversal, member_stage, output, router_setup, indexed_lookup, indexed_prefix, learning_interval, count };
inline constexpr std::array<const char*,static_cast<std::size_t>(Phase::count)> names={
    "process_run","plan_setup","kernel_setup","trainer_preflight","trainer_run","marginal_key_setup",
    "marginal_callback","terminal_callback","rank_cache","rational_conversion","history_lookup",
    "history_route","history_transform","history_parse","history_validation","rematch","responder",
    "target_traversal","average_pass","average_traversal","member_stage","output","router_setup","indexed_lookup","indexed_prefix","learning_interval"};
enum class Context:std::size_t { process, setup, preflight, learning, output, count };
inline constexpr std::array<const char*,5> contexts={"process","setup","preflight","learning","output"};
struct Record {std::uint64_t calls=0,inclusive_ns=0,exclusive_ns=0;};
inline std::array<std::array<Record,static_cast<std::size_t>(Phase::count)>,5> records{};
inline std::uint64_t finite_checks=0;
class Scope;
inline thread_local Scope* active=nullptr;
inline thread_local Context context=Context::process;
class Scope final {
    using Clock=std::chrono::steady_clock;
    Scope* parent_;Phase phase_;Context previous_,used_;Clock::time_point begin_;
    std::uint64_t children_ns_=0;
public:
    explicit Scope(Phase phase):Scope(phase,context){}
    Scope(Phase phase,Context selected):parent_(active),phase_(phase),previous_(context),used_(selected),begin_(Clock::now()) {active=this;context=selected;}
    Scope(const Scope&)=delete;Scope& operator=(const Scope&)=delete;
    ~Scope() noexcept {
        const auto signed_ns=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-begin_).count();
        const auto elapsed=static_cast<std::uint64_t>(signed_ns>0?signed_ns:0);
        auto& out=records[static_cast<std::size_t>(used_)][static_cast<std::size_t>(phase_)];
        ++out.calls;out.inclusive_ns+=elapsed;out.exclusive_ns+=elapsed>=children_ns_?elapsed-children_ns_:0;
        if(parent_)parent_->children_ns_+=elapsed;
        active=parent_;context=previous_;
    }
};
struct Report final {
    ~Report() noexcept {
        try {
            std::cerr<<"{\"contract\":\"external-native-phase-profile-v1\",\"finite_checks\":"<<finite_checks<<",\"records\":[";
            bool first=true;
            for(std::size_t c=0;c<contexts.size();++c)for(std::size_t p=0;p<names.size();++p) {
                const auto& value=records[c][p];if(!value.calls)continue;
                if(!first)std::cerr<<',';first=false;
                std::cerr<<"{\"context\":\""<<contexts[c]<<"\",\"phase\":\""<<names[p]<<"\",\"calls\":"<<value.calls
                    <<",\"inclusive_ns\":"<<value.inclusive_ns<<",\"exclusive_ns\":"<<value.exclusive_ns<<'}';
            }
            std::cerr<<"]}\n";
        }catch(...){}
    }
};
} // namespace opl_phase_profile
