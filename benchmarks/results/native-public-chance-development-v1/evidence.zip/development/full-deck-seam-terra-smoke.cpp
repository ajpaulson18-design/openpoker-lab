#include "full_deck_public_chance.hpp"
#include <array>
#include <bit>
#include <iostream>
int main() {
    namespace p=openpoker::full_deck_public_chance;
    const std::array<p::WeightedHand,1> a{{{{0,1},std::bit_cast<std::uint64_t>(1.0)}}};
    const std::array<p::WeightedHand,1> b{{{{2,3},std::bit_cast<std::uint64_t>(1.0)}}};
    p::PublicChanceKernel k(a,b);
    const auto r=k.prefix({});
    if (r.total_numerator!=r.denominator) return 2;
    const std::array<std::uint8_t,5> board{4,5,6,7,8};
    const std::array<double,1> reach{1.0};
    auto t=k.terminal(0,board,p::TerminalKind::fold,1.0,reach,p::Integer(1),p::Integer(1));
    std::cout<<t.numerators[0]<<'/'<<t.denominator<<'\n';
    return 0;
}
