#include "full_deck_public_chance.hpp"
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <vector>
namespace p=openpoker::full_deck_public_chance;
using I=p::Integer; using H=p::Hand;
bool disjoint(H a,H b) {return a.first!=b.first&&a.first!=b.second&&a.second!=b.first&&a.second!=b.second;}
bool clear(H h,const std::vector<std::uint8_t>& b) {for(auto c:b)if(c==h.first||c==h.second)return false;return true;}
int main() {
 const std::array<std::uint8_t,9> deck{0,1,2,3,4,5,6,7,8};
 const std::array<p::WeightedHand,2> sb{{{{0,1},std::bit_cast<std::uint64_t>(1.0)},{{0,2},std::bit_cast<std::uint64_t>(0.5)}}};
 const std::array<p::WeightedHand,2> bb{{{{3,4},std::bit_cast<std::uint64_t>(1.0)},{{2,5},std::bit_cast<std::uint64_t>(0.5)}}};
 const std::array<std::array<H,2>,2> hs{{{{0,1},{0,2}} , {{{3,4},{2,5}}}}};
 const std::array<std::array<int,2>,2> w{{{{4,2}},{{4,2}}}};
 const std::array<double,2> reach{0.25,0.75}; const std::array<int,2> rs{1,3};
 p::PublicChanceKernel k(sb,bb,p::DeckDefinition::reduced(deck));
 int z=0;for(int i=0;i<2;++i)for(int j=0;j<2;++j)if(disjoint(hs[0][i],hs[1][j]))z+=w[0][i]*w[1][j];
 std::size_t boards=0, positive=0;
 for(int a=0;a<9;++a)for(int b=a+1;b<9;++b)for(int c=b+1;c<9;++c)
 for(int t=0;t<9;++t)for(int r=0;r<9;++r) {
  if(t==a||t==b||t==c||r==a||r==b||r==c||r==t)continue;
  const std::vector<std::uint8_t> board{static_cast<std::uint8_t>(a),static_cast<std::uint8_t>(b),static_cast<std::uint8_t>(c),static_cast<std::uint8_t>(t),static_cast<std::uint8_t>(r)};
  ++boards; bool world=false;
  for(int i=0;i<2;++i)for(int j=0;j<2;++j)world|=disjoint(hs[0][i],hs[1][j])&&clear(hs[0][i],board)&&clear(hs[1][j],board);
  if(world)++positive;
  for(int side=0;side<2;++side)for(int kind=0;kind<2;++kind) {
   const auto mode=kind?p::TerminalKind::showdown:p::TerminalKind::fold;
   const auto actual=k.terminal(side,board,mode,1.0,reach,I(2),I(7));
   for(int i=0;i<2;++i) {
    int expected=0;
    for(int j=0;j<2;++j) {
     const auto own=hs[side][i],other=hs[1-side][j];
     if(!disjoint(own,other)||!clear(own,board)||!clear(other,board))continue;
     int sign=1;
     if(kind) {
      const std::array<std::uint8_t,7> c1{own.first,own.second,board[0],board[1],board[2],board[3],board[4]};
      const std::array<std::uint8_t,7> c2{other.first,other.second,board[0],board[1],board[2],board[3],board[4]};
      const auto v1=p::prior::rank_seven(c1),v2=p::prior::rank_seven(c2);
      sign=(v2<v1)-(v1<v2);
     }
     expected+=w[side][i]*w[1-side][j]*rs[j]*sign*7;
    }
    if(actual.numerators[i]*I(z*4*20*2)!=I(expected)*actual.denominator) {std::cerr<<"terminal mismatch "<<boards<<' '<<side<<' '<<kind<<' '<<i<<'\n';return 2;}
   }
  }
 }
 if(boards!=2520||positive!=60){std::cerr<<"board counts mismatch\n";return 3;}
 const std::array<std::uint8_t,3> flop{0,1,2}; const auto r=k.prefix(flop);
 for(int side=0;side<2;++side)for(int i=0;i<2;++i) {
  int expected=0;const std::vector<std::uint8_t> b(flop.begin(),flop.end());
  for(int j=0;j<2;++j)if(disjoint(hs[side][i],hs[1-side][j])&&clear(hs[side][i],b)&&clear(hs[1-side][j],b))expected+=w[side][i]*w[1-side][j];
  if(r.hand_masses[side].numerators[i]*I(z*10)!=I(expected)*r.denominator || r.physical_support[side][i]!=(expected!=0))return 4;
 }
 const auto old=k.receipt().rank_calls;
 try {const std::array<std::uint8_t,5> b{0,1,2,3,4};(void)k.terminal(0,b,p::TerminalKind::showdown,1.0,reach,I(0),I(1));return 5;}
 catch(const p::KernelError&) {}
 if(k.receipt().rank_calls!=old)return 6;
 std::cout<<"PASS "<<boards<<" boards "<<positive<<" positive, both seats/fold/showdown, prefix, reject-before-rank\n";
}
