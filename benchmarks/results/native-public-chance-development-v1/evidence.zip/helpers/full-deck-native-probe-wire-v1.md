# Full-deck public-chance probe wire v1

Status: Luna implementation proposal for the native probability boundary. This
wire carries one independently admitted query per line. It is a bounded test
interface, not a policy, sampler, or training protocol. The probe may process
many lines in one process; each line constructs a fresh kernel and cannot rely
on state from another line.

## Framing and limits

- UTF-8/ASCII whitespace-token request records terminated by LF; CRLF is accepted.
- Maximum request line is 1 MiB. The reader stops immediately at byte 1 MiB + 1
  and exits nonzero without draining an oversized line.
- Maximum successful response line is 64 MiB; the parser forecasts this bound
  before materializing query vectors. The process accepts at most 4,096 records.
- One request line produces one bounded response block: one newline-terminated
  field per line, with the kernel `receipt` as the final line. EOF is clean.
  Malformed requests produce one bounded `ERR <code>` line; framing overflow
  terminates the process.
- No extra tokens, signs on unsigned fields, leading `+`, decimal floating
  point, or locale-dependent parsing. Hex integers are lowercase or uppercase
  ASCII hexadecimal, no `0x`, no leading sign except for output numerators.
- Every query's complete syntax, dimensions, bit-string lengths, and bounded
  token count are checked before range/reach/query arrays or arbitrary-width
  integers are constructed. Kernel limits are reduce-only. The probe enforces
  its line/token/dimension ceiling before constructing the kernel.
- Before vector or big-integer allocation, the probe reserves combined modeled
  work for `parse_work_upper + 8 * response_bytes_upper`. It passes only the
  remainder of the caller's requested work ceiling to the kernel; kernel
  modeled work plus that transport reserve stays within the original request
  limit. This is a logical model, not CPU time.
- It also reserves probe ownership entries and proposal/numeric input payload
  before materializing range/reach vectors or proposal integers. These amounts
  are subtracted from the caller's storage and integer-payload ceilings before
  passing the remaining limits to the kernel.

## Request grammar

Tokens below are separated by one or more ASCII whitespace characters. `u`
means a canonical unsigned decimal integer; `hex16` means exactly 16 hex digits
encoding the raw IEEE-754 binary64 bits; `hexint` means a nonempty unsigned
hexadecimal integer with no prefix.

```text
OPENPOKER_FULL_DECK_PUBLIC_CHANCE_V1
deck FULL52
```
or
```text
OPENPOKER_FULL_DECK_PUBLIC_CHANCE_V1
deck REDUCED n card_id_0 ... card_id_(n-1)
```
then
```text
limits max_hands_per_side max_integer_bits max_modeled_work max_storage_entries max_integer_payload_bits
ranges sb_count bb_count
sb (card_id_0 card_id_1 hex16_weight)*
bb (card_id_0 card_id_1 hex16_weight)*
query PREFIX|TERMINAL
```

For `PREFIX`:

```text
prefix exact|binary64 k card_id_0 ... card_id_(k-1)
```

For `TERMINAL`:

```text
terminal exact|binary64 player FOLD|SHOWDOWN payoff_hex16 q_num_hexint q_den_hexint reach_count reach_hex16_0 ... reach_hex16_(reach_count-1) board_card_0 ... board_card_4
```

`player` is 0 (SB) or 1 (BB); `reach_count` must equal the opponent range row
count. Fold payoff is signed in the queried player's convention. Showdown
payoff is finite, nonnegative stake. Proposal numerator and denominator are
positive exact integers, and `q_num <= q_den`. The five board IDs are the full
visible board; first three cards use canonical increasing deck order, while
turn and river remain ordered. The kernel validates physical/deck membership,
duplicates, and prefix shape. Binary64 weights/reaches/payoffs use raw bits,
not decimal parsing.

The first three range fields are canonical card IDs with `card_id_0 <
card_id_1`; input row order is preserved. Both ranges must be nonempty and each
side count is at most 1,326. Reduced decks have 9..52 strictly increasing IDs
in `[0,52)`; `FULL52` is the explicit complete deck. Query line count in a
single process is capped at 4,096 as an outer transport bound.

## Response grammar

Every successful response block begins with:

```text
OPENPOKER_FULL_DECK_PUBLIC_CHANCE_RESULT_V1
deck_size N
deck_mode FULL52|REDUCED
normalizer_hex Z
weight_denominator_exponents D_sb D_bb
probe_receipt request_bytes request_tokens parse_work_upper response_bytes_upper
probe_ownership entries_upper integer_payload_bits_upper
```

The `receipt` line is emitted last, after the query vector and optional
binary64 fields:

```text
receipt modeled_work retained_entries peak_scratch_entries peak_integer_bits setup_integer_payload_bits peak_integer_payload_bits prefix_queries terminal_queries rank_calls conversion_calls
```

`deck_mode` explicitly records the declared law; a 52-card reduced proof deck
remains marked `REDUCED`. `probe_receipt` reports bounded transport parsing and
output sizing, separate from kernel modeled work. The response upper bound
includes three maximum-width exact scalars plus row outputs. Neither measure is
CPU, allocator, or RSS accounting. `Z` is the exact global compatible-pair
normalizer represented by the kernel's integer weights. Denominator exponents
are signed decimal integers. For a prefix response, emit:

The transport model is `parse_work_upper = 16384 + 6 * request_bytes + 16 * request_tokens`;
`response_bytes_upper` conservatively covers three maximum-width integer hex
fields and all result rows. The probe reserves `parse_work_upper + 8 *
response_bytes_upper` against the request's original modeled-work limit before
allocating range/reach vectors or parsing proposal integers. The kernel gets
the remaining modeled-work allowance. The fixed 1 MiB request and 64 MiB
response framing ceilings remain separate bounded buffers, not the kernel's
storage or integer-payload claims.

`probe_ownership entries_upper` is `4 * (SB_rows + BB_rows) + 128`;
`integer_payload_bits_upper` is `16 * (q_num_hex_chars + q_den_hex_chars) +
4 * max_integer_bits + 256`, with proposal-token lengths zero for PREFIX. These
are logical entry/value-width reserves for owned input snapshots and parser
temporaries, not allocator byte measurements. Both are deducted from the
original caller limits before the kernel is given its reduced-only limits.

```text
prefix k
denominator_hex D
total_numerator_hex N
side 0 row_count
value sign magnitude_hex physical_support_bit
... (one value per original SB input row)
side 1 row_count
value sign magnitude_hex physical_support_bit
... (one value per original BB input row)
```

For a terminal response, emit:

```text
terminal player row_count
denominator_hex D
value sign magnitude_hex
... (one value per original queried-player input row)
```

When the request asks for `binary64`, append `binary64_bits count` and exactly
`count` 16-digit lowercase IEEE-754 bit patterns after all exact vectors. For a
prefix, binary64 values are flattened in SB row order and then BB row order.
Exact numerators and denominator remain present and authoritative in both modes.
Signed exact zeros serialize as sign `0`, magnitude `0`; nonzero values use
sign `+` or `-` and unsigned magnitude hex. Binary64 conversion follows the
existing strict exact converter; a conversion failure is an error, never a
silent zero or subnormal replacement.

Error codes are stable short tokens (`invalid_request`, `invalid_limit`,
`invalid_range`, `invalid_query`, `integer_bit_limit`, `integer_payload_limit`,
`modeled_work_limit`, `storage_limit`, `no_compatible_deals`,
`conversion_failure`, `request_too_large`). No exception text, stack trace, or
unbounded input token is echoed. `response_too_large` and `record_limit` are
transport errors with the same bounded format. Probe receipt work is a
transport parser/output sizing model, separate from the kernel's modeled work;
neither is CPU or allocator/RSS accounting.

## Scope

This protocol can compare exact outputs with a separate scalar oracle. It does
not prove regret or average-strategy increment expectations, implement chance
sampling, or certify a full-deck betting solver. The nine-card 2,520-outcome
expectation experiment remains a separate acceptance gate.
