# Proposed next structural slice: public-chance update contract

Design only; no sampler, training, convergence or full-deck quality result is
claimed. PR #279's selected-game certificate is a separate completed-mathematics
gate with publication CI still pending. The original architecture model remains
unavailable; the main agent supplies this proposal for independent challenge.

## Mathematical seam

Sample a canonical unordered flop followed by ordered turn/river, independently
of hidden holdings and action choices. For a deck of N cards and two disjoint
two-card holdings, d5 = C(N-4,3)*(N-7)*(N-8). Let Z be the compatible root pair
weight sum, without a board-conditioned renormalizer. For a public full-board
proposal q(b)>0, a compatible terminal pair contribution is
wi*wj*u/(Z*d5*q(b)), multiplied by the opponent's action reach exactly once.
Own prior is included once; own preceding action reach is excluded from the
counterfactual increment. Future own play follows the frozen current policy.
Raw regret is sampled action value minus its same-policy action mixture.
All action increments in one proof pass use one frozen policy for both players.

Early fold/all-in uses that same full-board importance estimator, not another
completion count. A sampled board with zero target-compatible pairs still
counts as an outcome/iteration; redrawing it would change the proposal law.
Its numeric regret contribution may be zero. That does not make its earlier
visible-prefix average-policy increment zero.

Average increments are a separate seam: at own-hand/visible-prefix/full-history
row I, accumulate own realization reach * absolute own-hand prefix mass * sigma
divided by proposal prefix inclusion q(prefix), only when that prefix is sampled.
Prefix mass includes own prior and compatible opponent prior under the full
finite deck, with d0/d3/d4/d5, never the sampled full-board marginal at preflop.
Prove expected numerator AND denominator increments; their normalized finite
sample ratio is not asserted unbiased. Define a complete legal zero-visit
fallback. Start with vanilla regret matching and identity symmetry, not CFR+
clipping or a sampled-board stabilizer.

## Storage/ownership seam

Policy lookup/row identity is (global actor, own holding, full visible history),
including only the currently visible public prefix. No future-board pruning of
rows, strategy ownership, menus or prefix support. Board blocking may zero only
the correctly weighted numeric contribution. Opponent reach is full-history
policy reach; no reconvergent public-vertex aliasing. Admit history/action-slot
pages, transient updates, proposal/RNG and rank state before allocation; resource
exhaustion is incomplete, never eviction/reset or a restricted-game fallback.
The sampled trajectory is not a per-sample best-response certificate.

Existing selected-board native Graph/Router construction is unsafe to invoke as
a one-board trainer: it can prune earlier hands/rows using that future board.
An isolated terminal vector might be reusable with an explicit external mass
scale, but its selected-board normalizer and zero-target-board behavior require
proof. Do not change or silently route existing native contracts.

## Smallest acceptance anchor before native training

Use a declared reduced finite nine-card deck, not a full-52 solve claim. One
candidate support is SB {ab,ac}, BB {de,cf}, with positive unequal weights and
distinct cards a..i: three compatible pairs have 20 boards each, so the union of
target-legal boards has at most 60 entries. All 2,520 public proposal outcomes
include zero-target boards. The union can fit the current selected-board exact
reference cap without changing the nine-card target law: every compatible pair
retains all 20 of its legal boards and the global selected normalizer is 20*Z.
Verify these counts explicitly; do not assume them if fixture/rules change.

Freeze a complete nonuniform four-street policy with early folds/all-ins,
unequal opponent reaches, a zero-own-probability legal branch and varying hidden
showdown ranks. Enumerate every proposal outcome exactly for uniform and a
strictly positive nonuniform proposal. Compare the expectation of every raw
regret action increment for BOTH players and each average-policy numerator and
denominator against independently enumerated finite-game reference increments.
Use complete public history at all 0/3/4/5 prefixes; do not compare just root EV.

Negative controls: missing importance factor; wrong canonical flop multiplier;
double-counted prior/reach; full-board average mass at an earlier prefix;
future-card row pruning; hidden-future maximization; and reconvergent history
aliasing must each fail the appropriate anchor. Keep structural support proof
separate from numeric-zero updates and final policy normalization.

The reduced-deck estimator proof is a prerequisite for one native virtual-chance
training path, not another stand-alone solver release. A credible full-game
quality verifier, variance/cost evidence and bounded history/strategy storage
remain required before any large/full-deck quality claim.
