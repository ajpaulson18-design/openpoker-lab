# Native public-chance probability/payoff seam: accepted implementation scope

Baseline acf7aaf; new isolated checkout `work/full-deck-sampling-contract-repo`.
This is the first native component of the next four-street virtual-chance path,
not an independent street solver, trainer, random sampler or quality release.
Keep old selected APIs/source/defaults unchanged. Root supplies architecture
while Sol is unavailable; Terra implements difficult exact native arithmetic,
Luna integrates bounded protocol/build controls, root owns independent oracles.

## Required semantics

1. Owned immutable original SB/BB ranges, exact binary64 weight snapshots,
   canonical rank-major c/d/h/s card IDs. Root Z sums wi*wj over compatible
   private pairs, without board conditioning. No retained private-pair/world or
   public-board list. Prefix queries use card buckets and same-holding addback.
2. Explicit full52 deck by default. A separately declared reduced-deck proof
   mode may accept a subset of at least nine physical card IDs; do not label it
   full52. Public prefix sizes 0/3/4/5, canonical unordered flop, ordered turn and
   river. Reject noncanonical/duplicate/foreign cards rather than silently
   replacing input law. No stochastic sampling or RNG in this component.
3. Prefix result retains input row order, including exact zero masses and
   physical support. Shared denominator is root Z times d_k, with d0=1,
   d3=C(N-4,3), d4=d3*(N-7), d5=d4*(N-8). Do not locally renormalize. Physical
   support ignores policy reach and unknown sampled future cards.
4. Single-full-board terminal query takes original role, fold/showdown kind,
   signed fold payoff or nonnegative showdown stake, complete opponent reach
   vector [0,1], and exact positive rational proposal q<=1. It returns exact
   own-hand counterfactual numerators/common denominator for
   wi*sum_j(wj*opp_reach_j*payoff_ij)/(Z*d5*q(board)). Include own prior once,
   global Z once, no own prior action reach. Board-blocked own rows return zero
   NUMERIC contribution, not a new strategy-support or identity decision.
   Zero-target-compatible boards return valid zero vectors without constructing
   a one-board selected game or redrawing. Sameholding/addback, ties and role
   signs must be correct. Signed fold utility follows the queried player's
   existing net-transfer convention; actual betting/refunds stay caller-owned.
5. Keep exact numerator/denominator output through proposal scaling. Optional
   binary64 output uses exact_binary64 once at the final boundary, preserving
   strict underflow/overflow rejection. Do not multiply already-rounded selected
   vectors by an importance correction. Independent tests compare exact values
   before conversion and binary64 bits after it.

## Suggested owned API (Terra may refine and communicate before integration)

Header `native/full_deck_public_chance.hpp`, namespace
`openpoker::full_deck_public_chance`. Reuse canonical Hand/WeightedHand types and
ranker/decoder from existing native code without modifying that code.

`ExactVector { vector<Integer> numerators; Integer denominator; }`
`PrefixResult { array<ExactVector,2> hand_masses; Integer total_numerator;
                Integer denominator; array<vector<bool>,2> physical_support; }`
`PublicChanceKernel(span<const WeightedHand> sb, span<const WeightedHand> bb,
                    DeckDefinition deck=full52(), Limits limits={})`
`prefix(span<const uint8_t> visible_prefix)`
`terminal(player, full_board, kind, payoff, opponent_reach, proposal_num, proposal_den)`
`binary64(ExactVector)` (or explicitly named combined query with same semantics)
`receipt()` plus root Z/deck metadata for diagnostics.

## Admission and implementation boundaries

Reduce-only explicit bounds at most 1,326 hands/seat, 500m named logical work,
2m logical retained/scratch entries, 65,536 integer-value bits and 1<<30 integer
payload forecast bits. These are a new component model, not credits against an
old producer's caps and not CPU/allocator/RSS guarantees. Reject invalid dimensions
before ownership/allocation. Reserve output/bucket/rank/sort/copy/lookup storage
and query work before operations, including input parsing in the probe. Guard
integer shifts/products/sums and converter scratch before constructing them.
Account for declared support and zero cases; no arbitrary maps/unchecked sorting
claims. No retained rank cache is necessary initially. Exact global mass and
terminal bucket/sweep arithmetic are independent of any complete-world table.

The protocol/probe must not expose hidden-board state to policy lookup: this
component has NO policy or history routing API. Later virtual traversal owns
visible full-history identity and lazy bounded row pages. Prefix average weighting
uses the prefix result with its OWN q(prefix) correction; it must never substitute
the sampled terminal vector or a full-board marginal at an earlier street.

## Acceptance and next dependency

Root tests native exact outputs against a separately written scalar physical
pair oracle and existing independent Python full52 prefix operator. Cover both
roles, weighted/subnormal/extreme priors, overlapping/same holdings, all prefixes,
ordered reveals, blocked/zero-target boards, fold/tie/win/loss, signed utility,
nonuniform rational proposal, strict conversions and pre-operation guards.
Compile with strict FP in an external build folder, pin source/compiler/Boost/
executable identities, preserve first failures. CI: Linux/Windows and sanitizer.

Before training, enumerate all 2,520 proposal outcomes of the reviewed nine-card
anchor: 60 target-legal boards and 2,460 zero-target boards. Prove both players'
raw regret/action and average numerator/denominator expectation increments for
uniform/nonuniform q, with independent full-history references and negative
controls. This component alone does not discharge that gate. Then implement one
native virtual-chance four-street traversal and bounded strategy storage; do not
keep expanding standalone probability modules. Full-game independent quality
verification and variance/cost evidence remain required.
