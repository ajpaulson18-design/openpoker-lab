"""Development-only compiled controls; preserve modes, first errors and pins."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

work=Path(__file__).resolve().parent
repo=work/'full-deck-sampling-contract-repo'
exe=work/'full-deck-public-chance-luna-v4/probe/native-full-deck-public-chance-probe.exe'
out=work/'full-deck-public-chance-root-controls-v3'
out.mkdir(exist_ok=False)
paths=['native/full_deck_public_chance.hpp','native/full_deck_public_chance_probe.cpp',
       'native/exact_selected_kernel.hpp','native/exact_binary64.hpp',
       'scripts/build_native_exact_four_street.py','scripts/build_native_full_deck_public_chance.py',
       'tests/full_deck_public_chance_reference.py','tests/test_native_full_deck_public_chance.py',
       'tests/test_build_native_full_deck_public_chance.py','scripts/preflop_validation.py',
       'tests/native/full_deck_public_chance_preflight_controls.cpp',
       'pokerlab/full_deck_prefix_mass.py']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pins():return {name:sha((repo/name).read_bytes()) for name in paths}
before=pins(); results=[]
environment=os.environ.copy()
environment['OPENPOKER_NATIVE_FULL_DECK_CHANCE_EXE']=str(exe)
for name,flags in (('normal',[]),('optimized',['-O'])):
    environment['OPENPOKER_NATIVE_FULL_DECK_CONTROL_DIR']=str(out/('n' if name=='normal' else 'o'))
    command=[sys.executable,'-B',*flags,'-m','unittest',
        'tests.test_build_native_full_deck_public_chance',
        'tests.test_native_full_deck_public_chance','-v']
    with (out/(name+'.stdout.log')).open('xb') as stdout,(out/(name+'.stderr.log')).open('xb') as stderr:
        child=subprocess.run(command,cwd=repo,env=environment,stdout=stdout,stderr=stderr)
    result={'mode':name,'command':command,'returncode':child.returncode}
    (out/(name+'-status.json')).write_text(json.dumps(result,indent=2)+'\n')
    results.append(result)
    if child.returncode:break
after=pins()
receipt={'scope':'Development controls; scoped source pins, not full committed-source acceptance.',
    'source_before':before,'source_after':after,'source_stable':before==after,
    'executable':str(exe),'executable_sha256':sha(exe.read_bytes()),
    'manifest_sha256':sha(exe.with_name('native-exact-build-manifest.json').read_bytes()),'results':results}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'results':results,'source_stable':before==after}),flush=True)
raise SystemExit(0 if before==after and len(results)==2 and all(r['returncode']==0 for r in results) else 1)


