# Full-deck public-chance sampling: integration inventory

Status: read-only architecture inventory. No solver, sampler, native integration, full-deck training, or quality claim was run or implemented.

## Source snapshot inspected

- Published selected-game source: `work/matrix-free-certificate-publication-repo`, clean at `acf7aaf`.
- The Python full-deck prefix-mass operator is `pokerlab/full_deck_prefix_mass.py` in that checkout.
- Native selected-game APIs are in `native/exact_selected_kernel.hpp`, `native/exact_public_graph.hpp`, `native/exact_public_history_index.hpp`, `native/exact_indexed_routing.hpp`, and `native/exact_selected_cfr.hpp`.
- The earlier `work/repo` checkout is at `db66ac3` and has the Python prefix operator but no native graph/router headers. I used the clean published checkout above for the current native interface inventory.

## Existing interfaces and their boundaries

| Component | Reusable behavior | Boundary for a full-deck sampled game |
|---|---|---|
| [`FullDeckPrefixMass`](matrix-free-certificate-publication-repo/pokerlab/full_deck_prefix_mass.py#L127) | Snapshots each binary64 weight exactly as a `Fraction`; computes global compatible private-pair `Z`; `.at(prefix)` returns total and per-hand absolute masses for root, flop, turn, or river. Flop is canonicalized as unordered; turn and river remain ordered. | Python reference operator only. It builds per-query filtered hand maps and has no public-deal sampler, rank/payoff query, CFR traversal, whole-request admission, or full-game certificate. It is the clearest semantic oracle for the proposed native range-mass seam. |
| [`ExactSelectedKernel`](matrix-free-certificate-publication-repo/native/exact_selected_kernel.hpp#L253) | Exact dyadic weight arithmetic, global product normalization, blocker/card buckets, rank sweeps, one final binary64 conversion, and batched marginal/support/terminal vectors. It can evaluate fold or showdown terminals with opponent reach and does not need a private-pair table. | Its constructor owns a fixed `SelectedBoard` vector, with a hard maximum of 64 boards. Its `Z` and every query are defined over those selected board occurrences. Queries take board indexes into that fixed list. It cannot be passed an arbitrary sampled full-deck board without changing that input and normalization contract. |
| [`Graph` and `Plan`](matrix-free-certificate-publication-repo/native/exact_public_graph.hpp#L79) | Represents ordered actions, explicit chance branches, and terminals. `Plan` owns the graph, ranges, selected boards, kernel, support maps, and Q rows; it validates exact graph closure and physical support before training. | Chance children are finite, explicitly supplied branches, and support is cached only for prefixes admitted by the Plan. A full-deck chance node cannot be represented by enumerating every possible public continuation under existing graph/edge/storage limits. |
| [`HistoryIndex` and `TraversalWorkspace`](matrix-free-certificate-publication-repo/native/exact_public_history_index.hpp#L242) | Routes a cursor through an admitted graph edge; active frames keep a bounded stack of live continuation state and reveal the visible prefix as streets are reached. | `advance_reveal` takes a branch index from the static graph. Active frames reduce traversal state; they do not create missing chance branches or an on-demand full-deck history graph. |
| [`IndexedRouting`](matrix-free-certificate-publication-repo/native/exact_indexed_routing.hpp#L116) | Resolves a decision from a cursor, actor, complete ordered menu, and hand; returns holes for unsupported hands and routes supported rows to Q storage. It borrows the Plan’s prefix support and board-index vectors. | Row support and chance-prefix lookup flow through the Plan’s selected-board list and static graph. A sampled future board must not become a decision key or support filter before its street is revealed. |
| [`Trainer`](matrix-free-certificate-publication-repo/native/exact_selected_cfr.hpp#L100) | Runs one whole-root alternating CFR+ request with fixed rematch, responder, and average passes. It uses batched terminal vectors and precomputed marginals; Q rows remain complete for the admitted finite game. | This is a deterministic full-tree CFR+ trajectory. It is not a vanilla stochastic regret estimator, and CFR+ clipping/alternating updates cannot inherit an unbiased raw-regret proof by substitution. |

The selected native kernel caps are explicit: 1,326 hands per seat, 64 selected boards, 65,536 input integer bits, 500 million modeled work units, 2 million logical entries, and a separate integer-payload model. Those are selected-kernel limits, not full-deck capacity claims.

## Probability units that a sampler must preserve

For a compatible private pair, full-deck chance is uniform over

`d5 = C(48,3) * 45 * 44 = 34,246,080`

canonical-flop / ordered-turn / ordered-river outcomes. The number of public outcomes before conditioning on a private pair is

`M = C(52,3) * 49 * 48 = 51,979,200`.

The root law remains `w0(hand0) * w1(hand1) / Z`; board chance is conditional on that pair. At a visible prefix of length 0, 3, 4, or 5, the corresponding conditional chance divisor is respectively `1`, `C(48,3)`, `C(48,3)*45`, or `d5`. Do not renormalize the compatible hand mass locally at a prefix.

For the simplest public proposal, sample uniformly from all `M` public outcomes independently of both private hands and the action path. A compatible pair/full-board terminal then needs importance factor `1 / (d5*q(board)) = M/d5 = 54145/35673`; boards colliding with either hand contribute zero. If the proposal is changed, its exact probability and full-support condition must be part of the algorithm contract. Sampling only boards that avoid sampled private hands is a different, private-dependent estimator and needs its own inclusion proof.

The exact `FullDeckPrefixMass.at(prefix)` result is the useful anchor for visible-prefix prior mass. For a row on a sampled public path, derive and test the prefix-inclusion correction against that target mass. Do not multiply a full-board correction and a prefix correction twice. At a preflop row, keep the full range support even when the privately hidden sampled board collides with a hand; the sampled terminal value can be zero for that hand, but the preflop row still exists.

## Smallest reusable native seam

The narrow next native component should be an opt-in, rank-free full-deck range-mass object, separate from the selected-board `Plan`:

1. Snapshot each input weight as its exact binary64 dyadic and calculate one compatible-pair `Z` over the original ranges.
2. Expose bounded queries for visible-prefix absolute total mass, per-hand masses, and physical support at prefixes of length 0/3/4/5. Reuse the kernel’s integer/card-bucket/same-hand correction ideas; do not enumerate private-pair tables or public boards for these queries.
3. Separately expose a single-board terminal vector query that receives the sampled five-card board, terminal kind/payoff, player, opponent reaches, and explicit proposal probability. It must use the same root `Z`, blockers, exact board ranking/ties, and a once-only strict conversion.

This seam gives the sampler and a small exact oracle the same prior/terminal contract while leaving public history and CFR updates for a later proof slice. It is not a trainer. Avoid extending `ExactSelectedKernel` by silently treating each sampled board as a one-board selected game: its current normalizer would condition on that board’s compatible pair mass, changing the law.

After that seam is independently checked, introduce a virtual public traversal over betting states and sampled reveal tokens. The existing graph can inform action/menu and money-state representation, and its active-frame lifetime pattern is reusable, but a dynamic reveal transition must not pretend an unlisted card is an existing graph edge. Keep full public history in information-set identity even if betting continuations reconverge.

## Estimator requirements and leakage hazards

- Start with vanilla CFR and one fixed update order. A sampled public board can estimate raw regret increments; it does not preserve the deterministic CFR+ trajectory. Test expected per-action regret increments for both players, not final policy similarity.
- Freeze a complete nonuniform policy for the anchor. Enumerate every outcome under the proposal exactly, weight each sampled update by its proposal probability, and compare the expected regret increments and average-strategy numerator/denominator increments with the independently enumerated full-game result.
- At every decision, row identity/support/menu use only actor, own private hand, and full visible action/card history. A future turn/river held internally for payoff evaluation must not affect earlier row lookup, legal support, marginal selection, or policy.
- At showdown, use the sampled full board to calculate the sampled terminal payoff. A best response or certificate must integrate hidden future outcomes before maximizing; maximizing after looking at a sampled hidden river is clairvoyant and invalid.
- For early fold/all-in terminals, a root-sampled full board may still be used as an unbiased sample, but its chance correction is applied exactly once. Do not both marginalize future runouts and multiply by the sampled-full-board correction.
- Average strategy has a separate weight proof: own realization reach, the exact visible-prefix mass for that row, and the action probability. A row appears only when its prefix is sampled, so derive the inclusion correction for that prefix. Unbiased numerator and denominator increments do not make a finite-sample ratio unbiased; specify zero-visit fallback.
- Keep board RNG, proposal, policy, and history separate. Record RNG algorithm/version and seed; require positive proposal support over every target outcome. A suit stabilizer of one sampled board is not a full-game symmetry. Begin with identity symmetry.
- Include negative controls for ordered-flop multiplicity (six permutations versus one canonical flop), turn/river order, blocked hands, same-hand/card corrections, zero proposal, missing support, omitted/double reach, duplicate chance correction, hidden-river leakage, and reconvergent histories.

## Admission and evidence path

Full-deck sampling removes the finite-board enumeration barrier, but the number of public histories and learned rows can still grow with unique sampled prefixes and action sequences. Pre-admit live row/action/history storage, cumulative update work, sampler state, rank-cache state, exact arithmetic bits, importance-weight bounds, and transient scratch before allocating. If a cap is reached, return an explicit resumable resource rejection; do not evict rows, reset regrets, alias histories, or silently condition the game on visited boards.

Minimum sequence before any scale claim:

1. Differentially check root `Z`, every 0/3/4/5-prefix mass, per-hand support, and child-mass conservation against an independent small-range physical-pair oracle.
2. On a finite card subgame, freeze a nonuniform profile and exactly enumerate the sampler distribution. Prove expected raw regret and average increments for both players, with blockers, unequal reaches, ties, early folds, all-ins, and a hidden-river counterexample.
3. Check seed replay, proposal support/weights, zero-visit policy completion, resource rejection, resume, and no legacy/native fallback.
4. Compare quality and total end-to-end work on predeclared small games and independent seeds. Preserve all misses.
5. Keep a full-deck exploitability claim blocked until a separately valid full-game best-response bound exists. The selected-board exact certificate and a finite sampled evaluation do not certify unrestricted full-deck exploitability.

