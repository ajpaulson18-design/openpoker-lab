"""Preserve one source-frozen streamed checkpoint study and its digest replay."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import struct
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
REPO = WORK/'dyadic-training-repo'
RESULTS = REPO/'benchmarks/results'
COHORT = WORK/'dys-ten-cohort1'
OPERATOR = WORK/'dys-ten-launch1'
DEST = RESULTS/'native-dyadic-sweep-stream-ten-card-accepted-v1'
BASE = RESULTS/'native-dyadic-paged-directory-ten-card-accepted-v1'
HEAD = '83d143d89a47528be36fe1f847e49d5568292a81'
BASE_PUBLICATION = 'a01e4d69e3dfe42cfbad719faecd5637d1b2557e'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def reconstructed_wire(numeric, images):
    digest = sha256()
    total = 0

    def consume(stream, size):
        nonlocal total
        remaining = size
        while remaining:
            block = stream.read(min(1<<20, remaining))
            require(block, 'wire reconstruction truncated')
            digest.update(block)
            remaining -= len(block)
        total += size

    with numeric.open('rb') as stream:
        consume(stream, 8+16*8+11*8+1105*96+119196*24)
        for sweep, image in enumerate(images, 1):
            consume(stream, 281066*8+4*12*8)
            header = struct.pack('<8sQQQ', b'OPLCPG01', sweep, sweep%2, image['bytes'])
            digest.update(header)
            total += len(header)
            with (COHORT/'page-images'/image['name']).open('rb') as checkpoint:
                consume(checkpoint, image['bytes'])
                require(not checkpoint.read(1), 'wire checkpoint trailing bytes')
        consume(stream, numeric.stat().st_size-stream.tell())
        require(not stream.read(1), 'wire numerical trailing bytes')
    return {'bytes': total, 'sha256': digest.hexdigest()}


def main():
    run = read(COHORT/'result.json')
    outer = read(OPERATOR/'completion.json')
    require(run['head'] == outer['head'] == HEAD and run['training_invocations']==1
            and outer['mode']=='train_ten_sweep_stream' and outer['raw_source_stable']
            and outer['actual_exit_observed'] and outer['returncode']==0 and not outer['failures']
            and read(COHORT/'terminal.json')['status']=='complete', 'source-frozen cohort incomplete')
    source = read(COHORT/'source.json')['files']
    hashes = {name: record['raw_sha256'] for name,record in source.items()}
    require(read(OPERATOR/'source-before.json') == read(OPERATOR/'source-after.json') == hashes,
            'source inventories differ')
    for path in (OPERATOR/'bootstrap.json', COHORT/'saved-review-bootstrap.json'):
        boot = read(path)
        require(all(hashes.get(name)==digest for name,digest in boot['compiled'].items())
                and not boot['initial_cache_scan']['project_bytecode_files']
                and not boot['final_cache_scan']['project_bytecode_files'], 'executed source closure differs')
    build_path = COHORT/'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(identity(Path(build['executable']))['sha256']==build['executable_sha256']
            and all(hashes[name]==digest for name,digest in build['source_sha256'].items()), 'native build differs')
    build_hash = identity(build_path)['sha256']
    for label in ('admit_ten_sweep_stream','train_ten_sweep_stream','saved-review'):
        receipt = read(COHORT/label/'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode']==0 and not receipt['failures']
                and receipt['automatic_retries']==0, 'child exit differs')
        if label!='saved-review':
            binary = read(COHORT/label/'binary-identity.json')
            require(binary['before_sha256']==binary['after_sha256']==build['executable_sha256']
                    and binary['build_manifest_sha256']==build_hash, 'observed native executable differs')
    trained = COHORT/'train_ten_sweep_stream'
    process = read(trained/'process.json')
    capture = run['sweep_capture']
    inputs = run['checkpoint_inputs']
    replay = run['saved_only_replay']
    require(identity(trained/'process.json')['sha256']==run['sweep_capture_process_sha256']
            and process['sweep_capture']==capture and identity(trained/'stdout.bin')==inputs['stream']
            and capture['retained_sha256']==inputs['stream']['sha256']==replay['saved_output_sha256']
            and replay['checkpoint_verification']=='independent_compact_digest'
            and replay['native_producer_calls']==0, 'digest replay binding differs')
    for item in (BASE/'manifest.json', BASE/'verification.zip'):
        require(identity(item)['sha256']==hashes[item.relative_to(REPO).as_posix()], 'baseline source differs')
    baseline = read(BASE/'manifest.json')
    prior = baseline['saved_only_replay']
    require(baseline['status']=='accepted_paged_directory_ten_card_training_and_replay'
            and identity(BASE/'verification.zip')['sha256']==baseline['archive']['sha256']
            and inputs==baseline['checkpoint_inputs'] and run['paging']==baseline['paging']
            and run['policy_spill']==baseline['policy_spill'] and run['row_directory']==baseline['row_directory']
            and all(replay[key]==prior[key] for key in ('sweeps','profile_and_br','shape','work_actual',
                'parent_work_actual','chance_actual','changed_current_rows','quality_gate','checkpoint_images')),
            'paged directory baseline parity differs')
    images = inputs['sweep_images']
    require(reconstructed_wire(trained/'stdout.bin',images)==
            {'bytes': capture['contract']['wire_bytes'], 'sha256': capture['wire_sha256']},
            'independent full wire reconstruction differs')
    for image in images:
        require(identity(COHORT/'page-images'/image['name'])=={key:image[key] for key in ('bytes','sha256')},
                'retained final slot identity differs')
    files = {}
    for label, directory in (('cohort',COHORT),('operator',OPERATOR)):
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(), 'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if label=='cohort' and (rel.parts[0]=='source' or
                    (rel.parts[0]=='build' and path.name!='native-exact-build-manifest.json') or
                    (rel.parts[0]=='page-images' and path.name in ('committed.bin','staged.bin'))):
                continue
            files[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__), WORK/'trusted-virtual-dyadic-training-launch-v18.py',
                 WORK/'dys-state-controls1.log', WORK/'dys-training-controls1.log', WORK/'dys-controls-opt1.log'):
        files[f'external/{path.name}'] = path
    inventory = {name:identity(path) for name,path in files.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST/'verification.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=6) as zipped:
        for name,path in files.items():
            zipped.write(path,name)
        zipped.writestr('inventory.json',json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'archive CRC differs')
        for name,expected in inventory.items():
            with zipped.open(name) as stream:
                require(zipped.getinfo(name).file_size==expected['bytes']
                        and file_digest(stream,'sha256').hexdigest()==expected['sha256'],'archive member differs')
    manifest = {'status':'accepted_streamed_sweep_checkpoint_digest_replay','source_head':HEAD,
                'baseline_publication':BASE_PUBLICATION,'operator':outer,
                'exact_numerical_stream_parity':True,'independent_wire_reconstruction':True,
                'focused_tests_per_mode':33,'packed_replay_images':baseline['packed_replay_images'],
                **{key:run[key] for key in ('admission','sweep_capture','sweep_capture_process_sha256','checkpoint_inputs',
                    'paging','row_directory','policy_spill','sweep_stream_comparison','saved_only_replay',
                    'training_invocations','quality_gate')},
                'archive':{'name':archive.name,**identity(archive),'members':len(inventory)+1}}
    (DEST/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':manifest['archive'],'observation':run['sweep_stream_comparison']['sweep_stream_native_observation'],
                      'wire':capture['wire_sha256']},sort_keys=True))


if __name__=='__main__':
    main()
