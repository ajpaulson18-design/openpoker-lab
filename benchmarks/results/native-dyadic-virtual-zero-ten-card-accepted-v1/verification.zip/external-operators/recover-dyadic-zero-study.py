"""Authenticate one retained producer and recover its failed comparison/replay stages."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
from zipfile import ZipFile


WORK = Path(__file__).resolve().parent
SOURCE = WORK / 'dyt2-zero-src1'
COHORT = WORK / 'dyt2-zero-cohort1'
OPERATOR = WORK / 'dyt2-zero-launch1'
OUT = WORK / 'dyt2-zero-recovery1'
HEAD = 'e0826e07289e778c263587ab5c37bf4f972aed1e'
BASE_HEAD = '69dc7b4c7b4cd3221fc85eef565b894db71ea0e9'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def main():
    helper = WORK / 'trusted-virtual-dyadic-training-launch-v13.py'
    tools = runpy.run_path(str(helper))
    git, snapshot, sha, observe, save = (tools[name] for name in ('git','snapshot','sha','observe','save'))
    original_exit = read(OPERATOR / 'exit.json')
    failure = read(COHORT / 'terminal.json')
    launch = read(OPERATOR / 'operator-launch.json')
    require(original_exit == {'actual_exit_observed': True, 'returncode': 1, 'failures': []}
            and failure['status'] == 'failed' and failure['receipt']['first_error'] == "KeyError: 'saved_replay'"
            and failure['receipt']['training_invocations_entered'] == 1
            and launch['head'] == HEAD and launch['mode'] == 'train_ten_virtual_zero'
            and launch['operator_sha256'] == sha(helper), 'unexpected original attempt')
    source = read(COHORT / 'source.json')
    hashes = {name: record['raw_sha256'] for name, record in source['files'].items()}
    require(source['head'] == read(COHORT / 'claim.json')['head'] == HEAD
            and git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == HEAD
            and snapshot(SOURCE) == hashes == read(OPERATOR / 'source-before.json'), 'original source inventory differs')
    boot_name = 'scripts/run_virtual_frozen_source_only.py'
    bootstrap = SOURCE / boot_name
    first_stage = launch['first_stage']
    require(sha(bootstrap) == hashes[boot_name] == launch['bootstrap_sha256']
            and hashlib.sha256(first_stage.encode()).hexdigest() == launch['first_stage_sha256']
            and bootstrap.read_bytes().replace(b'\r\n',b'\n') == git(SOURCE,'show',HEAD+':'+boot_name),
            'original trusted bootstrap identity differs')
    build_path = COHORT / 'build/native-exact-build-manifest.json'
    build = read(build_path)
    require(build['target'] == 'virtual-dyadic-training' and
            sha(Path(build['executable'])) == build['executable_sha256']
            and all(hashes[name] == digest == sha(COHORT / 'source' / name)
                    for name, digest in build['source_sha256'].items()), 'original native build differs')
    for label, mode in (('admit_ten_virtual_zero','ADMIT_TEN_VIRTUAL_ZERO'),
                        ('train_ten_virtual_zero','TRAIN_TEN_VIRTUAL_ZERO')):
        directory = COHORT / label
        process = read(directory / 'process.json')
        identity = read(directory / 'binary-identity.json')
        require(process['status'] == 'exited' and process['actual_exit_observed'] and process['returncode'] == 0
                and not process['failures'] and not process['automatic_retries']
                and identity['before_sha256'] == identity['after_sha256'] == build['executable_sha256']
                and identity['build_manifest_sha256'] == sha(build_path)
                and (directory / 'request.bin').read_bytes() == ('DYADIC_T2_V1 '+mode+'\n').encode()
                and sha(directory / 'request.bin') == process['request_sha256']
                and (directory / 'stderr.bin').stat().st_size == 0, 'original child process identity differs')
        for name, stream in zip(('stdout.bin','stderr.bin'),process['streams'],strict=True):
            path = directory / name
            require(path.stat().st_size == stream['saved_bytes'] == stream['observed_bytes']
                    and sha(path) == stream['sha256'], 'original child stream changed')
    admission = read(COHORT / 'admission.json')
    require(admission == read(COHORT / 'admit_ten_virtual_zero/stdout.bin'), 'original admission differs')
    inputs = read(COHORT / 'checkpoint-inputs.json')
    data = COHORT / 'train_ten_virtual_zero/stdout.bin'
    pages = COHORT / 'page-images'
    paging = read(pages / 'paging.json')
    require(inputs['stream'] == {'bytes':data.stat().st_size,'sha256':sha(data)}
            and [row['name'] for row in inputs['sweep_images']] == ['staged.bin','committed.bin']
            and all(row['bytes'] == (pages / row['name']).stat().st_size
                    and row['sha256'] == sha(pages / row['name']) for row in inputs['sweep_images']),
            'saved native checkpoint inputs differ')
    base_dir = 'benchmarks/results/native-dyadic-buffered-ten-card-accepted-v1'
    manifest = base_dir + '/manifest.json'
    accepted = (SOURCE / manifest).read_bytes()
    require(hashlib.sha256(accepted).hexdigest() == hashes[manifest]
            and accepted.replace(b'\r\n',b'\n') == git(SOURCE,'show',BASE_HEAD+':'+manifest),
            'published buffered baseline manifest differs')
    baseline = json.loads(accepted)
    old = baseline['saved_only_replay']
    old_paging = baseline['paging']['counts']
    archive = base_dir + '/evidence.zip'
    require(inputs['sweep_images'] == old['checkpoint_images']
            and sha(SOURCE / archive) == hashes[archive] == baseline['archive']['sha256']
            and all(paging[k] == old_paging[k] for k in ('read_calls','logical_read_words','stage_calls','completed_sweeps')),
            'buffered baseline identity or invariant differs')
    prefix_length = inputs['stream']['bytes'] - 520
    with ZipFile(SOURCE / archive) as evidence, evidence.open('cohort/train_ten_buffered/stdout.bin') as prior:
        baseline_data = prior.read(inputs['stream']['bytes'] + 1)
    require(len(baseline_data) == inputs['stream']['bytes']
            and hashlib.sha256(baseline_data).hexdigest() == old['saved_output_sha256']
            and baseline_data[-520:-512] == b'OPLDTP02','buffered baseline scaffold differs')
    with data.open('rb') as stream:
        require(stream.read(prefix_length) == baseline_data[:prefix_length], 'numerical scaffold differs')
    OUT.mkdir()
    save(OUT/'initial-inventory.json',{'head':HEAD,'hashes':hashes,'original_exit':original_exit,
        'original_terminal_sha256':sha(COHORT/'terminal.json')})
    trace_dir = OUT / 'trace'
    trace_dir.mkdir()
    trace_code = (
        'import json,sys; sys.path.insert(0,sys.argv[1]); '
        'from tests.virtual_dyadic_stage_schedule import stage_schedule; '
        'print(json.dumps(stage_schedule(ten_card=True,virtual_zero=True),sort_keys=True))'
    )
    trace_exit = observe([sys.executable,'-I','-S','-B','-c',trace_code,str(SOURCE)],SOURCE,trace_dir)
    trace = read(trace_dir/'stdout.log')
    expected = {'read_words':trace['physical_read_words'],'logical_read_words':trace['logical_read_words'],
        'write_words':trace['written_words'],'read_calls':trace['logical_read_calls'],
        'stage_calls':trace['sweeps']*trace['per_sweep_stage_calls'],'physical_read_requests':trace['cache_misses'],
        'physical_write_requests':trace['batched_write_calls'],'cache_hits':trace['cache_hits'],
        'cache_misses':trace['cache_misses'],'completed_sweeps':trace['sweeps'],
        'synthetic_read_calls':trace['virtual_read_calls'],'synthetic_read_words':trace['virtual_read_words']}
    require(paging == expected and not trace['initialization_calls'], 'independent trace differs')
    replay_dir = OUT / 'saved-review'
    replay_dir.mkdir()
    receipt_path = replay_dir / 'bootstrap.json'
    command = [sys.executable,'-I','-S','-B','-c',first_stage,str(bootstrap),hashes[boot_name],
               '--module','scripts.verify_virtual_dyadic_training','--receipt',str(receipt_path),'--',
               '--saved',str(data),'--sha256',inputs['stream']['sha256'],'--ten-card','--paired','--rank-sets',
               '--page-images',str(pages),'--sweep-image-sha256',*(row['sha256'] for row in inputs['sweep_images'])]
    replay_exit = observe(command,SOURCE,replay_dir)
    receipt = read(receipt_path)
    require(receipt['entry_module'] == 'scripts.verify_virtual_dyadic_training'
            and receipt['trusted_first_stage']['bootstrap_sha256'] == hashes[boot_name]
            and receipt['trusted_first_stage']['command_sha256'] == launch['first_stage_sha256']
            and not receipt['initial_cache_scan']['project_bytecode_files']
            and not receipt['final_cache_scan']['project_bytecode_files']
            and all(hashes[name] == digest for name,digest in receipt['compiled'].items()),
            'saved replay source binding differs')
    replay = read(replay_dir/'stdout.log')
    require(replay['status'] == 'saved_two_sweep_exact_replay_pass' and replay['native_producer_calls'] == 0
            and replay['saved_output_sha256'] == inputs['stream']['sha256']
            and replay['work_plan'] == admission['component_work'] and replay['parent_work_plan'] == admission['parent_work']
            and replay['planned_entries'] == admission['entries'] and replay['planned_payload_bits'] == admission['payload_bits']
            and all(replay[key] == old[key] for key in ('sweeps','shape','profile_and_br','chance_actual',
                'checkpoint_images','changed_current_rows','public_walks_per_sweep','quality_gate')),
            'saved exact replay differs')
    require(snapshot(SOURCE) == hashes and git(SOURCE,'rev-parse','HEAD').decode().strip() == HEAD
            and sha(data) == inputs['stream']['sha256']
            and all(sha(pages/row['name']) == row['sha256'] for row in inputs['sweep_images']),
            'source or retained checkpoint changed in recovery')
    comparison = {'baseline_source_head':baseline['source_head'],'baseline_stream_sha256':old['saved_output_sha256'],
        'numeric_bytes':prefix_length,'numeric_sha256':hashlib.sha256(baseline_data[:prefix_length]).hexdigest(),
        'exact_checkpoint_images':inputs['sweep_images'],'baseline_paging':old_paging,'virtual_zero_paging':paging,
        'baseline_native_observation':baseline['buffered_comparison']['buffered_native_observation'],
        'virtual_zero_native_observation':{k:process[k] for k in ('duration_seconds','memory')}}
    result = {'head':HEAD,'original_exit':original_exit,'original_terminal':failure,
        'training_invocations':1,'native_producer_calls_during_recovery':0,
        'trace_exit':trace_exit,'replay_exit':replay_exit,'compiled_sources':len(receipt['compiled']),
        'admission':admission,'checkpoint_inputs':inputs,'paging':{'counts':paging},
        'virtual_zero_comparison':comparison,'independent_stage_schedule':trace,
        'saved_only_replay':replay,'quality_gate':None,'raw_source_revalidated':True}
    save(OUT/'completion.json',result)
    print(json.dumps({'head':HEAD,'replay_status':replay['status'],'replay_exit':replay_exit,
        'training_invocations':1,'native_producer_calls_during_recovery':0,'raw_source_revalidated':True}))


if __name__ == '__main__':
    main()
