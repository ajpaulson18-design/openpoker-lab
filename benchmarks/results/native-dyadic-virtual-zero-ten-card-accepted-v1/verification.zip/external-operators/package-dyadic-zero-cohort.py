"""Retain the virtual-zero study and bind its unchanged images to published pages."""
from hashlib import file_digest
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


WORK = Path(__file__).resolve().parent
REPO = WORK / 'dyadic-training-repo'
RESULTS = REPO / 'benchmarks/results'
DEST = RESULTS / 'native-dyadic-virtual-zero-ten-card-accepted-v1'
COHORT = WORK / 'dyt2-zero-cohort1'
OPERATOR = WORK / 'dyt2-zero-launch1'
RECOVERY = WORK / 'dyt2-zero-recovery1'
HEAD = 'e0826e07289e778c263587ab5c37bf4f972aed1e'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': file_digest(stream, 'sha256').hexdigest()}


def main():
    result = read(RECOVERY / 'completion.json')
    outer = read(OPERATOR / 'exit.json')
    require(result['head'] == HEAD and result['training_invocations'] == 1
            and result['native_producer_calls_during_recovery'] == 0 and result['raw_source_revalidated']
            and outer == result['original_exit'] == {'actual_exit_observed': True, 'returncode': 1, 'failures': []}
            and read(COHORT / 'terminal.json') == result['original_terminal']
            and result['original_terminal']['status'] == 'failed'
            and result['replay_exit'] == {'actual_exit_observed': True, 'returncode': 0, 'failures': []},
            'original failure or saved-only recovery exit differs')
    source = read(COHORT / 'source.json')['files']
    source_hashes = {key: value['raw_sha256'] for key, value in source.items()}
    require(read(OPERATOR / 'source-before.json') == read(RECOVERY / 'initial-inventory.json')['hashes'] == source_hashes,
            'raw source inventories differ')
    receipt = read(RECOVERY / 'saved-review/bootstrap.json')
    require(all(source_hashes.get(name) == digest for name, digest in receipt['compiled'].items())
            and not receipt['initial_cache_scan']['project_bytecode_files']
            and not receipt['final_cache_scan']['project_bytecode_files'], 'source-only proof differs')
    for stage in ('admit_ten_virtual_zero', 'train_ten_virtual_zero'):
        receipt = read(COHORT / stage / 'process.json')
        require(receipt['actual_exit_observed'] and receipt['returncode'] == 0
                and not receipt['failures'] and receipt['automatic_retries'] == 0, 'child exit differs')
    build = read(COHORT / 'build/native-exact-build-manifest.json')
    require(identity(Path(build['executable']))['sha256'] == build['executable_sha256'], 'build binary differs')
    comparison = result['virtual_zero_comparison']
    replay = result['saved_only_replay']
    inputs = result['checkpoint_inputs']
    observed_stream = read(COHORT / 'train_ten_virtual_zero/process.json')['streams'][0]
    require(inputs == read(COHORT / 'checkpoint-inputs.json')
            and identity(COHORT / 'train_ten_virtual_zero/stdout.bin') == inputs['stream']
            and replay['saved_output_sha256'] == inputs['stream']['sha256'] == observed_stream['sha256']
            and replay['status'] == 'saved_two_sweep_exact_replay_pass' and replay['native_producer_calls'] == 0
            and replay['checkpoint_images'] == inputs['sweep_images'] == comparison['exact_checkpoint_images']
            and all(identity(COHORT / 'page-images' / row['name']) == {'bytes': row['bytes'], 'sha256': row['sha256']}
                    for row in inputs['sweep_images']), 'independent replay or retained identity differs')
    packed_dir = RESULTS / 'native-dyadic-packed-ten-card-accepted-v1'
    packed_manifest = packed_dir / 'manifest.json'
    packed_result = read(packed_manifest)
    records = packed_result['packet']['images']
    require(packed_result['status'] == 'saved_packed_ten_card_exact_replay_pass'
            and [row['raw'] for row in records] == inputs['sweep_images']
            and all(identity(packed_dir / row['packed']['name']) ==
                    {key: row['packed'][key] for key in ('bytes', 'sha256')} for row in records),
            'published packed image binding differs')
    paging = result['paging']['counts']
    require((paging['read_words'], paging['write_words'], paging['physical_read_requests'],
             paging['physical_write_requests']) == (6130244, 5925444, 1498, 18836),
            'observed I/O differs from virtual-zero trace')
    prior = comparison['baseline_paging']
    saved_bytes = 8 * sum(prior[key] - paging[key] for key in ('read_words', 'write_words'))

    included = {}
    for label, root in (('cohort', COHORT), ('operator', OPERATOR), ('recovery', RECOVERY)):
        for path in sorted(root.rglob('*')):
            require(not path.is_symlink(), 'linked evidence')
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if label == 'cohort' and (rel.parts[0] == 'source' or
                    (rel.parts[0] == 'build' and path.name != 'native-exact-build-manifest.json') or
                    (rel.parts[0] == 'page-images' and path.suffix == '.bin')):
                continue
            included[f'{label}/{rel.as_posix()}'] = path
    for path in (Path(__file__), WORK / 'trusted-virtual-dyadic-training-launch-v13.py',
                 WORK / 'recover-dyadic-zero-study.py'):
        included[f'external-operators/{path.name}'] = path
    inventory = {key: identity(path) for key, path in included.items()}
    DEST.mkdir(exist_ok=False)
    archive = DEST / 'verification.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=6) as saved:
        for key, path in included.items():
            saved.write(path, key)
        saved.writestr('inventory.json', json.dumps(inventory, sort_keys=True, indent=2) + '\n')
    with ZipFile(archive) as saved:
        require(saved.testzip() is None, 'verification archive CRC differs')
        for key, expected in inventory.items():
            with saved.open(key) as item:
                require(saved.getinfo(key).file_size == expected['bytes']
                        and file_digest(item, 'sha256').hexdigest() == expected['sha256'], 'verification archive drift')
    manifest = {'status': 'accepted_recovered_virtual_zero_ten_card_training_and_replay',
                'source_head': HEAD, 'original_operator_exit': outer,
                'original_terminal': result['original_terminal'],
                'saved_only_recovery': {key:result[key] for key in ('trace_exit','replay_exit','compiled_sources',
                    'native_producer_calls_during_recovery','raw_source_revalidated')},
                **{key: result[key] for key in ('admission', 'checkpoint_inputs', 'paging', 'virtual_zero_comparison',
                    'independent_stage_schedule', 'saved_only_replay', 'training_invocations', 'quality_gate')},
                'file_stream_bytes_saved': saved_bytes,
                'packed_replay_images': {'publication': 'e1010bf51d52cc4b621004f7e64a8b02fb2924ee',
                    'manifest': packed_manifest.relative_to(REPO).as_posix(), 'images': records},
                'archive': {'name': archive.name, **identity(archive), 'members': len(inventory) + 1},
                'archive_scope': 'Observed processes and numerical scaffold. Build and source hashes pin the committed '
                                 'source. Identical sweep images can be replayed from the referenced packed publication.'}
    (DEST / 'manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'archive': manifest['archive'], 'file_stream_bytes_saved': saved_bytes,
                      'observation': comparison['virtual_zero_native_observation']}, sort_keys=True))


if __name__ == '__main__':
    main()
