@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Users\pauls\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m scripts.build_native_exact_four_street --target kernel --output-dir "C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\native-exact-kernel-development-build"
exit /b %errorlevel%
