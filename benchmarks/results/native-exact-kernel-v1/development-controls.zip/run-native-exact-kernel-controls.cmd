@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
set "OPENPOKER_NATIVE_EXACT_SELECTED_VECTORS_EXE=C:\Users\pauls\Documents\Codex\2026-10-26\files-pasted-by-the-user-i\work\native-exact-kernel-development-build\native-exact-selected-vectors.exe"
"C:\Users\pauls\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -O -m unittest tests.test_native_exact_selected_vectors -v
exit /b %errorlevel%
