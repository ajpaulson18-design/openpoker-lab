import importlib.util, os, sys, unittest, random, math
from pathlib import Path
repo = Path(sys.argv[1]).resolve()
os.environ['OPENPOKER_NATIVE_EXACT_SELECTED_VECTORS_EXE'] = str(Path(sys.argv[2]).resolve())
sys.path.insert(0, str(repo))
spec = importlib.util.spec_from_file_location('native_vector_controls', repo / 'tests/test_native_exact_selected_vectors.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class IndependentControls(m.NativeExactSelectedVectorTests):
    def test_invalid_reaches_payoffs_indexes(self):
        hands = ([(m.cards('AsAh'), 1.)], [(m.cards('KsKh'), 1.)])
        boards = [m.board('2c3d4h7s8c')]
        for value in (-0.01, 1.000001, math.inf, -math.inf, math.nan):
            with self.subTest(reach=value):
                self.invoke(m.wire(hands, boards, [('D',0,(0,),1.,(value,))]),success=False)
        for value in (-1., math.inf, -math.inf, math.nan):
            with self.subTest(payoff=value):
                self.invoke(m.wire(hands, boards, [('D',0,(0,),value,(1.,))]),success=False)
        self.invoke(m.wire(hands, boards, [('M',0,(1,),0.,())]),success=False)

    def test_zero_payoff_zero_reach_and_ties(self):
        hands = ([(m.cards('2c3c'),1.),(m.cards('2d3d'),.5)], [(m.cards('2c3c'),.3),(m.cards('4d5d'),.7)])
        boards = [m.board('AcKcQcJcTc')]
        queries = [('S',0,(0,),0,()),('M',0,(),0,())]
        for p in (0,1):
            for kind in ('F','D'):
                queries.extend([(kind,p,(0,),0.,(1.,.5)),(kind,p,(0,),2.,(0.,0.))])
        counts = self.compare(hands,boards,queries)
        self.assertEqual(counts[4],0)

    def test_adversarial_seeded_physical(self):
        rng = random.Random(294091)
        for case in range(64):
            cards = rng.sample(m.DECK, 15)
            # Include identical hands across seats, overlapping blockers, and varied fractional weights.
            hands = ([(tuple(cards[0:2]),.125),(tuple(cards[2:4]),.75),(tuple(cards[4:6]),1.)],
                     [(tuple(cards[0:2]),.5),(tuple(cards[6:8]),.25),(tuple(cards[8:10]),.875)])
            boards = [tuple(sorted(cards[10:13],key=m.DECK.index))+tuple(cards[13:15])]
            queries = [(kind,0,(0,),0,()) for kind in ('M','S')]
            queries += [(kind,p,(0,),-1.25 if kind=='F' else 1.25,(0.,.375,1.)) for p in (0,1) for kind in ('F','D')]
            with self.subTest(case=case): self.compare(hands,boards,queries)

if __name__ == '__main__':
    unittest.main(argv=[sys.argv[0]], verbosity=2)
