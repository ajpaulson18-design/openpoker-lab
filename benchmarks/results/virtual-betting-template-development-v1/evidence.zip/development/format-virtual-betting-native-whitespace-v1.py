"""Apply only clang-format whitespace replacements; preserve original sources."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
REPO = WORK / 'virtual-betting-template-repo'
OUTPUT = WORK / 'virtual-betting-native-format-v1'
FORMATTER = Path(r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\Llvm\bin\clang-format.exe')
STYLE = ('{BasedOnStyle: LLVM, IndentWidth: 4, ColumnLimit: 100, '
         'SortIncludes: Never, BreakStringLiterals: false, ReflowComments: false, '
         'FixNamespaceComments: false}')
FILES = ('native/virtual_betting_template.hpp', 'native/virtual_betting_template_probe.cpp',
         'tests/native/virtual_betting_template_controls.cpp')


def main():
    OUTPUT.mkdir(exist_ok=False)
    receipt = {'formatter': str(FORMATTER), 'style': STYLE, 'files': {}}
    for name in FILES:
        path = REPO / name
        original = path.read_bytes()
        original.decode('ascii')
        preserved = OUTPUT / name
        preserved.parent.mkdir(parents=True, exist_ok=True)
        preserved.write_bytes(original)
        result = subprocess.run([str(FORMATTER), '--style=' + STYLE,
                                 '--output-replacements-xml', str(path)], check=True, capture_output=True)
        (preserved.parent / (preserved.name + '.replacements.xml')).write_bytes(result.stdout)
        root = ET.fromstring(result.stdout)
        if root.attrib.get('incomplete_format') != 'false':
            raise RuntimeError('Incomplete format')
        replacements = []
        for replacement in root.findall('replacement'):
            offset, length = int(replacement.attrib['offset']), int(replacement.attrib['length'])
            text = (replacement.text or '').encode('ascii')
            if original[offset:offset + length].strip() or text.strip():
                raise RuntimeError('Refusing a replacement that changes non-whitespace: ' + name)
            replacements.append((offset, length, text))
        final = original
        for offset, length, text in reversed(replacements):
            final = final[:offset] + text + final[offset + length:]
        if path.read_bytes() != original:
            raise RuntimeError('Source changed while formatting')
        path.write_bytes(final)
        receipt['files'][name] = {'before_sha256': hashlib.sha256(original).hexdigest(),
                                  'after_sha256': hashlib.sha256(final).hexdigest(),
                                  'whitespace_replacements': len(replacements)}
    (OUTPUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
