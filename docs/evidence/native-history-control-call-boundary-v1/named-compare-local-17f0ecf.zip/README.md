# Fixed-signature history control candidate

This archive contains committed source, the local MSVC build receipt and executable, and both existing native control observations. The normal and optimized runs each exited 0 with empty stderr, no retries, and stdout byte-identical to the retained baseline captures. The candidate restores the pre-experiment source and changes only the generic recursive `compare` fixture into a named fixed-signature helper. Local MSVC 19.44 success does not establish MSVC 14.52 behavior or prove the failure cause.
