# Native history control call-boundary evidence

This package preserves the baseline and test-only recursive-call mitigation source, local MSVC builds, the first corrected-build failure, four normal/optimized test observations, and three original CI failure archives. `manifest.json` hashes each payload file.

The four native outputs are byte-identical and all process runs exited 0. The compiler was MSVC 19.44.35229; these results do not establish the MSVC 14.52 CI outcome. The comment describes the optimizer-expansion mitigation as a hypothesis because the cause of the observed 0xc00000fd exit is unproven.
